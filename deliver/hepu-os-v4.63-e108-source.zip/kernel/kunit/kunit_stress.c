/* ============================================================================
 * 赫普OS - 压力测试套件 (E-43)
 * 覆盖: 高频内存分配 / 释放安全 / CPU 亲和性 API / 堆碎片统计 /
 *       切换计数器 / 锁往返 —— 供 shell `ktest` 一键回归
 * ========================================================================== */

#include <stdint.h>
#include "kunit.h"
#include "vga.h"
#include "string.h"
#include "smp.h"   /* spinlock_t / SPINLOCK_INIT */

/* === 高频混合大小 kmalloc/kfree 压力 (触发 slab + 堆双路径) === */
static kunit_result_t test_kmalloc_stress(void)
{
    void *ptrs[64];
    for (int round = 0; round < 8; round++) {
        for (int i = 0; i < 64; i++) {
            uint32_t size = 8 + ((i * 131) % 8192);   /* 8B ~ 8KB 混合 */
            ptrs[i] = kmalloc(size);
            if (!ptrs[i]) {
                vga_printf("[KUNIT] stress: kmalloc(%u) fail at round %d i=%d\n",
                           size, round, i);
                for (int j = 0; j < i; j++) kfree(ptrs[j]);
                return KUNIT_FAIL;
            }
            /* 写一遍, 验分配区可写 */
            ((uint8_t *)ptrs[i])[0] = (uint8_t)i;
            ((uint8_t *)ptrs[i])[size - 1] = (uint8_t)~i;
        }
        for (int i = 0; i < 64; i++) kfree(ptrs[i]);
    }
    return KUNIT_PASS;
}

/* === kfree(NULL) / 双释放防护: 安全返回不崩溃 === */
static kunit_result_t test_kfree_null_safe(void)
{
    kfree(NULL);
    void *p = kmalloc(256);
    KUNIT_ASSERT_NOT_NULL(p, " 256B alloc ");
    kfree(p);
    kfree(p);   /* 双释放应被 kheap magic/used 校验拦截, 不崩溃 */
    return KUNIT_PASS;
}

/* === E-42 CPU 亲和性 API 校验 === */
static kunit_result_t test_affinity_api(void)
{
    extern int sched_set_affinity(uint32_t, uint32_t);
    /* mask=0 拒绝 */
    KUNIT_ASSERT_EQ(sched_set_affinity(1, 0), -1, " mask=0 reject ");
    /* 不存在的 pid 拒绝 */
    KUNIT_ASSERT_EQ(sched_set_affinity(9999, 1), -1, " bad pid reject ");
    /* 有效设置成功(与在线 CPU0 有交集) */
    KUNIT_ASSERT_EQ(sched_set_affinity(1, 1), 0, " pid1->cpu0 ok ");
    KUNIT_ASSERT_EQ(sched_set_affinity(1, 0x3), 0, " pid1->cpu0+1 ok ");
    KUNIT_ASSERT_EQ(sched_set_affinity(1, 1), 0, " pid1->cpu0 restore ");
    return KUNIT_PASS;
}

/* === 堆碎片统计可调用 + 空闲块至少 1 === */
static kunit_result_t test_frag_stats_callable(void)
{
    extern void kheap_frag_stats(uint32_t *, uint32_t *, uint32_t *);
    uint32_t fb = 0, lf = 0, fr = 0;
    kheap_frag_stats(&fb, &lf, &fr);
    KUNIT_ASSERT(fb >= 1, " free_blocks>=1 ");
    KUNIT_ASSERT(fr <= 100, " frag_rate<=100% ");
    return KUNIT_PASS;
}

/* === 切换计数器单调 === */
static kunit_result_t test_switch_counter(void)
{
    extern uint32_t sched_switch_count(void);
    uint32_t c1 = sched_switch_count();
    KUNIT_ASSERT(c1 >= 0, " counter non-negative ");
    return KUNIT_PASS;
}

/* === 锁往返: 普通/irqsave 自旋锁 500 次往返 === */
static kunit_result_t test_lock_roundtrip(void)
{
    extern void spin_lock(spinlock_t *);
    extern void spin_unlock(spinlock_t *);
    extern void spin_lock_irqsave(spinlock_t *, uint32_t *);
    extern void spin_unlock_irqrestore(spinlock_t *, uint32_t);
    static spinlock_t lt = SPINLOCK_INIT;
    for (int i = 0; i < 500; i++) {
        spin_lock(&lt);
        spin_unlock(&lt);
        uint32_t fl;
        spin_lock_irqsave(&lt, &fl);
        spin_unlock_irqrestore(&lt, fl);
    }
    return KUNIT_PASS;
}

/* === 套件定义 === */
static const kunit_test_t stress_tests[] = {
    { "kmalloc_stress",  test_kmalloc_stress,     "stress" },
    { "kfree_null_safe", test_kfree_null_safe,    "stress" },
    { "affinity_api",    test_affinity_api,       "stress" },
    { "frag_stats_call", test_frag_stats_callable,"stress" },
    { "switch_counter",  test_switch_counter,     "stress" },
    { "lock_roundtrip",  test_lock_roundtrip,     "stress" },
};

const kunit_suite_t kunit_stress_suite = {
    "stress",
    stress_tests,
    sizeof(stress_tests) / sizeof(stress_tests[0])
};

void kunit_stress_register(void)
{
    extern void kunit_register_suite(const kunit_suite_t *);
    kunit_register_suite(&kunit_stress_suite);
    vga_puts("[KUNIT] stress suite registered\n");
}
