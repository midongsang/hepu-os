/* ============================================================================
 * 赫普OS - binfmt 格式注册框架 (多格式软件兼容层 L0)
 * 通过文件魔数识别可执行格式并分发给对应加载器.
 * V3.87: 支持 Linux ELF32; 预留 Windows PE / Apple Mach-O 槽位.
 * ========================================================================== */

#ifndef HEPU_BINFMT_H
#define HEPU_BINFMT_H

#include <stdint.h>

/* 加载结果 */
#define BINFMT_OK           0
#define BINFMT_ERR_FORMAT   (-1)   /* 魔数/结构不匹配 */
#define BINFMT_ERR_UNSUP    (-2)   /* 格式支持但特性不支持(如动态链接) */
#define BINFMT_ERR_MEM      (-3)   /* 内存不足 */
#define BINFMT_ERR_IO       (-4)   /* 读取失败 */

/* 格式标识 */
#define BINFMT_ID_UNKNOWN   0
#define BINFMT_ID_ELF32     1       /* Linux/ELF32 */
#define BINFMT_ID_PE32      2       /* Windows PE (V3.89) */
#define BINFMT_ID_MACHO     3       /* Apple Mach-O (远期) */
#define BINFMT_ID_HEPU_HUG  4       /* 自研 .hug */

/* 格式注册项 */
typedef struct {
    uint32_t    id;
    const char *name;
    uint32_t    magic_len;
    const uint8_t *magic;
    /* 识别函数: 返回 1 匹配 */
    int (*probe)(const uint8_t *buf, uint32_t len);
    /* 加载函数: 从 initrd/VFS 加载并执行 */
    int (*load)(const char *path, const uint8_t *data, uint32_t size);
} binfmt_t;

/* 注册格式 (内部调用) */
int binfmt_register(const binfmt_t *fmt);

/* 识别格式: 返回格式ID */
uint32_t binfmt_probe(const uint8_t *buf, uint32_t len);

/* 按路径加载执行 (Shell `run` / execve 分发入口) */
int binfmt_exec(const char *path, const uint8_t *data, uint32_t size);

/* V3.87 B-3: 设置/读取当前进程命令行 (shell `run` 真实传参).
 * cmdline 为完整命令串 "prog arg1 arg2", 加载器分词注入 argv 区. */
void binfmt_set_cmdline(const char *cmdline);
const char *binfmt_get_cmdline(void);

/* 初始化: 注册内置格式 */
void binfmt_init(void);

/* 兼容层自检 */
void binfmt_selftest(void);

#endif /* HEPU_BINFMT_H */
