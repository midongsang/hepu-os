#ifndef SWAP_H
#define SWAP_H

#include <stdint.h>

/* 初始化swap子系统 */
void swap_init(void);

/* 启用/禁用swap */
int swap_set_enabled(uint8_t enable);

/* 换出一页到swap（返回槽号，-1失败） */
int swap_out(uint32_t phys_addr);

/* 从swap换入一页（返回新物理地址，0失败） */
uint32_t swap_in(int slot);

/* 检查swap是否可用 */
int swap_is_enabled(void);

/* 统计 */
void swap_stats(uint32_t *total_slots, uint32_t *used_slots,
                uint32_t *swap_in, uint32_t *swap_out);

/* 内存压力触发换出 */
int swap_swapout_until(uint32_t target_free_pages);

#endif
