#ifndef AES_H
#define AES_H

#include <stdint.h>

#define AES_BLOCK_SIZE 16
#define AES_KEY_SIZE_128 16
#define AES_KEY_SIZE_192 24
#define AES_KEY_SIZE_256 32
#define AES_MAX_ROUNDS 14
#define AES_MAX_EXP_KEY_SIZE 240

/* AES上下文 */
typedef struct {
    uint32_t round_key[AES_MAX_EXP_KEY_SIZE / 4];
    int rounds;
    int key_size;
} aes_ctx_t;

void aes_init(void);
int aes_set_key(aes_ctx_t *ctx, const uint8_t *key, int key_size);
int aes_encrypt_block(const aes_ctx_t *ctx, const uint8_t input[16], uint8_t output[16]);
int aes_decrypt_block(const aes_ctx_t *ctx, const uint8_t input[16], uint8_t output[16]);
int aes_encrypt_cbc(const aes_ctx_t *ctx, const uint8_t *iv,
                    const uint8_t *input, uint8_t *output, uint32_t length);
int aes_decrypt_cbc(const aes_ctx_t *ctx, const uint8_t *iv,
                    const uint8_t *input, uint8_t *output, uint32_t length);

#endif /* AES_H */
