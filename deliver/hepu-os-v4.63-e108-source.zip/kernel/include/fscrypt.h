#ifndef FSCRYPT_H
#define FSCRYPT_H

#include <stdint.h>

#define FSCRYPT_MAGIC 0x46534352  /* "FSCR" */
#define FSCRYPT_KEY_LEN 32        /* AES-256密钥长度 */
#define FSCRYPT_BLOCK_SIZE 16     /* AES块大小 */
#define FSCRYPT_MAX_FILES 256

typedef enum {
    FSCRYPT_ALG_XOR = 0,    /* 简化XOR加密 */
    FSCRYPT_ALG_AES_128,    /* AES-128 */
    FSCRYPT_ALG_AES_256,    /* AES-256 */
} fscrypt_alg_t;

typedef struct {
    uint32_t magic;
    uint8_t  algorithm;
    uint8_t  key[FSCRYPT_KEY_LEN];
    uint32_t inode_num;
    int      encrypted;
} fscrypt_context_t;

void fscrypt_init(void);
int fscrypt_set_key(const uint8_t *key, uint32_t len);
int fscrypt_encrypt(uint32_t inode, uint8_t *data, uint32_t len);
int fscrypt_decrypt(uint32_t inode, uint8_t *data, uint32_t len);
int fscrypt_enable(uint32_t inode, fscrypt_alg_t alg);
int fscrypt_disable(uint32_t inode);
int fscrypt_is_encrypted(uint32_t inode);
int fscrypt_status(uint32_t *encrypted_files, uint32_t *total);

#endif /* FSCRYPT_H */
