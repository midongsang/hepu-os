#ifndef MM_H
#define MM_H

#include <stdint.h>

#define PAGE_SIZE 4096

/* 内存区域类型 */
#define MEM_REGION_USABLE    0
#define MEM_REGION_RESERVED  1
#define MEM_REGION_KERNEL    2
#define MEM_REGION_MMIO      3

/* 初始化内存管理 */
void     mm_init(uint32_t mem_kb, uint32_t bitmap_addr);

/* 单页分配/释放 */
uint32_t mm_alloc_page(void);
void     mm_free_page(uint32_t phys_addr);

/* 多页连续分配/释放 */
uint32_t mm_alloc_pages(uint32_t count);
void     mm_free_pages(uint32_t phys_addr, uint32_t count);

/* 在指定地址分配 */
int      mm_alloc_page_at(uint32_t phys_addr);

/* 保留页 */
int      mm_reserve_page(uint32_t phys_addr);

/* 内存区域管理 */
int      mm_add_region(uint32_t start_addr, uint32_t size, uint8_t type);
void     mm_dump_regions(void);

/* 统计 */
void     mm_stats(uint32_t *total, uint32_t *used, uint32_t *free);
uint32_t mm_free_bytes(void);

#endif
