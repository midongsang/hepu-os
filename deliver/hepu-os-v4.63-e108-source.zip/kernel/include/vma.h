#ifndef VMA_H
#define VMA_H

#include <stdint.h>

#define PAGE_SIZE 4096

/* VMA访问标志 */
#define VMA_READ    0x1
#define VMA_WRITE   0x2
#define VMA_EXEC    0x4
#define VMA_SHARED  0x8

/* 前向声明 */
typedef struct vm_address_space vm_address_space_t;
typedef struct vma_area vma_area_t;

/* 创建/销毁地址空间 */
vm_address_space_t *vma_create_space(void);
void                vma_destroy_space(vm_address_space_t *space);

/* 映射/取消映射 */
int  vma_map(vm_address_space_t *space, uint32_t start, uint32_t length, uint32_t flags);
int  vma_unmap(vm_address_space_t *space, uint32_t start, uint32_t length);

/* 查找/检查 */
vma_area_t *vma_find(vm_address_space_t *space, uint32_t addr);
int         vma_check_access(vm_address_space_t *space, uint32_t addr, uint32_t access_flags);

/* 统计/调试 */
void vma_stats(vm_address_space_t *space, uint32_t *areas, uint32_t *pages, uint32_t *bytes);
void vma_dump(vm_address_space_t *space);

#endif
