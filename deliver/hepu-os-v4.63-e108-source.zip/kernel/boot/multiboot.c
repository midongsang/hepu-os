/* ============================================================================
 * 赫普OS - Multiboot信息解析 (V0.99新增)
 * 实现：完整解析Multiboot信息结构，内存映射、命令行、启动模块、帧缓冲
 * ========================================================================== */
#include <stdint.h>
#include <stddef.h>
#include "multiboot.h"
#include "vga.h"
#include "string.h"

/* Multiboot信息结构（标准定义） */
typedef struct {
    uint32_t flags;
    uint32_t mem_lower;
    uint32_t mem_upper;
    uint32_t boot_device;
    uint32_t cmdline;
    uint32_t mods_count;
    uint32_t mods_addr;
    uint32_t syms[4];
    uint32_t mmap_length;
    uint32_t mmap_addr;
    uint32_t drives_length;
    uint32_t drives_addr;
    uint32_t config_table;
    uint32_t boot_loader_name;
    uint32_t apm_table;
    uint32_t vbe_control_info;
    uint32_t vbe_mode_info;
    uint16_t vbe_mode;
    uint16_t vbe_interface_seg;
    uint16_t vbe_interface_off;
    uint16_t vbe_interface_len;
    uint64_t framebuffer_addr;
    uint32_t framebuffer_pitch;
    uint32_t framebuffer_width;
    uint32_t framebuffer_height;
    uint8_t  framebuffer_bpp;
    uint8_t  framebuffer_type;
    uint8_t  color_info[6];
} __attribute__((packed)) multiboot_info_t;

/* 内存映射条目 */
typedef struct {
    uint32_t size;
    uint64_t base_addr;
    uint64_t length;
    uint32_t type;
} __attribute__((packed)) multiboot_mmap_entry_t;

/* 启动模块 */
typedef struct {
    uint32_t mod_start;
    uint32_t mod_end;
    uint32_t cmdline;
    uint32_t pad;
} multiboot_module_t;

static multiboot_info_t *mb_info = NULL;
static uint32_t mb_magic = 0;

/* 内存映射缓存 */
#define MB_MMAP_MAX 16
static mb_memory_region_t mb_mmap[MB_MMAP_MAX];
static uint32_t mb_mmap_count = 0;

/* 初始化Multiboot解析 */
void multiboot_init(uint32_t magic, void *info)
{
    mb_magic = magic;
    mb_info = (multiboot_info_t *)info;
    mb_mmap_count = 0;

    vga_printf("[MB] Multiboot magic: 0x%x %s\n", magic,
               (magic == 0x2BADB002) ? "(has 效)" : "(invalid !)");

    if (!mb_info) {
        vga_puts("[MB] no Multiboot info structure \n");
        return;
    }

    /* 解析内存映射 */
    if (mb_info->flags & (1 << 6)) {
        multiboot_mmap_entry_t *mmap = (multiboot_mmap_entry_t *)mb_info->mmap_addr;
        uint32_t length = mb_info->mmap_length;
        uint32_t offset = 0;

        while (offset < length && mb_mmap_count < MB_MMAP_MAX) {
            mb_mmap[mb_mmap_count].base = (uint32_t)mmap->base_addr;
            mb_mmap[mb_mmap_count].length = (uint32_t)mmap->length;
            mb_mmap[mb_mmap_count].type = mmap->type;
            mb_mmap_count++;

            const char *type_name = "reserved";
            if (mmap->type == 1) type_name = "usable";
            else if (mmap->type == 2) type_name = "reserved";
            else if (mmap->type == 3) type_name = "ACPI";
            else if (mmap->type == 4) type_name = "NVS";

            vga_printf("[MB] mem region: 0x%x-0x%x(%dKB) %s\n",
                       (uint32_t)mmap->base_addr,
                       (uint32_t)(mmap->base_addr + mmap->length),
                       (uint32_t)(mmap->length / 1024), type_name);

            offset += mmap->size + 4;
            mmap = (multiboot_mmap_entry_t *)((uint8_t *)mmap + mmap->size + 4);
        }
    }

    /* V2.40: 解析 VBE framebuffer 信息 (flags bit 12) */
    if (mb_info->flags & (1 << 12)) {
        vga_printf("[MB] VBE framebuffer: %dx%d bpp=%d pitch=%d type=%d fb=0x%llx\n",
                   mb_info->framebuffer_width, mb_info->framebuffer_height,
                   mb_info->framebuffer_bpp, mb_info->framebuffer_pitch,
                   mb_info->framebuffer_type,
                   (unsigned long long)mb_info->framebuffer_addr);
        /* 只支持 8bpp 索引色模式 (与当前调色板渲染兼容) */
        if (mb_info->framebuffer_bpp == 8 && mb_info->framebuffer_type == 0) {
            extern void gfx_set_vbe_info(int, int, uint8_t*, int, int);
            gfx_set_vbe_info(
                (int)mb_info->framebuffer_width,
                (int)mb_info->framebuffer_height,
                (uint8_t *)(uint32_t)mb_info->framebuffer_addr,
                (int)mb_info->framebuffer_pitch,
                (int)mb_info->framebuffer_bpp);
            vga_puts("[MB] VBE LFB enabled (8bpp)\n");
        } else {
            vga_printf("[MB] VBE mode unsupported (bpp=%d type=%d), fallback VGA\n",
                       mb_info->framebuffer_bpp, mb_info->framebuffer_type);
        }
    }

    /* 解析命令行 */
    if (mb_info->flags & (1 << 2)) {
        char *cmdline = (char *)mb_info->cmdline;
        if (cmdline && cmdline[0]) {
            vga_printf("[MB] cmdline: %s\n", cmdline);
        }
    }

    /* 解析启动模块 */
    if (mb_info->flags & (1 << 3)) {
        vga_printf("[MB] boot modules: %d \n", mb_info->mods_count);
        multiboot_module_t *mods = (multiboot_module_t *)mb_info->mods_addr;
        for (uint32_t i = 0; i < mb_info->mods_count; i++) {
            vga_printf("[MB] module [%d]: 0x%x-0x%x\n", i,
                       mods[i].mod_start, mods[i].mod_end);
        }
    }

    /* 帧缓冲信息 */
    if (mb_info->flags & (1 << 12)) {
        vga_printf("[MB] framebuffer: %dx%d %dbpp pitch=%d\n",
                   mb_info->framebuffer_width,
                   mb_info->framebuffer_height,
                   mb_info->framebuffer_bpp,
                   mb_info->framebuffer_pitch);
    }

    /* 引导加载器名称 */
    if (mb_info->flags & (1 << 9)) {
        char *loader = (char *)mb_info->boot_loader_name;
        if (loader) vga_printf("[MB] bootloader: %s\n", loader);
    }
}

/* 获取总内存（KB） */
uint32_t multiboot_get_memory_kb(void)
{
    if (!mb_info) return 0;
    if (mb_info->flags & (1 << 0)) {
        return mb_info->mem_lower + mb_info->mem_upper;
    }
    /* 从内存映射计算 */
    uint32_t total = 0;
    for (uint32_t i = 0; i < mb_mmap_count; i++) {
        if (mb_mmap[i].type == 1) {  /* 可用内存 */
            total += mb_mmap[i].length / 1024;
        }
    }
    return total;
}

/* 获取内存映射 */
uint32_t multiboot_get_mmap(mb_memory_region_t **regions)
{
    if (regions) *regions = mb_mmap;
    return mb_mmap_count;
}

/* 获取命令行 */
const char *multiboot_get_cmdline(void)
{
    if (!mb_info || !(mb_info->flags & (1 << 2))) return NULL;
    return (const char *)mb_info->cmdline;
}

/* 检查命令行参数是否存在 */
int multiboot_has_param(const char *key)
{
    const char *cmdline = multiboot_get_cmdline();
    if (!cmdline || !key) return 0;
    return (strstr(cmdline, key) != NULL);
}

/* 获取启动模块数量 */
uint32_t multiboot_get_module_count(void)
{
    if (!mb_info || !(mb_info->flags & (1 << 3))) return 0;
    return mb_info->mods_count;
}

/* 获取启动模块信息 */
int multiboot_get_module(uint32_t index, uint32_t *start, uint32_t *end)
{
    if (!mb_info || !(mb_info->flags & (1 << 3))) return -1;
    if (index >= mb_info->mods_count) return -1;
    multiboot_module_t *mods = (multiboot_module_t *)mb_info->mods_addr;
    if (start) *start = mods[index].mod_start;
    if (end) *end = mods[index].mod_end;
    return 0;
}

/* 获取帧缓冲信息 */
int multiboot_get_framebuffer(mb_framebuffer_t *fb)
{
    if (!mb_info || !(mb_info->flags & (1 << 12)) || !fb) return -1;
    fb->addr = (uint32_t)mb_info->framebuffer_addr;
    fb->width = mb_info->framebuffer_width;
    fb->height = mb_info->framebuffer_height;
    fb->pitch = mb_info->framebuffer_pitch;
    fb->bpp = mb_info->framebuffer_bpp;
    fb->type = mb_info->framebuffer_type;
    return 0;
}
