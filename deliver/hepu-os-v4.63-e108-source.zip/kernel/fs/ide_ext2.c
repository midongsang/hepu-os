/* ============================================================================
 * 赫普OS - IDE磁盘 ext2 文件系统挂载 (V3.87-D6 按需读写架构)
 * 设计: superblock+GDT 常驻 sb_area(32KB, 覆盖块0-31);
 *       位图/inode表/间接表/数据块 经 4x4KB 块缓存 按需 IDE 直读直写。
 * 数据盘容量上限: IDE 28位LBA 硬件上限 128GB (此前架构上限 128MB 已突破)。
 * ========================================================================== */
#include <stdint.h>
#include <string.h>
#include "ide.h"
#include "ext2.h"
#include "i18n.h"
#include "ide_ext2.h"
#include "kheap.h"
#include "vga.h"
#include "serial.h"

static uint8_t sb_area[32768];          /* superblock+GDT 常驻区 (块0-31) */
static int fs_mounted = 0;
/* V3.80: 数据区定位 (MBR 0x83 分区或整盘) */
static uint32_t data_lba = 0;
static uint32_t data_sectors = 0;

/* V3.87-D6: 块缓存 4x4KB (位图/inode表/间接表/数据块共用) */
static uint8_t  cache_blk[4][4096];
static uint32_t cache_num[4] = {0xFFFFFFFFu, 0xFFFFFFFFu, 0xFFFFFFFFu, 0xFFFFFFFFu};
static int      cache_dirty[4] = {0, 0, 0, 0};
static uint32_t cache_bs = 1024;

/* 读IDE磁盘指定扇区区间到内存 (逐扇区, QEMU PIO 稳定) */
static int ide_read_range(uint8_t *mem, uint32_t lba0, uint32_t total)
{
    uint32_t lba = 0;
    while (lba < total) {
        if (ide_read_sectors(lba0 + lba, mem + lba * 512, 1) <= 0) return -1;
        lba++;
    }
    return 0;
}

/* 写回IDE磁盘指定扇区区间 */
static int ide_write_range(uint8_t *mem, uint32_t lba0, uint32_t total)
{
    uint32_t lba = 0;
    while (lba < total) {
        if (ide_write_sectors(lba0 + lba, mem + lba * 512, 1) <= 0) return -1;
        lba++;
    }
    return 0;
}

/* === 块缓存核心: 取块指针(未命中则逐出脏块+IDE读入) === */
static uint8_t *meta_get(uint32_t blk)
{
    for (int i = 0; i < 4; i++)
        if (cache_num[i] == blk) return cache_blk[i];
    static int next = 0;
    int slot = next; next = (next + 1) & 3;
    if (cache_dirty[slot]) {
        if (ide_write_range(cache_blk[slot], data_lba + cache_num[slot] * cache_bs / 512,
                            cache_bs / 512) != 0) return NULL;
        cache_dirty[slot] = 0;
    }
    if (ide_read_range(cache_blk[slot], data_lba + blk * cache_bs / 512, cache_bs / 512) != 0)
        return NULL;
    cache_num[slot] = blk;
    return cache_blk[slot];
}

/* 标记块为脏(调用方修改 meta_get 返回指针后必须调用) */
void ext2_block_dirty(uint32_t blk)
{
    for (int i = 0; i < 4; i++)
        if (cache_num[i] == blk) { cache_dirty[i] = 1; return; }
}

/* 按需访问: 返回块缓存指针(可读可写), 写后须 ext2_block_dirty */
uint8_t *ext2_block_access(uint32_t blk)
{
    return meta_get(blk);
}

/* 按需读: 拷贝一块到 out */
int ext2_read_block(uint32_t blk, uint8_t *out)
{
    if (!fs_mounted || !out) return -1;
    uint8_t *p = meta_get(blk);
    if (!p) return -1;
    memcpy(out, p, cache_bs);
    return 0;
}

/* 按需写: 整块拷入缓存并标记脏 */
int ext2_write_block(uint32_t blk, const uint8_t *in)
{
    if (!fs_mounted || !in) return -1;
    uint8_t *p = meta_get(blk);
    if (!p) return -1;
    memcpy(p, in, cache_bs);
    ext2_block_dirty(blk);
    return 0;
}

/* 写回全部脏缓存块 */
int ext2_block_flush(void)
{
    if (!fs_mounted) return -1;
    for (int i = 0; i < 4; i++) {
        if (cache_dirty[i]) {
            if (ide_write_range(cache_blk[i], data_lba + cache_num[i] * cache_bs / 512,
                                cache_bs / 512) != 0) return -1;
            cache_dirty[i] = 0;
        }
    }
    return 0;
}

/* 挂载: 读 sb+gdt 常驻区(块0-31) → ext2_init → 就绪 */
int ide_ext2_mount(void)
{
    if (fs_mounted) return 0;
    ide_drive_t d;
    if (ide_get_drive_info(0, &d) != 0) return -1;

    /* V3.80: MBR 分区解析——找第一个 0x83 (Linux) 分区作为数据区;
     * 无分区表/无0x83分区则回退整盘 ext2 (兼容纯 ext2 数据盘 ext2disk.img) */
    data_lba = 0;
    data_sectors = d.total_sectors;
    static uint8_t mbr[512];  /* V3.81: 移出栈, 防栈溢出 */
    if (ide_read_sectors(0, mbr, 1) > 0) {
        if (mbr[510] == 0x55 && mbr[511] == 0xAA) {
            for (int i = 0; i < 4; i++) {
                uint8_t *pe = mbr + 446 + i * 16;
                if (pe[4] == 0x83 && (pe[8] | pe[9] | pe[10] | pe[11]) != 0) {
                    uint32_t start = pe[8] | (pe[9] << 8) | (pe[10] << 16) |
                                     ((uint32_t)pe[11] << 24);
                    uint32_t cnt  = pe[12] | (pe[13] << 8) | (pe[14] << 16) |
                                    ((uint32_t)pe[15] << 24);
                    if (cnt > 0 && start + cnt <= d.total_sectors) {
                        data_lba = start;
                        data_sectors = cnt;
                        break;
                    }
                }
            }
        }
    }

    /* V3.87-D6: 数据盘容量上限 = IDE 28位LBA 硬件上限 128GB (不再受内存镜像限制) */
    if (data_sectors == 0 || (uint64_t)data_sectors * 512 > (uint64_t)128ULL * 1024 * 1024 * 1024)
        return -1;

    /* 读块0-31 常驻区: superblock(块1) + GDT(块2起) */
    if (ide_read_range(sb_area, data_lba, 64) != 0) return -1;

    /* 校验 superblock */
    if (*(uint16_t *)(sb_area + 1024 + 56) != 0xEF53) return -1;

    /* 检查 GDT 是否在常驻区内 (gdt_bytes <= 32KB - gdt偏移) */
    {
        uint32_t log_bs = *(uint32_t *)(sb_area + 1024 + 24);
        uint32_t blocks = *(uint32_t *)(sb_area + 1024 + 4);
        uint32_t bpg    = *(uint32_t *)(sb_area + 1024 + 32);
        uint32_t bs = 1024 << log_bs;
        uint32_t groups = (blocks + bpg - 1) / bpg;
        uint32_t gdt_block = (bs == 1024) ? 2 : 1;
        uint32_t gdt_bytes = groups * 32;
        if ((uint32_t)gdt_block * bs + gdt_bytes > sizeof(sb_area)) {
            serial_puts(0x3F8, "[FS] GDT too large for resident area\n");
            return -1;
        }
        cache_bs = bs;
    }

    if (ext2_init(sb_area, sizeof(sb_area)) != 0) return -1;
    fs_mounted = 1;
    return 0;
}

/* 同步回写: superblock+GDT 常驻区 + 全部脏缓存块 */
int ide_ext2_sync(void)
{
    if (!fs_mounted) return -1;
    /* 常驻区(块0-31)全量写回: superblock 计数/GDT 空闲计数等 */
    if (ide_write_range(sb_area, data_lba, sizeof(sb_area) / 512) != 0) return -1;
    return ext2_block_flush();
}

void ide_ext2_selftest(void)
{
    ide_drive_t d;
    if (ide_get_drive_info(0, &d) != 0) {
        serial_puts(0x3F8, "[EXT2] selftest: no disk, skip\n");
        return;
    }
    if (ide_ext2_mount() != 0) {
        serial_puts(0x3F8, "[EXT2] selftest: mount FAIL\n");
        return;
    }
    serial_puts(0x3F8, "[EXT2] selftest: mounted (ext2 fs on IDE disk)\n");

    /* 读 /hello.txt */
    {
        ext2_inode_t root, inode;
        if (ext2_read_inode(EXT2_ROOT_INODE, &root) == 0) {
            uint32_t ino = 0;
            if (ext2_lookup(&root, "hello.txt", &ino) == 0 &&
                ext2_read_inode(ino, &inode) == 0) {
                char buf[128];
                uint32_t rd = ext2_read_data(&inode, 0, buf, 127);
                buf[rd] = 0;
                serial_puts(0x3F8, "[EXT2] read /hello.txt: ");
                serial_puts(0x3F8, buf);
                serial_putc(0x3F8, '\n');
            } else {
                serial_puts(0x3F8, "[EXT2] read /hello.txt FAIL\n");
            }
        }
    }

    /* 写测试(幂等): test_hepu.txt 不存在才创建, 存在直接复用 */
    {
        ext2_inode_t root, ti;
        uint32_t tino = 0;
        int have = 0;
        if (ext2_read_inode(EXT2_ROOT_INODE, &root) == 0) {
            have = (ext2_lookup(&root, "test_hepu.txt", &tino) == 0);
        }
        if (!have) {
            int pc = ext2_path_create("/test_hepu.txt", 0x81A4);
            if (pc <= 0) {
                serial_puts(0x3F8, "[EXT2] create /test_hepu.txt FAIL\n");
                return;
            }
            ext2_read_inode(EXT2_ROOT_INODE, &root);
            if (ext2_lookup(&root, "test_hepu.txt", &tino) != 0) {
                serial_puts(0x3F8, "[EXT2] create ok but lookup FAIL\n");
                return;
            }
        }
        if (ext2_read_inode(tino, &ti) == 0) {
            const char *data = "written by Hepu OS kernel\n";
            uint32_t dl = 27;
            if (ext2_write_data(&ti, 0, data, dl) >= 0) {
                ext2_write_inode(tino, &ti);
                uint8_t rbuf[64];
                uint32_t n = ext2_read_data(&ti, 0, rbuf, 63);
                if (n == dl && memcmp(rbuf, data, dl) == 0) {
                    serial_puts(0x3F8, "[EXT2] write+readback /test_hepu.txt PASS\n");
                } else {
                    serial_puts(0x3F8, "[EXT2] write+readback MISMATCH\n");
                }
            } else {
                serial_puts(0x3F8, "[EXT2] write /test_hepu.txt FAIL\n");
            }
        }
    }

    /* V2.57: 目录/删除/重命名持久化自测(幂等) */
    {
        /* 1. 建目录 /docs (已存在则复用) */
        ext2_inode_t root;
        uint32_t dino = 0;
        int have_dir = 0;
        if (ext2_read_inode(EXT2_ROOT_INODE, &root) == 0) {
            have_dir = (ext2_lookup(&root, "docs", &dino) == 0);
        }
        if (!have_dir) {
            if (ext2_path_mkdir_v2("/docs", 0x1ED) > 0) {
                serial_puts(0x3F8, "[EXT2] mkdir /docs PASS\n");
            } else {
                serial_puts(0x3F8, "[EXT2] mkdir /docs FAIL\n");
            }
        } else {
            serial_puts(0x3F8, "[EXT2] mkdir /docs (already exists)\n");
        }

        /* 2. 往 /docs/note.txt 写数据并读回 */
        {
            uint32_t nino = 0;
            int have_note = 0;
            if (ext2_read_inode(EXT2_ROOT_INODE, &root) == 0) {
                if (ext2_lookup(&root, "docs", &dino) == 0) {
                    ext2_inode_t dir;
                    if (ext2_read_inode(dino, &dir) == 0) {
                        have_note = (ext2_lookup(&dir, "note.txt", &nino) == 0);
                    }
                }
            }
            if (!have_note) {
                int pc = ext2_path_create_v2("/docs/note.txt", 0x81A4);
                if (pc <= 0) {
                    serial_puts(0x3F8, "[EXT2] create /docs/note.txt FAIL\n");
                } else {
                    serial_puts(0x3F8, "[EXT2] create /docs/note.txt PASS\n");
                }
            }
            /* 写数据+读回 */
            if (ext2_read_inode(EXT2_ROOT_INODE, &root) == 0 &&
                ext2_lookup(&root, "docs", &dino) == 0) {
                ext2_inode_t dir, ti;
                if (ext2_read_inode(dino, &dir) == 0 &&
                    ext2_lookup(&dir, "note.txt", &nino) == 0 &&
                    ext2_read_inode(nino, &ti) == 0) {
                    const char *d = "nested file in docs dir";
                    uint32_t dl = 24;
                    if (ext2_write_data(&ti, 0, d, dl) >= 0) {
                        ext2_write_inode(nino, &ti);
                        char rb[64];
                        uint32_t nr = ext2_read_data(&ti, 0, rb, 63);
                        rb[nr] = 0;
                        if (nr == dl && memcmp(rb, d, dl) == 0) {
                            serial_puts(0x3F8, "[EXT2] nested write+readback PASS\n");
                        } else {
                            serial_puts(0x3F8, "[EXT2] nested write+readback MISMATCH\n");
                        }
                    } else {
                        serial_puts(0x3F8, "[EXT2] nested write FAIL\n");
                    }
                }
            }
        }

        /* 3. rm: 创建临时文件后删除, 验证目录项移除 */
        {
            static char tmppath[300];
            int tn = 0;
            tmppath[tn++] = '/'; tmppath[tn++] = 't'; tmppath[tn++] = 'm'; tmppath[tn++] = 'p';
            tmppath[tn++] = 'x'; tmppath[tn++] = '.'; tmppath[tn++] = 't'; tmppath[tn++] = 'x';
            tmppath[tn++] = 't'; tmppath[tn] = 0;
            /* 先清理旧 */
            ext2_path_unlink_v2(tmppath);
            if (ext2_path_create_v2(tmppath, 0x81A4) > 0) {
                if (ext2_path_unlink_v2(tmppath) == 0) {
                    /* 验证已消失: lookup 应失败 */
                    ext2_inode_t rootv;
                    uint32_t gone_ino = 0;
                    int gone = -1;
                    if (ext2_read_inode(EXT2_ROOT_INODE, &rootv) == 0) {
                        if (ext2_lookup(&rootv, "tmp.txt", &gone_ino) != 0) {
                            gone = 0;
                        }
                    }
                    if (gone == 0) {
                        serial_puts(0x3F8, "[EXT2] unlink tmp PASS\n");
                    } else {
                        serial_puts(0x3F8, "[EXT2] unlink tmp but entry remains\n");
                    }
                } else {
                    serial_puts(0x3F8, "[EXT2] unlink tmp FAIL\n");
                }
            } else {
                serial_puts(0x3F8, "[EXT2] create tmp for unlink FAIL\n");
            }
        }

        /* 4. rename: /ren_a.txt -> /ren_b.txt */
        {
            ext2_path_unlink_v2("/ren_a.txt");
            ext2_path_unlink_v2("/ren_b.txt");
            if (ext2_path_create_v2("/ren_a.txt", 0x81A4) > 0) {
                if (ext2_path_rename("/ren_a.txt", "/ren_b.txt") == 0) {
                    uint32_t rb_ino = 0;
                    ext2_inode_t root2;
                    int ok = -1;
                    if (ext2_read_inode(EXT2_ROOT_INODE, &root2) == 0) {
                        if (ext2_lookup(&root2, "ren_b.txt", &rb_ino) == 0) ok = 0;
                    }
                    if (ok == 0) {
                        serial_puts(0x3F8, "[EXT2] rename a->b PASS\n");
                    } else {
                        serial_puts(0x3F8, "[EXT2] rename a->b but b not found\n");
                    }
                } else {
                    serial_puts(0x3F8, "[EXT2] rename FAIL\n");
                }
            } else {
                serial_puts(0x3F8, "[EXT2] create ren_a FAIL\n");
            }
        }
    }

    /* V2.59: 大文件(>12KB 一级间接块)写入 + 读回校验 */
    {
        int big_ok = 1;
        static uint8_t tmpb[1024];
        static uint8_t chkb[1024];
        ext2_path_unlink_v2("/big.bin");
        if (ext2_path_create_v2("/big.bin", 0x81A4) > 0) {
            uint32_t bino = 0;
            ext2_inode_t root3;
            if (ext2_read_inode(EXT2_ROOT_INODE, &root3) == 0 &&
                ext2_lookup(&root3, "big.bin", &bino) == 0) {
                ext2_inode_t bi;
                if (ext2_read_inode(bino, &bi) == 0) {
                    uint32_t total = 512 * 1024;   /* V3.87-D3: 512KB 触发双级间接块(>268块) */
                    uint32_t off = 0;
                    while (off < total) {
                        for (int i = 0; i < 1024; i++) tmpb[i] = (uint8_t)((off + i) * 31 + 7);
                        if (ext2_write_data(&bi, off, tmpb, 1024) < 0) { big_ok = 0; break; }
                        off += 1024;
                    }
                    bi.i_size = total;
                    ext2_write_inode(bino, &bi);
                    if (big_ok) {
                        int bad = 0;
                        uint32_t r = 0;
                        for (; r < total; r += 1024) {
                            if (ext2_read_data(&bi, r, chkb, 1024) != 1024) { bad = 1; break; }
                            for (int i = 0; i < 1024; i++) {
                                if (chkb[i] != (uint8_t)((r + i) * 31 + 7)) { bad = 1; break; }
                            }
                            if (bad) break;
                        }
                        if (!bad) {
                            serial_puts(0x3F8, "[EXT2] bigfile(512KB,dbl-indirect) write+readback PASS\n");
                        } else {
                            serial_puts(0x3F8, "[EXT2] bigfile readback MISMATCH\n");
                        }
                    } else {
                        serial_puts(0x3F8, "[EXT2] bigfile write FAIL\n");
                    }
                }
            }
        }
    }

    if (ide_ext2_sync() == 0) {
        serial_puts(0x3F8, "[EXT2] selftest: synced back to IDE disk\n");
    }

    /* V3.89-E25: 启动自动 fsck 健康检查(只读哨兵).
     * 数据盘同步完成后执行一次完整 fsck: 位图/超级块一致性 + 孤儿块/inode 报告.
     * 发现孤儿时提示用 fs fsck fix 修复; 此哨兵可持续监控"每启动资源消耗"回归. */
#ifdef HEPU_AUTO_FSCK
    {
        extern int ide_ext2_fsck(void);
        serial_puts(0x3F8, "[EXT2] auto-fsck: running\n");
        int r = ide_ext2_fsck();
        serial_puts(0x3F8, "[EXT2] auto-fsck: ");
        if (r == 0) serial_puts(0x3F8, "OK\n");
        else serial_puts(0x3F8, "ISSUES (use 'fs fsck fix' to repair)\n");
    }
#endif

    serial_puts(0x3F8, "[EXT2] selftest done\n");
}

/* ============ shell 辅助(VGA输出) ============ */

/* 列根目录(仅一级, 手机系统场景够用) */
void ide_ext2_list_dir(void)
{
    if (!fs_mounted) {
        if (ide_ext2_mount() != 0) { vga_puts(" fs: no ext2 disk mounted\n"); return; }
    }
    ext2_inode_t root;
    if (ext2_read_inode(EXT2_ROOT_INODE, &root) != 0) { vga_puts(" fs: read root inode FAIL\n"); return; }
    vga_puts(" /:\n");
    uint32_t offset = 0;
    static uint8_t block[4096];
    while (offset < root.i_size) {
        uint32_t to_read = root.i_size - offset;
        if (to_read > 4096) to_read = 4096;
        uint32_t n = ext2_read_data(&root, offset, block, to_read);
        if (n <= 0) break;
        uint32_t pos = 0;
        while (pos + 8 <= n) {
            ext2_dir_entry_t *entry = (ext2_dir_entry_t *)(block + pos);
            if (entry->rec_len < 8 || entry->name_len >= 255) break;
            if (pos + entry->rec_len > n) break;
            if (entry->inode != 0) {
                char nm[256];
                uint32_t nl = entry->name_len;
                if (nl > 255) nl = 255;
                memcpy(nm, entry->name, nl);
                nm[nl] = 0;
                vga_printf("   %d  %s\n", entry->inode, nm);
            }
            pos += entry->rec_len;
        }
        offset += to_read;
    }
}

/* 读取文件并打印内容（支持 /path 多级） */
int ide_ext2_cat(const char *name)
{
    if (!fs_mounted) {
        if (ide_ext2_mount() != 0) return -1;
    }
    static char path[300];
    int n = 0;
    path[n++] = '/';
    for (int i = 0; name[i] && n < 298; i++) path[n++] = name[i];
    path[n] = 0;
    char filename[256];
    uint32_t dir_ino;
    ext2_inode_t inode;
    uint32_t ino = 0;
    if (ext2_resolve_path(path, &dir_ino, filename, 256) != 0) return -1;
    ext2_inode_t dir;
    if (ext2_read_inode(dir_ino, &dir) != 0) return -1;
    if (ext2_lookup(&dir, filename, &ino) != 0) return -1;
    if (ext2_read_inode(ino, &inode) != 0) return -1;
    if (inode.i_size > 0) {
        static char rbuf[512];
        uint32_t n = ext2_read_data(&inode, 0, rbuf, inode.i_size > 511 ? 511 : inode.i_size);
        rbuf[n] = 0;
        vga_puts(rbuf);
        vga_putc('\n');
    }
    return 0;
}

/* 创建/覆盖文件并写入内容（支持 /path 多级） */
int ide_ext2_writefile(const char *name, const char *data)
{
    if (!fs_mounted) {
        if (ide_ext2_mount() != 0) return -1;
    }
    ext2_inode_t inode;
    uint32_t ino = 0;
    int have = 0;
    static char path[300];
    int n = 0;
    path[n++] = '/';
    for (int i = 0; name[i] && n < 298; i++) path[n++] = name[i];
    path[n] = 0;
    char filename[256];
    uint32_t dir_ino;
    ext2_inode_t dir;
    if (ext2_resolve_path(path, &dir_ino, filename, 256) != 0) return -1;
    if (ext2_read_inode(dir_ino, &dir) != 0) return -1;
    have = (ext2_lookup(&dir, filename, &ino) == 0);
    if (!have) {
        int pc = ext2_path_create(path, 0x81A4);
        if (pc <= 0) return -1;
        if (ext2_resolve_path(path, &dir_ino, filename, 256) != 0) return -1;
        if (ext2_read_inode(dir_ino, &dir) != 0) return -1;
        if (ext2_lookup(&dir, filename, &ino) != 0) return -1;
    }
    if (ext2_read_inode(ino, &inode) != 0) return -1;
    uint32_t dl = 0;
    while (data[dl] && dl < 4095) dl++;
    if (ext2_write_data(&inode, 0, data, dl) > 0) {
        inode.i_size = dl;
        ext2_write_inode(ino, &inode);
        extern int ide_ext2_sync(void);
        ide_ext2_sync();   /* V3.87-E15: 脏缓存落盘——否则写入只留在内存缓存 */
        return (int)dl;
    }
    return -1;
}

/* V2.57: 构造 /name 根路径（一级，手机系统场景够用） */
static int make_root_path(const char *name, char *out, int cap)
{
    if (!name || !name[0] || !out) return -1;
    int n = 0;
    out[n++] = '/';
    for (int i = 0; name[i] && n < cap - 1; i++) out[n++] = name[i];
    out[n] = 0;
    return n;
}

/* V2.57: 删除根目录文件 */
int ide_ext2_rm(const char *name)
{
    if (!fs_mounted) {
        if (ide_ext2_mount() != 0) return -1;
    }
    static char path[300];
    if (make_root_path(name, path, 300) < 0) return -1;
    int r = ext2_path_unlink_v2(path);
    if (r == 0) {
        extern int ide_ext2_sync(void);
        ide_ext2_sync();
        vga_printf(" deleted /%s\n", name);
    } else vga_printf(" rm /%s FAIL (not found?)\n", name);
    return r;
}

/* V2.57: 重命名根目录文件 */
int ide_ext2_mv(const char *oldn, const char *newn)
{
    if (!fs_mounted) {
        if (ide_ext2_mount() != 0) return -1;
    }
    static char oldp[300], newp[300];
    if (make_root_path(oldn, oldp, 300) < 0) return -1;
    if (make_root_path(newn, newp, 300) < 0) return -1;
    int r = ext2_path_rename(oldp, newp);
    if (r == 0) {
        extern int ide_ext2_sync(void);
        ide_ext2_sync();
        vga_printf(" renamed /%s -> /%s\n", oldn, newn);
    } else vga_printf(" mv /%s -> /%s FAIL\n", oldn, newn);
    return r;
}

/* V2.57: 根目录下建子目录 */
int ide_ext2_mkdir(const char *name)
{
    if (!fs_mounted) {
        if (ide_ext2_mount() != 0) return -1;
    }
    static char path[300];
    if (make_root_path(name, path, 300) < 0) return -1;
    int r = ext2_path_mkdir_v2(path, 0x1ED);
    if (r > 0) vga_printf(" created dir /%s (inode=%d)\n", name, r);
    else vga_printf(" mkdir /%s FAIL (exists?)\n", name);
    return r > 0 ? 0 : -1;
}

/* V2.58: 解析目录 inode（"/"->根; "/docs"->docs 目录 inode） */
static int fm_dir_ino(const char *dirpath, uint32_t *dir_ino)
{
    if (dirpath && dirpath[0] == '/' && dirpath[1] == 0) {
        *dir_ino = EXT2_ROOT_INODE;
        return 0;
    }
    char fname[256];
    uint32_t pino;
    if (ext2_resolve_path(dirpath, &pino, fname, 256) != 0) return -1;
    ext2_inode_t pdir;
    if (ext2_read_inode(pino, &pdir) != 0) return -1;
    if (ext2_lookup(&pdir, fname, dir_ino) != 0) return -1;
    return 0;
}

/* V2.58: 手机文件管理器列表接口 */
int ide_ext2_list_entries(const char *dirpath, fm_entry_t *entries, int max)
{
    if (!entries || max <= 0) return -1;
    if (!fs_mounted) {
        if (ide_ext2_mount() != 0) return -1;
    }
    ext2_inode_t dir;
    uint32_t dir_ino;
    if (fm_dir_ino(dirpath, &dir_ino) != 0) return -1;
    if (ext2_read_inode(dir_ino, &dir) != 0) return -1;
    if (!(dir.i_mode & 0x4000)) return -1;

    uint32_t offset = 0;
    static uint8_t block[4096];
    int count = 0;
    while (offset < dir.i_size && count < max) {
        /* 按块读取，避免目录项跨块丢失 */
        uint32_t to_read = dir.i_size - offset;
        if (to_read > ext2_block_size) to_read = ext2_block_size;
        uint32_t n = ext2_read_data(&dir, offset, block, to_read);
        if (n <= 0) break;
        uint32_t pos = 0;
        while (pos + 8 <= n && count < max) {
            ext2_dir_entry_t *entry = (ext2_dir_entry_t *)(block + pos);
            if (entry->rec_len < 8 || entry->name_len >= 255) break;
            if (pos + entry->rec_len > n) break;
            /* 跳过删除项(ino=0)与 . .. */
            if (entry->inode != 0 && entry->name_len > 0 && entry->name[0] != '.') {
                ext2_inode_t fi;
                if (ext2_read_inode(entry->inode, &fi) == 0) {
                    uint32_t nl = entry->name_len;
                    if (nl > 127) nl = 127;
                    memcpy(entries[count].name, entry->name, nl);
                    entries[count].name[nl] = 0;
                    entries[count].size = fi.i_size;
                    entries[count].is_dir = (fi.i_mode & 0x4000) ? 1 : 0;
                    count++;
                }
            }
            pos += entry->rec_len;
        }
        offset += to_read;
    }
    return count;
}

/* V2.58: 删除文件（根目录或子目录） */
int ide_ext2_delete(const char *dirpath, const char *name)
{
    if (!fs_mounted) {
        if (ide_ext2_mount() != 0) return -1;
    }
    static char path[320];
    int n = 0;
    const char *d = dirpath;
    while (*d && n < 300) { path[n++] = *d; d++; }
    if (n > 1 && path[n-1] == '/') n--;   /* 去尾斜杠 */
    if (n > 0 && path[0] != '/') { /* 前面补 / */ }
    path[n++] = '/';
    for (int i = 0; name[i] && n < 318; i++) path[n++] = name[i];
    path[n] = 0;
    return ext2_path_unlink_v2(path);
}

/* V2.58: 读取文件内容到 buffer（供手机 UI 查看） */
int ide_ext2_read_file(const char *dirpath, const char *name, char *buf, int max)
{
    if (!fs_mounted) {
        if (ide_ext2_mount() != 0) return -1;
    }
    ext2_inode_t dir;
    uint32_t dir_ino;
    if (fm_dir_ino(dirpath, &dir_ino) != 0) return -1;
    if (ext2_read_inode(dir_ino, &dir) != 0) return -1;
    uint32_t ino;
    if (ext2_lookup(&dir, name, &ino) != 0) return -1;
    ext2_inode_t fi;
    if (ext2_read_inode(ino, &fi) != 0) return -1;
    if (fi.i_mode & 0x4000) return -2;   /* 目录不可直接读 */
    uint32_t sz = fi.i_size;
    if (sz > (uint32_t)max - 1) sz = (uint32_t)max - 1;
    uint32_t rd = ext2_read_data(&fi, 0, buf, sz);
    /* V4.47-E92: 防御——读取失败(rd<0)或读数异常时不得越界写 buf[rd] */
    if ((int32_t)rd < 0 || rd > sz) return (int)rd;
    buf[rd] = 0;
    return (int)rd;
}

/* V2.80: 任意长度二进制写入 (BMP 等, 无 \0 截断 / 无 4095 上限)。
 * dirpath 如 "/data/photos", name 如 "photo_1.bmp", len 为数据字节数。 */
int ide_ext2_write_raw(const char *dirpath, const char *name,
                       const char *data, int len)
{
    if (!fs_mounted) {
        if (ide_ext2_mount() != 0) return -1;
    }
    static char path[320];
    int n = 0;
    if (dirpath[0] != '/') path[n++] = '/';   /* V4.44-E89: 兼容无前导斜杠的 dirpath */
    const char *d = dirpath;
    while (*d && n < 300) { path[n++] = *d; d++; }
    if (n > 1 && path[n - 1] == '/') n--;
    path[n++] = '/';
    for (int i = 0; name[i] && n < 318; i++) path[n++] = name[i];
    path[n] = 0;
    char fname[256];
    uint32_t dino;
    if (ext2_resolve_path(path, &dino, fname, 256) != 0) return -1;
    ext2_inode_t dir;
    if (ext2_read_inode(dino, &dir) != 0) return -1;
    uint32_t ex;
    if (ext2_lookup(&dir, fname, &ex) != 0) {
        int pc = ext2_path_create(path, 0x81A4);
        if (pc <= 0) return -1;
        if (ext2_resolve_path(path, &dino, fname, 256) != 0) return -1;
        if (ext2_read_inode(dino, &dir) != 0) return -1;
        if (ext2_lookup(&dir, fname, &ex) != 0) return -1;
    }
    ext2_inode_t fi;
    if (ext2_read_inode(ex, &fi) != 0) return -1;
    if (len < 0) len = 0;
    if (ext2_write_data(&fi, 0, data, (uint32_t)len) < 0) return -1;
    fi.i_size = (uint32_t)len;
    ext2_write_inode(ex, &fi);
    return len;
}

/* V2.58: 在目录下新建文件（供手机文件管理器"新建"） */
int ide_ext2_create_file(const char *dirpath, const char *name, const char *content)
{
    if (!fs_mounted) {
        if (ide_ext2_mount() != 0) return -1;
    }
    static char path[320];
    int n = 0;
    const char *d = dirpath;
    while (*d && n < 300) { path[n++] = *d; d++; }
    if (n > 1 && path[n-1] == '/') n--;
    path[n++] = '/';
    for (int i = 0; name[i] && n < 318; i++) path[n++] = name[i];
    path[n] = 0;
    /* 已存在则直接返回 */
    char fname[256];
    uint32_t dino;
    if (ext2_resolve_path(path, &dino, fname, 256) != 0) return -1;
    ext2_inode_t dir;
    if (ext2_read_inode(dino, &dir) != 0) return -1;
    uint32_t ex;
    if (ext2_lookup(&dir, fname, &ex) == 0) {
        /* 覆盖内容 */
        ext2_inode_t fi;
        if (ext2_read_inode(ex, &fi) != 0) return -1;
        uint32_t dl = 0;
        while (content[dl] && dl < 4095) dl++;
        if (ext2_write_data(&fi, 0, content, dl) >= 0) {
            fi.i_size = dl;
            ext2_write_inode(ex, &fi);
            extern int ide_ext2_sync(void);
            ide_ext2_sync();
            return (int)dl;
        }
        return -1;
    }
    int pc = ext2_path_create(path, 0x81A4);
    if (pc <= 0) return -1;
    /* 写入内容 */
    if (ext2_resolve_path(path, &dino, fname, 256) != 0) return -1;
    if (ext2_read_inode(dino, &dir) != 0) return -1;
    if (ext2_lookup(&dir, fname, &ex) != 0) return -1;
    ext2_inode_t fi;
    if (ext2_read_inode(ex, &fi) != 0) return -1;
    uint32_t dl = 0;
    while (content[dl] && dl < 4095) dl++;
    if (ext2_write_data(&fi, 0, content, dl) >= 0) {
        fi.i_size = dl;
        ext2_write_inode(ex, &fi);
        extern int ide_ext2_sync(void);
        ide_ext2_sync();
        return (int)dl;
    }
    return -1;
}
int ide_ext2_ls_dir(const char *name)
{
    if (!fs_mounted) {
        if (ide_ext2_mount() != 0) return -1;
    }
    ext2_inode_t root, dir;
    uint32_t dino = 0;
    if (ext2_read_inode(EXT2_ROOT_INODE, &root) != 0) return -1;
    if (ext2_lookup(&root, name, &dino) != 0) return -1;
    if (ext2_read_inode(dino, &dir) != 0) return -1;
    vga_printf(" /%s/:\n", name);
    uint32_t offset = 0;
    static uint8_t block[4096];
    while (offset < dir.i_size) {
        uint32_t to_read = dir.i_size - offset;
        if (to_read > 4096) to_read = 4096;
        uint32_t n = ext2_read_data(&dir, offset, block, to_read);
        if (n <= 0) break;
        uint32_t pos = 0;
        while (pos + 8 <= n) {
            ext2_dir_entry_t *entry = (ext2_dir_entry_t *)(block + pos);
            if (entry->rec_len < 8 || entry->name_len >= 255) break;
            if (pos + entry->rec_len > n) break;
            if (entry->inode != 0) {
                char nm[256];
                uint32_t nl = entry->name_len;
                if (nl > 255) nl = 255;
                memcpy(nm, entry->name, nl);
                nm[nl] = 0;
                vga_printf("   %d  %s\n", entry->inode, nm);
            }
            pos += entry->rec_len;
        }
        offset += to_read;
    }
    return 0;
}

/* V3.87-D2: 数据盘剩余可写字节 (供安装器空间预检) */
int ide_ext2_free_bytes(void)
{
    if (!fs_mounted) {
        if (ide_ext2_mount() != 0) return -1;
    }
    ext2_superblock_t *sb = ext2_get_sb();
    if (!sb) return -1;
    uint64_t free_bytes = (uint64_t)sb->s_free_blocks_count * ext2_block_size;
    if (free_bytes > 0x7FFFFFFF) return 0x7FFFFFFF;
    return (int)free_bytes;
}

/* ============================================================================
 * V4.03-E48: fs stat / fs df —— 数据盘管理与写入增强
 * - fs stat <name>: inode/类型/大小/块数/时间
 * - fs df        : 空间统计(总块/空闲块/空闲inode/占用%)
 * ========================================================================== */
int ide_ext2_stat(const char *name)
{
    if (!fs_mounted) {
        if (ide_ext2_mount() != 0) return -1;
    }
    static char path[300];
    int n = 0;
    path[n++] = '/';
    for (int i = 0; name[i] && n < 298; i++) path[n++] = name[i];
    path[n] = 0;

    char filename[256];
    uint32_t dir_ino;
    ext2_inode_t dir, ino;
    if (ext2_resolve_path(path, &dir_ino, filename, 256) != 0) return -1;
    if (ext2_read_inode(dir_ino, &dir) != 0) return -1;
    uint32_t ino_num = 0;
    if (ext2_lookup(&dir, filename, &ino_num) != 0) return -1;
    if (ext2_read_inode(ino_num, &ino) != 0) return -1;

    vga_printf(" %s: inode=%u size=%u blocks=%u\n", name,
               ino_num, ino.i_size, ino.i_blocks / 2);
    vga_printf("  mode=0x%x uid=%u gid=%u links=%u\n",
               ino.i_mode, ino.i_uid, ino.i_gid, ino.i_links_count);
    if (ino.i_mode & 0x4000)      vga_puts("  type: dir\n");
    else if (ino.i_mode & 0x8000) vga_puts("  type: regular file\n");
    else                          vga_puts("  type: other\n");
    vga_printf("  mtime=%u\n", ino.i_mtime);
    return 0;
}

int ide_ext2_df(void)
{
    if (!fs_mounted) {
        if (ide_ext2_mount() != 0) return -1;
    }
    ext2_superblock_t *sb = ext2_get_sb();
    if (!sb) return -1;
    /* 32 位内核无 __udivdi3: 全程 uint32 运算(32MB 盘 blocks*bs=32MB, KB 不溢出) */
    uint32_t total_kb = (uint32_t)(sb->s_blocks_count * ext2_block_size / 1024);
    uint32_t free_kb  = (uint32_t)(sb->s_free_blocks_count * ext2_block_size / 1024);
    uint32_t used_kb  = total_kb - free_kb;
    uint32_t pct = (total_kb > 0) ? (used_kb * 100 / total_kb) : 0;
    extern const char *i18n_get(int);
    vga_puts(i18n_get(I18N_STORAGE_FREE));
    vga_printf(": total=%uKB used=%uKB free=%uKB (%u%% used)\n",
               total_kb, used_kb, free_kb, pct);
    vga_printf("     inodes: free=%u/%u blocks: free=%u/%u\n",
               sb->s_free_inodes_count, sb->s_inodes_count,
               sb->s_free_blocks_count, sb->s_blocks_count);
    return 0;
}
