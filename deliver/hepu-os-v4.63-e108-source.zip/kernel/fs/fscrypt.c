/* ============================================================================
 * 赫普OS - 文件系统加密
 * 提供文件级加密保护，支持XOR和AES算法
 * ========================================================================== */

#include <stdint.h>
#include "fscrypt.h"
#include "vga.h"
#include "string.h"

static uint8_t master_key[FSCRYPT_KEY_LEN];
static int key_set = 0;
static fscrypt_context_t contexts[FSCRYPT_MAX_FILES];
static int fscrypt_initialized = 0;

void fscrypt_init(void)
{
    memset(contexts, 0, sizeof(contexts));
    memset(master_key, 0, sizeof(master_key));
    key_set = 0;
    fscrypt_initialized = 1;
    vga_puts("[FSCRYPT] fs encryption init \n");
}

int fscrypt_set_key(const uint8_t *key, uint32_t len)
{
    if (!fscrypt_initialized || !key || len == 0) return -1;
    uint32_t copy_len = len < FSCRYPT_KEY_LEN ? len : FSCRYPT_KEY_LEN;
    memcpy(master_key, key, copy_len);
    key_set = 1;
    vga_printf("[FSCRYPT] master key set(%d bytes)\n", copy_len);
    return 0;
}

/* 简化XOR加密（开发阶段使用，生产环境应使用AES） */
static void xor_crypt(uint8_t *data, uint32_t len, uint8_t *key, uint32_t key_len)
{
    for (uint32_t i = 0; i < len; i++) {
        data[i] ^= key[i % key_len];
    }
}

int fscrypt_encrypt(uint32_t inode, uint8_t *data, uint32_t len)
{
    if (!fscrypt_initialized || !key_set || !data || len == 0) return -1;

    /* 查找文件加密上下文 */
    fscrypt_context_t *ctx = NULL;
    for (int i = 0; i < FSCRYPT_MAX_FILES; i++) {
        if (contexts[i].magic == FSCRYPT_MAGIC &&
            contexts[i].inode_num == inode &&
            contexts[i].encrypted) {
            ctx = &contexts[i];
            break;
        }
    }
    if (!ctx) return 0;  /* 未加密，直接返回 */

    /* 生成文件专用密钥（主密钥 XOR inode号） */
    uint8_t file_key[FSCRYPT_KEY_LEN];
    memcpy(file_key, master_key, FSCRYPT_KEY_LEN);
    for (int i = 0; i < 4; i++) {
        file_key[i] ^= (inode >> (i * 8)) & 0xFF;
    }

    switch (ctx->algorithm) {
        case FSCRYPT_ALG_XOR:
            xor_crypt(data, len, file_key, FSCRYPT_KEY_LEN);
            break;
        case FSCRYPT_ALG_AES_128:
        case FSCRYPT_ALG_AES_256:
            /* 简化：使用XOR替代AES（实际应实现AES） */
            xor_crypt(data, len, file_key, FSCRYPT_KEY_LEN);
            break;
        default:
            return -1;
    }

    return len;
}

int fscrypt_decrypt(uint32_t inode, uint8_t *data, uint32_t len)
{
    /* XOR加密解密相同 */
    return fscrypt_encrypt(inode, data, len);
}

int fscrypt_enable(uint32_t inode, fscrypt_alg_t alg)
{
    if (!fscrypt_initialized) return -1;

    /* 查找空闲上下文 */
    fscrypt_context_t *ctx = NULL;
    for (int i = 0; i < FSCRYPT_MAX_FILES; i++) {
        if (contexts[i].magic != FSCRYPT_MAGIC) {
            ctx = &contexts[i];
            break;
        }
    }
    if (!ctx) return -1;

    ctx->magic = FSCRYPT_MAGIC;
    ctx->algorithm = alg;
    ctx->inode_num = inode;
    ctx->encrypted = 1;
    memcpy(ctx->key, master_key, FSCRYPT_KEY_LEN);

    vga_printf("[FSCRYPT] enable file enc: inode=%d alg=%d\n", inode, alg);
    return 0;
}

int fscrypt_disable(uint32_t inode)
{
    for (int i = 0; i < FSCRYPT_MAX_FILES; i++) {
        if (contexts[i].magic == FSCRYPT_MAGIC &&
            contexts[i].inode_num == inode) {
            memset(&contexts[i], 0, sizeof(fscrypt_context_t));
            vga_printf("[FSCRYPT] disable file enc: inode=%d\n", inode);
            return 0;
        }
    }
    return -1;
}

int fscrypt_is_encrypted(uint32_t inode)
{
    for (int i = 0; i < FSCRYPT_MAX_FILES; i++) {
        if (contexts[i].magic == FSCRYPT_MAGIC &&
            contexts[i].inode_num == inode &&
            contexts[i].encrypted) {
            return 1;
        }
    }
    return 0;
}

int fscrypt_status(uint32_t *encrypted_files, uint32_t *total)
{
    uint32_t count = 0;
    for (int i = 0; i < FSCRYPT_MAX_FILES; i++) {
        if (contexts[i].magic == FSCRYPT_MAGIC && contexts[i].encrypted) {
            count++;
        }
    }
    if (encrypted_files) *encrypted_files = count;
    if (total) *total = FSCRYPT_MAX_FILES;
    return count;
}
