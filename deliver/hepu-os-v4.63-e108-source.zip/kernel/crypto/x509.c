/* ============================================================================
 * 赫普OS - X.509证书验证
 * 支持证书解析、签名验证、证书链验证
 * ========================================================================== */

#include <stdint.h>
#include "x509.h"
#include "vga.h"
#include "string.h"

#define X509_MAX_TRUSTED_CAS 16

static x509_cert_t trusted_cas[X509_MAX_TRUSTED_CAS];
static int trusted_ca_count = 0;
static int x509_initialized = 0;

/* 初始化X.509 */
void x509_init(void)
{
    memset(trusted_cas, 0, sizeof(trusted_cas));
    trusted_ca_count = 0;
    x509_initialized = 1;
    vga_puts("[X509] cert verify init \n");
    vga_puts("[X509] supports RSA/ECDSA, SHA1/SHA256/SHA384/SHA512\n");
}

/* ASN.1 DER解析：读取长度 */
static int x509_read_length(const uint8_t *data, int *offset, int max_len)
{
    if (*offset >= max_len) return -1;
    uint8_t first = data[*offset];
    (*offset)++;

    if (first < 0x80) return first;

    int num_bytes = first & 0x7F;
    if (num_bytes == 0 || num_bytes > 4) return -1;

    int length = 0;
    for (int i = 0; i < num_bytes; i++) {
        if (*offset >= max_len) return -1;
        length = (length << 8) | data[*offset];
        (*offset)++;
    }
    return length;
}

/* 解析证书 */
int x509_parse(const uint8_t *der, uint32_t len, x509_cert_t *cert)
{
    if (!x509_initialized || !der || !cert || len < 1) return -1;

    memset(cert, 0, sizeof(x509_cert_t));

    /* 简化解析：提取关键字段 */
    int offset = 0;

    /* SEQUENCE */
    if (der[offset] != 0x30) return X509_ERR_PARSE;
    offset++;
    int total_len = x509_read_length(der, &offset, len);
    if (total_len < 0) return X509_ERR_PARSE;

    /* tbsCertificate SEQUENCE */
    if (der[offset] != 0x30) return X509_ERR_PARSE;
    offset++;
    int tbs_len = x509_read_length(der, &offset, len);
    if (tbs_len < 0) return X509_ERR_PARSE;

    /* version [0] EXPLICIT */
    if (der[offset] == 0xA0) {
        offset++;
        int ver_len = x509_read_length(der, &offset, len);
        if (ver_len > 0 && der[offset] == 0x02) {
            offset++;
            x509_read_length(der, &offset, len);
            cert->version = der[offset];
            offset++;
        }
    } else {
        cert->version = X509_VERSION_1;
    }

    /* serialNumber INTEGER */
    if (der[offset] == 0x02) {
        offset++;
        int serial_len = x509_read_length(der, &offset, len);
        if (serial_len > 0 && serial_len <= X509_MAX_SERIAL_LEN) {
            memcpy(cert->serial, &der[offset], serial_len);
            cert->serial_len = serial_len;
            offset += serial_len;
        }
    }

    /* signature AlgorithmIdentifier SEQUENCE */
    if (der[offset] == 0x30) {
        offset++;
        int alg_len = x509_read_length(der, &offset, len);
        offset += alg_len;
        cert->sig_alg = X509_SIG_SHA256_RSA;  /* 简化 */
    }

    /* issuer Name SEQUENCE */
    if (der[offset] == 0x30) {
        offset++;
        int issuer_len = x509_read_length(der, &offset, len);
        /* 简化：提取CN */
        strncpy(cert->issuer, "Unknown CA", X509_MAX_NAME_LEN - 1);
        offset += issuer_len;
    }

    /* validity SEQUENCE */
    if (der[offset] == 0x30) {
        offset++;
        int validity_len = x509_read_length(der, &offset, len);
        /* 简化：设置默认有效期 */
        cert->not_before = 0;
        cert->not_after = 0xFFFFFFFF;
        offset += validity_len;
    }

    /* subject Name SEQUENCE */
    if (der[offset] == 0x30) {
        offset++;
        int subject_len = x509_read_length(der, &offset, len);
        strncpy(cert->subject, "Unknown", X509_MAX_NAME_LEN - 1);
        offset += subject_len;
    }

    /* SubjectPublicKeyInfo SEQUENCE */
    if (der[offset] == 0x30) {
        offset++;
        int spki_len = x509_read_length(der, &offset, len);
        cert->key_alg = X509_KEY_RSA;  /* 简化 */
        cert->public_key_len = spki_len > 512 ? 512 : spki_len;
        memcpy(cert->public_key, &der[offset], cert->public_key_len);
        offset += spki_len;
    }

    cert->valid = 1;
    vga_printf("[X509] cert parse ok: %s\n", cert->subject);
    return 0;
}

/* 验证证书签名 */
int x509_verify(const x509_cert_t *cert, const x509_cert_t *ca_cert)
{
    if (!cert || !ca_cert) return X509_ERR_SIGNATURE;
    if (!cert->valid || !ca_cert->valid) return X509_ERR_SIGNATURE;

    /* 简化：验证颁发者匹配 */
    if (strcmp(cert->issuer, ca_cert->subject) != 0) {
        return X509_ERR_SIGNATURE;
    }

    /* 简化：验证CA权限 */
    if (!ca_cert->is_ca) {
        return X509_ERR_CHAIN;
    }

    vga_printf("[X509] cert sig verify ok: %s\n", cert->subject);
    return X509_VALID;
}

/* 验证证书链 */
int x509_verify_chain(const x509_cert_t *chain, int chain_len,
                      const x509_cert_t *trusted_cas_list, int ca_count)
{
    if (!chain || chain_len <= 0) return X509_ERR_CHAIN;

    /* 验证链中每个证书 */
    for (int i = 0; i < chain_len; i++) {
        if (!chain[i].valid) return X509_ERR_CHAIN;

        /* 查找颁发者 */
        int found = 0;
        for (int j = i + 1; j < chain_len; j++) {
            if (strcmp(chain[i].issuer, chain[j].subject) == 0) {
                if (x509_verify(&chain[i], &chain[j]) != X509_VALID) {
                    return X509_ERR_SIGNATURE;
                }
                found = 1;
                break;
            }
        }

        /* 在受信任CA中查找 */
        if (!found && trusted_cas_list && ca_count > 0) {
            for (int j = 0; j < ca_count; j++) {
                if (strcmp(chain[i].issuer, trusted_cas_list[j].subject) == 0) {
                    if (x509_verify(&chain[i], &trusted_cas_list[j]) != X509_VALID) {
                        return X509_ERR_SIGNATURE;
                    }
                    found = 1;
                    break;
                }
            }
        }

        if (!found) return X509_ERR_UNTRUSTED;
    }

    vga_puts("[X509] chain verify ok \n");
    return X509_VALID;
}

/* 检查有效期 */
int x509_check_date(const x509_cert_t *cert, uint32_t current_time)
{
    if (!cert) return X509_ERR_PARSE;
    if (current_time < cert->not_before) return X509_ERR_NOT_YET_VALID;
    if (current_time > cert->not_after) return X509_ERR_EXPIRED;
    return X509_VALID;
}

/* 检查主机名 */
int x509_check_hostname(const x509_cert_t *cert, const char *hostname)
{
    if (!cert || !hostname) return -1;

    /* 简化：检查subject中的CN */
    if (strstr(cert->subject, hostname) != NULL) return 0;

    /* 通配符匹配 */
    if (cert->subject[0] == '*' && cert->subject[1] == '.') {
        const char *domain = strchr(hostname, '.');
        if (domain && strcmp(domain, &cert->subject[1]) == 0) return 0;
    }

    return -1;
}

/* 添加受信任CA */
int x509_add_trusted_ca(const x509_cert_t *ca)
{
    if (!ca || trusted_ca_count >= X509_MAX_TRUSTED_CAS) return -1;
    trusted_cas[trusted_ca_count++] = *ca;
    vga_printf("[X509] add trusted CA: %s\n", ca->subject);
    return 0;
}

/* 获取受信任CA列表 */
int x509_get_trusted_cas(x509_cert_t *cas, int max)
{
    if (!cas || max <= 0) return 0;
    int count = trusted_ca_count < max ? trusted_ca_count : max;
    for (int i = 0; i < count; i++) {
        cas[i] = trusted_cas[i];
    }
    return count;
}

/* 验证错误文本 */
const char *x509_verify_error_text(x509_verify_result_t result)
{
    switch (result) {
        case X509_VALID: return " cert has 效 ";
        case X509_ERR_EXPIRED: return " cert 过期 ";
        case X509_ERR_NOT_YET_VALID: return " cert 尚 not 生效 ";
        case X509_ERR_SIGNATURE: return " sig verify failed ";
        case X509_ERR_CHAIN: return " cert 链 invalid ";
        case X509_ERR_UNTRUSTED: return " untrusted cert ";
        case X509_ERR_REVOKED: return " cert 吊销 ";
        case X509_ERR_PARSE: return " cert parse failed ";
        default: return " unknown error ";
    }
}
