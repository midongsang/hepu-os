/* ============================================================================
 * 赫普OS - CSPRNG安全随机数生成器
 * 密码学安全的伪随机数生成，基于ChaCha20
 * ========================================================================== */

#include <stdint.h>
#include "csprng.h"
#include "vga.h"
#include "string.h"

static csprng_state_t csprng;
static int csprng_initialized = 0;

/* ChaCha20四分之一轮 */
static inline uint32_t csprng_rotl(uint32_t x, int n)
{
    return (x << n) | (x >> (32 - n));
}

static void csprng_chacha20_quarter(uint32_t *a, uint32_t *b, uint32_t *c, uint32_t *d)
{
    *a += *b; *d ^= *a; *d = csprng_rotl(*d, 16);
    *c += *d; *b ^= *c; *b = csprng_rotl(*b, 12);
    *a += *b; *d ^= *a; *d = csprng_rotl(*d, 8);
    *c += *d; *b ^= *c; *b = csprng_rotl(*b, 7);
}

/* ChaCha20块函数 */
static void csprng_chacha20_block(const uint8_t *key, uint32_t counter,
                                   const uint8_t *nonce, uint8_t *out)
{
    static const char constants[16] = "expand 32-byte k";
    uint32_t state[16];

    /* 初始化状态 */
    for (int i = 0; i < 4; i++) {
        state[i] = ((uint32_t)constants[i*4]) |
                   ((uint32_t)constants[i*4+1] << 8) |
                   ((uint32_t)constants[i*4+2] << 16) |
                   ((uint32_t)constants[i*4+3] << 24);
    }
    for (int i = 0; i < 8; i++) {
        state[4+i] = ((uint32_t)key[i*4]) |
                     ((uint32_t)key[i*4+1] << 8) |
                     ((uint32_t)key[i*4+2] << 16) |
                     ((uint32_t)key[i*4+3] << 24);
    }
    state[12] = counter;
    for (int i = 0; i < 3; i++) {
        state[13+i] = ((uint32_t)nonce[i*4]) |
                      ((uint32_t)nonce[i*4+1] << 8) |
                      ((uint32_t)nonce[i*4+2] << 16) |
                      ((uint32_t)nonce[i*4+3] << 24);
    }

    /* 20轮 */
    uint32_t working[16];
    memcpy(working, state, sizeof(state));
    for (int i = 0; i < 10; i++) {
        csprng_chacha20_quarter(&working[0], &working[4], &working[8], &working[12]);
        csprng_chacha20_quarter(&working[1], &working[5], &working[9], &working[13]);
        csprng_chacha20_quarter(&working[2], &working[6], &working[10], &working[14]);
        csprng_chacha20_quarter(&working[3], &working[7], &working[11], &working[15]);
        csprng_chacha20_quarter(&working[0], &working[5], &working[10], &working[15]);
        csprng_chacha20_quarter(&working[1], &working[6], &working[11], &working[12]);
        csprng_chacha20_quarter(&working[2], &working[7], &working[8], &working[13]);
        csprng_chacha20_quarter(&working[3], &working[4], &working[9], &working[14]);
    }

    /* 输出 */
    for (int i = 0; i < 16; i++) {
        uint32_t val = working[i] + state[i];
        out[i*4] = val & 0xFF;
        out[i*4+1] = (val >> 8) & 0xFF;
        out[i*4+2] = (val >> 16) & 0xFF;
        out[i*4+3] = (val >> 24) & 0xFF;
    }
}

/* 初始化CSPRNG */
void csprng_init(void)
{
    memset(&csprng, 0, sizeof(csprng));
    csprng.algorithm = CSPRNG_ALG_CHACHA20;
    csprng.reseed_interval = 1000000;  /* 每100万次重新播种 */
    csprng.initialized = 1;
    csprng_initialized = 1;

    /* 使用默认种子（实际应从硬件熵源获取） */
    static const uint8_t default_seed[32] = {
        0x1A, 0x36, 0x5D, 0xA7, 0xC9, 0x00, 0x1A, 0x36,
        0x5D, 0xA7, 0xC9, 0x00, 0x1A, 0x36, 0x5D, 0xA7,
        0xC9, 0x00, 0x1A, 0x36, 0x5D, 0xA7, 0xC9, 0x00,
        0x1A, 0x36, 0x5D, 0xA7, 0xC9, 0x00, 0x1A, 0x36
    };
    memcpy(csprng.seed, default_seed, 32);
    memcpy(csprng.state, default_seed, 32);

    vga_puts("[CSPRNG] CSPRNG init \n");
    vga_puts("[CSPRNG] algo: ChaCha20, reseed interval: 1000000\n");
}

/* 播种 */
int csprng_seed(const uint8_t *seed, uint32_t len)
{
    if (!csprng_initialized || !seed || len < 16) return -1;

    uint32_t copy_len = len > CSPRNG_SEED_SIZE ? CSPRNG_SEED_SIZE : len;
    memcpy(csprng.seed, seed, copy_len);
    memcpy(csprng.state, seed, copy_len);
    csprng.counter = 0;
    csprng.reseed_counter = 0;

    vga_printf("[CSPRNG] seeded %d bytes\n", copy_len);
    return 0;
}

/* 重新播种 */
int csprng_reseed(const uint8_t *additional_data, uint32_t len)
{
    if (!csprng_initialized) return -1;

    /* 混合附加数据到种子 */
    if (additional_data && len > 0) {
        uint32_t mix_len = len > CSPRNG_SEED_SIZE ? CSPRNG_SEED_SIZE : len;
        for (uint32_t i = 0; i < mix_len; i++) {
            csprng.seed[i] ^= additional_data[i];
        }
    }

    /* 从当前状态生成新种子 */
    uint8_t new_seed[64];
    uint8_t nonce[12] = {0};
    csprng_chacha20_block(csprng.seed, csprng.counter++, nonce, new_seed);
    memcpy(csprng.seed, new_seed, 32);
    memcpy(csprng.state, new_seed + 32, 32);
    csprng.reseed_counter = 0;

    return 0;
}

/* 获取随机字节 */
int csprng_get_bytes(uint8_t *buffer, uint32_t len)
{
    if (!csprng_initialized || !buffer || len == 0) return -1;

    uint32_t offset = 0;
    uint8_t block[64];
    uint8_t nonce[12] = {0};

    while (offset < len) {
        /* 检查是否需要重新播种 */
        if (csprng.reseed_counter >= csprng.reseed_interval) {
            csprng_reseed(NULL, 0);
        }

        /* 生成一个块 */
        csprng_chacha20_block(csprng.seed, csprng.counter++, nonce, block);
        csprng.reseed_counter++;

        uint32_t copy_len = len - offset;
        if (copy_len > 64) copy_len = 64;
        memcpy(buffer + offset, block, copy_len);
        offset += copy_len;
    }

    /* 清零临时缓冲区 */
    memset(block, 0, sizeof(block));
    return 0;
}

/* 获取32位随机数 */
uint32_t csprng_get_uint32(void)
{
    uint32_t val;
    csprng_get_bytes((uint8_t *)&val, sizeof(val));
    return val;
}

/* 获取64位随机数 */
uint64_t csprng_get_uint64(void)
{
    uint64_t val;
    csprng_get_bytes((uint8_t *)&val, sizeof(val));
    return val;
}

/* 获取指定范围的随机数 */
int csprng_get_random_range(uint32_t min, uint32_t max, uint32_t *result)
{
    if (!result || min >= max) return -1;

    uint32_t range = max - min;
    uint32_t limit = UINT32_MAX - (UINT32_MAX % range);
    uint32_t val;

    /* 拒绝采样以避免偏差 */
    do {
        val = csprng_get_uint32();
    } while (val >= limit);

    *result = min + (val % range);
    return 0;
}

/* 健康检查 */
int csprng_health_check(void)
{
    if (!csprng_initialized) return -1;

    /* 生成两个随机数，确保不相同 */
    uint32_t a = csprng_get_uint32();
    uint32_t b = csprng_get_uint32();

    if (a == b) {
        csprng.health_check_passed = 0;
        return -1;
    }

    /* 检查熵：统计字节分布 */
    uint8_t sample[256];
    csprng_get_bytes(sample, sizeof(sample));
    int counts[256] = {0};
    for (int i = 0; i < 256; i++) counts[sample[i]]++;

    int non_zero = 0;
    for (int i = 0; i < 256; i++) {
        if (counts[i] > 0) non_zero++;
    }

    if (non_zero < 100) {
        csprng.health_check_passed = 0;
        return -1;
    }

    csprng.health_check_passed = 1;
    vga_puts("[CSPRNG] health ok \n");
    return 0;
}

/* 获取熵 */
int csprng_get_entropy(uint8_t *buffer, uint32_t len)
{
    if (!buffer || len == 0) return -1;
    return csprng_get_bytes(buffer, len);
}

/* 添加熵 */
void csprng_add_entropy(const uint8_t *data, uint32_t len)
{
    if (!data || len == 0) return;
    csprng_reseed(data, len);
}

/* 算法名称 */
const char *csprng_algorithm_name(csprng_alg_t alg)
{
    switch (alg) {
        case CSPRNG_ALG_CHACHA20: return "ChaCha20";
        case CSPRNG_ALG_AES_CTR: return "AES-CTR";
        case CSPRNG_ALG_HASH_DRBG: return "Hash_DRBG";
        default: return "Unknown";
    }
}
