/* ============================================================================
 * 赫普OS - 系统调用：MEM
 * ========================================================================== */

#include "types.h"
#include <stdint.h>
#include <stddef.h>
#include "syscall.h"
#include "vga.h"
#include "kheap.h"
#include "sched.h"
#include "hepu.h"
#include "fingerprint.h"
#include "vfs.h"
#include "ipc.h"
#include "process.h"
#include "paging.h"
#include "mm.h"
#include "constants.h"
extern const char *hepu_kernel_version;

/* V3.87: 进程堆顶设置/查询 (Linux brk 兼容——标准库 malloc 的基础).
 * 语义 (Linux i386 公开 ABI):
 *   brk(0)        → 返回当前堆顶 (查询)
 *   brk(new_brk)  → 尝试设置堆顶, 返回实际堆顶 (失败时保持原值)
 * 堆区间 [heap_start, heap_end), 由 ELF 加载器初始化 heap_start;
 * 增长逐页 mm_alloc_page + 映射到进程用户目录, 收缩 paging_unmap. */
u32 sys_brk(u32 new_brk, u32 arg2,
                         u32 arg3, u32 arg4)
{
    (void)arg2; (void)arg3; (void)arg4;
    extern process_t *current;
    if (!current || current->heap_start == 0) {
        return 0;   /* 无堆区进程 (原生 .hug/内核): 不支持 */
    }
    if (new_brk == 0) {
        return current->heap_end;   /* 查询当前堆顶 */
    }
    if (new_brk < current->heap_start) {
        return current->heap_end;   /* 低于堆起点: 拒绝 */
    }
    if (new_brk > USER_STACK_ADDR - 0x10000) {
        return current->heap_end;   /* 撞用户栈区 (栈顶之下留 64KB): 拒绝 */
    }

    uint32_t old_pg_end = (current->heap_end + PAGE_SIZE - 1) & ~(PAGE_SIZE - 1);
    uint32_t new_pg_end = (new_brk + PAGE_SIZE - 1) & ~(PAGE_SIZE - 1);

    if (new_pg_end > old_pg_end) {
        /* 增长: 逐页分配物理帧并映射 (用户可读写) */
        for (uint32_t a = old_pg_end; a < new_pg_end; a += PAGE_SIZE) {
            uint32_t frame = mm_alloc_page();
            if (!frame) {
                return current->heap_end;   /* 内存不足: 保持原堆顶 */
            }
            if (paging_map(current->page_dir, a, frame,
                           PAGE_PRESENT | PAGE_WRITE | PAGE_USER) < 0) {
                return current->heap_end;
            }
        }
    } else if (new_pg_end < old_pg_end) {
        /* 收缩: 解除映射 (物理帧由 paging_unmap 归还) */
        for (uint32_t a = new_pg_end; a < old_pg_end; a += PAGE_SIZE) {
            paging_unmap(current->page_dir, a);
        }
    }

    current->heap_end = new_brk;
    return new_brk;
}

u32 sys_malloc(u32 size, u32 arg2,
                           u32 arg3, u32 arg4)
{
    (void)arg2; (void)arg3; (void)arg4;
    return (u32)kmalloc(size);
}

u32 sys_free(u32 ptr, u32 arg2,
                         u32 arg3, u32 arg4)
{
    (void)arg2; (void)arg3; (void)arg4;
    kfree((void *)ptr);
    return 0;
}

u32 sys_shmget(u32 key, u32 size,
                           u32 arg3, u32 arg4)
{
    (void)arg3; (void)arg4;
    return ipc_shm_get(key, size);
}

u32 sys_shmat(u32 shm_id, u32 arg2,
                          u32 arg3, u32 arg4)
{
    (void)arg2; (void)arg3; (void)arg4;
    return (u32)ipc_shm_attach(shm_id, sched_current_pid());
}

/* V3.77: 释放共享内存段（补 shmget 回收路径, 防止反复分配耗尽 kheap） */
u32 sys_shmdt(u32 shm_id, u32 arg2,
                          u32 arg3, u32 arg4)
{
    (void)arg2; (void)arg3; (void)arg4;
    return (u32)ipc_shm_release(shm_id, sched_current_pid());
}

u32 sys_mmap(u32 addr, u32 length, u32 prot, u32 flags)
{
    (void)addr; (void)prot; (void)flags;
    return (u32)kmalloc(length);
}

u32 sys_munmap(u32 addr, u32 length, u32 arg3, u32 arg4)
{
    (void)length; (void)arg3; (void)arg4;
    kfree((void *)addr);
    return 0;
}

u32 sys_mprotect(u32 addr, u32 length, u32 prot, u32 arg4)
{
    (void)addr; (void)length; (void)prot; (void)arg4;
    return 0;
}

