/* ============================================================================
 * 赫普OS - 网络系统调用（从syscall.c拆分）
 * ========================================================================== */

#include <stdint.h>
#include "types.h"
#include "syscall.h"
#include "socket.h"
#include "vga.h"
#include "string.h"
#include "process.h"

u32 sys_socket(u32 domain, u32 type, u32 protocol, u32 arg4)
{
    (void)domain; (void)type; (void)protocol; (void)arg4;
    extern int sys_socket_impl(int domain, int type, int protocol);
    return (u32)sys_socket_impl(domain, type, protocol);
}

u32 sys_bind(u32 fd, u32 addr_ptr, u32 addrlen, u32 arg4)
{
    (void)fd; (void)addr_ptr; (void)addrlen; (void)arg4;
    extern int sys_bind_impl(int fd, sockaddr_in_t *addr);
    return (u32)sys_bind_impl(fd, (sockaddr_in_t *)addr_ptr);
}

u32 sys_listen(u32 fd, u32 backlog, u32 arg3, u32 arg4)
{
    (void)fd; (void)backlog; (void)arg3; (void)arg4;
    extern int sys_listen_impl(int fd, int backlog);
    return (u32)sys_listen_impl(fd, backlog);
}

u32 sys_accept(u32 fd, u32 addr_ptr, u32 addrlen_ptr, u32 arg4)
{
    (void)fd; (void)addr_ptr; (void)addrlen_ptr; (void)arg4;
    extern int sys_accept_impl(int fd, sockaddr_in_t *addr);
    return (u32)sys_accept_impl(fd, (sockaddr_in_t *)addr_ptr);
}

u32 sys_connect(u32 fd, u32 addr_ptr, u32 addrlen, u32 arg4)
{
    (void)fd; (void)addr_ptr; (void)addrlen; (void)arg4;
    extern int sys_connect_impl(int fd, sockaddr_in_t *addr);
    return (u32)sys_connect_impl(fd, (sockaddr_in_t *)addr_ptr);
}

u32 sys_send(u32 fd, u32 buf_ptr, u32 len, u32 flags)
{
    (void)fd; (void)buf_ptr; (void)len; (void)flags;
    extern int sys_send_impl(int fd, const void *buf, u32 len, int flags);
    return (u32)sys_send_impl(fd, (const void *)buf_ptr, len, flags);
}

u32 sys_recv(u32 fd, u32 buf_ptr, u32 len, u32 flags)
{
    (void)fd; (void)buf_ptr; (void)len; (void)flags;
    extern int sys_recv_impl(int fd, void *buf, u32 len, int flags);
    return (u32)sys_recv_impl(fd, (void *)buf_ptr, len, flags);
}

