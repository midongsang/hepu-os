/* ============================================================================
 * 赫普OS (HEPU Hyper Evolve OS) - 内核主入口 V0.2
 * 新增：物理内存管理、分页、内核堆、进程管理、系统调用
 * ========================================================================== */

#include <stdint.h>
#include <stddef.h>
#include "hepu.h"
extern void syscall_dbg_check(const char *);
extern void serial_puts(unsigned short, const char *);
#include "vga.h"
#include "types.h"
#include "gdt.h"
#include "idt.h"
#include "fingerprint.h"
#include "mm.h"
#include "paging.h"
#include "kheap.h"
#include "sched.h"
#include "process.h"
#include "syscall.h"
#include "hal.h"
#include "ipc.h"
#include "string.h"
#include "pic.h"
#include "pit.h"
#include "irq.h"
#include "keyboard.h"
#include "tss.h"
#include "initrd.h"
#include "vfs.h"
#include "devfs.h"
#include "net.h"
#include "touch.h"
#include "smp.h"
#include "dynld.h"
#include "usb.h"
#include "pm.h"
#include "security.h"
#include "dtb.h"
#include "audio.h"
#include "camera.h"
#include "bluetooth.h"
#include "wifi.h"
#include "arp.h"
#include "dhcp.h"
#include "dns.h"
#include "icmp.h"
#include "http.h"
#include "tls.h"
#include "tcp.h"
#include "websocket.h"
#include "x509.h"
#include "csprng.h"
#include "ecdhe.h"
#include "sha.h"
#include "hmac.h"
#include "hkdf.h"
#include "rsa.h"
#include "http2.h"
#include "tls_handshake.h"
#include "quic.h"
#include "http3.h"
#include "doq.h"
#include "quic_0rtt.h"
#include "quic_migration.h"
#include "quic_recovery.h"
#include "mp_quic.h"
#include "quic_datagram.h"
#include "qpack_dynamic.h"
#include "init_sequence.h"
#include "klog.h"
#include "kunit.h"
#include "kbench.h"
#include "kunit_log.h"
#include "services.h"
#include "gpu.h"
#include "sensors.h"
#include "gps.h"
#include "ota.h"
#include "codec.h"
#include "compositor.h"
#include "input.h"
#include "trace.h"
#include "media.h"
#include "camera_hal.h"
#include "ril.h"
#include "appframework.h"
#include "packagemanager.h"
#include "notification.h"
#include "windowsystem.h"
#include "share.h"
#include "account.h"
#include "systemui.h"
#include "webengine.h"
#include "ai.h"
#include "security2.h"
#include "media2.h"
#include "desktopmode.h"
#include "gameframework.h"
#include "enterprise.h"
#include "devtools.h"
#include "compat.h"
#include "fs2.h"
#include "net2.h"
#include "bt2.h"
#include "usb2.h"
#include "gfx2.h"
#include "camera2.h"
#include "audio2.h"
#include "telecom2.h"
#include "ai2.h"
#include "carlink.h"
#include "enterprise2.h"
#include "kernel_opt.h"
#include "drivers2.h"
#include "fs3.h"
#include "net3.h"
#include "appeco.h"
#include "kernel_core.h"
#include "drivers_real.h"
#include "userland.h"
#include "fs_real.h"
#include "bootchain.h"
#include "kdebug.h"
#include "kperf.h"
#include "distributed.h"
#include "hhal.h"
#include "hdpk.h"
#include "device_support.h"
#include "fp_enhanced.h"
#include "phone_service.h"
#include "sms_service.h"
#include "settings_app.h"
#include "file_manager.h"
#include "camera_app.h"
#include "gallery_app.h"
#include "browser_app.h"
#include "app_store.h"
#include "system_tools.h"
#include "music_player.h"
#include "video_player.h"
#include "photo_editor.h"
#include "voice_recorder.h"
#include "audio_effects.h"
#include "hug_sdk.h"
#include "hug_template.h"
#include "hug_debugger.h"
#include "hug_depman.h"
#include "apk_parser.h"
#include "microg_service.h"
#include "art_runtime.h"
#include "compat_layer.h"
#include "secure_boot.h"
#include "boot_optimizer.h"
#include "memory_optimizer.h"
#include "kernel_slimmer.h"
#include "perf_profiler.h"
#include "hepu_brand.h"
#include "app_container.h"
#include "distributed_os.h"
#include "car_connect.h"
#include "privacy_compute.h"
#include "realtime_kernel.h"
#include "power_optimizer.h"
#include "permission_manager.h"
#include "notification_center.h"
#include "i18n_system.h"
#include "multilingual_ime.h"
#include "backup_restore.h"
#include "storage_manager.h"
#include "multi_user.h"
#include "system_stability.h"
#include "app_freeze.h"
#include "id_randomizer.h"
#include "elastic_desktop.h"
#include "ai_notification.h"
#include "creator_mode.h"
#include "onboarding.h"
#include "lowmem_throttle.h"
#include "hdpk_template.h"
#include "android_api.h"
#include "driver_manager.h"
#include "bist.h"
#include "ai_assistant.h"
#include "socket.h"
#include "mount.h"
#include "quota.h"
#include "fs_registry.h"
#include "vfat.h"
#include "journal.h"
#include "ide.h"
#include "ext4.h"
#include "fscrypt.h"
#include "partition.h"
#include "unified_driver.h"
#include "ahci.h"
#include "nvme.h"
#include "exfat.h"
#include "ntfs.h"
#include "aes.h"
#include "eth.h"
#include "wifi.h"
#include "arp.h"
#include "dhcp.h"
#include "dns.h"
#include "icmp.h"
#include "http.h"
#include "tls.h"
#include "tcp.h"
#include "websocket.h"
#include "x509.h"
#include "csprng.h"
#include "ecdhe.h"
#include "sha.h"
#include "hmac.h"
#include "hkdf.h"
#include "rsa.h"
#include "http2.h"
#include "tls_handshake.h"
#include "quic.h"
#include "http3.h"
#include "doq.h"
#include "quic_0rtt.h"
#include "quic_migration.h"
#include "quic_recovery.h"
#include "mp_quic.h"
#include "quic_datagram.h"
#include "qpack_dynamic.h"
#include "init_sequence.h"
#include "kunit.h"
#include "kbench.h"
#include "kunit_log.h"

/* 用户态程序入口 (定义在 user/init/user_init.S) */
extern void user_init_start(void);
extern void user_init_end(void);

/* 第二个用户态进程 (定义在 user/apps/procb/procb.S) */
extern void procb_start(void);

/* initrd 镜像符号 (由 objcopy 生成) */
extern uint8_t _binary_build_v250_initrd_img_start[];
extern uint8_t _binary_build_v250_initrd_img_end[];

/* Multiboot 信息结构 */
typedef struct {
    uint32_t flags;
    uint32_t mem_lower;
    uint32_t mem_upper;
    uint32_t boot_device;
    uint32_t cmdline;
    uint32_t mods_count;
    uint32_t mods_addr;
} multiboot_info_t;

extern hepu_fingerprint_t hepu_fingerprint;

/* V4.10-E55: 版本体系修正——内核版本与系统版本分离:
 *  - hepu_kernel_version: 内核自身版本(独立演进)
 *  - hepu_system_version: 系统分发版本(与镜像命名 hepu-os-vX.Y.* 一致) */
const char *hepu_kernel_version = "1.0.2";
const char *hepu_system_version = "1.02";
const char *hepu_kernel_name = "HEPU Hyper Evolve OS";

/* 简单的用户态测试函数（原型阶段在内核态模拟） */
static void __attribute__((unused)) user_test_function(void)
{
    /* 模拟用户态通过系统调用打印 */
    const char *msg = "  [user-mode sim] Hello! I am the first Hepu OS user process.\n";
    syscall_handler(SYS_PRINT, (uint32_t)msg, 0, 0, 0);

    uint32_t ver_ptr = syscall_handler(SYS_HEPU_INFO, 0, 0, 0, 0);
    syscall_handler(SYS_PRINT, ver_ptr, 0, 0, 0);
    syscall_handler(SYS_PRINT, (uint32_t)"\n", 0, 0, 0);
}

#ifdef HEPU_BOOT_DEBUG
/* V2.08: 内核启动蜂鸣诊断已移除——用户明确要求去蜂鸣, 改用文本日志.
   启动进度完全依赖屏幕KLOG文本(K0-K5, boot.S VGA直写) + 引导器行8-12文本标签. */
#endif

void hepu_kernel_main(uint32_t magic, multiboot_info_t *mb_info)
{
    (void)magic;
#ifdef HEPU_BOOT_DEBUG
    /* 诊断K4: 进入内核主函数(BSS清零+call都成功).
       屏幕日志主通道: 显示"K4 MAIN CALL"到行4(与boot.S的KLOG一致).
       V2.08: 已去除K4蜂鸣7次, 纯文本日志. */
    {
        extern char klog4[];
        __asm__ volatile(
            "movw $0x10, %%ax\n\t"
            "movw %%ax, %%es\n\t"
            "movl $0xB8000, %%edi\n\t"
            "movl $640, %%ecx\n\t"       /* 行4*160 */
            "addl %%ecx, %%edi\n\t"
            "movl %0, %%esi\n\t"
            "1: lodsb\n\t"
            "testb %%al, %%al\n\t"
            "jz 2f\n\t"
            "movb %%al, %%es:(%%edi)\n\t"
            "movb $0x0F, %%es:1(%%edi)\n\t"
            "addl $2, %%edi\n\t"
            "jmp 1b\n\t"
            "2:\n\t"
            : : "r"(klog4) : "ax", "cx", "di", "si", "memory");
    }
#endif

    /* ---- 基础初始化 ---- */
    vga_init();
    vga_clear();
    /* V3.81 调试: 提前初始化 COM1 串口(原在TSS后), 让 QEMU -serial file 记录全部日志 */
    {
        extern void serial_init_com1(void);
        serial_init_com1();
    /* EARLY 探针: 启动最早期读表区物理内容, 区分"引导器未加载.data"与"运行中写坏" */
    extern void serial_puthex(uint16_t, uint32_t);
    {
        uint32_t t0 = *(volatile uint32_t *)0x001498A0; /* V3.82段重排后新表区 */
        uint32_t v0 = *(volatile uint32_t *)0x00149800;
        serial_puts(0x3F8, "[EARLY] tbl0=");
        serial_puthex(0x3F8, t0);
        serial_puts(0x3F8, " ver=");
        serial_puthex(0x3F8, v0);
        serial_puts(0x3F8, "\n");
    }
    }
    /* V3.82: dump SeaBIOS 文本模式 VGA 寄存器 (对照 text_mode 恢复序列) */
    extern void vga_dump_regs(void);
    vga_dump_regs();
    gdt_init();
    idt_init();
    extern void early_console_init(void);
    early_console_init();
    extern void multiboot_init(uint32_t, void *);
    multiboot_init(magic, mb_info);
    extern void cpu_init(void);
    cpu_init();
    syscall_dbg_check("after-cpu");

    /* ---- 启动横幅 ---- */
    vga_set_color(VGA_COLOR_LIGHT_CYAN, VGA_COLOR_BLACK);
    vga_puts("+==============================================+\n");
    vga_puts("| HEPU HYPER EVOLVE OS Hepu Hyper Evolve OS |\n");
    vga_puts("+==============================================+\n\n");

    vga_set_color(VGA_COLOR_LIGHT_GREY, VGA_COLOR_BLACK);
    vga_printf("Kernel Version : %s\n", hepu_kernel_version);
    vga_printf("Architecture   : x86 (i686)\n");

    uint32_t mem_kb = 0;
    if (mb_info && (mb_info->flags & 0x1)) {
        mem_kb = mb_info->mem_lower + mb_info->mem_upper;
        vga_printf("Total Memory   : %d KB (%d MB)\n", mem_kb, mem_kb / 1024);
    }
    vga_putc('\n');

    /* ---- 版权指纹校验 ---- */
    vga_set_color(VGA_COLOR_YELLOW, VGA_COLOR_BLACK);
    vga_puts("[HEPU] kernel fingerprint verify ...\n");
    fingerprint_result_t fp_result = fingerprint_verify(&hepu_fingerprint);
    if (fp_result.valid) {
        vga_set_color(VGA_COLOR_GREEN, VGA_COLOR_BLACK);
        vga_printf("[HEPU] fingerprint ok: %s\n", hepu_fingerprint.name);
        vga_printf("[HEPU] License: %s\n", hepu_fingerprint.license);
    } else {
        vga_set_color(VGA_COLOR_RED, VGA_COLOR_BLACK);
        vga_puts("[HEPU] warn: kernel fingerprint tampered !\n");
    }
    vga_set_color(VGA_COLOR_LIGHT_GREY, VGA_COLOR_BLACK);
    vga_putc('\n');

    /* ---- 内存管理初始化 ---- */
    vga_puts("=== memory subsystem ===\n");

    /* 物理内存管理：位图放在 2MB 处 */
    if (mem_kb > 0) {
        mm_init(mem_kb, 0x00200000);
    }
    syscall_dbg_check("after-mm-init");

    /* V2.17修复: 保留内核映像+BSS+堆区域, 防止物理页分配器
     * 把内核/堆所在的页帧分配给页表/进程, 造成数据踩踏.
     * BSS高达106MB(0x16B000-0x6A13000), 原型阶段不启用分页,
     * 全部按物理地址直访, 必须整体保留. */
    extern char __bss_end[];
    {
        /* V3.83: 保留区必须含 .stack 段(在 __bss_end 之后、__kernel_end 之前).
         * 原只保留到 __bss_end, alloc_frame 把 .stack 页(0x6B2A000-0x6B2E000)
         * 当空闲页分配出去→页表写入覆盖内核栈→返回地址被破坏→EIP 跳 0x1. */
        extern uint8_t __kernel_end[];
        uint32_t kern_reserve_end = ((uint32_t)__kernel_end + 0xFFF) & ~0xFFF;
        mm_add_region(0x00000000, kern_reserve_end, MEM_REGION_KERNEL);
        vga_printf("[MM] reserved kernel+bss+stack region: 0x0 - 0x%x (%d MB)\n",
                   kern_reserve_end, kern_reserve_end / (1024 * 1024));
    }

    /* V3.86: 堆保留提前到 paging_init 之前——paging_init 的 alloc_frame
     * (内核页表帧) 会从第一个空闲页(堆起点 0x6B2E000 区)分配, 与 kmalloc
     * 堆数据重叠踩踏(实测页表帧 0x6B67000 落在 kheap 已用区内);
     * 保留范围扩到 kheap 全容量 32MB. */
    extern uint8_t __kernel_end[];
    uint32_t heap_base = ((uint32_t)__kernel_end + 0xFFF) & ~0xFFF;
    mm_add_region(heap_base, 64 * 1024 * 1024, MEM_REGION_RESERVED);

    /* 分页初始化（身份映射256MB全物理直映） */
    paging_init(mem_kb);
    syscall_dbg_check("after-paging");
    /* V3.86: 启用分页——V2.x 注释"原型阶段不启用分页"已过时:
     * V3.83 起 用户进程独享页目录/CR3切换/demand paging/TSS 全部按
     * 分页启用设计; 不分页则用户代码必须落在物理存在的低地址,
     * .hug 固定基址 0x20000000(512MB) 物理不存在 → clock 应用
     * 进入用户态即空转(EIP=0x20Axxxxx 爬升). 内核 identity
     * 0-256MB 直映保证内核代码/堆/显存访问无感. */
    paging_enable();

    /* V2.17修复: 内核堆移到 BSS 之后(0x6A13000), 容量16MB.
     * 原放在4MB处与BSS重叠, kmalloc分配出的块就是BSS全局变量地址,
     * 互相踩踏导致 kheap OOM / kernel stack alloc fail. */
    /* V3.82修复: 堆起点必须放在 initrd 数据区之后——
     * initrd(objcopy 嵌入)与 .bss 相邻, 原 __bss_end 会落在 initrd 内部,
     * 堆初始化覆盖 initrd 尾部(后部文件如 top.hug/clock.hug 读回 0xFF) */
    /* V3.83根治: 堆起点改到 __kernel_end(.bss 末尾)之后——
     * .bss 含大量巨型静态数组(documents 17MB/sdk 12MB/notes 1.2MB 等, 总计~110MB),
     * 链接器把它们排到 0x1A5000+ (initrd 尾) 与旧堆区重叠:
     * notes_init 的 memset(&notes,0,1.2MB) 恰好清零 0x1C4710 的 compositor 块头
     * → kheap 链表断裂 → 33MB 空闲却分配 16KB 失败(伪 OOM)。
     * 分页已启用(V3.86), 内核 identity 0-256MB 直映, 107MB 物理区
     * 虚拟=物理可直接访问; QEMU -m 256M / 真机 ≥192MB 均可行。 */
    {
        /* V2.26: 扩大到32MB——支持将IDE磁盘(16MB ext2镜像)读入内存挂载.
         * 堆保留区已在 paging_init 前注册(32MB), 此处只初始化堆. */
        kheap_init(heap_base, 64 * 1024 * 1024);
    }
    syscall_dbg_check("after-mm");
    extern void slab_init(void);
    slab_init();
    extern void reclaim_init(void);
    reclaim_init();
    extern void swap_init(void);
    swap_init();
    extern void hugetlb_init(void);
    hugetlb_init();
    extern void mempool_init(void);
    mempool_init();
    extern void acpi_init(void);
    acpi_init();

    /* V3.87: 多格式兼容层 (Linux ELF32 / 后续 PE/Mach-O) */
    extern void binfmt_init(void);
    extern void binfmt_selftest(void);
    binfmt_init();
    binfmt_selftest();

    /* 测试内核堆 */
    void *test_ptr = kmalloc(256);
    if (test_ptr) {
        vga_set_color(VGA_COLOR_GREEN, VGA_COLOR_BLACK);
        vga_printf("[KHEAP] kmalloc(256) = 0x%x test passed \n", (uint32_t)test_ptr);
        kfree(test_ptr);
    }
    vga_set_color(VGA_COLOR_LIGHT_GREY, VGA_COLOR_BLACK);
    vga_putc('\n');

    /* ---- 进程与调度初始化 ---- */
    vga_puts("=== process subsystem ===\n");
    sched_init();
    syscall_dbg_check("after-sched");
    process_init();
    syscall_dbg_check("after-proc");
    ipc_init();
    extern void ipc_sem_init(void);
    ipc_sem_init();
    extern void ipc_mutex_init(void);
    ipc_mutex_init();
    extern void ipc_cond_init(void);
    ipc_cond_init();
    extern void ipc_fifo_init(void);
    ipc_fifo_init();
    extern void ipc_perm_init(void);
    ipc_perm_init();
    syscall_dbg_check("after-ipc");
    unified_driver_init();  /* 统一驱动框架：包含hal+hhal+driver_manager */
    extern void hal_device_init(void);
    hal_device_init();
    extern void hotplug_init(void);
    hotplug_init();
    extern void hal_irq_init(void);
    hal_irq_init();
    extern void hal_clock_init(uint32_t);
    hal_clock_init(1000);
    extern void hal_gpio_init(void);
    hal_gpio_init();
    extern void dma_init(void);
    dma_init();
    extern void power_init(void);
    power_init();
    /* V2.54: 手机电源管理 (pm.c) 接入——状态/电池/休眠唤醒 */
    extern void pm_init(void);
    pm_init();
    syscall_dbg_check("after-drv");
    /* hal_init(); - 已整合到unified_driver_init */   /* 已过 process/ipc/driver 段 */
    syscall_init();
    syscall_dbg_check("after-syscall-init");
    vga_putc('\n');
    serial_puts(0x3F8, "[M1] after newline\n");

    /* ---- 系统调用测试 ---- */
    vga_puts("=== syscall test ===\n");
    serial_puts(0x3F8, "[M2] after banner\n");
    vga_set_color(VGA_COLOR_GREEN, VGA_COLOR_BLACK);
    serial_puts(0x3F8, "[M3] after setcolor\n");

    /* 测试 SYS_HEPU_INFO */
    serial_puts(0x3F8, "[M4] before handler\n");
    uint32_t ver = syscall_handler(SYS_HEPU_INFO, 0, 0, 0, 0);
    vga_printf("[SYSCALL] SYS_HEPU_INFO -> %s\n", (char *)ver);

    /* 测试 SYS_HEPU_FP_VERIFY */
    uint32_t fp_ok = syscall_handler(SYS_HEPU_FP_VERIFY, 0, 0, 0, 0);
    vga_printf("[SYSCALL] SYS_HEPU_FP_VERIFY -> %s\n",
               fp_ok == 0 ? " fingerprint has 效 " : " fingerprint invalid ");

    /* 测试 SYS_MALLOC / SYS_FREE */
    uint32_t alloc = syscall_handler(SYS_MALLOC, 128, 0, 0, 0);
    vga_printf("[SYSCALL] SYS_MALLOC(128) -> 0x%x\n", alloc);
    syscall_handler(SYS_FREE, alloc, 0, 0, 0);
    vga_puts("[SYSCALL] SYS_FREE -> ok");

    vga_set_color(VGA_COLOR_LIGHT_GREY, VGA_COLOR_BLACK);
    vga_putc('\n');

    vga_putc('\n');

    /* ---- 硬件中断子系统 ---- */
    vga_puts("=== HW IRQ subsystem ===\n");
    pic_init();
    irq_init();
    pit_init();
    keyboard_init();
    tss_init();
    irq_register_handler(IRQ_TIMER, pit_handler);
    __asm__ volatile ("sti");
    vga_puts("[IRQ] global IRQ enabled \n");
    serial_puts(0x3F8, "[LIVE] sti done\n");
    vga_putc('\n');

    /* ---- initrd 文件系统 ---- */
    vga_puts("=== initrd fs ===\n");
    uint32_t initrd_addr = (uint32_t)_binary_build_v250_initrd_img_start;
    uint32_t initrd_sz = (uint32_t)(_binary_build_v250_initrd_img_end - _binary_build_v250_initrd_img_start);
    initrd_init(initrd_addr, initrd_sz);
    if (initrd_ready()) {
        initrd_list();
    }
    serial_puts(0x3F8, "[LIVE] initrd done\n");
    vga_putc('\n');

    /* ---- V2.23: RTC 实时时钟 + 串口 UART ----
     * 提前到 init_sequence 之前初始化, 使 FS/IDE 等阶段可用串口调试输出 */
    extern void rtc_init(void);
    extern void serial_init_com1(void);
    rtc_init();
    serial_puts(0x3F8, "[LIVE] rtc done\n");
    serial_init_com1();

    /* V2.35: 图形化开机 logo (串口就绪, 显示约2.5秒后继续) */
    {
        extern void splash_show(void);
        splash_show();
    }
    serial_puts(0x3F8, "[LIVE] splash done\n");

    /* ---- VFS 虚拟文件系统 ---- */
    vga_puts("=== VFS VFS ===\n");
    /* V2.30: 捕获引导器 VGA 诊断 → 内核日志(dmesg 可回溯) */
    klog_capture_boot();
    klog_printf("[KLOG] kernel log started\n");

    hepu_init_sequence();

    /* V3.87 阶段B-2: initrd 文件挂载到 VFS /app/ —— .exe/.elf/.hug 应用
     * 以"已安装应用"形式暴露给文件系统 (APK 式: 应用区只读, 系统区不可见) */
    {
        extern int initrd_vfs_mount(const char *);
        initrd_vfs_mount("/app");
    }
        kunit_init();
    kbench_init();
    extern int kbench_run_kernel(void);
    kbench_run_kernel();
    kunit_log_init();
    extern void kunit_register_all_suites(void);
    kunit_register_all_suites();
    
    /* ---- 子系统状态汇总 ---- */
    vga_puts("=== microkernel subsystem state ===\n");
    vga_set_color(VGA_COLOR_GREEN, VGA_COLOR_BLACK);
    vga_puts(" [OK] physmem mgr(bitmap allocator)\n");
    vga_puts(" [OK] paging(page dir / pages table framework)\n");
    vga_puts(" [OK] kheap(kmalloc/kfree)\n");
    vga_puts(" [OK] process mgmt(PCB/ ctx switch framework)\n");
    vga_puts(" [OK] syscall(int 0x80, 63 call nums)\n");
    vga_puts(" [OK] IPC msg passing \n");
    vga_puts(" [OK] H-HAL HAL(driver fault isolation)\n");
    vga_puts(" [OK] kernel fingerprint(open-source protection)\n");
    vga_set_color(VGA_COLOR_YELLOW, VGA_COLOR_BLACK);
    vga_puts(" [OK] TSS/ real user-mode switch(ring3)\n");
    vga_puts(" [OK] fs service(ext2/vfat/vfs)\n");
    vga_puts(" [OK] net stack(tcp/udp/dns/http)\n");
    vga_puts(" [OK] graphics(VGA gfx 640x480)\n");
    vga_puts(" [OK] .hug app loader\n");

    vga_set_color(VGA_COLOR_LIGHT_CYAN, VGA_COLOR_BLACK);
    vga_putc('\n');
    vga_puts(" Hepu OS V1.02 microkernel boot done .\n");
    vga_puts(" own your system , own your data , free & controllable , pure and clean .\n");

    /* ---- V3.78: 诊断日志落盘 (ext2 已就绪, 写入 /hepu_boot.log) ---- */
    extern void klog_save_to_disk(void);
        klog_save_to_disk();
    
    vga_set_color(VGA_COLOR_LIGHT_GREY, VGA_COLOR_BLACK);
    vga_putc('\n');

    /* ---- V2.23: PCI 总线探测——自动枚举硬件, 供驱动匹配绑定 ---- */
    extern int pci_scan_all(void);
    extern void pci_dump_devices(void);
    int pci_count = pci_scan_all();
    vga_printf("[PCI] bus scan done: %d device(s) detected\n", pci_count);
    pci_dump_devices();
    vga_putc('\n');
    
    /* ---- V2.23: PCI 设备注册进设备树 (驱动自动匹配基础) ---- */
    extern int pci_bind_to_devtree(void);
    pci_bind_to_devtree();
    
    /* ---- V2.62: USB 驱动栈 (PCI 已扫描, 检测控制器 + 枚举 + HID) ---- */
    extern void usb_init(void);
    usb_init();
    vga_putc('\n');

    /* ---- V2.23: PS/2 鼠标 ---- */
    extern int ps2mouse_init(void);
    ps2mouse_init();
    vga_putc('\n');

    /* ---- V4.35-E80: 输入子系统 + 触屏驱动 (必须先于用户态进程:
     * proc1 SYS_EXIT 会经 sys_exit 直达 shell, 跳过下方代码,
     * 旧位置在进程创建后导致 input 子系统从未初始化, 触屏 dev_id=-1) ---- */
    extern void input_init(void);
    input_init();
    extern int touch_hw_init(void);
    touch_hw_init();

    /* ---- 创建用户态进程并进入 ---- */
    vga_puts("=== user processes ===\n");
    process_t *proc1 = process_create("init",
                                       (uint32_t)user_init_start,
                                       PRIV_USER, 1 /* E1: NORM */);
    process_t *proc2 = process_create("procb",
                                       (uint32_t)procb_start,
                                       PRIV_USER, 1 /* E1: NORM */);
    if (proc1 && proc2) {
        vga_set_color(VGA_COLOR_GREEN, VGA_COLOR_BLACK);
        vga_printf("[PROC] init (PID=%d), procb (PID=%d)\n", proc1->pid, proc2->pid);
        vga_puts("[PROC] preemptive sched ready , timer will switch processes \n");
        vga_set_color(VGA_COLOR_LIGHT_GREY, VGA_COLOR_BLACK);
        vga_putc('\n');
        /* V2.22: 恢复用户态进程 (TSS/用户段/GDT已实现, PAGE_USER已加),
         * init 有限演示后 SYS_EXIT -> sys_exit 启动内核 Shell.
         * 若用户态异常崩溃, process_enter_user_mode 返回时由下方 Shell 兜底. */
            process_enter_user_mode(proc1);
        }

    vga_puts("(start Shell...)\n");

    /* 启动内核 Shell */
    extern void shell_main(void);
    shell_main();
}
