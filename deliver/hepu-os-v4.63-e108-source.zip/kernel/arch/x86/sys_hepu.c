/* ============================================================================
 * 赫普OS - 系统调用：HEPU
 * ========================================================================== */

#include "types.h"
#include <stdint.h>
#include <stddef.h>
#include "syscall.h"
#include "vga.h"
#include "kheap.h"
#include "sched.h"
#include "hepu.h"
#include "fingerprint.h"
#include "vfs.h"
#include "ipc.h"
extern const char *hepu_kernel_version;

u32 sys_hepu_info(u32 arg1, u32 arg2,
                              u32 arg3, u32 arg4)
{
    (void)arg1; (void)arg2; (void)arg3; (void)arg4;
    /* 返回内核版本指针 */
    return (u32)hepu_kernel_version;
}

u32 sys_hepu_fp_verify(u32 arg1, u32 arg2,
                                   u32 arg3, u32 arg4)
{
    (void)arg1; (void)arg2; (void)arg3; (void)arg4;
    extern hepu_fingerprint_t hepu_fingerprint;
    fingerprint_result_t r = fingerprint_verify(&hepu_fingerprint);
    return r.valid ? 0 : 1;
}

u32 sys_print(u32 str_ptr, u32 arg2,
                          u32 arg3, u32 arg4)
{
    (void)arg2; (void)arg3; (void)arg4;
    const char *s = (const char *)str_ptr;
    if (s) vga_puts(s);
    return 0;
}

