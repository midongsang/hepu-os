/* ============================================================================
 * 赫普OS - 系统调用：IPC
 * ========================================================================== */

#include "types.h"
#include <stdint.h>
#include <stddef.h>
#include "syscall.h"
#include "vga.h"
#include "kheap.h"
#include "sched.h"
#include "hepu.h"
#include "fingerprint.h"
#include "vfs.h"
#include "ipc.h"
extern const char *hepu_kernel_version;

u32 sys_ipc_send(u32 target_pid, u32 type,
                             u32 data_ptr, u32 length)
{
    return ipc_send(target_pid, type, (void *)data_ptr, length);
}

u32 sys_ipc_recv(u32 msg_ptr, u32 arg2,
                             u32 arg3, u32 arg4)
{
    (void)arg2; (void)arg3; (void)arg4;
    return ipc_recv(sched_current_pid(), (ipc_message_t *)msg_ptr);
}

u32 sys_pipe(u32 fds_ptr, u32 arg2,
                         u32 arg3, u32 arg4)
{
    (void)arg2; (void)arg3; (void)arg4;
    int fds[2];
    int ret = ipc_pipe(&fds[0], &fds[1]);
    if (ret == 0) {
        int *user_fds = (int *)fds_ptr;
        user_fds[0] = fds[0];
        user_fds[1] = fds[1];
    }
    return ret;
}

u32 sys_poll(u32 fds_ptr, u32 nfds, u32 timeout, u32 arg4)
{
    (void)fds_ptr; (void)nfds; (void)timeout; (void)arg4;
    return 0;
}

u32 sys_select(u32 nfds, u32 readfds, u32 writefds, u32 exceptfds)
{
    (void)nfds; (void)readfds; (void)writefds; (void)exceptfds;
    return 0;
}

