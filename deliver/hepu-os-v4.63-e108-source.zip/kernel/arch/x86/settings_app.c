/* ============================================================================
 * 赫普OS - 系统设置应用
 * ========================================================================== */

#include <stdint.h>
#include "settings_app.h"
#include "vga.h"
#include "string.h"



static settings_app_t sa;

/* 分类名称表 */
static const char *category_names[] = {
    " net & connect ", " device ", " app ", " display ", " 声音 ", " battery ",
    " storage ", " security & 隐私 ", " accounts ", " system ", " 关于手机 ",
    " no 障碍 ", "AI assistant ", " 开发者选 "
};

void settings_init(void)
{
    memset(&sa, 0, sizeof(settings_app_t));
    sa.initialized = 1;
    sa.enabled = 1;
    sa.current_category = SETTING_CAT_SYSTEM;

    /* 注册分类 */
    for (int i = 0; i < 14; i++) {
        sa.categories[i].id = (setting_category_t)i;
        strncpy(sa.categories[i].name, category_names[i], 63);
        sa.categories[i].visible = 1;
    }
    sa.category_count = 14;

    /* 注册常用设置项 */
    /* 网络 */
    settings_register("WiFi", SETTING_CAT_NETWORK, SETTING_TYPE_BOOL, " on / close WiFi", 0);
    settings_register(" BT ", SETTING_CAT_NETWORK, SETTING_TYPE_BOOL, " on / close BT ", 0);
    settings_register(" airplane mode ", SETTING_CAT_NETWORK, SETTING_TYPE_BOOL, " close all no 线 connect ", 0);
    settings_register(" mobile data ", SETTING_CAT_NETWORK, SETTING_TYPE_BOOL, " used 蜂窝 data ", 0);
    settings_register(" hotspot ", SETTING_CAT_NETWORK, SETTING_TYPE_BOOL, " 便携式 WiFi hotspot ", 0);
    settings_register("VPN", SETTING_CAT_NETWORK, SETTING_TYPE_BOOL, " virtual 专用 net ", 0);
    settings_register("NFC", SETTING_CAT_NETWORK, SETTING_TYPE_BOOL, " 近场通信 ", 0);

    /* 显示 */
    settings_register(" 亮度 ", SETTING_CAT_DISPLAY, SETTING_TYPE_SLIDER, " screen 亮度 0-100", 0);
    settings_set_int(sa.item_count - 1, 80);
    settings_register(" auto 亮度 ", SETTING_CAT_DISPLAY, SETTING_TYPE_BOOL, " 根据环境光 auto 调节 ", 0);
    settings_register(" dark mode ", SETTING_CAT_DISPLAY, SETTING_TYPE_BOOL, " 全局深色 master 题 ", 0);
    settings_register(" 字体 size ", SETTING_CAT_DISPLAY, SETTING_TYPE_SLIDER, " 字体 size 0-100", 0);
    settings_set_int(sa.item_count - 1, 50);
    settings_register(" display size ", SETTING_CAT_DISPLAY, SETTING_TYPE_SLIDER, " 界面元素 size 0-100", 0);
    settings_set_int(sa.item_count - 1, 50);
    settings_register(" screen timeout ", SETTING_CAT_DISPLAY, SETTING_TYPE_ENUM, " no ops auto 息屏 time ", 0);
    settings_register(" 护眼 mode ", SETTING_CAT_DISPLAY, SETTING_TYPE_BOOL, " 减少蓝光 ", 0);
    settings_register(" refresh rate ", SETTING_CAT_DISPLAY, SETTING_TYPE_ENUM, " screen refresh rate ", 0);

    /* 声音 */
    settings_register(" 铃声 ", SETTING_CAT_SOUND, SETTING_TYPE_SLIDER, " 铃声音量 0-100", 0);
    settings_set_int(sa.item_count - 1, 70);
    settings_register(" media ", SETTING_CAT_SOUND, SETTING_TYPE_SLIDER, " media 音量 0-100", 0);
    settings_set_int(sa.item_count - 1, 60);
    settings_register(" 闹钟 ", SETTING_CAT_SOUND, SETTING_TYPE_SLIDER, " 闹钟音量 0-100", 0);
    settings_set_int(sa.item_count - 1, 50);
    settings_register(" 通话 ", SETTING_CAT_SOUND, SETTING_TYPE_SLIDER, " 通话音量 0-100", 0);
    settings_set_int(sa.item_count - 1, 80);
    settings_register(" 静音 ", SETTING_CAT_SOUND, SETTING_TYPE_BOOL, " 全局静音 ", 0);
    settings_register(" 震动 ", SETTING_CAT_SOUND, SETTING_TYPE_BOOL, " 触感反馈 ", 0);
    settings_set_bool(sa.item_count - 1, 1);
    settings_register(" DND ", SETTING_CAT_SOUND, SETTING_TYPE_BOOL, " 屏蔽 notify ", 0);

    /* 电池 */
    settings_register(" 省电 mode ", SETTING_CAT_BATTERY, SETTING_TYPE_BOOL, " 限制 next 台活动省电 ", 0);
    settings_register(" 超 level 省电 ", SETTING_CAT_BATTERY, SETTING_TYPE_BOOL, " 仅保留 base 功能 ", 0);
    settings_register(" battery 百分比 ", SETTING_CAT_BATTERY, SETTING_TYPE_BOOL, " status bar display 百分比 ", 0);
    settings_set_bool(sa.item_count - 1, 1);

    /* 存储 */
    settings_register(" storage cleanup ", SETTING_CAT_STORAGE, SETTING_TYPE_ACTION, " cleanup cache & 垃圾 file ", 0);
    settings_register(" default storage ", SETTING_CAT_STORAGE, SETTING_TYPE_ENUM, " default storage bit 置 ", 0);

    /* 安全与隐私 */
    settings_register(" screen lock ", SETTING_CAT_SECURITY, SETTING_TYPE_ENUM, " 锁屏方式 ", 1);
    settings_register(" fingerprint unlock ", SETTING_CAT_SECURITY, SETTING_TYPE_BOOL, " used fingerprint unlock ", 1);
    settings_register(" 面部 unlock ", SETTING_CAT_SECURITY, SETTING_TYPE_BOOL, " used 面部 unlock ", 1);
    settings_register(" 隐私沙盒 ", SETTING_CAT_SECURITY, SETTING_TYPE_BOOL, " app isolation run ", 0);
    settings_set_bool(sa.item_count - 1, 1);
    settings_register(" data 金库 ", SETTING_CAT_SECURITY, SETTING_TYPE_BOOL, " local data encryption storage ", 0);
    settings_set_bool(sa.item_count - 1, 1);
    settings_register(" location ", SETTING_CAT_SECURITY, SETTING_TYPE_BOOL, " 允许 app get bit 置 ", 0);
    settings_register(" camera perm ", SETTING_CAT_SECURITY, SETTING_TYPE_BOOL, " 全局 camera perm ", 0);
    settings_set_bool(sa.item_count - 1, 1);
    settings_register(" 麦克风 perm ", SETTING_CAT_SECURITY, SETTING_TYPE_BOOL, " 全局麦克风 perm ", 0);
    settings_set_bool(sa.item_count - 1, 1);
    settings_register(" secure boot ", SETTING_CAT_SECURITY, SETTING_TYPE_BOOL, " verify system 完整性 ", 1);
    settings_set_bool(sa.item_count - 1, 1);

    /* 系统 */
    settings_register(" system lang ", SETTING_CAT_SYSTEM, SETTING_TYPE_ENUM, " display lang ", 0);
    settings_register(" runtime region ", SETTING_CAT_SYSTEM, SETTING_TYPE_STRING, " system runtime region ", 0);
    settings_register(" auto time ", SETTING_CAT_SYSTEM, SETTING_TYPE_BOOL, " net auto sync time ", 0);
    settings_set_bool(sa.item_count - 1, 1);
    settings_register("24 小 runtime 制 ", SETTING_CAT_SYSTEM, SETTING_TYPE_BOOL, " used 24 小 runtime 制 ", 0);
    settings_register(" system update ", SETTING_CAT_SYSTEM, SETTING_TYPE_ACTION, " check system update ", 0);
    settings_register(" backup ", SETTING_CAT_SYSTEM, SETTING_TYPE_ACTION, " backup settings ", 0);
    settings_register(" reset ", SETTING_CAT_SYSTEM, SETTING_TYPE_ACTION, " resume 出厂 set ", 1);

    /* 关于 */
    settings_register(" system version ", SETTING_CAT_ABOUT, SETTING_TYPE_STRING, "HEPU OS V0.27", 0);
    settings_register(" kernel version ", SETTING_CAT_ABOUT, SETTING_TYPE_STRING, "HEPU Microkernel 0.27", 0);
    settings_register(" model ", SETTING_CAT_ABOUT, SETTING_TYPE_STRING, "HEPU Generic", 0);
    settings_register(" 序列号 ", SETTING_CAT_ABOUT, SETTING_TYPE_STRING, "HEPU-000001", 0);
    settings_register(" 开源声明 ", SETTING_CAT_ABOUT, SETTING_TYPE_ACTION, " 查看开源许可证 ", 0);

    /* AI */
    settings_register("AI assistant ", SETTING_CAT_AI, SETTING_TYPE_BOOL, " enabled system AI", 0);
    settings_set_bool(sa.item_count - 1, 1);
    settings_register(" local 推理 ", SETTING_CAT_AI, SETTING_TYPE_BOOL, " 优先 local AI 推理 ", 0);
    settings_set_bool(sa.item_count - 1, 1);
    settings_register("AI notif classify ", SETTING_CAT_AI, SETTING_TYPE_BOOL, "AI 智能过滤 notify ", 0);

    /* 开发者选项 */
    settings_register("USB 调试 ", SETTING_CAT_DEVELOPER, SETTING_TYPE_BOOL, " 允许 USB 调试 ", 1);
    settings_register("ADB", SETTING_CAT_DEVELOPER, SETTING_TYPE_BOOL, " 允许 ADB connect ", 1);
    settings_register("CPU stats ", SETTING_CAT_DEVELOPER, SETTING_TYPE_BOOL, " display CPU used 率 ", 1);
    settings_register("GPU 渲染 ", SETTING_CAT_DEVELOPER, SETTING_TYPE_BOOL, " mandatory GPU 渲染 ", 1);
    settings_register(" 动画缩放 ", SETTING_CAT_DEVELOPER, SETTING_TYPE_SLIDER, " window 动画缩放 0-100", 1);
    settings_set_int(sa.item_count - 1, 100);

    vga_puts("[SETTINGS] system settings app init done \n");
    vga_printf(" set: %d, categories: %d \n", sa.item_count, sa.category_count);
}

/* 设置项管理 */
int settings_register(const char *name, setting_category_t category, setting_type_t type,
                      const char *desc, int protected)
{
    for (int i = 0; i < SETTINGS_MAX_ITEMS; i++) {
        if (!sa.items[i].used) {
            memset(&sa.items[i], 0, sizeof(setting_item_t));
            sa.items[i].used = 1;
            sa.items[i].id = i;
            if (name) strncpy(sa.items[i].name, name, 63);
            sa.items[i].category = category;
            sa.items[i].type = type;
            if (desc) strncpy(sa.items[i].description, desc, 127);
            sa.items[i].protected = protected;
            sa.items[i].visible = 1;
            sa.items[i].enabled = 1;
            sa.items[i].min_val = 0;
            sa.items[i].max_val = 100;
            sa.items[i].step = 1;
            sa.item_count++;
            if (category < SETTINGS_MAX_CATEGORIES)
                sa.categories[category].item_count++;
            return i;
        }
    }
    return -1;
}

int settings_set_value(int id, const char *value)
{
    if (id < 0 || id >= SETTINGS_MAX_ITEMS || !sa.items[id].used) return -1;
    if (sa.items[id].protected) return -1;
    if (value) strncpy(sa.items[id].value_str, value, 255);
    sa.items[id].modified = 1;
    sa.total_changes++;
    return 0;
}

int settings_get_value(int id, char *buf, int size)
{
    if (id < 0 || id >= SETTINGS_MAX_ITEMS || !sa.items[id].used || !buf || size <= 0) return -1;
    strncpy(buf, sa.items[id].value_str, size - 1);
    return 0;
}

int settings_set_bool(int id, int value)
{
    if (id < 0 || id >= SETTINGS_MAX_ITEMS || !sa.items[id].used) return -1;
    if (sa.items[id].protected) return -1;
    sa.items[id].value_bool = value ? 1 : 0;
    sa.items[id].modified = 1;
    sa.total_changes++;
    return 0;
}

int settings_get_bool(int id)
{
    if (id < 0 || id >= SETTINGS_MAX_ITEMS || !sa.items[id].used) return 0;
    return sa.items[id].value_bool;
}

int settings_set_int(int id, int value)
{
    if (id < 0 || id >= SETTINGS_MAX_ITEMS || !sa.items[id].used) return -1;
    if (sa.items[id].protected) return -1;
    if (value < sa.items[id].min_val) value = sa.items[id].min_val;
    if (value > sa.items[id].max_val) value = sa.items[id].max_val;
    sa.items[id].value_int = value;
    sa.items[id].modified = 1;
    sa.total_changes++;
    return 0;
}

int settings_get_int(int id)
{
    if (id < 0 || id >= SETTINGS_MAX_ITEMS || !sa.items[id].used) return 0;
    return sa.items[id].value_int;
}

int settings_reset(int id)
{
    if (id < 0 || id >= SETTINGS_MAX_ITEMS || !sa.items[id].used) return -1;
    sa.items[id].value_int = 0;
    sa.items[id].value_bool = 0;
    sa.items[id].value_str[0] = 0;
    sa.items[id].modified = 0;
    return 0;
}

int settings_reset_category(setting_category_t category)
{
    for (int i = 0; i < SETTINGS_MAX_ITEMS; i++) {
        if (sa.items[i].used && sa.items[i].category == category && !sa.items[i].protected)
            settings_reset(i);
    }
    return 0;
}

int settings_reset_all(void)
{
    for (int i = 0; i < SETTINGS_MAX_ITEMS; i++) {
        if (sa.items[i].used && !sa.items[i].protected)
            settings_reset(i);
    }
    return 0;
}

/* 查询 */
int settings_get_item(int id, setting_item_t *item)
{
    if (id < 0 || id >= SETTINGS_MAX_ITEMS || !sa.items[id].used || !item) return -1;
    memcpy(item, &sa.items[id], sizeof(setting_item_t));
    return 0;
}

int settings_list_by_category(setting_category_t category, setting_item_t *items, int max)
{
    if (!items || max <= 0) return 0;
    int count = 0;
    for (int i = 0; i < SETTINGS_MAX_ITEMS && count < max; i++) {
        if (sa.items[i].used && sa.items[i].category == category && sa.items[i].visible)
            memcpy(&items[count++], &sa.items[i], sizeof(setting_item_t));
    }
    return count;
}

int settings_list_all(setting_item_t *items, int max)
{
    if (!items || max <= 0) return 0;
    int count = 0;
    for (int i = 0; i < SETTINGS_MAX_ITEMS && count < max; i++) {
        if (sa.items[i].used) memcpy(&items[count++], &sa.items[i], sizeof(setting_item_t));
    }
    return count;
}

int settings_get_category_info(setting_category_t category, setting_category_info_t *info)
{
    if (category >= SETTINGS_MAX_CATEGORIES || !info) return -1;
    memcpy(info, &sa.categories[category], sizeof(setting_category_info_t));
    return 0;
}

int settings_list_categories(setting_category_info_t *categories, int max)
{
    if (!categories || max <= 0) return 0;
    int count = sa.category_count < max ? sa.category_count : max;
    for (int i = 0; i < count; i++)
        memcpy(&categories[i], &sa.categories[i], sizeof(setting_category_info_t));
    return count;
}

/* 搜索 */
int settings_search(const char *query, int *results, int max)
{
    if (!query || !results || max <= 0) return 0;
    int count = 0;
    for (int i = 0; i < SETTINGS_MAX_ITEMS && count < max; i++) {
        if (sa.items[i].used && sa.items[i].visible) {
            if (strstr(sa.items[i].name, query) || strstr(sa.items[i].description, query))
                results[count++] = i;
        }
    }
    return count;
}

/* 导入导出 */
int settings_export(char *buf, int size)
{
    if (!buf || size <= 0) return -1;
    int pos = 0;
    for (int i = 0; i < SETTINGS_MAX_ITEMS && pos < size - 64; i++) {
        if (sa.items[i].used && sa.items[i].modified) {
            int len = strlen(sa.items[i].name);
            if (pos + len + 32 < size) {
                memcpy(buf + pos, sa.items[i].name, len);
                pos += len;
                buf[pos++] = '=';
                buf[pos++] = '0' + sa.items[i].value_bool;
                buf[pos++] = '\n';
            }
        }
    }
    buf[pos] = 0;
    return pos;
}

int settings_import(const char *data)
{
    (void)data;
    return 0;
}

/* 导航 */
int settings_navigate(setting_category_t category)
{
    if (category >= SETTINGS_MAX_CATEGORIES) return -1;
    sa.current_category = category;
    return 0;
}

int settings_get_current_category(setting_category_t *category)
{
    if (!category) return -1;
    *category = sa.current_category;
    return 0;
}

/* 统计 */
int settings_get_stats(settings_app_t *stats)
{
    if (!stats) return -1;
    memcpy(stats, &sa, sizeof(settings_app_t));
    return 0;
}
