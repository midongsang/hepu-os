/* ============================================================================
 * 赫普OS - VGA 图形模式驱动 (320x200 256色, 模式0x13)
 * ========================================================================== */

#include <stdint.h>
#include <string.h>
#include "vga_gfx.h"
#include "vga.h"
#include "font8x16.h"

/* 双缓冲: 所有绘制写入内存 back_buffer, gfx_flip() 垂直同步后整帧拷贝到 0xA0000,
 * 消除 GUI 单缓冲直接写显存导致的闪烁/撕裂 */
/* V2.40: 运行时分辨率变量 (VBE LFB) */
int gfx_width = GFX_WIDTH;
int gfx_height = GFX_HEIGHT;
int gfx_pitch = GFX_WIDTH;
int gfx_bpp = 8;
uint8_t *gfx_fb_addr = (uint8_t *)GFX_FB;
int gfx_scale_x = 100;
int gfx_scale_y = 100;

/* V2.40: 启动时存储的 VBE framebuffer 信息 (由 kernel.c 设置) */
static int vbe_width = 0, vbe_height = 0, vbe_pitch = 0, vbe_bpp = 0;
static uint8_t *vbe_fb = NULL;

void gfx_set_vbe_info(int w, int h, uint8_t *fb, int pitch, int bpp)
{
    vbe_width = w; vbe_height = h; vbe_fb = fb;
    vbe_pitch = pitch; vbe_bpp = bpp;
}

/* 双缓冲: 最大支持 1024x768x8 */
#define GFX_MAX_BUF (1024 * 768)
static uint8_t back_buffer[GFX_MAX_BUF];
static uint8_t *framebuffer = back_buffer;


/* ----------------------------------------------------------------------------
 * VGA 端口操作
 * -------------------------------------------------------------------------- */
static inline void outb(uint16_t port, uint8_t val) {
    __asm__ volatile ("outb %0, %1" : : "a"(val), "Nd"(port));
}

static inline uint8_t inb(uint16_t port) {
    uint8_t ret;
    __asm__ volatile ("inb %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}

static inline void io_wait(void) {
    __asm__ volatile ("outb %%al, $0x80" : : "a"(0));
}

/* ----------------------------------------------------------------------------
 * VGA 模式 0x13 寄存器设置表
 * -------------------------------------------------------------------------- */

/* 序列器寄存器 (0x3C4/0x3C5) */
/* CRT控制器寄存器 (0x3D4/0x3D5)
 * V2.33: 采用标准 VGA mode 13h (320x200x256) CRTC 值.
 * 原值 (CR6=0xBF/CR7=0x1F/CR16=0x9C/CR18=0x8F 等) 偏离标准时序,
 * QEMU std VGA 宽容可显示, 但真机 NVIDIA 等 VGA 兼容显卡严格遵守
 * 时序寄存器导致乱码. 标准值经 DOS/Linux VGA 驱动广泛验证, 全兼容. */
static const uint8_t crtc_regs[] = {
    0x5F, 0x4F, 0x50, 0x82, 0x54, 0x80, 0xBF, 0x1F,
    0x00, 0x41, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x9C, 0x8E, 0x8F, 0x28, 0x40, 0x96, 0xB9, 0xA3,
    0xFF
};

/* 图形控制器寄存器 (0x3CE/0x3CF) */
static const uint8_t gc_regs[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x05, 0x0F,
    0xFF
};

/* 属性控制器寄存器 (0x3C0) */
static const uint8_t attr_regs[] = {
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
    0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
    0x41, 0x00, 0x0F, 0x00, 0x00
};

/* ----------------------------------------------------------------------------
 * 初始化 VGA 图形模式 0x13
 * -------------------------------------------------------------------------- */
/* V2.25: VGA显存(0xA0000)页表关闭CPU缓存(PCD=1),
 * 防止CPU缓存VGA显存导致花屏/画面残留. 兼容4KB页表与4MB大页. */
static void gfx_disable_vga_cache(void)
{
    uint32_t cr3;
    __asm__ volatile("mov %%cr3, %0" : "=r"(cr3));
    /* V2.35: 分页未启用时 CR3=0——直接跳过, 避免解引用 NULL 写坏物理 0 区
     * (开机 logo 在 paging_init 后、paging_enable 前调用时会触发) */
    if (cr3 == 0) return;
    uint32_t *pd = (uint32_t *)cr3;
    uint32_t pd_idx = GFX_FB >> 22;              /* 0 */
    uint32_t pt_idx = (GFX_FB >> 12) & 0x3FF;    /* 160 */
    uint32_t entry = pd[pd_idx];
    if (entry & 0x80) {
        /* 4MB 大页 (PSE): 直接设 PCD */
        pd[pd_idx] = entry | 0x10;
    } else if (entry & 0x01) {
        /* 4KB 页表: 设 PCD */
        uint32_t *pt = (uint32_t *)(entry & 0xFFFFF000);
        pt[pt_idx] |= 0x10;
    }
    /* 刷新 TLB */
    __asm__ volatile("invlpg (%0)" :: "r"((uint32_t)GFX_FB));
}


/* V3.82: 读当前 VGA 寄存器状态 (启动早期=SeaBIOS文本模式; 用于对照恢复序列) */
void vga_dump_regs(void)
{
    extern void serial_puts(uint16_t, const char *);
    extern void serial_puthex(uint16_t, uint32_t);
    serial_puts(0x3F8, "[VGAREG] misc=");
    serial_puthex(0x3F8, inb(0x3CC));
    serial_puts(0x3F8, "\n[VGAREG] seq:");
    for (int i = 0; i < 5; i++) {
        outb(0x3C4, i);
        serial_puthex(0x3F8, inb(0x3C5));
    }
    serial_puts(0x3F8, "\n[VGAREG] crtc:");
    for (int i = 0; i < 25; i++) {
        outb(0x3D4, i);
        serial_puthex(0x3F8, inb(0x3D5));
    }
    serial_puts(0x3F8, "\n[VGAREG] gc:");
    for (int i = 0; i < 9; i++) {
        outb(0x3CE, i);
        serial_puthex(0x3F8, inb(0x3CF));
    }
    serial_puts(0x3F8, "\n");
}

/* V3.82: 强制 VGA 0x13 (供 splash/文本恢复场景——VBE LFB 模式下
   vga_gfx_text_mode 的标准VGA寄存器序列无法切回文本, 屏幕花屏) */
void gfx_force_vga13(void)
{
    vbe_fb = NULL; vbe_width = 0; vbe_height = 0;
}

void vga_gfx_init(void)
{
    /* V2.40: VBE LFB 模式——如果启动时设置了 VBE 信息, 直接用线性帧缓冲 */
    if (vbe_fb && vbe_width > 0 && vbe_height > 0) {
        gfx_width = vbe_width;
        gfx_height = vbe_height;
        gfx_pitch = (vbe_pitch > 0) ? vbe_pitch : vbe_width;
        gfx_bpp = (vbe_bpp > 0) ? vbe_bpp : 8;
        gfx_fb_addr = vbe_fb;
        /* V2.41: 计算 UI 缩放因子 (基准 320x200) */
        gfx_scale_x = (vbe_width * 100) / 320;
        gfx_scale_y = (vbe_height * 100) / 200;
        if (gfx_scale_x < 100) gfx_scale_x = 100;
        if (gfx_scale_y < 100) gfx_scale_y = 100;
        vga_printf("[GFX] VBE LFB: %dx%d bpp=%d pitch=%d fb=%p\n",
                   vbe_width, vbe_height, vbe_bpp, vbe_pitch, vbe_fb);
        memset(back_buffer, 0, gfx_width * gfx_height);
        gfx_clear(0);
        gfx_flip();
        return;
    }
    /* 默认 VGA 模式 0x13 (320x200x256) */
    gfx_width = GFX_WIDTH;
    gfx_height = GFX_HEIGHT;
    gfx_pitch = GFX_WIDTH;
    gfx_bpp = 8;
    gfx_fb_addr = (uint8_t *)GFX_FB;
    gfx_scale_x = 100;
    gfx_scale_y = 100;

    /* 关闭中断 */
    __asm__ volatile ("cli");

    /* V2.25: 清空后台缓冲区(双缓冲), 防止进入图形模式残留旧画面 */
    memset(back_buffer, 0, gfx_width * gfx_height);

    /* V2.25: VGA显存关闭CPU缓存(PCD=1) */
    gfx_disable_vga_cache();

    /* 0. 混合输出寄存器 (先设时钟/IO, 标准顺序 Misc 第一) */
    outb(0x3C2, 0x63);

    /* 1. 序列器 — V3.82: 标准 mode 13h 流程.
     * 必须先 SR0=0x01 同步重置, 再写 SR1-4, 最后 SR0=0x03 取消重置.
     * (旧实现直接写 SR0=0x03 后写 SR1-4, QEMU std VGA 会忽略
     *  未重置状态的 SR4 写入 → Chain4 未生效 → 平面错位竖条纹) */
    outb(0x3C4, 0x00); outb(0x3C5, 0x03);   /* SR0=0x03: bit1 同步重置 + bit0 显示重置 */
    outb(0x3C4, 0x01); outb(0x3C5, 0x01);
    outb(0x3C4, 0x02); outb(0x3C5, 0x0F);
    outb(0x3C4, 0x03); outb(0x3C5, 0x00);
    outb(0x3C4, 0x04); outb(0x3C5, 0x07);   /* SR4=0x07: Chain4 ON */
    outb(0x3C4, 0x00); outb(0x3C5, 0x03);   /* 取消重置, 8-dot */

    /* 2. 解锁CRTC寄存器 */
    outb(0x3D4, 0x11);
    outb(0x3D5, inb(0x3D5) & ~0x80);

    /* 3. CRT控制器 */
    for (int i = 0; i < 25; i++) {
        outb(0x3D4, i);
        outb(0x3D5, crtc_regs[i]);
    }

    /* 4. 图形控制器 */
    for (int i = 0; i < 9; i++) {
        outb(0x3CE, i);
        outb(0x3CF, gc_regs[i]);
    }

    /* 5. 属性控制器 */
    inb(0x3DA); /* 重置属性控制器翻转锁 */
    for (int i = 0; i < 21; i++) {
        outb(0x3C0, i);
        outb(0x3C0, attr_regs[i]);
    }
    outb(0x3C0, 0x20); /* 启用显示 */

    /* 7. 设置默认调色板 (前16色为标准CGA颜色) */
    gfx_set_palette(0,  0,   0,   0);   /* 黑 */
    gfx_set_palette(1,  0,   0,   170); /* 蓝 */
    gfx_set_palette(2,  0,   170, 0);   /* 绿 */
    gfx_set_palette(3,  0,   170, 170); /* 青 */
    gfx_set_palette(4,  170, 0,   0);   /* 红 */
    gfx_set_palette(5,  170, 0,   170); /* 品红 */
    gfx_set_palette(6,  170, 85,  0);   /* 棕 */
    gfx_set_palette(7,  170, 170, 170); /* 浅灰 */
    gfx_set_palette(8,  85,  85,  85);  /* 深灰 */
    gfx_set_palette(9,  85,  85,  255); /* 浅蓝 */
    gfx_set_palette(10, 85,  255, 85);  /* 浅绿 */
    gfx_set_palette(11, 85,  255, 255); /* 浅青 */
    gfx_set_palette(12, 255, 85,  85);  /* 浅红 */
    gfx_set_palette(13, 255, 85,  255); /* 浅品红 */
    gfx_set_palette(14, 255, 255, 85);  /* 黄 */
    gfx_set_palette(15, 255, 255, 255); /* 白 */

    /* 清屏 */
    gfx_clear(GFX_COLOR_BLACK);

    /* 重新开启中断 */
    __asm__ volatile ("sti");
}

/* 切换回文本模式 (80x25) */
void vga_gfx_text_mode(void)
{
    __asm__ volatile ("cli");

    /* 简化的文本模式设置 */
    outb(0x3C2, 0x67);

    /* 序列器 */
    outb(0x3C4, 0x00);
    /* V2.33: mode 03h 序列器. SR4(Memory Mode)=0x07 是关键:
     * bit0=8/16bit字符, bit1=chain, bit2=odd/even寻址(文本模式必需).
     * 原值 0x02 缺少 odd/even 使能, 导致字体(plane2)访问/渲染异常→条纹. */
    static const uint8_t text_seq[] = {0x03, 0x00, 0x03, 0x00, 0x02};  /* V3.82: SeaBIOS实测=0x02(仅奇偶寻址); 0x07含扩展内存位→平面映射错乱花屏 */
    for (int i = 0; i < 5; i++) {
        outb(0x3C4, i);
        outb(0x3C5, text_seq[i]);
    }

    /* CRTC */
    outb(0x3D4, 0x11);
    outb(0x3D5, inb(0x3D5) & ~0x80);
    /* V2.33: 标准 mode 03h (80x25 彩色文本) CRTC 值,
     * 修复原错误值(CR6=0xBF/CR9=0x47/CR17=0x0E/CR18=0x8F等)导致
     * gfxtest 切回文本后显示竖条纹/乱码的问题 */
    /* V2.33: 标准 mode 03h (80x25 彩色文本, 400线) CRTC 值,
     * 修复原错误值(CR6=0xBF/CR9=0x47/CR17=0x0E/CR18=0x8F等)导致
     * gfxtest 切回文本后显示竖条纹/乱码的问题.
     * 400线时序: Vertical Total=449, Display End=400 */
    /* V3.82: 采用 SeaBIOS(QEMU std VGA) 实测 mode 03 寄存器值——
     * 原值 CR6=0xC1/CR18=0x90/CR20=0x00/CR22=0x02 等垂直时序错误,
     * 与 BIOS 不一致导致文本恢复花屏 */
    static const uint8_t text_crtc[] = {
        0x5F, 0x4F, 0x50, 0x82, 0x55, 0x81, 0xBF, 0x1F,
        0x00, 0x4F, 0x0D, 0x0E, 0x00, 0x00, 0x00, 0x00,
        0x9C, 0x8E, 0x8F, 0x28, 0x1F, 0x96, 0xB9, 0xA3, 0xFF
    };
    for (int i = 0; i < 25; i++) {
        outb(0x3D4, i);
        outb(0x3D5, text_crtc[i]);
    }

    /* 图形控制器 */
    static const uint8_t text_gc[] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x10, 0x0E, 0x0F, 0xFF};  /* V3.82: GC7=0x0F(SeaBIOS实测,全平面ColorDon'tCare) */
    for (int i = 0; i < 9; i++) {
        outb(0x3CE, i);
        outb(0x3CF, text_gc[i]);
    }

    /* 属性控制器 */
    inb(0x3DA);
    static const uint8_t text_attr[] = {
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
        0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
        0x08, 0x00, 0x0F, 0x00, 0x00
    };
    for (int i = 0; i < 21; i++) {
        outb(0x3C0, i);
        outb(0x3C0, text_attr[i]);
    }
    outb(0x3C0, 0x20);

    /* V3.82: 重载 8x16 字体到平面 2 (plane 2)——
     * 图形模式(0x13/VBE)切换会破坏字体平面, 切回文本后字符渲染为
     * 密集竖条纹(花屏). 从内嵌标准 VGA 字体(hepu_font8x16)恢复:
     *   1) Map Mask 只选 plane 2  (SR2=0x04)
     *   2) GC6=0x04: 0xA0000 段映射 plane 2 可写
     *   3) 写入 256 字符 x 16 行 = 4096 字节
     *   4) 恢复 GC6=0x0E / Map Mask=0x0F */
    outb(0x3C4, 0x02);
    outb(0x3C5, 0x04);                    /* Map Mask = plane 2 */
    outb(0x3CE, 0x06);
    outb(0x3CF, 0x05);                    /* GC6 = 0x05: 图形模式段选择 + 128K
                                              (文本模式 0xA0000 段未映射, 读回0x0F) */
    inb(0x3DA);                            /* IO 延迟: 寄存器同步 */
    memcpy((void *)0xA0000, hepu_font8x16, 4096);
    outb(0x3CE, 0x06);
    outb(0x3CF, 0x0E);                    /* GC6 恢复 0x0E (文本模式) */
    outb(0x3C4, 0x02);
    outb(0x3C5, 0x0F);                    /* Map Mask 恢复全平面 */

    __asm__ volatile ("sti");
}

/* ----------------------------------------------------------------------------
 * 绘图 API
 * -------------------------------------------------------------------------- */

void gfx_putpixel(int x, int y, uint8_t color)
{
    if (x < 0 || x >= gfx_width || y < 0 || y >= gfx_height) return;
    framebuffer[y * gfx_width + x] = color;
}

uint8_t gfx_getpixel(int x, int y)
{
    if (x < 0 || x >= gfx_width || y < 0 || y >= gfx_height) return 0;
    return framebuffer[y * gfx_width + x];
}

void gfx_hline(int x, int y, int w, uint8_t color)
{
    if (y < 0 || y >= gfx_height) return;
    if (x < 0) { w += x; x = 0; }
    if (x + w > gfx_width) w = gfx_width - x;
    if (w <= 0) return;
    for (int i = 0; i < w; i++) {
        framebuffer[y * gfx_width + x + i] = color;
    }
}

void gfx_vline(int x, int y, int h, uint8_t color)
{
    if (x < 0 || x >= gfx_width) return;
    if (y < 0) { h += y; y = 0; }
    if (y + h > gfx_height) h = gfx_height - y;
    if (h <= 0) return;
    for (int i = 0; i < h; i++) {
        framebuffer[(y + i) * gfx_width + x] = color;
    }
}

void gfx_rect(int x, int y, int w, int h, uint8_t color)
{
    gfx_hline(x, y, w, color);
    gfx_hline(x, y + h - 1, w, color);
    gfx_vline(x, y, h, color);
    gfx_vline(x + w - 1, y, h, color);
}

void gfx_fillrect(int x, int y, int w, int h, uint8_t color)
{
    for (int i = 0; i < h; i++) {
        gfx_hline(x, y + i, w, color);
    }
}

void gfx_line(int x0, int y0, int x1, int y1, uint8_t color)
{
    int dx = (x1 > x0) ? (x1 - x0) : (x0 - x1);
    int dy = (y1 > y0) ? (y1 - y0) : (y0 - y1);
    int sx = (x0 < x1) ? 1 : -1;
    int sy = (y0 < y1) ? 1 : -1;
    int err = dx - dy;

    while (1) {
        gfx_putpixel(x0, y0, color);
        if (x0 == x1 && y0 == y1) break;
        int e2 = 2 * err;
        if (e2 > -dy) { err -= dy; x0 += sx; }
        if (e2 < dx)  { err += dx; y0 += sy; }
    }
}

void gfx_clear(uint8_t color)
{
    for (int i = 0; i < gfx_width * gfx_height; i++) {
        framebuffer[i] = color;
    }
}

void gfx_set_palette(uint8_t index, uint8_t r, uint8_t g, uint8_t b)
{
    outb(0x3C8, index);
    outb(0x3C9, r >> 2);  /* VGA调色板用6位 */
    outb(0x3C9, g >> 2);
    outb(0x3C9, b >> 2);
}

uint8_t *gfx_get_framebuffer(void)
{
    return framebuffer;  /* 返回 back_buffer, 由 gfx_flip 提交显示 */
}

/* 等待 VGA 垂直回扫: 读 0x3DA bit3, 在回扫期间 flip 可避免撕裂 */
void gfx_wait_vsync(void)
{
    /* V3.87-E5: 超时保护——VGA 控制器异常时防永久忙等(真机黑屏场景相关) */
    uint32_t guard = 0;
    inb(0x3DA);
    while (inb(0x3DA) & 0x08) {  /* 等待回扫结束 */
        if (++guard > 100000) return;
    }
    guard = 0;
    while (!(inb(0x3DA) & 0x08)) {  /* 等待回扫开始 */
        if (++guard > 100000) return;
    }
}

/* 提交 back_buffer 到显存 (带垂直同步) */
/* V2.99 反色已临时回退 (调试); V3.82 清理死变量 gfx_invert */
void gfx_set_invert(int on) { (void)on; }

void gfx_flip(void)
{
    /* V2.61: 休眠灭屏状态 -> 保持黑屏 (直接填黑显存, 省电) */
    extern int pm_is_screen_blanked(void);
    if (pm_is_screen_blanked()) {
        gfx_black_screen();
        return;
    }

    gfx_wait_vsync();
    volatile uint8_t *fb = (volatile uint8_t *)gfx_fb_addr;
    if (gfx_pitch == gfx_width) {
        for (int i = 0; i < gfx_width * gfx_height; i++) {
            fb[i] = back_buffer[i];
        }
    } else {
        for (int y = 0; y < gfx_height; y++) {
            for (int x = 0; x < gfx_width; x++) {
                fb[y * gfx_pitch + x] = back_buffer[y * gfx_width + x];
            }
        }
    }
}
void gfx_black_screen(void)
{
    /* V2.61: 直接填黑显存 (休眠灭屏) */
    volatile uint8_t *fb = (volatile uint8_t *)gfx_fb_addr;
    if (gfx_pitch == gfx_width) {
        for (int i = 0; i < gfx_width * gfx_height; i++) {
            fb[i] = 0x00;
        }
    } else {
        for (int y = 0; y < gfx_height; y++) {
            for (int x = 0; x < gfx_width; x++) {
                fb[y * gfx_pitch + x] = 0x00;
            }
        }
    }
}


/* V2.25: 纯色填充测试——定位花屏根源用.
 * 填满纯色 → flip 提交, 可逐色验证显存写入/缓存/回扫是否正常. */
void gfx_fill_test(uint8_t color)
{
    for (int i = 0; i < gfx_width * gfx_height; i++) {
        back_buffer[i] = color;
    }
    gfx_flip();
}

/* ----------------------------------------------------------------------------
 * 8x8 字体 (简化版，ASCII 32-127)
 * 每个字符8字节，每字节一行，从顶部开始
 * -------------------------------------------------------------------------- */
static const uint8_t font_8x8[][8] = {
    {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}, /* 32 space */
    {0x18,0x18,0x18,0x18,0x18,0x00,0x18,0x00}, /* 33 ! */
    {0x6C,0x6C,0x6C,0x00,0x00,0x00,0x00,0x00}, /* 34 " */
    {0x6C,0x6C,0xFE,0x6C,0xFE,0x6C,0x6C,0x00}, /* 35 # */
    {0x18,0x7E,0xC0,0x7C,0x06,0xFC,0x18,0x00}, /* 36 $ */
    {0x00,0xC6,0xCC,0x18,0x30,0x66,0xC6,0x00}, /* 37 % */
    {0x38,0x6C,0x38,0x76,0xDC,0xCC,0x76,0x00}, /* 38 & */
    {0x18,0x18,0x30,0x00,0x00,0x00,0x00,0x00}, /* 39 ' */
    {0x0C,0x18,0x30,0x30,0x30,0x18,0x0C,0x00}, /* 40 ( */
    {0x30,0x18,0x0C,0x0C,0x0C,0x18,0x30,0x00}, /* 41 ) */
    {0x00,0x66,0x3C,0xFF,0x3C,0x66,0x00,0x00}, /* 42 * */
    {0x00,0x18,0x18,0x7E,0x18,0x18,0x00,0x00}, /* 43 + */
    {0x00,0x00,0x00,0x00,0x00,0x18,0x18,0x30}, /* 44 , */
    {0x00,0x00,0x00,0x7E,0x00,0x00,0x00,0x00}, /* 45 - */
    {0x00,0x00,0x00,0x00,0x00,0x18,0x18,0x00}, /* 46 . */
    {0x06,0x0C,0x18,0x30,0x60,0xC0,0x80,0x00}, /* 47 / */
    {0x7C,0xC6,0xCE,0xD6,0xE6,0xC6,0x7C,0x00}, /* 48 0 */
    {0x18,0x38,0x18,0x18,0x18,0x18,0x7E,0x00}, /* 49 1 */
    {0x7C,0xC6,0x06,0x1C,0x70,0xC0,0xFE,0x00}, /* 50 2 */
    {0x7C,0xC6,0x06,0x3C,0x06,0xC6,0x7C,0x00}, /* 51 3 */
    {0x1C,0x3C,0x6C,0xCC,0xFE,0x0C,0x1E,0x00}, /* 52 4 */
    {0xFE,0xC0,0xFC,0x06,0x06,0xC6,0x7C,0x00}, /* 53 5 */
    {0x38,0x60,0xC0,0xFC,0xC6,0xC6,0x7C,0x00}, /* 54 6 */
    {0xFE,0xC6,0x0C,0x18,0x30,0x30,0x30,0x00}, /* 55 7 */
    {0x7C,0xC6,0xC6,0x7C,0xC6,0xC6,0x7C,0x00}, /* 56 8 */
    {0x7C,0xC6,0xC6,0x7E,0x06,0x0C,0x78,0x00}, /* 57 9 */
    {0x00,0x18,0x18,0x00,0x00,0x18,0x18,0x00}, /* 58 : */
    {0x00,0x18,0x18,0x00,0x00,0x18,0x18,0x30}, /* 59 ; */
    {0x06,0x0C,0x18,0x30,0x18,0x0C,0x06,0x00}, /* 60 < */
    {0x00,0x00,0x7E,0x00,0x7E,0x00,0x00,0x00}, /* 61 = */
    {0x60,0x30,0x18,0x0C,0x18,0x30,0x60,0x00}, /* 62 > */
    {0x7C,0xC6,0x0C,0x18,0x18,0x00,0x18,0x00}, /* 63 ? */
    {0x7C,0xC6,0xDE,0xDE,0xDE,0xC0,0x78,0x00}, /* 64 @ */
    {0x38,0x6C,0xC6,0xC6,0xFE,0xC6,0xC6,0x00}, /* 65 A */
    {0xFC,0x66,0x66,0x7C,0x66,0x66,0xFC,0x00}, /* 66 B */
    {0x3C,0x66,0xC0,0xC0,0xC0,0x66,0x3C,0x00}, /* 67 C */
    {0xF8,0x6C,0x66,0x66,0x66,0x6C,0xF8,0x00}, /* 68 D */
    {0xFE,0x62,0x68,0x78,0x68,0x62,0xFE,0x00}, /* 69 E */
    {0xFE,0x62,0x68,0x78,0x68,0x60,0xF0,0x00}, /* 70 F */
    {0x3C,0x66,0xC0,0xC0,0xCE,0x66,0x3E,0x00}, /* 71 G */
    {0xC6,0xC6,0xC6,0xFE,0xC6,0xC6,0xC6,0x00}, /* 72 H */
    {0x3C,0x18,0x18,0x18,0x18,0x18,0x3C,0x00}, /* 73 I */
    {0x1E,0x0C,0x0C,0x0C,0xCC,0xCC,0x78,0x00}, /* 74 J */
    {0xE6,0x66,0x6C,0x78,0x6C,0x66,0xE6,0x00}, /* 75 K */
    {0xF0,0x60,0x60,0x60,0x62,0x66,0xFE,0x00}, /* 76 L */
    {0xC6,0xEE,0xFE,0xFE,0xD6,0xC6,0xC6,0x00}, /* 77 M */
    {0xC6,0xE6,0xF6,0xDE,0xCE,0xC6,0xC6,0x00}, /* 78 N */
    {0x7C,0xC6,0xC6,0xC6,0xC6,0xC6,0x7C,0x00}, /* 79 O */
    {0xFC,0x66,0x66,0x7C,0x60,0x60,0xF0,0x00}, /* 80 P */
    {0x7C,0xC6,0xC6,0xC6,0xD6,0xDE,0x7C,0x06}, /* 81 Q */
    {0xFC,0x66,0x66,0x7C,0x6C,0x66,0xE6,0x00}, /* 82 R */
    {0x7C,0xC6,0x60,0x38,0x0C,0xC6,0x7C,0x00}, /* 83 S */
    {0x7E,0x7E,0x5A,0x18,0x18,0x18,0x3C,0x00}, /* 84 T */
    {0xC6,0xC6,0xC6,0xC6,0xC6,0xC6,0x7C,0x00}, /* 85 U */
    {0xC6,0xC6,0xC6,0xC6,0xC6,0x6C,0x38,0x00}, /* 86 V */
    {0xC6,0xC6,0xC6,0xD6,0xFE,0xEE,0xC6,0x00}, /* 87 W */
    {0xC6,0xC6,0x6C,0x38,0x6C,0xC6,0xC6,0x00}, /* 88 X */
    {0x66,0x66,0x66,0x3C,0x18,0x18,0x3C,0x00}, /* 89 Y */
    {0xFE,0xC6,0x8C,0x18,0x32,0x66,0xFE,0x00}, /* 90 Z */
    {0x3C,0x30,0x30,0x30,0x30,0x30,0x3C,0x00}, /* 91 [ */
    {0xC0,0x60,0x30,0x18,0x0C,0x06,0x02,0x00}, /* 92 \ */
    {0x3C,0x0C,0x0C,0x0C,0x0C,0x0C,0x3C,0x00}, /* 93 ] */
    {0x10,0x38,0x6C,0xC6,0x00,0x00,0x00,0x00}, /* 94 ^ */
    {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xFF}, /* 95 _ */
    {0x30,0x18,0x0C,0x00,0x00,0x00,0x00,0x00}, /* 96 ` */
    {0x00,0x00,0x78,0x0C,0x7C,0xCC,0x76,0x00}, /* 97 a */
    {0xE0,0x60,0x7C,0x66,0x66,0x66,0xDC,0x00}, /* 98 b */
    {0x00,0x00,0x7C,0xC6,0xC0,0xC6,0x7C,0x00}, /* 99 c */
    {0x1C,0x0C,0x7C,0xCC,0xCC,0xCC,0x76,0x00}, /* 100 d */
    {0x00,0x00,0x7C,0xC6,0xFE,0xC0,0x7C,0x00}, /* 101 e */
    {0x38,0x6C,0x60,0xF0,0x60,0x60,0xF0,0x00}, /* 102 f */
    {0x00,0x00,0x76,0xCC,0xCC,0x7C,0x0C,0xF8}, /* 103 g */
    {0xE0,0x60,0x6C,0x76,0x66,0x66,0xE6,0x00}, /* 104 h */
    {0x18,0x00,0x38,0x18,0x18,0x18,0x3C,0x00}, /* 105 i */
    {0x06,0x00,0x0E,0x06,0x06,0x66,0x66,0x3C}, /* 106 j */
    {0xE0,0x60,0x66,0x6C,0x78,0x6C,0xE6,0x00}, /* 107 k */
    {0x38,0x18,0x18,0x18,0x18,0x18,0x3C,0x00}, /* 108 l */
    {0x00,0x00,0xEC,0xFE,0xD6,0xD6,0xD6,0x00}, /* 109 m */
    {0x00,0x00,0xDC,0x66,0x66,0x66,0x66,0x00}, /* 110 n */
    {0x00,0x00,0x7C,0xC6,0xC6,0xC6,0x7C,0x00}, /* 111 o */
    {0x00,0x00,0xDC,0x66,0x66,0x7C,0x60,0xF0}, /* 112 p */
    {0x00,0x00,0x76,0xCC,0xCC,0x7C,0x0C,0x1E}, /* 113 q */
    {0x00,0x00,0xDC,0x76,0x60,0x60,0xF0,0x00}, /* 114 r */
    {0x00,0x00,0x7E,0xC0,0x7C,0x06,0xFC,0x00}, /* 115 s */
    {0x30,0x30,0xFC,0x30,0x30,0x36,0x1C,0x00}, /* 116 t */
    {0x00,0x00,0xCC,0xCC,0xCC,0xCC,0x76,0x00}, /* 117 u */
    {0x00,0x00,0xC6,0xC6,0xC6,0x6C,0x38,0x00}, /* 118 v */
    {0x00,0x00,0xC6,0xD6,0xD6,0xFE,0x6C,0x00}, /* 119 w */
    {0x00,0x00,0xC6,0x6C,0x38,0x6C,0xC6,0x00}, /* 120 x */
    {0x00,0x00,0xC6,0xC6,0xC6,0x7E,0x06,0xFC}, /* 121 y */
    {0x00,0x00,0xFE,0x4C,0x18,0x32,0xFE,0x00}, /* 122 z */
    {0x0E,0x18,0x18,0x70,0x18,0x18,0x0E,0x00}, /* 123 { */
    {0x18,0x18,0x18,0x00,0x18,0x18,0x18,0x00}, /* 124 | */
    {0x70,0x18,0x18,0x0E,0x18,0x18,0x70,0x00}, /* 125 } */
    {0x76,0xDC,0x00,0x00,0x00,0x00,0x00,0x00}, /* 126 ~ */
};

void gfx_putchar(int x, int y, char c, uint8_t color)
{
    if (c < 32 || c > 126) c = '?';
    const uint8_t *glyph = font_8x8[c - 32];
    for (int row = 0; row < 8; row++) {
        uint8_t line = glyph[row];
        for (int col = 0; col < 8; col++) {
            if (line & (0x80 >> col)) {
                gfx_putpixel(x + col, y + row, color);
            }
        }
    }
}

void gfx_puts(int x, int y, const char *s, uint8_t color)
{
    int cx = x;
    while (*s) {
        if (*s == '\n') {
            y += 8;
            cx = x;
            s++;
            continue;
        }
        gfx_putchar(cx, y, *s, color);
        cx += 8;
        s++;
    }
}

/* V2.35: 放大 8x8 字体绘制字符 (scale=整数倍), 用于开机 logo 大字 */
void gfx_putchar_big(int x, int y, char c, uint8_t color, int scale)
{
    if (scale < 1) scale = 1;
    if (c < 32 || c > 126) c = '?';
    const uint8_t *glyph = font_8x8[c - 32];
    for (int row = 0; row < 8; row++) {
        uint8_t line = glyph[row];
        for (int col = 0; col < 8; col++) {
            if (line & (0x80 >> col)) {
                gfx_fillrect(x + col * scale, y + row * scale, scale, scale, color);
            }
        }
    }
}

void gfx_puts_big(int x, int y, const char *s, uint8_t color, int scale)
{
    int cx = x;
    while (*s) {
        if (*s == '\n') {
            y += 8 * scale;
            cx = x;
            s++;
            continue;
        }
        gfx_putchar_big(cx, y, *s, color, scale);
        cx += 8 * scale;
        s++;
    }
}
