/* ============================================================================
 * 赫普OS - IDE磁盘驱动 (PIO模式)
 * 支持LBA28寻址，PIO读写
 * ========================================================================== */

#include <stdint.h>
#include "ide.h"
#include "vga.h"
#include "string.h"

static ide_drive_t drives[MAX_IDE_DRIVES];
static int ide_initialized = 0;

/* 端口IO */
static inline uint8_t inb(uint16_t port)
{
    uint8_t ret;
    __asm__ volatile("inb %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}

static inline void outb(uint16_t port, uint8_t val)
{
    __asm__ volatile("outb %0, %1" : : "a"(val), "Nd"(port));
}

static inline uint16_t inw(uint16_t port)
{
    uint16_t ret;
    __asm__ volatile("inw %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}

static inline void outw(uint16_t port, uint16_t val)
{
    __asm__ volatile("outw %0, %1" : : "a"(val), "Nd"(port));
}

/* 等待IDE控制器就绪 */
static int ide_wait_ready(uint16_t io_base, int timeout)
{
    uint8_t status;
    while (timeout-- > 0) {
        status = inb(io_base + IDE_REG_STATUS);
        if (!(status & IDE_STATUS_BUSY)) {
            if (status & IDE_STATUS_DRDY) return 0;
            if (status & IDE_STATUS_ERR) return -1;
        }
    }
    return -1;
}

/* 等待数据请求 */
static int ide_wait_drq(uint16_t io_base, int timeout)
{
    uint8_t status;
    while (timeout-- > 0) {
        status = inb(io_base + IDE_REG_STATUS);
        if (status & IDE_STATUS_DRQ) return 0;
        if (status & IDE_STATUS_ERR) return -1;
    }
    return -1;
}

/* 选择驱动器 */
static void ide_select_drive(uint16_t io_base, int drive)
{
    outb(io_base + IDE_REG_DRIVE, 0xA0 | (drive << 4));
}

/* 读取扇区 (PIO) */
static void ide_read_pio(uint16_t io_base, uint8_t *buffer, uint32_t count)
{
    uint32_t words = count * (IDE_SECTOR_SIZE / 2);
    uint16_t *buf = (uint16_t *)buffer;
    for (uint32_t i = 0; i < words; i++) {
        buf[i] = inw(io_base + IDE_REG_DATA);
    }
}

/* 写入扇区 (PIO) */
static void ide_write_pio(uint16_t io_base, const uint8_t *buffer, uint32_t count)
{
    uint32_t words = count * (IDE_SECTOR_SIZE / 2);
    const uint16_t *buf = (const uint16_t *)buffer;
    for (uint32_t i = 0; i < words; i++) {
        outw(io_base + IDE_REG_DATA, buf[i]);
    }
}

/* IDE识别命令 */
int ide_identify(int channel, int drive, ide_drive_t *info)
{
    uint16_t io_base = (channel == 0) ? IDE_PRIMARY_IO : IDE_SECONDARY_IO;

    ide_select_drive(io_base, drive);
    if (ide_wait_ready(io_base, 10000) != 0) return -1;

    /* 发送IDENTIFY命令 */
    outb(io_base + IDE_REG_COMMAND, IDE_CMD_IDENTIFY);

    if (ide_wait_drq(io_base, 10000) != 0) return -1;

    /* 读取识别数据 */
    uint16_t identify[256];
    for (int i = 0; i < 256; i++) {
        identify[i] = inw(io_base + IDE_REG_DATA);
    }

    if (info) {
        info->present = 1;
        info->channel = channel;
        info->drive = drive;
        info->total_sectors = identify[60] | (identify[61] << 16);
        info->lba_support = (identify[49] & 0x0200) ? 1 : 0;

        /* 解析型号 (字节交换) */
        for (int i = 0; i < 20; i += 2) {
            info->model[i] = identify[27 + i/2] >> 8;
            info->model[i+1] = identify[27 + i/2] & 0xFF;
        }
        info->model[40] = 0;

        /* 解析序列号 */
        for (int i = 0; i < 10; i += 2) {
            info->serial[i] = identify[10 + i/2] >> 8;
            info->serial[i+1] = identify[10 + i/2] & 0xFF;
        }
        info->serial[20] = 0;
    }

    return 0;
}

void ide_init(void)
{
    memset(drives, 0, sizeof(drives));
    ide_initialized = 1;

    vga_puts("[IDE] 初始化IDE控制器...\n");

    /* 探测4个驱动器 */
    int found = 0;
    for (int ch = 0; ch < 2; ch++) {
        for (int dr = 0; dr < 2; dr++) {
            int idx = ch * 2 + dr;
            if (ide_identify(ch, dr, &drives[idx]) == 0) {
                vga_printf("[IDE] 发现驱动器 %d: %s (%d sectors)\n",
                           idx, drives[idx].model, drives[idx].total_sectors);
                found++;
            }
        }
    }

    if (found == 0) {
        vga_puts("[IDE] 未发现IDE驱动器（QEMU/虚拟机环境可能需要配置）\n");
    } else {
        vga_printf("[IDE] 共发现%d个驱动器\n", found);
    }
}

/* 读取扇区 */
int ide_read_sectors(uint32_t lba, uint8_t *buffer, uint32_t count)
{
    if (!ide_initialized || !buffer || count == 0) return -1;

    /* 使用第一个可用驱动器 */
    ide_drive_t *drive = NULL;
    for (int i = 0; i < MAX_IDE_DRIVES; i++) {
        if (drives[i].present) {
            drive = &drives[i];
            break;
        }
    }
    if (!drive) return -1;

    uint16_t io_base = (drive->channel == 0) ? IDE_PRIMARY_IO : IDE_SECONDARY_IO;

    ide_select_drive(io_base, drive->drive);
    if (ide_wait_ready(io_base, 10000) != 0) return -1;

    /* 设置LBA地址 */
    outb(io_base + IDE_REG_SECCOUNT, count & 0xFF);
    outb(io_base + IDE_REG_LBA0, lba & 0xFF);
    outb(io_base + IDE_REG_LBA1, (lba >> 8) & 0xFF);
    outb(io_base + IDE_REG_LBA2, (lba >> 16) & 0xFF);
    outb(io_base + IDE_REG_DRIVE, 0xE0 | (drive->drive << 4) | ((lba >> 24) & 0x0F));

    /* 发送读命令 */
    outb(io_base + IDE_REG_COMMAND, IDE_CMD_READ_PIO);

    if (ide_wait_drq(io_base, 10000) != 0) return -1;

    /* 读取数据 */
    ide_read_pio(io_base, buffer, count);

    return count;
}

/* 写入扇区 */
int ide_write_sectors(uint32_t lba, const uint8_t *buffer, uint32_t count)
{
    if (!ide_initialized || !buffer || count == 0) return -1;

    ide_drive_t *drive = NULL;
    for (int i = 0; i < MAX_IDE_DRIVES; i++) {
        if (drives[i].present) {
            drive = &drives[i];
            break;
        }
    }
    if (!drive) return -1;

    uint16_t io_base = (drive->channel == 0) ? IDE_PRIMARY_IO : IDE_SECONDARY_IO;

    ide_select_drive(io_base, drive->drive);
    if (ide_wait_ready(io_base, 10000) != 0) return -1;

    /* 设置LBA地址 */
    outb(io_base + IDE_REG_SECCOUNT, count & 0xFF);
    outb(io_base + IDE_REG_LBA0, lba & 0xFF);
    outb(io_base + IDE_REG_LBA1, (lba >> 8) & 0xFF);
    outb(io_base + IDE_REG_LBA2, (lba >> 16) & 0xFF);
    outb(io_base + IDE_REG_DRIVE, 0xE0 | (drive->drive << 4) | ((lba >> 24) & 0x0F));

    /* 发送写命令 */
    outb(io_base + IDE_REG_COMMAND, IDE_CMD_WRITE_PIO);

    if (ide_wait_drq(io_base, 10000) != 0) return -1;

    /* 写入数据 */
    ide_write_pio(io_base, buffer, count);

    /* 刷新缓存 */
    outb(io_base + IDE_REG_COMMAND, IDE_CMD_FLUSH);
    ide_wait_ready(io_base, 10000);

    return count;
}

int ide_get_drive_info(int index, ide_drive_t *info)
{
    if (index < 0 || index >= MAX_IDE_DRIVES || !info) return -1;
    if (!drives[index].present) return -1;
    *info = drives[index];
    return 0;
}
