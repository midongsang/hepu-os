/* ============================================================================
 * 赫普OS - USB 驱动栈
 * 主机控制器框架 + 设备枚举 + 控制传输 + HID类驱动
 * ========================================================================== */

#include <stdint.h>
#include "usb.h"
#include "vga.h"
#include "string.h"
#include "kheap.h"

static usb_device_t devices[USB_MAX_DEVICES];
static usb_hc_t host_controller;
static usb_driver_t *drivers[8];
static int driver_count = 0;
static int usb_initialized = 0;

void usb_init(void)
{
    for (int i = 0; i < USB_MAX_DEVICES; i++) {
        devices[i].used = 0;
    }
    driver_count = 0;
    usb_initialized = 1;

    vga_puts("[USB] USB子系统初始化完成\n");

    /* 初始化HID类驱动 */
    usb_hid_init();
}

int usb_hc_init(usb_hc_type_t type, uint32_t base)
{
    host_controller.type = type;
    host_controller.io_base = base;
    host_controller.mem_base = base;
    host_controller.irq = 11;  /* 默认IRQ */
    host_controller.initialized = 1;

    const char *type_name = "Unknown";
    switch (type) {
        case USB_HC_UHCI: type_name = "UHCI"; break;
        case USB_HC_OHCI: type_name = "OHCI"; break;
        case USB_HC_EHCI: type_name = "EHCI"; break;
        case USB_HC_XHCI: type_name = "XHCI"; break;
    }
    vga_printf("[USB] 主机控制器 %s @ 0x%x 初始化完成\n", type_name, base);
    return 0;
}

int usb_control_transfer(usb_device_t *dev, uint8_t request_type,
                          uint8_t request, uint16_t value, uint16_t index,
                          void *data, uint16_t length)
{
    if (!dev || !dev->used) return -1;

    /* 原型阶段: 模拟控制传输
     * 实际硬件: 通过主机控制器发送设置包 + 数据阶段 + 状态阶段
     */
    (void)request_type; (void)request; (void)value;
    (void)index; (void)data; (void)length;

    return length;  /* 模拟成功 */
}

int usb_bulk_transfer(usb_device_t *dev, uint8_t ep, void *data, int length)
{
    if (!dev || !dev->used) return -1;
    (void)ep; (void)data;
    return length;  /* 模拟成功 */
}

int usb_interrupt_transfer(usb_device_t *dev, uint8_t ep, void *data, int length)
{
    if (!dev || !dev->used) return -1;
    (void)ep; (void)data;
    return length;  /* 模拟成功 */
}

int usb_get_descriptor(usb_device_t *dev, uint8_t type, uint8_t index,
                        void *buf, uint16_t length)
{
    return usb_control_transfer(dev,
        0x80,  /* IN | Standard | Device */
        USB_REQ_GET_DESCRIPTOR,
        (type << 8) | index,
        0,
        buf, length);
}

int usb_set_address(usb_device_t *dev, uint8_t address)
{
    int ret = usb_control_transfer(dev,
        0x00,  /* OUT | Standard | Device */
        USB_REQ_SET_ADDRESS,
        address, 0, NULL, 0);
    if (ret == 0) {
        dev->address = address;
    }
    return ret;
}

int usb_set_configuration(usb_device_t *dev, uint8_t config)
{
    int ret = usb_control_transfer(dev,
        0x00,
        USB_REQ_SET_CONFIG,
        config, 0, NULL, 0);
    if (ret == 0) {
        dev->configured = 1;
    }
    return ret;
}

int usb_enumerate_device(usb_device_t *dev)
{
    if (!dev) return -1;

    vga_puts("[USB] 开始设备枚举...\n");

    /* 1. 读取设备描述符 (前8字节获取max_packet_size0) */
    usb_device_desc_t dev_desc; memset(&dev_desc, 0, sizeof(dev_desc));
    int ret = usb_get_descriptor(dev, USB_DESC_DEVICE, 0, &dev_desc, 8);
    if (ret < 0) {
        vga_puts("[USB] 错误: 无法读取设备描述符\n");
        return -1;
    }
    dev->max_packet_size0 = dev_desc.bMaxPacketSize0;

    /* 2. 设置地址 */
    static uint8_t next_address = 1;
    ret = usb_set_address(dev, next_address);
    if (ret < 0) {
        vga_puts("[USB] 错误: 设置地址失败\n");
        return -1;
    }
    next_address++;

    /* 3. 读取完整设备描述符 */
    ret = usb_get_descriptor(dev, USB_DESC_DEVICE, 0, &dev_desc, sizeof(dev_desc));
    if (ret < 0) return -1;

    dev->vendor_id = dev_desc.idVendor;
    dev->product_id = dev_desc.idProduct;
    dev->device_class = dev_desc.bDeviceClass;

    vga_printf("[USB] 设备: VID=0x%04x PID=0x%04x 类=%d\n",
               dev->vendor_id, dev->product_id, dev->device_class);

    /* 4. 读取配置描述符 (前9字节) */
    usb_config_desc_t cfg_desc; memset(&cfg_desc, 0, sizeof(cfg_desc));
    ret = usb_get_descriptor(dev, USB_DESC_CONFIG, 0, &cfg_desc, 9);
    if (ret < 0) return -1;

    /* 5. 读取完整配置描述符 (包含接口和端点) */
    uint8_t *cfg_buf = kmalloc(cfg_desc.wTotalLength);
    if (!cfg_buf) return -1;
    ret = usb_get_descriptor(dev, USB_DESC_CONFIG, 0, cfg_buf, cfg_desc.wTotalLength);
    if (ret < 0) { kfree(cfg_buf); return -1; }

    /* 6. 解析接口和端点描述符 */
    uint32_t offset = 9;  /* 跳过配置描述符 */
    dev->num_interfaces = 0;
    while (offset < cfg_desc.wTotalLength) {
        uint8_t desc_len = cfg_buf[offset];
        uint8_t desc_type = cfg_buf[offset + 1];
        if (desc_len == 0) break;

        if (desc_type == USB_DESC_INTERFACE) {
            usb_interface_desc_t *if_desc = (usb_interface_desc_t *)(cfg_buf + offset);
            if (dev->num_interfaces < USB_MAX_INTERFACES) {
                usb_interface_t *iface = &dev->interfaces[dev->num_interfaces++];
                iface->number = if_desc->bInterfaceNumber;
                iface->class = if_desc->bInterfaceClass;
                iface->subclass = if_desc->bInterfaceSubClass;
                iface->protocol = if_desc->bInterfaceProtocol;
                iface->num_endpoints = 0;
                vga_printf("[USB]   接口%d: 类=%d 端点=%d\n",
                           iface->number, iface->class, if_desc->bNumEndpoints);
            }
        }
        else if (desc_type == USB_DESC_ENDPOINT) {
            usb_endpoint_desc_t *ep_desc = (usb_endpoint_desc_t *)(cfg_buf + offset);
            if (dev->num_interfaces > 0) {
                usb_interface_t *iface = &dev->interfaces[dev->num_interfaces - 1];
                if (iface->num_endpoints < USB_MAX_ENDPOINTS) {
                    usb_endpoint_t *ep = &iface->endpoints[iface->num_endpoints++];
                    ep->address = ep_desc->bEndpointAddress;
                    ep->type = ep_desc->bmAttributes & 0x03;
                    ep->max_packet_size = ep_desc->wMaxPacketSize;
                    ep->interval = ep_desc->bInterval;
                    ep->toggle = 0;
                }
            }
        }
        offset += desc_len;
    }

    kfree(cfg_buf);

    /* 7. 设置配置 */
    ret = usb_set_configuration(dev, cfg_desc.bConfigurationValue);
    if (ret < 0) return -1;

    /* 8. 匹配驱动 */
    for (int i = 0; i < driver_count; i++) {
        if (drivers[i]->device_class == dev->device_class ||
            (dev->num_interfaces > 0 &&
             drivers[i]->interface_class == dev->interfaces[0].class)) {
            vga_printf("[USB] 匹配驱动: %s\n", drivers[i]->name);
            drivers[i]->probe(dev);
            break;
        }
    }

    vga_puts("[USB] 设备枚举完成\n");
    return 0;
}

int usb_register_driver(usb_driver_t *driver)
{
    if (!driver || driver_count >= 8) return -1;
    drivers[driver_count++] = driver;
    vga_printf("[USB] 注册驱动: %s\n", driver->name);
    return 0;
}

/* ---- HID类驱动 ---- */

static int hid_probe(usb_device_t *dev)
{
    vga_printf("[USB-HID] HID设备连接: VID=0x%04x PID=0x%04x\n",
               dev->vendor_id, dev->product_id);

    /* 判断是键盘还是鼠标 */
    if (dev->num_interfaces > 0) {
        usb_interface_t *iface = &dev->interfaces[0];
        if (iface->protocol == 1) {
            vga_puts("[USB-HID] 键盘设备\n");
        } else if (iface->protocol == 2) {
            vga_puts("[USB-HID] 鼠标设备\n");
        }
    }
    return 0;
}

static int hid_disconnect(usb_device_t *dev)
{
    (void)dev;
    vga_puts("[USB-HID] HID设备断开\n");
    return 0;
}

static usb_driver_t hid_driver = {
    .name = "HID",
    .device_class = 0,
    .interface_class = USB_CLASS_HID,
    .probe = hid_probe,
    .disconnect = hid_disconnect,
};

int usb_hid_init(void)
{
    return usb_register_driver(&hid_driver);
}
