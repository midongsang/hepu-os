/* ============================================================================
 * 赫普OS - 输入子系统 (evdev式)
 * 事件总线 + 多点触摸 + 手势识别 + 输入法框架
 * ========================================================================== */

#include <stdint.h>
#include "input.h"
#include "vga.h"
#include "string.h"

static int input_abs(int x) { return x < 0 ? -x : x; }

static input_device_t devices[INPUT_MAX_DEVICES];
static input_listener_t listeners[INPUT_MAX_LISTENERS];
static input_event_t event_queue[INPUT_EVENT_QUEUE_SIZE];
static int queue_head = 0;
static int queue_tail = 0;
static int device_count = 0;
static int listener_count = 0;
static int input_initialized = 0;

/* 手势识别状态 */
static int gestures_enabled = 0;
static gesture_callback_t gesture_cb = NULL;
static int touch_down = 0;
static int touch_start_x = 0, touch_start_y = 0;
static int touch_last_x = 0, touch_last_y = 0;
static uint64_t touch_start_time = 0;

/* 输入法 */
static input_method_t current_method;
static int method_registered = 0;

void input_init(void)
{
    for (int i = 0; i < INPUT_MAX_DEVICES; i++) devices[i].used = 0;
    for (int i = 0; i < INPUT_MAX_LISTENERS; i++) listeners[i].used = 0;
    queue_head = queue_tail = 0;
    device_count = 0;
    listener_count = 0;
    input_initialized = 1;

    /* 注册默认键盘 */
    input_device_t kb;
    memset(&kb, 0, sizeof(kb));
    kb.name = "PS/2 Keyboard";
    kb.type = INPUT_DEV_KEYBOARD;
    kb.vendor_id = 0x0001;
    kb.product_id = 0x0001;
    kb.ev_types[0] = 1;  /* EV_SYN */
    kb.ev_types[1] = 1;  /* EV_KEY */
    kb.ev_types[7] = 1;  /* EV_REP */
    input_register_device(&kb);

    /* 注册默认鼠标 */
    input_device_t mouse;
    memset(&mouse, 0, sizeof(mouse));
    mouse.name = "PS/2 Mouse";
    mouse.type = INPUT_DEV_MOUSE;
    mouse.vendor_id = 0x0002;
    mouse.product_id = 0x0001;
    mouse.ev_types[0] = 1;
    mouse.ev_types[1] = 1;
    mouse.ev_types[2] = 1;  /* EV_REL */
    input_register_device(&mouse);

    /* 注册触屏 */
    input_device_t touch;
    memset(&touch, 0, sizeof(touch));
    touch.name = "Touchscreen";
    touch.type = INPUT_DEV_TOUCHSCREEN;
    touch.vendor_id = 0x0003;
    touch.product_id = 0x0001;
    touch.ev_types[0] = 1;
    touch.ev_types[1] = 1;
    touch.ev_types[3] = 1;  /* EV_ABS */
    touch.slot_count = 5;
    input_register_device(&touch);

    vga_puts("[INPUT] 输入子系统初始化完成\n");
    vga_printf("        注册 %d 个输入设备\n", device_count);
}

int input_register_device(input_device_t *dev)
{
    if (!dev || !input_initialized) return -1;
    for (int i = 0; i < INPUT_MAX_DEVICES; i++) {
        if (!devices[i].used) {
            memcpy(&devices[i], dev, sizeof(input_device_t));
            devices[i].used = 1;
            devices[i].id = i;
            device_count++;
            return i;
        }
    }
    return -1;
}

int input_unregister_device(int dev_id)
{
    if (dev_id < 0 || dev_id >= INPUT_MAX_DEVICES || !devices[dev_id].used) return -1;
    devices[dev_id].used = 0;
    device_count--;
    return 0;
}

static void dispatch_event(input_event_t *event)
{
    /* 通知所有监听器 */
    for (int i = 0; i < INPUT_MAX_LISTENERS; i++) {
        if (listeners[i].used) {
            if (listeners[i].type_filter == -1 ||
                listeners[i].type_filter == event->type) {
                if (listeners[i].callback) {
                    listeners[i].callback(event, listeners[i].user_data);
                }
            }
        }
    }
}

static void detect_gesture(input_event_t *event)
{
    if (!gestures_enabled) return;

    if (event->type == EV_ABS && event->code == ABS_MT_TRACKING_ID) {
        if (event->value >= 0) {
            /* 触摸按下 */
            touch_down = 1;
            touch_start_x = touch_last_x;
            touch_start_y = touch_last_y;
            touch_start_time = 0;
        } else {
            /* 触摸抬起 */
            if (touch_down) {
                int dx = touch_last_x - touch_start_x;
                int dy = touch_last_y - touch_start_y;
                int dist = dx * dx + dy * dy;

                gesture_event_t ge;
                memset(&ge, 0, sizeof(ge));
                ge.x = touch_start_x;
                ge.y = touch_start_y;
                ge.dx = dx;
                ge.dy = dy;

                if (dist < 100) {
                    /* 轻点 */
                    ge.type = GESTURE_TAP;
                    if (gesture_cb) gesture_cb(&ge);
                } else if (dx > 50 && input_abs(dy) < 50) {
                    ge.type = GESTURE_SWIPE_RIGHT;
                    if (gesture_cb) gesture_cb(&ge);
                } else if (dx < -50 && input_abs(dy) < 50) {
                    ge.type = GESTURE_SWIPE_LEFT;
                    if (gesture_cb) gesture_cb(&ge);
                } else if (dy > 50 && input_abs(dx) < 50) {
                    ge.type = GESTURE_SWIPE_DOWN;
                    if (gesture_cb) gesture_cb(&ge);
                } else if (dy < -50 && input_abs(dx) < 50) {
                    ge.type = GESTURE_SWIPE_UP;
                    if (gesture_cb) gesture_cb(&ge);
                }
            }
            touch_down = 0;
        }
    } else if (event->type == EV_ABS && event->code == ABS_MT_POSITION_X) {
        touch_last_x = event->value;
    } else if (event->type == EV_ABS && event->code == ABS_MT_POSITION_Y) {
        touch_last_y = event->value;
    }
}

int input_inject_event(int dev_id, uint16_t type, uint16_t code, int32_t value)
{
    if (dev_id < 0 || dev_id >= INPUT_MAX_DEVICES || !devices[dev_id].used) return -1;

    input_event_t event;
    event.type = type;
    event.code = code;
    event.value = value;
    event.timestamp = 0;

    /* 更新设备状态 */
    if (type == EV_KEY) {
        if (code < 256) {
            devices[dev_id].key_state[code / 8] = value ?
                (devices[dev_id].key_state[code / 8] | (1 << (code % 8))) :
                (devices[dev_id].key_state[code / 8] & ~(1 << (code % 8)));
        }
    } else if (type == EV_ABS) {
        if (code < 16) devices[dev_id].abs_value[code] = value;
    } else if (type == EV_REL) {
        if (code < 8) devices[dev_id].rel_value[code] += value;
    }

    /* 加入队列 */
    event_queue[queue_tail] = event;
    queue_tail = (queue_tail + 1) % INPUT_EVENT_QUEUE_SIZE;
    if (queue_tail == queue_head) {
        queue_head = (queue_head + 1) % INPUT_EVENT_QUEUE_SIZE;  /* 覆盖最旧 */
    }

    /* 分发 */
    dispatch_event(&event);

    /* 手势识别 */
    detect_gesture(&event);

    return 0;
}

int input_read_event(input_event_t *event)
{
    if (!event) return -1;
    if (queue_head == queue_tail) return 0;  /* 无事件 */
    *event = event_queue[queue_head];
    queue_head = (queue_head + 1) % INPUT_EVENT_QUEUE_SIZE;
    return 1;
}

int input_add_listener(int device_filter, int type_filter,
                       void (*callback)(input_event_t *, void *), void *user_data)
{
    if (!callback || !input_initialized) return -1;
    for (int i = 0; i < INPUT_MAX_LISTENERS; i++) {
        if (!listeners[i].used) {
            listeners[i].used = 1;
            listeners[i].id = i;
            listeners[i].device_filter = device_filter;
            listeners[i].type_filter = type_filter;
            listeners[i].callback = callback;
            listeners[i].user_data = user_data;
            listener_count++;
            return i;
        }
    }
    return -1;
}

int input_remove_listener(int listener_id)
{
    if (listener_id < 0 || listener_id >= INPUT_MAX_LISTENERS || !listeners[listener_id].used) return -1;
    listeners[listener_id].used = 0;
    listener_count--;
    return 0;
}

int input_get_device_info(int dev_id, input_device_t *info)
{
    if (dev_id < 0 || dev_id >= INPUT_MAX_DEVICES || !devices[dev_id].used) return -1;
    if (info) memcpy(info, &devices[dev_id], sizeof(input_device_t));
    return 0;
}

int input_get_key_state(int dev_id, int key_code)
{
    if (dev_id < 0 || dev_id >= INPUT_MAX_DEVICES || !devices[dev_id].used) return 0;
    if (key_code < 0 || key_code >= 256) return 0;
    return (devices[dev_id].key_state[key_code / 8] >> (key_code % 8)) & 1;
}

int input_get_abs_value(int dev_id, int axis)
{
    if (dev_id < 0 || dev_id >= INPUT_MAX_DEVICES || !devices[dev_id].used) return 0;
    if (axis < 0 || axis >= 16) return 0;
    return devices[dev_id].abs_value[axis];
}

int input_get_rel_value(int dev_id, int axis)
{
    if (dev_id < 0 || dev_id >= INPUT_MAX_DEVICES || !devices[dev_id].used) return 0;
    if (axis < 0 || axis >= 8) return 0;
    int val = devices[dev_id].rel_value[axis];
    devices[dev_id].rel_value[axis] = 0;
    return val;
}

int input_get_touch(int dev_id, int slot, input_touch_slot_t *touch)
{
    if (dev_id < 0 || dev_id >= INPUT_MAX_DEVICES || !devices[dev_id].used) return -1;
    if (slot < 0 || slot >= 10 || !touch) return -1;
    memcpy(touch, &devices[dev_id].touch_slots[slot], sizeof(input_touch_slot_t));
    return 0;
}

int input_touch_count(int dev_id)
{
    if (dev_id < 0 || dev_id >= INPUT_MAX_DEVICES || !devices[dev_id].used) return 0;
    int count = 0;
    for (int i = 0; i < 10; i++) {
        if (devices[dev_id].touch_slots[i].active) count++;
    }
    return count;
}

int input_enable_gestures(int enable)
{
    gestures_enabled = enable ? 1 : 0;
    vga_printf("[INPUT] 手势识别 %s\n", enable ? "已启用" : "已禁用");
    return 0;
}

int input_set_gesture_callback(gesture_callback_t cb)
{
    gesture_cb = cb;
    return 0;
}

/* 默认英文输入法 */
static int default_method_process_key(int key_code, int *output_char)
{
    if (!output_char) return 0;
    /* 简化: 直接映射 */
    if (key_code >= 2 && key_code <= 11) {
        *output_char = '0' + (key_code == 11 ? 0 : key_code - 1);
        return 1;
    }
    if (key_code >= 16 && key_code <= 25) {
        *output_char = 'a' + (key_code - 16);
        return 1;
    }
    if (key_code == KEY_SPACE) { *output_char = ' '; return 1; }
    if (key_code == KEY_ENTER) { *output_char = '\n'; return 1; }
    return 0;
}

static int default_method_get_candidates(char *buf, int len)
{
    if (buf && len > 0) buf[0] = '\0';
    return 0;
}

int input_register_method(input_method_t *method)
{
    if (!method) return -1;
    memcpy(&current_method, method, sizeof(input_method_t));
    method_registered = 1;
    vga_printf("[INPUT] 注册输入法: %s\n", method->name);
    return 0;
}

int input_switch_method(const char *name)
{
    if (!name) return -1;
    /* 原型阶段: 只有默认输入法 */
    if (strcmp(name, "default") == 0) {
        current_method.active = 1;
        current_method.name = "Default Keyboard";
        current_method.process_key = default_method_process_key;
        current_method.get_candidates = default_method_get_candidates;
        method_registered = 1;
        return 0;
    }
    return -1;
}

int input_device_count(void) { return device_count; }

void input_flush(void)
{
    queue_head = queue_tail = 0;
}
