/* ============================================================================
 * 赫普OS - 电源管理
 * 休眠/唤醒/省电模式/电池管理
 * ========================================================================== */

#include <stdint.h>
#include "pm.h"
#include "vga.h"
#include "pit.h"
#include "string.h"

static pm_state_t current_state = PM_STATE_ON;
static pm_battery_t battery;
static pm_callback_t callbacks[8];
static int callback_count = 0;
static int sleep_timeout = 300;  /* 5分钟 */
static volatile uint32_t idle_seconds = 0;
static int pm_initialized = 0;

void pm_init(void)
{
    current_state = PM_STATE_ON;
    callback_count = 0;
    idle_seconds = 0;

    /* 初始化电池状态 (模拟) */
    battery.present = 1;
    battery.charging = 0;
    battery.capacity = 85;
    battery.voltage = 3800;
    battery.current = -500;
    battery.temperature = 250;
    battery.design_capacity = 3000;
    battery.full_capacity = 2850;
    battery.remaining_capacity = 2420;

    pm_initialized = 1;
    vga_puts("[PM] 电源管理初始化完成\n");
    vga_printf("     电池: %d%% %s\n", battery.capacity,
               battery.charging ? "充电中" : "放电中");
}

int pm_set_state(pm_state_t state)
{
    if (state == current_state) return 0;

    pm_state_t old_state = current_state;
    current_state = state;

    /* 通知回调 */
    pm_event_t event = (state < old_state) ? PM_EVENT_SLEEP : PM_EVENT_WAKEUP;
    for (int i = 0; i < callback_count; i++) {
        if (callbacks[i]) callbacks[i](event);
    }

    const char *state_name = "Unknown";
    switch (state) {
        case PM_STATE_ON: state_name = "ON"; break;
        case PM_STATE_IDLE: state_name = "IDLE"; break;
        case PM_STATE_STANDBY: state_name = "STANDBY"; break;
        case PM_STATE_SUSPEND: state_name = "SUSPEND(S3)"; break;
        case PM_STATE_HIBERNATE: state_name = "HIBERNATE(S4)"; break;
        case PM_STATE_OFF: state_name = "OFF(S5)"; break;
    }
    vga_printf("[PM] 电源状态: %s -> %s\n",
               old_state == PM_STATE_ON ? "ON" : "...", state_name);

    /* 原型阶段: 实际硬件需要ACPI/APM调用 */
    if (state == PM_STATE_SUSPEND || state == PM_STATE_HIBERNATE) {
        vga_puts("[PM] 进入低功耗状态...\n");
        /* 实际: 保存CPU状态, 关闭外设, 进入休眠 */
    }

    return 0;
}

pm_state_t pm_get_state(void)
{
    return current_state;
}

void pm_register_callback(pm_callback_t cb)
{
    if (cb && callback_count < 8) {
        callbacks[callback_count++] = cb;
    }
}

void pm_wakeup(void)
{
    if (current_state != PM_STATE_ON) {
        vga_puts("[PM] 唤醒系统...\n");
        pm_set_state(PM_STATE_ON);
        idle_seconds = 0;
    }
}

void pm_sleep(pm_state_t state)
{
    if (state <= PM_STATE_ON || state > PM_STATE_OFF) return;
    pm_set_state(state);
}

int pm_get_battery(pm_battery_t *out)
{
    if (!out) return -1;
    memcpy(out, &battery, sizeof(pm_battery_t));
    return 0;
}

void pm_update_battery(pm_battery_t *new_battery)
{
    if (!new_battery) return;
    memcpy(&battery, new_battery, sizeof(pm_battery_t));

    /* 检查低电量 */
    if (battery.capacity <= 5 && !battery.charging) {
        vga_puts("[PM] 警告: 电量严重不足, 即将休眠!\n");
        for (int i = 0; i < callback_count; i++) {
            if (callbacks[i]) callbacks[i](PM_EVENT_BATTERY_CRITICAL);
        }
        pm_set_state(PM_STATE_SUSPEND);
    }
    else if (battery.capacity <= 20 && !battery.charging) {
        for (int i = 0; i < callback_count; i++) {
            if (callbacks[i]) callbacks[i](PM_EVENT_BATTERY_LOW);
        }
    }
}

void pm_cpu_idle(void)
{
    /* CPU进入空闲状态, 等待中断 */
    __asm__ volatile ("hlt");
}

int pm_should_sleep(void)
{
    if (current_state != PM_STATE_ON) return 0;
    if (sleep_timeout <= 0) return 0;
    return (idle_seconds >= (uint32_t)sleep_timeout);
}

void pm_set_sleep_timeout(int seconds)
{
    sleep_timeout = seconds;
}

int pm_get_sleep_timeout(void)
{
    return sleep_timeout;
}

void pm_reset_idle_timer(void)
{
    idle_seconds = 0;
}

/* 电源管理计时器 (由PIT中断调用) */
void pm_tick(void)
{
    if (current_state == PM_STATE_ON) {
        idle_seconds++;
        if (pm_should_sleep()) {
            vga_puts("[PM] 空闲超时, 进入休眠\n");
            pm_set_state(PM_STATE_SUSPEND);
        }
    }

    /* 模拟电池放电 */
    if (!battery.charging && battery.remaining_capacity > 0) {
        battery.remaining_capacity--;
        battery.capacity = (battery.remaining_capacity * 100) / battery.full_capacity;
    }
}
