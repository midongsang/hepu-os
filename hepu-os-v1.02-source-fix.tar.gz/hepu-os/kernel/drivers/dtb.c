/* ============================================================================
 * 赫普OS - 设备树 (DTB) 解析与硬件自动配置
 * ========================================================================== */

#include <stdint.h>
#include "dtb.h"
#include "vga.h"
#include "string.h"
#include "kstdio.h"

static dtb_node_t nodes[DTB_MAX_NODES];
static int node_count = 0;
static int dtb_parsed = 0;

static uint32_t be32(uint32_t val)
{
    return ((val & 0xFF) << 24) | ((val & 0xFF00) << 8) |
           ((val >> 8) & 0xFF00) | ((val >> 24) & 0xFF);
}

static uint64_t be64(uint64_t val)
{
    return ((uint64_t)be32(val & 0xFFFFFFFF) << 32) | be32(val >> 32);
}

int dtb_verify(void *dtb_data)
{
    if (!dtb_data) return -1;
    dtb_header_t *hdr = (dtb_header_t *)dtb_data;
    if (be32(hdr->magic) != DTB_MAGIC) {
        vga_puts("[DTB] 错误: 魔数不匹配\n");
        return -1;
    }
    return 0;
}

int dtb_parse(void *dtb_data)
{
    if (dtb_verify(dtb_data) != 0) return -1;

    dtb_header_t *hdr = (dtb_header_t *)dtb_data;
    uint32_t struct_off = be32(hdr->off_dt_struct);
    uint32_t strings_off = be32(hdr->off_dt_strings);
    uint8_t *struct_base = (uint8_t *)dtb_data + struct_off;
    char *strings_base = (char *)dtb_data + strings_off;

    node_count = 0;
    int depth = 0;
    int parent_stack[32];
    uint32_t offset = 0;

    while (1) {
        uint32_t token = be32(*(uint32_t *)(struct_base + offset));
        offset += 4;

        if (token == DTB_BEGIN_NODE) {
            if (node_count >= DTB_MAX_NODES) break;
            dtb_node_t *node = &nodes[node_count];
            memset(node, 0, sizeof(dtb_node_t));

            /* 节点名称 (以null结尾, 4字节对齐) */
            char *name = (char *)(struct_base + offset);
            strncpy(node->name, name, 63);
            int name_len = strlen(name) + 1;
            offset += (name_len + 3) & ~3;

            node->depth = depth;
            node->parent = (depth > 0) ? parent_stack[depth - 1] : -1;
            if (node->parent >= 0) {
                nodes[node->parent].children[nodes[node->parent].child_count++] = node_count;
            }

            /* 构建路径 */
            if (node->parent >= 0) {
                snprintf(node->path, 128, "%s/%s", nodes[node->parent].path, node->name);
            } else {
                strncpy(node->path, node->name, 127);
            }

            parent_stack[depth] = node_count;
            depth++;
            node_count++;
        }
        else if (token == DTB_END_NODE) {
            if (depth > 0) depth--;
        }
        else if (token == DTB_PROP) {
            uint32_t prop_len = be32(*(uint32_t *)(struct_base + offset));
            uint32_t name_off = be32(*(uint32_t *)(struct_base + offset + 4));
            offset += 8;

            if (depth > 0 && node_count > 0) {
                dtb_node_t *node = &nodes[parent_stack[depth - 1]];
                if (node->prop_count < 16) {
                    dtb_prop_t *prop = &node->props[node->prop_count++];
                    strncpy(prop->name, strings_base + name_off, 63);
                    prop->length = prop_len;
                    prop->data = struct_base + offset;
                }
            }
            offset += (prop_len + 3) & ~3;
        }
        else if (token == DTB_NOP) {
            continue;
        }
        else if (token == DTB_END) {
            break;
        }
        else {
            break;
        }
    }

    dtb_parsed = 1;
    vga_printf("[DTB] 解析完成: %d 个节点\n", node_count);
    return 0;
}

dtb_node_t *dtb_find_node(const char *path)
{
    if (!dtb_parsed || !path) return NULL;
    for (int i = 0; i < node_count; i++) {
        if (strcmp(nodes[i].path, path) == 0) return &nodes[i];
    }
    return NULL;
}

dtb_prop_t *dtb_find_prop(dtb_node_t *node, const char *name)
{
    if (!node || !name) return NULL;
    for (int i = 0; i < node->prop_count; i++) {
        if (strcmp(node->props[i].name, name) == 0) return &node->props[i];
    }
    return NULL;
}

uint32_t dtb_get_prop_u32(dtb_node_t *node, const char *name, uint32_t def)
{
    dtb_prop_t *prop = dtb_find_prop(node, name);
    if (!prop || prop->length < 4) return def;
    return be32(*(uint32_t *)prop->data);
}

uint64_t dtb_get_prop_u64(dtb_node_t *node, const char *name, uint64_t def)
{
    dtb_prop_t *prop = dtb_find_prop(node, name);
    if (!prop || prop->length < 8) return def;
    return be64(*(uint64_t *)prop->data);
}

const char *dtb_get_prop_string(dtb_node_t *node, const char *name)
{
    dtb_prop_t *prop = dtb_find_prop(node, name);
    if (!prop || prop->length == 0) return NULL;
    return (const char *)prop->data;
}

uint32_t dtb_get_reg(dtb_node_t *node, int index)
{
    dtb_prop_t *prop = dtb_find_prop(node, "reg");
    if (!prop || prop->length < (uint32_t)(index + 1) * 8) return 0;
    return be32(*(uint32_t *)(prop->data + index * 8));
}

int dtb_get_irq(dtb_node_t *node, int index)
{
    dtb_prop_t *prop = dtb_find_prop(node, "interrupts");
    if (!prop || prop->length < (uint32_t)(index + 1) * 4) return -1;
    return (int)be32(*(uint32_t *)(prop->data + index * 4));
}

const char *dtb_get_compatible(dtb_node_t *node)
{
    return dtb_get_prop_string(node, "compatible");
}

int dtb_for_each_node(int (*callback)(dtb_node_t *node, void *data), void *data)
{
    if (!callback) return -1;
    for (int i = 0; i < node_count; i++) {
        int ret = callback(&nodes[i], data);
        if (ret != 0) return ret;
    }
    return 0;
}

int dtb_node_count(void)
{
    return node_count;
}

void dtb_dump(void)
{
    vga_puts("[DTB] 设备树转储:\n");
    for (int i = 0; i < node_count; i++) {
        for (int d = 0; d < nodes[i].depth; d++) vga_puts("  ");
        vga_printf("%s (%d props)\n", nodes[i].name, nodes[i].prop_count);
    }
}

/* 硬件自动配置: 根据设备树初始化驱动 */
int dtb_auto_config(void)
{
    if (!dtb_parsed) return -1;
    vga_puts("[DTB] 开始硬件自动配置...\n");

    int configured = 0;
    for (int i = 0; i < node_count; i++) {
        dtb_node_t *node = &nodes[i];
        const char *compatible = dtb_get_compatible(node);
        if (!compatible) continue;

        if (strcmp(compatible, "ns16550a") == 0) {
            uint32_t base = dtb_get_reg(node, 0);
            int irq = dtb_get_irq(node, 0);
            vga_printf("[DTB] UART @ 0x%x IRQ %d\n", base, irq);
            configured++;
        }
        else if (strcmp(compatible, "gdrom") == 0 || strcmp(compatible, "mmc") == 0) {
            uint32_t base = dtb_get_reg(node, 0);
            vga_printf("[DTB] 存储控制器 @ 0x%x\n", base);
            configured++;
        }
        else if (compatible[0] == 'u' && compatible[1] == 's' && compatible[2] == 'b') {
            uint32_t base = dtb_get_reg(node, 0);
            int irq = dtb_get_irq(node, 0);
            vga_printf("[DTB] USB控制器 @ 0x%x IRQ %d\n", base, irq);
            configured++;
        }
    }

    vga_printf("[DTB] 自动配置完成: %d 个设备\n", configured);
    return configured;
}

int dtb_init(void *dtb_data)
{
    if (dtb_parse(dtb_data) != 0) return -1;
    dtb_auto_config();
    return 0;
}
