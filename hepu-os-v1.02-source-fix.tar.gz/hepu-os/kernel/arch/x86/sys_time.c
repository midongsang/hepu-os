/* ============================================================================
 * 赫普OS - 系统调用：TIME
 * ========================================================================== */

#include "types.h"
#include <stdint.h>
#include <stddef.h>
#include "syscall.h"
#include "vga.h"
#include "kheap.h"
#include "sched.h"
#include "hepu.h"
#include "fingerprint.h"
#include "vfs.h"
#include "ipc.h"
extern const char *hepu_kernel_version;

u32 sys_sleep(u32 ms, u32 arg2,
                          u32 arg3, u32 arg4)
{
    (void)arg2; (void)arg3; (void)arg4;
    /* 简单忙等 (原型阶段) */
    for (volatile u32 i = 0; i < ms * 1000; i++);
    return 0;
}

u32 sys_time(u32 arg1, u32 arg2, u32 arg3, u32 arg4)
{
    (void)arg1; (void)arg2; (void)arg3; (void)arg4;
    extern u32 pit_get_ticks(void);
    return pit_get_ticks() / 1000;  /* 毫秒转秒 */
}

u32 sys_gettimeofday(u32 tv_ptr, u32 arg2, u32 arg3, u32 arg4)
{
    (void)arg2; (void)arg3; (void)arg4;
    extern u32 pit_get_ticks(void);
    if (tv_ptr) {
        u32 *tv = (u32 *)tv_ptr;
        tv[0] = pit_get_ticks() / 1000;   /* seconds */
        tv[1] = (pit_get_ticks() % 1000) * 1000;  /* microseconds */
    }
    return 0;
}

u32 sys_settimeofday(u32 tv_ptr, u32 arg2, u32 arg3, u32 arg4)
{
    (void)tv_ptr; (void)arg2; (void)arg3; (void)arg4;
    return 0;  /* 原型阶段不允许设置时间 */
}

u32 sys_nanosleep(u32 req_ptr, u32 rem_ptr, u32 arg3, u32 arg4)
{
    (void)rem_ptr; (void)arg3; (void)arg4;
    if (req_ptr) {
        u32 *req = (u32 *)req_ptr;
        u32 ms = req[0] * 1000 + req[1] / 1000000;
        for (volatile u32 i = 0; i < ms * 1000; i++);
    }
    return 0;
}

