/* ============================================================================
 * 赫普OS - 系统设置应用
 * ========================================================================== */

#include <stdint.h>
#include "settings_app.h"
#include "vga.h"
#include "string.h"



static settings_app_t sa;

/* 分类名称表 */
static const char *category_names[] = {
    "网络与连接", "设备", "应用", "显示", "声音", "电池",
    "存储", "安全与隐私", "账户", "系统", "关于手机",
    "无障碍", "AI助手", "开发者选项"
};

void settings_init(void)
{
    memset(&sa, 0, sizeof(settings_app_t));
    sa.initialized = 1;
    sa.enabled = 1;
    sa.current_category = SETTING_CAT_SYSTEM;

    /* 注册分类 */
    for (int i = 0; i < 14; i++) {
        sa.categories[i].id = (setting_category_t)i;
        strncpy(sa.categories[i].name, category_names[i], 63);
        sa.categories[i].visible = 1;
    }
    sa.category_count = 14;

    /* 注册常用设置项 */
    /* 网络 */
    settings_register("WiFi", SETTING_CAT_NETWORK, SETTING_TYPE_BOOL, "开启/关闭WiFi", 0);
    settings_register("蓝牙", SETTING_CAT_NETWORK, SETTING_TYPE_BOOL, "开启/关闭蓝牙", 0);
    settings_register("飞行模式", SETTING_CAT_NETWORK, SETTING_TYPE_BOOL, "关闭所有无线连接", 0);
    settings_register("移动数据", SETTING_CAT_NETWORK, SETTING_TYPE_BOOL, "使用蜂窝数据", 0);
    settings_register("热点", SETTING_CAT_NETWORK, SETTING_TYPE_BOOL, "便携式WiFi热点", 0);
    settings_register("VPN", SETTING_CAT_NETWORK, SETTING_TYPE_BOOL, "虚拟专用网络", 0);
    settings_register("NFC", SETTING_CAT_NETWORK, SETTING_TYPE_BOOL, "近场通信", 0);

    /* 显示 */
    settings_register("亮度", SETTING_CAT_DISPLAY, SETTING_TYPE_SLIDER, "屏幕亮度 0-100", 0);
    settings_set_int(sa.item_count - 1, 80);
    settings_register("自动亮度", SETTING_CAT_DISPLAY, SETTING_TYPE_BOOL, "根据环境光自动调节", 0);
    settings_register("深色模式", SETTING_CAT_DISPLAY, SETTING_TYPE_BOOL, "全局深色主题", 0);
    settings_register("字体大小", SETTING_CAT_DISPLAY, SETTING_TYPE_SLIDER, "字体大小 0-100", 0);
    settings_set_int(sa.item_count - 1, 50);
    settings_register("显示大小", SETTING_CAT_DISPLAY, SETTING_TYPE_SLIDER, "界面元素大小 0-100", 0);
    settings_set_int(sa.item_count - 1, 50);
    settings_register("屏幕超时", SETTING_CAT_DISPLAY, SETTING_TYPE_ENUM, "无操作自动息屏时间", 0);
    settings_register("护眼模式", SETTING_CAT_DISPLAY, SETTING_TYPE_BOOL, "减少蓝光", 0);
    settings_register("刷新率", SETTING_CAT_DISPLAY, SETTING_TYPE_ENUM, "屏幕刷新率", 0);

    /* 声音 */
    settings_register("铃声", SETTING_CAT_SOUND, SETTING_TYPE_SLIDER, "铃声音量 0-100", 0);
    settings_set_int(sa.item_count - 1, 70);
    settings_register("媒体", SETTING_CAT_SOUND, SETTING_TYPE_SLIDER, "媒体音量 0-100", 0);
    settings_set_int(sa.item_count - 1, 60);
    settings_register("闹钟", SETTING_CAT_SOUND, SETTING_TYPE_SLIDER, "闹钟音量 0-100", 0);
    settings_set_int(sa.item_count - 1, 50);
    settings_register("通话", SETTING_CAT_SOUND, SETTING_TYPE_SLIDER, "通话音量 0-100", 0);
    settings_set_int(sa.item_count - 1, 80);
    settings_register("静音", SETTING_CAT_SOUND, SETTING_TYPE_BOOL, "全局静音", 0);
    settings_register("震动", SETTING_CAT_SOUND, SETTING_TYPE_BOOL, "触感反馈", 0);
    settings_set_bool(sa.item_count - 1, 1);
    settings_register("勿扰模式", SETTING_CAT_SOUND, SETTING_TYPE_BOOL, "屏蔽通知", 0);

    /* 电池 */
    settings_register("省电模式", SETTING_CAT_BATTERY, SETTING_TYPE_BOOL, "限制后台活动省电", 0);
    settings_register("超级省电", SETTING_CAT_BATTERY, SETTING_TYPE_BOOL, "仅保留基础功能", 0);
    settings_register("电池百分比", SETTING_CAT_BATTERY, SETTING_TYPE_BOOL, "状态栏显示百分比", 0);
    settings_set_bool(sa.item_count - 1, 1);

    /* 存储 */
    settings_register("存储清理", SETTING_CAT_STORAGE, SETTING_TYPE_ACTION, "清理缓存和垃圾文件", 0);
    settings_register("默认存储", SETTING_CAT_STORAGE, SETTING_TYPE_ENUM, "默认存储位置", 0);

    /* 安全与隐私 */
    settings_register("屏幕锁定", SETTING_CAT_SECURITY, SETTING_TYPE_ENUM, "锁屏方式", 1);
    settings_register("指纹解锁", SETTING_CAT_SECURITY, SETTING_TYPE_BOOL, "使用指纹解锁", 1);
    settings_register("面部解锁", SETTING_CAT_SECURITY, SETTING_TYPE_BOOL, "使用面部解锁", 1);
    settings_register("隐私沙盒", SETTING_CAT_SECURITY, SETTING_TYPE_BOOL, "应用隔离运行", 0);
    settings_set_bool(sa.item_count - 1, 1);
    settings_register("数据金库", SETTING_CAT_SECURITY, SETTING_TYPE_BOOL, "本地数据加密存储", 0);
    settings_set_bool(sa.item_count - 1, 1);
    settings_register("位置服务", SETTING_CAT_SECURITY, SETTING_TYPE_BOOL, "允许应用获取位置", 0);
    settings_register("相机权限", SETTING_CAT_SECURITY, SETTING_TYPE_BOOL, "全局相机权限", 0);
    settings_set_bool(sa.item_count - 1, 1);
    settings_register("麦克风权限", SETTING_CAT_SECURITY, SETTING_TYPE_BOOL, "全局麦克风权限", 0);
    settings_set_bool(sa.item_count - 1, 1);
    settings_register("安全启动", SETTING_CAT_SECURITY, SETTING_TYPE_BOOL, "验证系统完整性", 1);
    settings_set_bool(sa.item_count - 1, 1);

    /* 系统 */
    settings_register("系统语言", SETTING_CAT_SYSTEM, SETTING_TYPE_ENUM, "显示语言", 0);
    settings_register("时区", SETTING_CAT_SYSTEM, SETTING_TYPE_STRING, "系统时区", 0);
    settings_register("自动时间", SETTING_CAT_SYSTEM, SETTING_TYPE_BOOL, "网络自动同步时间", 0);
    settings_set_bool(sa.item_count - 1, 1);
    settings_register("24小时制", SETTING_CAT_SYSTEM, SETTING_TYPE_BOOL, "使用24小时制", 0);
    settings_register("系统更新", SETTING_CAT_SYSTEM, SETTING_TYPE_ACTION, "检查系统更新", 0);
    settings_register("备份", SETTING_CAT_SYSTEM, SETTING_TYPE_ACTION, "备份系统设置", 0);
    settings_register("重置", SETTING_CAT_SYSTEM, SETTING_TYPE_ACTION, "恢复出厂设置", 1);

    /* 关于 */
    settings_register("系统版本", SETTING_CAT_ABOUT, SETTING_TYPE_STRING, "HEPU OS V0.27", 0);
    settings_register("内核版本", SETTING_CAT_ABOUT, SETTING_TYPE_STRING, "HEPU Microkernel 0.27", 0);
    settings_register("型号", SETTING_CAT_ABOUT, SETTING_TYPE_STRING, "HEPU Generic", 0);
    settings_register("序列号", SETTING_CAT_ABOUT, SETTING_TYPE_STRING, "HEPU-000001", 0);
    settings_register("开源声明", SETTING_CAT_ABOUT, SETTING_TYPE_ACTION, "查看开源许可证", 0);

    /* AI */
    settings_register("AI助手", SETTING_CAT_AI, SETTING_TYPE_BOOL, "启用系统AI", 0);
    settings_set_bool(sa.item_count - 1, 1);
    settings_register("本地推理", SETTING_CAT_AI, SETTING_TYPE_BOOL, "优先本地AI推理", 0);
    settings_set_bool(sa.item_count - 1, 1);
    settings_register("AI通知分级", SETTING_CAT_AI, SETTING_TYPE_BOOL, "AI智能过滤通知", 0);

    /* 开发者选项 */
    settings_register("USB调试", SETTING_CAT_DEVELOPER, SETTING_TYPE_BOOL, "允许USB调试", 1);
    settings_register("ADB", SETTING_CAT_DEVELOPER, SETTING_TYPE_BOOL, "允许ADB连接", 1);
    settings_register("CPU统计", SETTING_CAT_DEVELOPER, SETTING_TYPE_BOOL, "显示CPU使用率", 1);
    settings_register("GPU渲染", SETTING_CAT_DEVELOPER, SETTING_TYPE_BOOL, "强制GPU渲染", 1);
    settings_register("动画缩放", SETTING_CAT_DEVELOPER, SETTING_TYPE_SLIDER, "窗口动画缩放 0-100", 1);
    settings_set_int(sa.item_count - 1, 100);

    vga_puts("[SETTINGS] 系统设置应用初始化完成\n");
    vga_printf("          设置项: %d个, 分类: %d个\n", sa.item_count, sa.category_count);
}

/* 设置项管理 */
int settings_register(const char *name, setting_category_t category, setting_type_t type,
                      const char *desc, int protected)
{
    for (int i = 0; i < SETTINGS_MAX_ITEMS; i++) {
        if (!sa.items[i].used) {
            memset(&sa.items[i], 0, sizeof(setting_item_t));
            sa.items[i].used = 1;
            sa.items[i].id = i;
            if (name) strncpy(sa.items[i].name, name, 63);
            sa.items[i].category = category;
            sa.items[i].type = type;
            if (desc) strncpy(sa.items[i].description, desc, 127);
            sa.items[i].protected = protected;
            sa.items[i].visible = 1;
            sa.items[i].enabled = 1;
            sa.items[i].min_val = 0;
            sa.items[i].max_val = 100;
            sa.items[i].step = 1;
            sa.item_count++;
            if (category < SETTINGS_MAX_CATEGORIES)
                sa.categories[category].item_count++;
            return i;
        }
    }
    return -1;
}

int settings_set_value(int id, const char *value)
{
    if (id < 0 || id >= SETTINGS_MAX_ITEMS || !sa.items[id].used) return -1;
    if (sa.items[id].protected) return -1;
    if (value) strncpy(sa.items[id].value_str, value, 255);
    sa.items[id].modified = 1;
    sa.total_changes++;
    return 0;
}

int settings_get_value(int id, char *buf, int size)
{
    if (id < 0 || id >= SETTINGS_MAX_ITEMS || !sa.items[id].used || !buf || size <= 0) return -1;
    strncpy(buf, sa.items[id].value_str, size - 1);
    return 0;
}

int settings_set_bool(int id, int value)
{
    if (id < 0 || id >= SETTINGS_MAX_ITEMS || !sa.items[id].used) return -1;
    if (sa.items[id].protected) return -1;
    sa.items[id].value_bool = value ? 1 : 0;
    sa.items[id].modified = 1;
    sa.total_changes++;
    return 0;
}

int settings_get_bool(int id)
{
    if (id < 0 || id >= SETTINGS_MAX_ITEMS || !sa.items[id].used) return 0;
    return sa.items[id].value_bool;
}

int settings_set_int(int id, int value)
{
    if (id < 0 || id >= SETTINGS_MAX_ITEMS || !sa.items[id].used) return -1;
    if (sa.items[id].protected) return -1;
    if (value < sa.items[id].min_val) value = sa.items[id].min_val;
    if (value > sa.items[id].max_val) value = sa.items[id].max_val;
    sa.items[id].value_int = value;
    sa.items[id].modified = 1;
    sa.total_changes++;
    return 0;
}

int settings_get_int(int id)
{
    if (id < 0 || id >= SETTINGS_MAX_ITEMS || !sa.items[id].used) return 0;
    return sa.items[id].value_int;
}

int settings_reset(int id)
{
    if (id < 0 || id >= SETTINGS_MAX_ITEMS || !sa.items[id].used) return -1;
    sa.items[id].value_int = 0;
    sa.items[id].value_bool = 0;
    sa.items[id].value_str[0] = 0;
    sa.items[id].modified = 0;
    return 0;
}

int settings_reset_category(setting_category_t category)
{
    for (int i = 0; i < SETTINGS_MAX_ITEMS; i++) {
        if (sa.items[i].used && sa.items[i].category == category && !sa.items[i].protected)
            settings_reset(i);
    }
    return 0;
}

int settings_reset_all(void)
{
    for (int i = 0; i < SETTINGS_MAX_ITEMS; i++) {
        if (sa.items[i].used && !sa.items[i].protected)
            settings_reset(i);
    }
    return 0;
}

/* 查询 */
int settings_get_item(int id, setting_item_t *item)
{
    if (id < 0 || id >= SETTINGS_MAX_ITEMS || !sa.items[id].used || !item) return -1;
    memcpy(item, &sa.items[id], sizeof(setting_item_t));
    return 0;
}

int settings_list_by_category(setting_category_t category, setting_item_t *items, int max)
{
    if (!items || max <= 0) return 0;
    int count = 0;
    for (int i = 0; i < SETTINGS_MAX_ITEMS && count < max; i++) {
        if (sa.items[i].used && sa.items[i].category == category && sa.items[i].visible)
            memcpy(&items[count++], &sa.items[i], sizeof(setting_item_t));
    }
    return count;
}

int settings_list_all(setting_item_t *items, int max)
{
    if (!items || max <= 0) return 0;
    int count = 0;
    for (int i = 0; i < SETTINGS_MAX_ITEMS && count < max; i++) {
        if (sa.items[i].used) memcpy(&items[count++], &sa.items[i], sizeof(setting_item_t));
    }
    return count;
}

int settings_get_category_info(setting_category_t category, setting_category_info_t *info)
{
    if (category >= SETTINGS_MAX_CATEGORIES || !info) return -1;
    memcpy(info, &sa.categories[category], sizeof(setting_category_info_t));
    return 0;
}

int settings_list_categories(setting_category_info_t *categories, int max)
{
    if (!categories || max <= 0) return 0;
    int count = sa.category_count < max ? sa.category_count : max;
    for (int i = 0; i < count; i++)
        memcpy(&categories[i], &sa.categories[i], sizeof(setting_category_info_t));
    return count;
}

/* 搜索 */
int settings_search(const char *query, int *results, int max)
{
    if (!query || !results || max <= 0) return 0;
    int count = 0;
    for (int i = 0; i < SETTINGS_MAX_ITEMS && count < max; i++) {
        if (sa.items[i].used && sa.items[i].visible) {
            if (strstr(sa.items[i].name, query) || strstr(sa.items[i].description, query))
                results[count++] = i;
        }
    }
    return count;
}

/* 导入导出 */
int settings_export(char *buf, int size)
{
    if (!buf || size <= 0) return -1;
    int pos = 0;
    for (int i = 0; i < SETTINGS_MAX_ITEMS && pos < size - 64; i++) {
        if (sa.items[i].used && sa.items[i].modified) {
            int len = strlen(sa.items[i].name);
            if (pos + len + 32 < size) {
                memcpy(buf + pos, sa.items[i].name, len);
                pos += len;
                buf[pos++] = '=';
                buf[pos++] = '0' + sa.items[i].value_bool;
                buf[pos++] = '\n';
            }
        }
    }
    buf[pos] = 0;
    return pos;
}

int settings_import(const char *data)
{
    (void)data;
    return 0;
}

/* 导航 */
int settings_navigate(setting_category_t category)
{
    if (category >= SETTINGS_MAX_CATEGORIES) return -1;
    sa.current_category = category;
    return 0;
}

int settings_get_current_category(setting_category_t *category)
{
    if (!category) return -1;
    *category = sa.current_category;
    return 0;
}

/* 统计 */
int settings_get_stats(settings_app_t *stats)
{
    if (!stats) return -1;
    memcpy(stats, &sa, sizeof(settings_app_t));
    return 0;
}
