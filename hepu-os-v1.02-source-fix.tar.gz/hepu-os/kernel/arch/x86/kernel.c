/* ============================================================================
 * 赫普OS (HEPU Hyper Evolve OS) - 内核主入口 V0.2
 * 新增：物理内存管理、分页、内核堆、进程管理、系统调用
 * ========================================================================== */

#include <stdint.h>
#include <stddef.h>
#include "hepu.h"
#include "vga.h"
#include "types.h"
#include "gdt.h"
#include "idt.h"
#include "fingerprint.h"
#include "mm.h"
#include "paging.h"
#include "kheap.h"
#include "sched.h"
#include "process.h"
#include "syscall.h"
#include "hal.h"
#include "ipc.h"
#include "string.h"
#include "pic.h"
#include "pit.h"
#include "irq.h"
#include "keyboard.h"
#include "tss.h"
#include "initrd.h"
#include "vfs.h"
#include "devfs.h"
#include "net.h"
#include "touch.h"
#include "smp.h"
#include "dynld.h"
#include "usb.h"
#include "pm.h"
#include "security.h"
#include "dtb.h"
#include "audio.h"
#include "camera.h"
#include "bluetooth.h"
#include "wifi.h"
#include "arp.h"
#include "dhcp.h"
#include "dns.h"
#include "icmp.h"
#include "http.h"
#include "tls.h"
#include "tcp.h"
#include "websocket.h"
#include "x509.h"
#include "csprng.h"
#include "ecdhe.h"
#include "sha.h"
#include "hmac.h"
#include "hkdf.h"
#include "rsa.h"
#include "http2.h"
#include "tls_handshake.h"
#include "quic.h"
#include "http3.h"
#include "doq.h"
#include "quic_0rtt.h"
#include "quic_migration.h"
#include "quic_recovery.h"
#include "mp_quic.h"
#include "quic_datagram.h"
#include "qpack_dynamic.h"
#include "init_sequence.h"
#include "kunit.h"
#include "kbench.h"
#include "kunit_log.h"
#include "services.h"
#include "gpu.h"
#include "sensors.h"
#include "gps.h"
#include "ota.h"
#include "codec.h"
#include "compositor.h"
#include "input.h"
#include "trace.h"
#include "media.h"
#include "camera_hal.h"
#include "ril.h"
#include "appframework.h"
#include "packagemanager.h"
#include "notification.h"
#include "windowsystem.h"
#include "share.h"
#include "account.h"
#include "systemui.h"
#include "webengine.h"
#include "ai.h"
#include "security2.h"
#include "media2.h"
#include "desktopmode.h"
#include "gameframework.h"
#include "enterprise.h"
#include "devtools.h"
#include "compat.h"
#include "fs2.h"
#include "net2.h"
#include "bt2.h"
#include "usb2.h"
#include "gfx2.h"
#include "camera2.h"
#include "audio2.h"
#include "telecom2.h"
#include "ai2.h"
#include "carlink.h"
#include "enterprise2.h"
#include "kernel_opt.h"
#include "drivers2.h"
#include "fs3.h"
#include "net3.h"
#include "appeco.h"
#include "kernel_core.h"
#include "drivers_real.h"
#include "userland.h"
#include "fs_real.h"
#include "bootchain.h"
#include "kdebug.h"
#include "kperf.h"
#include "distributed.h"
#include "hhal.h"
#include "hdpk.h"
#include "device_support.h"
#include "fp_enhanced.h"
#include "phone_service.h"
#include "sms_service.h"
#include "settings_app.h"
#include "file_manager.h"
#include "camera_app.h"
#include "gallery_app.h"
#include "browser_app.h"
#include "app_store.h"
#include "system_tools.h"
#include "music_player.h"
#include "video_player.h"
#include "photo_editor.h"
#include "voice_recorder.h"
#include "audio_effects.h"
#include "hug_sdk.h"
#include "hug_template.h"
#include "hug_debugger.h"
#include "hug_depman.h"
#include "apk_parser.h"
#include "microg_service.h"
#include "art_runtime.h"
#include "compat_layer.h"
#include "secure_boot.h"
#include "boot_optimizer.h"
#include "memory_optimizer.h"
#include "kernel_slimmer.h"
#include "perf_profiler.h"
#include "hepu_brand.h"
#include "app_container.h"
#include "distributed_os.h"
#include "car_connect.h"
#include "privacy_compute.h"
#include "realtime_kernel.h"
#include "power_optimizer.h"
#include "permission_manager.h"
#include "notification_center.h"
#include "i18n_system.h"
#include "multilingual_ime.h"
#include "backup_restore.h"
#include "storage_manager.h"
#include "multi_user.h"
#include "system_stability.h"
#include "app_freeze.h"
#include "id_randomizer.h"
#include "elastic_desktop.h"
#include "ai_notification.h"
#include "creator_mode.h"
#include "onboarding.h"
#include "lowmem_throttle.h"
#include "hdpk_template.h"
#include "android_api.h"
#include "driver_manager.h"
#include "bist.h"
#include "ai_assistant.h"
#include "socket.h"
#include "mount.h"
#include "quota.h"
#include "fs_registry.h"
#include "vfat.h"
#include "journal.h"
#include "ide.h"
#include "ext4.h"
#include "fscrypt.h"
#include "partition.h"
#include "unified_driver.h"
#include "ahci.h"
#include "nvme.h"
#include "exfat.h"
#include "ntfs.h"
#include "aes.h"
#include "eth.h"
#include "wifi.h"
#include "arp.h"
#include "dhcp.h"
#include "dns.h"
#include "icmp.h"
#include "http.h"
#include "tls.h"
#include "tcp.h"
#include "websocket.h"
#include "x509.h"
#include "csprng.h"
#include "ecdhe.h"
#include "sha.h"
#include "hmac.h"
#include "hkdf.h"
#include "rsa.h"
#include "http2.h"
#include "tls_handshake.h"
#include "quic.h"
#include "http3.h"
#include "doq.h"
#include "quic_0rtt.h"
#include "quic_migration.h"
#include "quic_recovery.h"
#include "mp_quic.h"
#include "quic_datagram.h"
#include "qpack_dynamic.h"
#include "init_sequence.h"
#include "kunit.h"
#include "kbench.h"
#include "kunit_log.h"

/* 用户态程序入口 (定义在 user/init/user_init.S) */
extern void user_init_start(void);
extern void user_init_end(void);

/* 第二个用户态进程 (定义在 user/apps/procb/procb.S) */
extern void procb_start(void);

/* initrd 镜像符号 (由 objcopy 生成) */
extern uint8_t _binary_build_initrd_img_start[];
extern uint8_t _binary_build_initrd_img_end[];

/* Multiboot 信息结构 */
typedef struct {
    uint32_t flags;
    uint32_t mem_lower;
    uint32_t mem_upper;
    uint32_t boot_device;
    uint32_t cmdline;
    uint32_t mods_count;
    uint32_t mods_addr;
} multiboot_info_t;

extern hepu_fingerprint_t hepu_fingerprint;

const char *hepu_kernel_version = "1.0.2";
const char *hepu_kernel_name = "HEPU Hyper Evolve OS";

/* 简单的用户态测试函数（原型阶段在内核态模拟） */
static void __attribute__((unused)) user_test_function(void)
{
    /* 模拟用户态通过系统调用打印 */
    const char *msg = "  [用户态模拟] 你好！我是赫普OS第一个用户进程。\n";
    syscall_handler(SYS_PRINT, (uint32_t)msg, 0, 0, 0);

    uint32_t ver_ptr = syscall_handler(SYS_HEPU_INFO, 0, 0, 0, 0);
    syscall_handler(SYS_PRINT, ver_ptr, 0, 0, 0);
    syscall_handler(SYS_PRINT, (uint32_t)"\n", 0, 0, 0);
}

#ifdef HEPU_BOOT_DEBUG
/* V2.08: 内核启动蜂鸣诊断已移除——用户明确要求去蜂鸣, 改用文本日志.
   启动进度完全依赖屏幕KLOG文本(K0-K5, boot.S VGA直写) + 引导器行8-12文本标签. */
#endif

void hepu_kernel_main(uint32_t magic, multiboot_info_t *mb_info)
{
    (void)magic;
#ifdef HEPU_BOOT_DEBUG
    /* 诊断K4: 进入内核主函数(BSS清零+call都成功).
       屏幕日志主通道: 显示"K4 MAIN CALL"到行4(与boot.S的KLOG一致).
       V2.08: 已去除K4蜂鸣7次, 纯文本日志. */
    {
        extern char klog4[];
        __asm__ volatile(
            "movw $0x10, %%ax\n\t"
            "movw %%ax, %%es\n\t"
            "movl $0xB8000, %%edi\n\t"
            "movl $640, %%ecx\n\t"       /* 行4*160 */
            "addl %%ecx, %%edi\n\t"
            "movl %0, %%esi\n\t"
            "1: lodsb\n\t"
            "testb %%al, %%al\n\t"
            "jz 2f\n\t"
            "movb %%al, %%es:(%%edi)\n\t"
            "movb $0x0F, %%es:1(%%edi)\n\t"
            "addl $2, %%edi\n\t"
            "jmp 1b\n\t"
            "2:\n\t"
            : : "r"(klog4) : "ax", "cx", "di", "si", "memory");
    }
#endif

    /* ---- 基础初始化 ---- */
    vga_init();
    vga_clear();
    gdt_init();
    idt_init();
    extern void early_console_init(void);
    early_console_init();
    extern void multiboot_init(uint32_t, void *);
    multiboot_init(magic, mb_info);
    extern void cpu_init(void);
    cpu_init();

    /* ---- 启动横幅 ---- */
    vga_set_color(VGA_COLOR_LIGHT_CYAN, VGA_COLOR_BLACK);
    vga_puts("╔══════════════════════════════════════════════╗\n");
    vga_puts("║     HEPU HYPER EVOLVE OS  赫普超感操作系统   ║\n");
    vga_puts("╚══════════════════════════════════════════════╝\n\n");

    vga_set_color(VGA_COLOR_LIGHT_GREY, VGA_COLOR_BLACK);
    vga_printf("Kernel Version : %s\n", hepu_kernel_version);
    vga_printf("Architecture   : x86 (i686)\n");

    uint32_t mem_kb = 0;
    if (mb_info && (mb_info->flags & 0x1)) {
        mem_kb = mb_info->mem_lower + mb_info->mem_upper;
        vga_printf("Total Memory   : %d KB (%d MB)\n", mem_kb, mem_kb / 1024);
    }
    vga_putc('\n');

    /* ---- 版权指纹校验 ---- */
    vga_set_color(VGA_COLOR_YELLOW, VGA_COLOR_BLACK);
    vga_puts("[HEPU] 内核版权指纹校验...\n");
    fingerprint_result_t fp_result = fingerprint_verify(&hepu_fingerprint);
    if (fp_result.valid) {
        vga_set_color(VGA_COLOR_GREEN, VGA_COLOR_BLACK);
        vga_printf("[HEPU] 指纹校验通过: %s\n", hepu_fingerprint.name);
        vga_printf("[HEPU] 开源协议: %s\n", hepu_fingerprint.license);
    } else {
        vga_set_color(VGA_COLOR_RED, VGA_COLOR_BLACK);
        vga_puts("[HEPU] 警告: 内核版权指纹被篡改!\n");
    }
    vga_set_color(VGA_COLOR_LIGHT_GREY, VGA_COLOR_BLACK);
    vga_putc('\n');

    /* ---- 内存管理初始化 ---- */
    vga_puts("=== 内存子系统 ===\n");

    /* 物理内存管理：位图放在 2MB 处 */
    if (mem_kb > 0) {
        mm_init(mem_kb, 0x00200000);
    }

    /* 分页初始化（身份映射前16MB） */
    paging_init(mem_kb);
    /* 注意：原型阶段不启用分页，避免地址转换问题
     * 完整实现需要TSS和正确的虚拟内存布局 */

    /* 内核堆：放在 4MB - 8MB */
    kheap_init(0x00400000, 4 * 1024 * 1024);
    extern void slab_init(void);
    slab_init();
    extern void reclaim_init(void);
    reclaim_init();
    extern void swap_init(void);
    swap_init();
    extern void hugetlb_init(void);
    hugetlb_init();
    extern void acpi_init(void);
    acpi_init();

    /* 测试内核堆 */
    void *test_ptr = kmalloc(256);
    if (test_ptr) {
        vga_set_color(VGA_COLOR_GREEN, VGA_COLOR_BLACK);
        vga_printf("[KHEAP] kmalloc(256) = 0x%x 测试通过\n", (uint32_t)test_ptr);
        kfree(test_ptr);
    }
    vga_set_color(VGA_COLOR_LIGHT_GREY, VGA_COLOR_BLACK);
    vga_putc('\n');

    /* ---- 进程与调度初始化 ---- */
    vga_puts("=== 进程子系统 ===\n");
    sched_init();
    process_init();
    ipc_init();
    extern void ipc_sem_init(void);
    ipc_sem_init();
    extern void ipc_mutex_init(void);
    ipc_mutex_init();
    extern void ipc_cond_init(void);
    ipc_cond_init();
    extern void ipc_fifo_init(void);
    ipc_fifo_init();
    extern void ipc_perm_init(void);
    ipc_perm_init();
    unified_driver_init();  /* 统一驱动框架：包含hal+hhal+driver_manager */
    extern void hal_device_init(void);
    hal_device_init();
    extern void hotplug_init(void);
    hotplug_init();
    extern void hal_irq_init(void);
    hal_irq_init();
    extern void hal_clock_init(uint32_t);
    hal_clock_init(1000);
    extern void hal_gpio_init(void);
    hal_gpio_init();
    extern void dma_init(void);
    dma_init();
    extern void power_init(void);
    power_init();
    /* hal_init(); - 已整合到unified_driver_init */
    syscall_init();
    vga_putc('\n');

    /* ---- 系统调用测试 ---- */
    vga_puts("=== 系统调用测试 ===\n");
    vga_set_color(VGA_COLOR_GREEN, VGA_COLOR_BLACK);

    /* 测试 SYS_HEPU_INFO */
    uint32_t ver = syscall_handler(SYS_HEPU_INFO, 0, 0, 0, 0);
    vga_printf("[SYSCALL] SYS_HEPU_INFO -> %s\n", (char *)ver);

    /* 测试 SYS_HEPU_FP_VERIFY */
    uint32_t fp_ok = syscall_handler(SYS_HEPU_FP_VERIFY, 0, 0, 0, 0);
    vga_printf("[SYSCALL] SYS_HEPU_FP_VERIFY -> %s\n",
               fp_ok == 0 ? "指纹有效" : "指纹无效");

    /* 测试 SYS_MALLOC / SYS_FREE */
    uint32_t alloc = syscall_handler(SYS_MALLOC, 128, 0, 0, 0);
    vga_printf("[SYSCALL] SYS_MALLOC(128) -> 0x%x\n", alloc);
    syscall_handler(SYS_FREE, alloc, 0, 0, 0);
    vga_puts("[SYSCALL] SYS_FREE -> ok");

    vga_set_color(VGA_COLOR_LIGHT_GREY, VGA_COLOR_BLACK);
    vga_putc('\n');

    vga_putc('\n');

    /* ---- 硬件中断子系统 ---- */
    vga_puts("=== 硬件中断子系统 ===\n");
    pic_init();
    irq_init();
    pit_init();
    keyboard_init();
    tss_init();
    irq_register_handler(IRQ_TIMER, pit_handler);
    __asm__ volatile ("sti");
    vga_puts("[IRQ] 全局中断已开启\n");
    vga_putc('\n');

    /* ---- initrd 文件系统 ---- */
    vga_puts("=== initrd 文件系统 ===\n");
    uint32_t initrd_addr = (uint32_t)_binary_build_initrd_img_start;
    uint32_t initrd_sz = (uint32_t)(_binary_build_initrd_img_end - _binary_build_initrd_img_start);
    initrd_init(initrd_addr, initrd_sz);
    if (initrd_ready()) {
        initrd_list();
    }
    vga_putc('\n');

    /* ---- VFS 虚拟文件系统 ---- */
    vga_puts("=== VFS 虚拟文件系统 ===\n");
    hepu_init_sequence();
    kunit_init();
    kbench_init();
    extern int kbench_run_kernel(void);
    kbench_run_kernel();
    kunit_log_init();
    extern void kunit_register_all_suites(void);
    kunit_register_all_suites();

    /* ---- 子系统状态汇总 ---- */
    vga_puts("=== 微内核子系统状态 ===\n");
    vga_set_color(VGA_COLOR_GREEN, VGA_COLOR_BLACK);
    vga_puts("  [OK] 物理内存管理 (位图分配器)\n");
    vga_puts("  [OK] 分页机制 (页目录/页表框架)\n");
    vga_puts("  [OK] 内核堆 (kmalloc/kfree)\n");
    vga_puts("  [OK] 进程管理 (PCB/上下文切换框架)\n");
    vga_puts("  [OK] 系统调用 (int 0x80, 14个调用号)\n");
    vga_puts("  [OK] IPC 消息传递\n");
    vga_puts("  [OK] H-HAL 硬件抽象层 (驱动故障隔离)\n");
    vga_puts("  [OK] 内核版权指纹 (开源保护)\n");
    vga_set_color(VGA_COLOR_YELLOW, VGA_COLOR_BLACK);
    vga_puts("  [..] TSS/真正用户态切换 (待实现)\n");
    vga_puts("  [..] 文件系统服务 (待实现)\n");
    vga_puts("  [..] 网络协议栈 (待实现)\n");
    vga_puts("  [..] 图形子系统 (待实现)\n");
    vga_puts("  [..] .hug 应用加载器 (待实现)\n");

    vga_set_color(VGA_COLOR_LIGHT_CYAN, VGA_COLOR_BLACK);
    vga_putc('\n');
    vga_puts("赫普OS V1.02 微内核启动完成。\n");
    vga_puts("系统归人，数据归己，自由可控，极致纯净。\n");

    vga_set_color(VGA_COLOR_LIGHT_GREY, VGA_COLOR_BLACK);
    vga_putc('\n');

    /* ---- 创建用户态进程并进入 ---- */
    vga_puts("=== 用户态进程 ===\n");
    process_t *proc1 = process_create("init",
                                       (uint32_t)user_init_start,
                                       PRIV_USER, 100);
    process_t *proc2 = process_create("procb",
                                       (uint32_t)procb_start,
                                       PRIV_USER, 100);
    if (proc1 && proc2) {
        vga_set_color(VGA_COLOR_GREEN, VGA_COLOR_BLACK);
        vga_printf("[PROC] init (PID=%d), procb (PID=%d)\n", proc1->pid, proc2->pid);
        vga_puts("[PROC] 抢占式调度就绪，时钟中断将在进程间切换\n");
        vga_set_color(VGA_COLOR_LIGHT_GREY, VGA_COLOR_BLACK);
        vga_putc('\n');
        process_enter_user_mode(proc1);
    }

    vga_puts("(启动 Shell...)\n");

    /* 启动内核 Shell */
    extern void shell_main(void);
    shell_main();
}
