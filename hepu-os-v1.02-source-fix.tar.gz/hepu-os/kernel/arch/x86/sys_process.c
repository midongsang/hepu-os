/* ============================================================================
 * 赫普OS - 系统调用：PROCESS
 * ========================================================================== */

#include "types.h"
#include <stdint.h>
#include <stddef.h>
#include "syscall.h"
#include "vga.h"
#include "kheap.h"
#include "sched.h"
#include "hepu.h"
#include "fingerprint.h"
#include "vfs.h"
#include "ipc.h"
extern const char *hepu_kernel_version;

u32 sys_exit(u32 code, u32 arg2,
                         u32 arg3, u32 arg4)
{
    (void)arg2; (void)arg3; (void)arg4;
    vga_printf("[SYSCALL] 进程退出 (code=%d)\n", code);
    /* 原型阶段：停机 */
    for (;;) { __asm__ volatile ("hlt"); }
    return 0;
}

u32 sys_yield(u32 arg1, u32 arg2,
                          u32 arg3, u32 arg4)
{
    (void)arg1; (void)arg2; (void)arg3; (void)arg4;
    sched_tick();
    return 0;
}

u32 sys_getpid(u32 arg1, u32 arg2,
                           u32 arg3, u32 arg4)
{
    (void)arg1; (void)arg2; (void)arg3; (void)arg4;
    return sched_current_pid();
}

u32 sys_kill(u32 pid, u32 sig,
                         u32 arg3, u32 arg4)
{
    (void)arg3; (void)arg4;
    return ipc_kill(pid, sig);
}

u32 sys_signal(u32 sig, u32 handler_ptr,
                           u32 arg3, u32 arg4)
{
    (void)arg3; (void)arg4;
    return ipc_signal(sig, (void (*)(int))handler_ptr);
}

u32 sys_clone(u32 flags, u32 stack_ptr, u32 ptid, u32 ctid)
{
    (void)flags; (void)stack_ptr; (void)ptid; (void)ctid;
    return (u32)-1;  /* 原型阶段不支持 */
}

u32 sys_waitpid(u32 pid, u32 status_ptr, u32 options, u32 arg4)
{
    (void)pid; (void)status_ptr; (void)options; (void)arg4;
    return 0;
}

u32 sys_execve(u32 path_ptr, u32 argv, u32 envp, u32 arg4)
{
    (void)argv; (void)envp; (void)arg4;
    extern int sys_execve_impl(const char *path, char *const argv[], char *const envp[]);
    return (u32)sys_execve_impl((const char *)path_ptr, NULL, NULL);
}

u32 sys_fork(u32 arg1, u32 arg2, u32 arg3, u32 arg4)
{
    (void)arg1; (void)arg2; (void)arg3; (void)arg4;
    extern int sys_fork_impl(void);
    return (u32)sys_fork_impl();
}

