/* ============================================================================
 * 赫普OS - VGA 文本模式驱动
 * ========================================================================== */

#include <stdint.h>
#include <stddef.h>
#include "vga.h"

#define VGA_BUFFER 0xB8000
#define VGA_WIDTH  80
#define VGA_HEIGHT 25

static uint16_t *vga_buffer = (uint16_t *)VGA_BUFFER;
static size_t   vga_row = 0;
static size_t   vga_col = 0;
static uint8_t  vga_color = 0x07;

/* 颜色组合 */
uint8_t vga_make_color(enum vga_color fg, enum vga_color bg)
{
    return fg | (bg << 4);
}

/* 生成字符单元 */
uint16_t vga_make_entry(char c, uint8_t color)
{
    return (uint16_t)c | ((uint16_t)color << 8);
}

void vga_init(void)
{
    vga_row = 0;
    vga_col = 0;
    vga_color = vga_make_color(VGA_COLOR_LIGHT_GREY, VGA_COLOR_BLACK);
    vga_clear();
}

void vga_clear(void)
{
    for (size_t y = 0; y < VGA_HEIGHT; y++) {
        for (size_t x = 0; x < VGA_WIDTH; x++) {
            vga_buffer[y * VGA_WIDTH + x] = vga_make_entry(' ', vga_color);
        }
    }
    vga_row = 0;
    vga_col = 0;
}

void vga_set_color(uint8_t fg, uint8_t bg)
{
    vga_color = vga_make_color(fg, bg);
}

static void vga_scroll(void)
{
    if (vga_row >= VGA_HEIGHT) {
        /* 上移一行 */
        for (size_t y = 0; y < VGA_HEIGHT - 1; y++) {
            for (size_t x = 0; x < VGA_WIDTH; x++) {
                vga_buffer[y * VGA_WIDTH + x] =
                    vga_buffer[(y + 1) * VGA_WIDTH + x];
            }
        }
        /* 清空最后一行 */
        for (size_t x = 0; x < VGA_WIDTH; x++) {
            vga_buffer[(VGA_HEIGHT - 1) * VGA_WIDTH + x] =
                vga_make_entry(' ', vga_color);
        }
        vga_row = VGA_HEIGHT - 1;
    }
}

void vga_putc(char c)
{
    if (c == '\n') {
        vga_col = 0;
        vga_row++;
        vga_scroll();
        return;
    }
    if (c == '\r') {
        vga_col = 0;
        return;
    }
    if (c == '\t') {
        vga_col = (vga_col + 8) & ~7;
        if (vga_col >= VGA_WIDTH) {
            vga_col = 0;
            vga_row++;
            vga_scroll();
        }
        return;
    }

    vga_buffer[vga_row * VGA_WIDTH + vga_col] =
        vga_make_entry(c, vga_color);

    if (++vga_col >= VGA_WIDTH) {
        vga_col = 0;
        vga_row++;
        vga_scroll();
    }
}

void vga_puts(const char *str)
{
    while (*str) {
        vga_putc(*str++);
    }
}

/* 简易 printf，支持 %s %d %x %c */
void vga_printf(const char *fmt, ...)
{
    __builtin_va_list args;
    __builtin_va_start(args, fmt);

    while (*fmt) {
        if (*fmt == '%') {
            fmt++;
            switch (*fmt) {
                case 's': {
                    const char *s = __builtin_va_arg(args, const char *);
                    vga_puts(s ? s : "(null)");
                    break;
                }
                case 'd': {
                    int d = __builtin_va_arg(args, int);
                    char buf[16];
                    int pos = 0;
                    int neg = 0;
                    if (d < 0) { neg = 1; d = -d; }
                    if (d == 0) buf[pos++] = '0';
                    while (d > 0) {
                        buf[pos++] = '0' + (d % 10);
                        d /= 10;
                    }
                    if (neg) buf[pos++] = '-';
                    while (pos > 0) vga_putc(buf[--pos]);
                    break;
                }
                case 'x': {
                    unsigned int x = __builtin_va_arg(args, unsigned int);
                    char buf[16];
                    int pos = 0;
                    const char *hex = "0123456789ABCDEF";
                    if (x == 0) buf[pos++] = '0';
                    while (x > 0) {
                        buf[pos++] = hex[x & 0xF];
                        x >>= 4;
                    }
                    vga_puts("0x");
                    while (pos > 0) vga_putc(buf[--pos]);
                    break;
                }
                case 'c': {
                    char c = (char)__builtin_va_arg(args, int);
                    vga_putc(c);
                    break;
                }
                case '%':
                    vga_putc('%');
                    break;
                default:
                    vga_putc('%');
                    vga_putc(*fmt);
                    break;
            }
        } else {
            vga_putc(*fmt);
        }
        fmt++;
    }

    __builtin_va_end(args);
}

/* 写缓冲区内容到屏幕（V1.01新增，替代不存在的幻觉API） */
void vga_write(const void *buf, uint32_t len)
{
    const uint8_t *p = (const uint8_t *)buf;
    for (uint32_t i = 0; i < len; i++) {
        vga_putc((char)p[i]);
    }
}
