/* ============================================================================
 * 赫普OS - 应用权限精细化管理
 * ========================================================================== */

#include <stdint.h>
#include "permission_manager.h"
#include "vga.h"
#include "string.h"

static permission_manager_t pm;

void permission_manager_init(void)
{
    memset(&pm, 0, sizeof(permission_manager_t));
    pm.initialized = 1;
    pm.enabled = 1;
    pm.config.onetime_permissions = 1;
    pm.config.fuzzy_location = 1;
    pm.config.empty_info_auth = 1;
    pm.config.permission_logging = 1;
    pm.config.auto_revoke_unused = 1;
    pm.config.auto_revoke_days = 30;
    pm.config.clipboard_warning = 1;
    pm.config.camera_mic_indicator = 1;
    pm.config.approximate_location_default = 1;
    pm.camera_in_use_by = -1;
    pm.mic_in_use_by = -1;
    pm.location_in_use_by = -1;

    vga_puts("[PERM] 权限管理器初始化完成\n");
    vga_printf("        一次性: %s, 模糊定位: %s, 空信息: %s\n",
               pm.config.onetime_permissions ? "开启" : "关闭",
               pm.config.fuzzy_location ? "开启" : "关闭",
               pm.config.empty_info_auth ? "开启" : "关闭");
}

int prm_app_register(const char *name, const char *package)
{
    for (int i = 0; i < PM_MAX_APPS; i++) {
        if (!pm.apps[i].used) {
            memset(&pm.apps[i], 0, sizeof(prm_app_perms_t));
            pm.apps[i].used = 1;
            pm.apps[i].app_id = i;
            if (name) strncpy(pm.apps[i].app_name, name, 127);
            if (package) strncpy(pm.apps[i].package, package, 127);
            pm.apps[i].fuzzy_location_radius = 1000.0f;  /* 默认1公里模糊 */
            pm.app_count++;
            return i;
        }
    }
    return -1;
}

int prm_app_unregister(int app_id)
{
    if (app_id < 0 || app_id >= PM_MAX_APPS || !pm.apps[app_id].used) return -1;
    pm.apps[app_id].used = 0;
    pm.app_count--;
    return 0;
}

int prm_app_get(int app_id, prm_app_perms_t *perms)
{
    if (app_id < 0 || app_id >= PM_MAX_APPS || !pm.apps[app_id].used || !perms) return -1;
    memcpy(perms, &pm.apps[app_id], sizeof(prm_app_perms_t));
    return 0;
}

int prm_app_list(prm_app_perms_t *apps, int max)
{
    if (!apps || max <= 0) return 0;
    int count = 0;
    for (int i = 0; i < PM_MAX_APPS && count < max; i++) {
        if (pm.apps[i].used) memcpy(&apps[count++], &pm.apps[i], sizeof(prm_app_perms_t));
    }
    return count;
}

int prm_request_permission(int app_id, prm_permission_t perm)
{
    if (app_id < 0 || app_id >= PM_MAX_APPS || !pm.apps[app_id].used) return -1;
    pm.total_permission_checks++;
    /* 默认拒绝，需要用户授权 */
    return pm.apps[app_id].grants[perm] == PM_GRANT_ALLOWED ? 1 : 0;
}

int prm_grant_permission(int app_id, prm_permission_t perm, prm_grant_t grant)
{
    if (app_id < 0 || app_id >= PM_MAX_APPS || !pm.apps[app_id].used) return -1;
    pm.apps[app_id].grants[perm] = grant;
    return 0;
}

int prm_revoke_permission(int app_id, prm_permission_t perm)
{
    if (app_id < 0 || app_id >= PM_MAX_APPS || !pm.apps[app_id].used) return -1;
    pm.apps[app_id].grants[perm] = PM_GRANT_DENIED;
    return 0;
}

int prm_check_permission(int app_id, prm_permission_t perm, int *granted)
{
    if (app_id < 0 || app_id >= PM_MAX_APPS || !pm.apps[app_id].used) return -1;
    pm.total_permission_checks++;
    prm_grant_t g = pm.apps[app_id].grants[perm];
    int allow = 0;
    if (g == PM_GRANT_ALLOWED || g == PM_GRANT_WHILE_USING ||
        g == PM_GRANT_ONETIME || g == PM_GRANT_FUZZY) {
        /* 检查一次性权限是否过期 */
        if (g == PM_GRANT_ONETIME && pm.apps[app_id].onetime_expiry[perm] > 0) {
            /* 简化：假设未过期 */
            allow = 1;
        } else {
            allow = 1;
        }
    }
    if (!allow) pm.total_permission_denials++;
    if (granted) *granted = allow;
    /* 记录使用 */
    if (allow) {
        pm.apps[app_id].usage_count[perm]++;
        pm.apps[app_id].last_used[perm] = 1;
        prm_log_access(app_id, perm, 0, NULL);
        /* 更新使用指示器 */
        if (perm == PM_PERM_CAMERA) pm.camera_in_use_by = app_id;
        if (perm == PM_PERM_MICROPHONE) pm.mic_in_use_by = app_id;
        if (perm == PM_PERM_LOCATION) pm.location_in_use_by = app_id;
    }
    return 0;
}

int prm_get_permission_status(int app_id, prm_permission_t perm, prm_grant_t *grant)
{
    if (app_id < 0 || app_id >= PM_MAX_APPS || !pm.apps[app_id].used || !grant) return -1;
    *grant = pm.apps[app_id].grants[perm];
    return 0;
}

int prm_grant_onetime(int app_id, prm_permission_t perm, uint64_t duration_ms)
{
    if (app_id < 0 || app_id >= PM_MAX_APPS || !pm.apps[app_id].used) return -1;
    pm.apps[app_id].grants[perm] = PM_GRANT_ONETIME;
    pm.apps[app_id].onetime_expiry[perm] = duration_ms;
    pm.total_onetime_grants++;
    return 0;
}

int prm_onetime_expired(int app_id, prm_permission_t perm, int *expired)
{
    if (app_id < 0 || app_id >= PM_MAX_APPS || !pm.apps[app_id].used) return -1;
    if (pm.apps[app_id].grants[perm] != PM_GRANT_ONETIME) {
        if (expired) *expired = 0;
        return 0;
    }
    /* 简化：假设未过期 */
    if (expired) *expired = 0;
    return 0;
}

int prm_extend_onetime(int app_id, prm_permission_t perm, uint64_t duration_ms)
{
    if (app_id < 0 || app_id >= PM_MAX_APPS || !pm.apps[app_id].used) return -1;
    pm.apps[app_id].onetime_expiry[perm] += duration_ms;
    return 0;
}

int prm_set_fuzzy_location(int app_id, float radius_m)
{
    if (app_id < 0 || app_id >= PM_MAX_APPS || !pm.apps[app_id].used) return -1;
    pm.apps[app_id].fuzzy_location_radius = radius_m;
    pm.apps[app_id].grants[PM_PERM_LOCATION] = PM_GRANT_FUZZY;
    return 0;
}

int prm_get_fuzzy_location(int app_id, float *radius_m)
{
    if (app_id < 0 || app_id >= PM_MAX_APPS || !pm.apps[app_id].used || !radius_m) return -1;
    *radius_m = pm.apps[app_id].fuzzy_location_radius;
    return 0;
}

int prm_fuzzy_location_coords(float lat, float lon, float *fuzzy_lat, float *fuzzy_lon, float radius)
{
    if (!fuzzy_lat || !fuzzy_lon) return -1;
    /* 简化：在半径内随机偏移 */
    float offset = radius * 0.00001f;  /* 粗略转换 */
    *fuzzy_lat = lat + offset;
    *fuzzy_lon = lon + offset;
    return 0;
}

int prm_set_empty_auth(int app_id, prm_permission_t perm, int enable)
{
    if (app_id < 0 || app_id >= PM_MAX_APPS || !pm.apps[app_id].used) return -1;
    if (enable) pm.apps[app_id].grants[perm] = PM_GRANT_EMPTY;
    else pm.apps[app_id].grants[perm] = PM_GRANT_DENIED;
    return 0;
}

int prm_get_empty_data(prm_permission_t perm, void *buf, int size)
{
    if (!buf || size <= 0) return -1;
    memset(buf, 0, size);
    (void)perm;
    return 0;
}

int prm_log_access(int app_id, prm_permission_t perm, int duration_ms, const char *detail)
{
    if (!pm.config.permission_logging) return 0;
    int idx = pm.log_pos % PM_MAX_LOGS;
    memset(&pm.logs[idx], 0, sizeof(prm_log_entry_t));
    pm.logs[idx].used = 1;
    pm.logs[idx].id = idx;
    pm.logs[idx].app_id = app_id;
    pm.logs[idx].permission = perm;
    pm.logs[idx].timestamp = 1;
    pm.logs[idx].duration_ms = duration_ms;
    if (detail) strncpy(pm.logs[idx].detail, detail, 255);
    pm.log_pos++;
    if (pm.log_count < PM_MAX_LOGS) pm.log_count++;
    return 0;
}

int prm_get_logs(prm_log_entry_t *logs, int max)
{
    if (!logs || max <= 0) return 0;
    int count = pm.log_count < max ? pm.log_count : max;
    for (int i = 0; i < count; i++) {
        int idx = (pm.log_pos - count + i) % PM_MAX_LOGS;
        memcpy(&logs[i], &pm.logs[idx], sizeof(prm_log_entry_t));
    }
    return count;
}

int prm_get_app_logs(int app_id, prm_log_entry_t *logs, int max)
{
    if (!logs || max <= 0) return 0;
    int count = 0;
    for (int i = 0; i < PM_MAX_LOGS && count < max; i++) {
        if (pm.logs[i].used && pm.logs[i].app_id == app_id)
            memcpy(&logs[count++], &pm.logs[i], sizeof(prm_log_entry_t));
    }
    return count;
}

int prm_clear_logs(void)
{
    for (int i = 0; i < PM_MAX_LOGS; i++) pm.logs[i].used = 0;
    pm.log_count = 0;
    pm.log_pos = 0;
    return 0;
}

int prm_group_get(prm_permission_t perm, prm_group_t *group)
{
    (void)perm;
    if (!group) return -1;
    memset(group, 0, sizeof(prm_group_t));
    return 0;
}

int prm_group_list(prm_group_t *groups, int max)
{
    (void)groups; (void)max;
    return 0;
}

int prm_auto_revoke_check(void)
{
    int revoked = 0;
    for (int i = 0; i < PM_MAX_APPS; i++) {
        if (pm.apps[i].used && !pm.apps[i].restricted) {
            /* 简化：检查长期未使用的权限 */
            for (int p = 0; p < PM_MAX_PERMISSIONS; p++) {
                if (pm.apps[i].grants[p] == PM_GRANT_ALLOWED &&
                    pm.apps[i].usage_count[p] == 0) {
                    pm.apps[i].grants[p] = PM_GRANT_DENIED;
                    revoked++;
                    pm.total_auto_revokes++;
                }
            }
        }
    }
    return revoked;
}

int prm_auto_revoke_app(int app_id)
{
    if (app_id < 0 || app_id >= PM_MAX_APPS || !pm.apps[app_id].used) return -1;
    for (int p = 0; p < PM_MAX_PERMISSIONS; p++)
        pm.apps[app_id].grants[p] = PM_GRANT_DENIED;
    return 0;
}

int prm_get_suspicious_apps(prm_app_perms_t *apps, int max)
{
    if (!apps || max <= 0) return 0;
    int count = 0;
    for (int i = 0; i < PM_MAX_APPS && count < max; i++) {
        if (pm.apps[i].used && pm.apps[i].suspicious)
            memcpy(&apps[count++], &pm.apps[i], sizeof(prm_app_perms_t));
    }
    return count;
}

int prm_set_config(const prm_config_t *config)
{
    if (!config) return -1;
    memcpy(&pm.config, config, sizeof(prm_config_t));
    return 0;
}

int prm_get_config(prm_config_t *config)
{
    if (!config) return -1;
    memcpy(config, &pm.config, sizeof(prm_config_t));
    return 0;
}

int prm_get_camera_in_use(int *app_id)
{
    if (!app_id) return -1;
    *app_id = pm.camera_in_use_by;
    return 0;
}

int prm_get_mic_in_use(int *app_id)
{
    if (!app_id) return -1;
    *app_id = pm.mic_in_use_by;
    return 0;
}

int prm_get_location_in_use(int *app_id)
{
    if (!app_id) return -1;
    *app_id = pm.location_in_use_by;
    return 0;
}

int prm_get_stats(permission_manager_t *stats)
{
    if (!stats) return -1;
    memcpy(stats, &pm, sizeof(permission_manager_t));
    return 0;
}
