/* ============================================================================
 * 赫普OS - IRQ 硬件中断处理框架
 * 功能: 管理16个硬件中断(IRQ0-15)，分发给注册的处理函数
 * ========================================================================== */

#include <stdint.h>
#include "irq.h"
#include "pic.h"
#include "pit.h"
#include "vga.h"

#define IRQ_COUNT 16

static irq_handler_t irq_handlers[IRQ_COUNT] = {0};

void irq_init(void)
{
    for (int i = 0; i < IRQ_COUNT; i++) {
        irq_handlers[i] = 0;
    }
    vga_puts("[IRQ] 硬件中断处理框架初始化完成\n");
}

void irq_register_handler(uint8_t irq, irq_handler_t handler)
{
    if (irq >= IRQ_COUNT) return;
    irq_handlers[irq] = handler;
    pic_unmask_irq(irq);
}

void irq_unregister_handler(uint8_t irq)
{
    if (irq >= IRQ_COUNT) return;
    irq_handlers[irq] = 0;
    pic_mask_irq(irq);
}

/* 通用IRQ处理函数（由汇编入口调用）
 * irq_number 是 0-15 的IRQ号，不是中断号 */
void irq_handler(uint32_t irq_number)
{
    if (irq_number >= IRQ_COUNT) {
        vga_printf("[IRQ] 未知IRQ: %d\n", irq_number);
        pic_send_eoi(irq_number);
        return;
    }

    /* 调用注册的处理函数 */
    if (irq_handlers[irq_number]) {
        irq_handlers[irq_number]();
    }

    /* 发送EOI */
    pic_send_eoi(irq_number);
}
