/* ============================================================================
 * 赫普OS - 系统调用：FS
 * ========================================================================== */

#include "types.h"
#include <stdint.h>
#include <stddef.h>
#include "syscall.h"
#include "vga.h"
#include "kheap.h"
#include "sched.h"
#include "hepu.h"
#include "fingerprint.h"
#include "vfs.h"
#include "ipc.h"
extern const char *hepu_kernel_version;

u32 sys_open(u32 path_ptr, u32 flags,
                         u32 arg3, u32 arg4)
{
    (void)arg3; (void)arg4;
    const char *path = (const char *)path_ptr;
    return vfs_open(path, flags);
}

u32 sys_read(u32 fd, u32 buf_ptr,
                         u32 size, u32 arg4)
{
    (void)arg4;
    return vfs_read(fd, (void *)buf_ptr, size);
}

u32 sys_write(u32 fd, u32 buf_ptr,
                          u32 size, u32 arg4)
{
    (void)arg4;
    return vfs_write(fd, (const void *)buf_ptr, size);
}

u32 sys_close(u32 fd, u32 arg2,
                          u32 arg3, u32 arg4)
{
    (void)arg2; (void)arg3; (void)arg4;
    return vfs_close(fd);
}

u32 sys_lseek(u32 fd, u32 offset,
                          u32 whence, u32 arg4)
{
    (void)arg4;
    return vfs_lseek(fd, (s32)offset, whence);
}

u32 sys_stat(u32 path_ptr, u32 stat_ptr, u32 arg3, u32 arg4)
{
    (void)arg3; (void)arg4;
    return vfs_stat((const char *)path_ptr, (vfs_stat_t *)stat_ptr);
}

u32 sys_fstat(u32 fd, u32 stat_ptr, u32 arg3, u32 arg4)
{
    (void)arg3; (void)arg4;
    return vfs_fstat(fd, (vfs_stat_t *)stat_ptr);
}

u32 sys_access(u32 path_ptr, u32 mode, u32 arg3, u32 arg4)
{
    (void)mode; (void)arg3; (void)arg4;
    return vfs_access((const char *)path_ptr);
}

u32 sys_unlink(u32 path_ptr, u32 arg2, u32 arg3, u32 arg4)
{
    (void)arg2; (void)arg3; (void)arg4;
    return vfs_unlink((const char *)path_ptr);
}

u32 sys_rename(u32 old_ptr, u32 new_ptr, u32 arg3, u32 arg4)
{
    (void)arg3; (void)arg4;
    return vfs_rename((const char *)old_ptr, (const char *)new_ptr);
}

u32 sys_mkdir(u32 path_ptr, u32 mode, u32 arg3, u32 arg4)
{
    (void)mode; (void)arg3; (void)arg4;
    return vfs_mkdir((const char *)path_ptr);
}

u32 sys_rmdir(u32 path_ptr, u32 arg2, u32 arg3, u32 arg4)
{
    (void)arg2; (void)arg3; (void)arg4;
    return vfs_rmdir((const char *)path_ptr);
}

u32 sys_readdir(u32 fd, u32 dirent_ptr, u32 arg3, u32 arg4)
{
    (void)arg3; (void)arg4;
    return vfs_readdir_fd(fd, (vfs_dirent_t *)dirent_ptr, 64);
}

u32 sys_chmod(u32 path_ptr, u32 mode, u32 arg3, u32 arg4)
{
    (void)path_ptr; (void)mode; (void)arg3; (void)arg4;
    return 0;  /* 原型阶段 */
}

u32 sys_chown(u32 path_ptr, u32 owner, u32 group, u32 arg4)
{
    (void)path_ptr; (void)owner; (void)group; (void)arg4;
    return 0;
}

u32 sys_mount(u32 src_ptr, u32 dst_ptr, u32 fstype_ptr, u32 flags)
{
    (void)src_ptr; (void)dst_ptr; (void)fstype_ptr; (void)flags;
    return 0;
}

u32 sys_umount(u32 target_ptr, u32 arg2, u32 arg3, u32 arg4)
{
    (void)target_ptr; (void)arg2; (void)arg3; (void)arg4;
    return 0;
}

u32 sys_ioctl(u32 fd, u32 cmd, u32 arg_ptr, u32 arg4)
{
    (void)fd; (void)cmd; (void)arg_ptr; (void)arg4;
    return 0;
}

u32 sys_getcwd(u32 buf_ptr, u32 size, u32 arg3, u32 arg4)
{
    (void)arg3; (void)arg4;
    if (buf_ptr && size > 0) {
        char *buf = (char *)buf_ptr;
        buf[0] = '/'; buf[1] = 0;
    }
    return 0;
}

u32 sys_chdir(u32 path_ptr, u32 arg2, u32 arg3, u32 arg4)
{
    (void)path_ptr; (void)arg2; (void)arg3; (void)arg4;
    return 0;
}

u32 sys_dup(u32 oldfd, u32 arg2, u32 arg3, u32 arg4)
{
    (void)arg2; (void)arg3; (void)arg4;
    return vfs_dup(oldfd);
}

u32 sys_dup2(u32 oldfd, u32 newfd, u32 arg3, u32 arg4)
{
    (void)arg3; (void)arg4;
    return vfs_dup2(oldfd, newfd);
}

u32 sys_fcntl(u32 fd, u32 cmd, u32 arg, u32 arg4)
{
    (void)fd; (void)cmd; (void)arg; (void)arg4;
    return 0;
}

