/* ============================================================================
 * 赫普OS - 中断描述符表 (IDT)
 * ========================================================================== */

#include <stdint.h>
#include "idt.h"
#include "constants.h"
#include "vga.h"
#include "paging.h"
#include "syscall.h"

#define IDT_ENTRIES 256

typedef struct {
    uint16_t base_low;
    uint16_t sel;
    uint8_t  always0;
    uint8_t  flags;
    uint16_t base_high;
} __attribute__((packed)) idt_entry_t;

typedef struct {
    uint16_t limit;
    uint32_t base;
} __attribute__((packed)) idt_ptr_t;

static idt_entry_t idt_entries[IDT_ENTRIES];
static idt_ptr_t   idt_ptr;

/* 汇编中断处理入口 */
extern void isr0(void);
extern void isr1(void);
extern void isr2(void);
extern void isr3(void);
extern void isr4(void);
extern void isr5(void);
extern void isr6(void);
extern void isr7(void);
extern void isr8(void);
extern void isr9(void);
extern void isr10(void);
extern void isr11(void);
extern void isr12(void);
extern void isr13(void);
extern void isr14(void);
extern void isr15(void);
extern void isr16(void);
extern void isr17(void);
extern void isr18(void);
extern void isr19(void);
extern void isr20(void);
extern void isr31(void);
extern void isr128(void);  /* 系统调用 */
extern void idt_load(uint32_t idt_ptr);

/* IRQ 硬件中断入口 */
extern void irq0(void);  extern void irq1(void);  extern void irq2(void);
extern void irq3(void);  extern void irq4(void);  extern void irq5(void);
extern void irq6(void);  extern void irq7(void);  extern void irq8(void);
extern void irq9(void);  extern void irq10(void); extern void irq11(void);
extern void irq12(void); extern void irq13(void); extern void irq14(void);
extern void irq15(void);

static void idt_set_gate(uint8_t num, uint32_t base, uint16_t sel, uint8_t flags)
{
    idt_entries[num].base_low  = base & IDT_BASE_LOW_MASK;
    idt_entries[num].base_high = (base >> 16) & IDT_BASE_HIGH_MASK;
    idt_entries[num].sel       = sel;
    idt_entries[num].always0   = 0;
    idt_entries[num].flags     = flags;
}

/* 异常名称 */
static const char *exception_messages[] = {
    "Division By Zero",
    "Debug",
    "Non Maskable Interrupt",
    "Breakpoint",
    "Into Detected Overflow",
    "Out of Bounds",
    "Invalid Opcode",
    "No Coprocessor",
    "Double Fault",
    "Coprocessor Segment Overrun",
    "Bad TSS",
    "Segment Not Present",
    "Stack Fault",
    "General Protection Fault",
    "Page Fault",
    "Unknown Interrupt",
    "Coprocessor Fault",
    "Alignment Check",
    "Machine Check",
    "Reserved", "Reserved", "Reserved", "Reserved",
    "Reserved", "Reserved", "Reserved", "Reserved",
    "Reserved", "Reserved", "Reserved", "Reserved",
    "Reserved"
};

/* 中断处理C函数
 * 注意：对于系统调用(int 0x80)，参数在寄存器中
 * isr_number=14 是页错误，需要特殊处理 */
void idt_handler(uint32_t isr_number, uint32_t error_code,
                 uint32_t ebx, uint32_t ecx, uint32_t edx, uint32_t esi)
{
    (void)ebx; (void)ecx; (void)edx; (void)esi;
    if (isr_number == 14) {
        /* 页错误 */
        extern uint32_t paging_read_cr2(void);
        uint32_t fault_addr = paging_read_cr2();
        page_fault_handler(fault_addr, error_code);
        return;
    }

    if (isr_number == 128) {
        /* 系统调用: eax=num, ebx=arg1, ecx=arg2, edx=arg3, esi=arg4
         * 返回值在 eax 中，由汇编入口处理 */
        /* 实际处理在 syscall_entry.S 中完成 */
        return;
    }

    if (isr_number < 32) {
        vga_set_color(VGA_COLOR_RED, VGA_COLOR_BLACK);
        vga_printf("\n[HEPU] 内核异常: %s (ISR %d, err=0x%x)\n",
                   exception_messages[isr_number], isr_number, error_code);
        vga_puts("系统已停止。请重启设备。\n");
        for (;;) { __asm__ volatile ("hlt"); }
    }
}

void idt_init(void)
{
    idt_ptr.limit = sizeof(idt_entry_t) * IDT_ENTRIES - 1;
    idt_ptr.base  = (uint32_t)&idt_entries;

    /* 初始化前32个异常处理 */
    idt_set_gate(0,  (uint32_t)isr0,  GDT_KERNEL_CODE, IDT_FLAGS_INT_GATE);
    idt_set_gate(1,  (uint32_t)isr1,  GDT_KERNEL_CODE, IDT_FLAGS_INT_GATE);
    idt_set_gate(2,  (uint32_t)isr2,  GDT_KERNEL_CODE, IDT_FLAGS_INT_GATE);
    idt_set_gate(3,  (uint32_t)isr3,  GDT_KERNEL_CODE, IDT_FLAGS_INT_GATE);
    idt_set_gate(4,  (uint32_t)isr4,  GDT_KERNEL_CODE, IDT_FLAGS_INT_GATE);
    idt_set_gate(5,  (uint32_t)isr5,  GDT_KERNEL_CODE, IDT_FLAGS_INT_GATE);
    idt_set_gate(6,  (uint32_t)isr6,  GDT_KERNEL_CODE, IDT_FLAGS_INT_GATE);
    idt_set_gate(7,  (uint32_t)isr7,  GDT_KERNEL_CODE, IDT_FLAGS_INT_GATE);
    idt_set_gate(8,  (uint32_t)isr8,  GDT_KERNEL_CODE, IDT_FLAGS_INT_GATE);
    idt_set_gate(9,  (uint32_t)isr9,  GDT_KERNEL_CODE, IDT_FLAGS_INT_GATE);
    idt_set_gate(10, (uint32_t)isr10, GDT_KERNEL_CODE, 0x8E);
    idt_set_gate(11, (uint32_t)isr11, GDT_KERNEL_CODE, 0x8E);
    idt_set_gate(12, (uint32_t)isr12, GDT_KERNEL_CODE, 0x8E);
    idt_set_gate(13, (uint32_t)isr13, GDT_KERNEL_CODE, 0x8E);
    idt_set_gate(14, (uint32_t)isr14, GDT_KERNEL_CODE, 0x8E);
    idt_set_gate(15, (uint32_t)isr15, GDT_KERNEL_CODE, 0x8E);
    idt_set_gate(16, (uint32_t)isr16, GDT_KERNEL_CODE, 0x8E);
    idt_set_gate(17, (uint32_t)isr17, GDT_KERNEL_CODE, 0x8E);
    idt_set_gate(18, (uint32_t)isr18, GDT_KERNEL_CODE, 0x8E);
    idt_set_gate(19, (uint32_t)isr19, GDT_KERNEL_CODE, 0x8E);
    idt_set_gate(20, (uint32_t)isr20, GDT_KERNEL_CODE, 0x8E);
    idt_set_gate(31, (uint32_t)isr31, GDT_KERNEL_CODE, 0x8E);

    /* 系统调用中断 0x80 */
    idt_set_gate(IDT_SYSCALL_VECTOR, (uint32_t)isr128, GDT_KERNEL_CODE, IDT_FLAGS_SYSCALL_GATE);

    /* IRQ 硬件中断 (32-47) */
    idt_set_gate(32, (uint32_t)irq0,  GDT_KERNEL_CODE, IDT_FLAGS_INT_GATE);
    idt_set_gate(33, (uint32_t)irq1,  GDT_KERNEL_CODE, IDT_FLAGS_INT_GATE);
    idt_set_gate(34, (uint32_t)irq2,  GDT_KERNEL_CODE, IDT_FLAGS_INT_GATE);
    idt_set_gate(35, (uint32_t)irq3,  GDT_KERNEL_CODE, IDT_FLAGS_INT_GATE);
    idt_set_gate(36, (uint32_t)irq4,  GDT_KERNEL_CODE, IDT_FLAGS_INT_GATE);
    idt_set_gate(37, (uint32_t)irq5,  GDT_KERNEL_CODE, IDT_FLAGS_INT_GATE);
    idt_set_gate(38, (uint32_t)irq6,  GDT_KERNEL_CODE, IDT_FLAGS_INT_GATE);
    idt_set_gate(39, (uint32_t)irq7,  GDT_KERNEL_CODE, IDT_FLAGS_INT_GATE);
    idt_set_gate(40, (uint32_t)irq8,  GDT_KERNEL_CODE, IDT_FLAGS_INT_GATE);
    idt_set_gate(41, (uint32_t)irq9,  GDT_KERNEL_CODE, IDT_FLAGS_INT_GATE);
    idt_set_gate(42, (uint32_t)irq10, GDT_KERNEL_CODE, 0x8E);
    idt_set_gate(43, (uint32_t)irq11, GDT_KERNEL_CODE, 0x8E);
    idt_set_gate(44, (uint32_t)irq12, GDT_KERNEL_CODE, 0x8E);
    idt_set_gate(45, (uint32_t)irq13, GDT_KERNEL_CODE, 0x8E);
    idt_set_gate(46, (uint32_t)irq14, GDT_KERNEL_CODE, 0x8E);
    idt_set_gate(47, (uint32_t)irq15, GDT_KERNEL_CODE, 0x8E);

    idt_load((uint32_t)&idt_ptr);
}
