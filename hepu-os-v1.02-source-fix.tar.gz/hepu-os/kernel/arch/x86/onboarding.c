/* ============================================================================
 * 赫普OS - 系统新手引导
 * ========================================================================== */

#include <stdint.h>
#include "onboarding.h"
#include "vga.h"
#include "string.h"

static onboarding_t ob;

void onboarding_init(void)
{
    memset(&ob, 0, sizeof(onboarding_t));
    ob.initialized = 1;
    ob.enabled = 1;
    ob.state = OB_STATE_NOT_STARTED;
    ob.config.enabled = 1;
    ob.config.auto_start_on_first_boot = 1;
    ob.config.show_tips = 1;
    ob.config.show_migration_guide = 1;
    ob.config.minimal_mode = 0;
    ob.config.animation_enabled = 1;

    /* 默认引导步骤 */
    const char *steps[][3] = {
        {"欢迎使用赫普OS", "HEPU Hyper Evolve OS，系统归人，数据归己", "首次使用建议完成引导"},
        {"数据迁移", "从安卓/iOS一键迁移联系人、照片、应用", "支持无线和有线迁移"},
        {"隐私设置", "赫普OS默认空权限，设备标识随机化", "你的数据只属于你"},
        {"手势操作", "底部上滑回主页，左右滑返回，侧边悬停多任务", "可在设置中自定义"},
        {"弹性桌面", "图标可自由摆放缩放，摒弃固定网格", "长按进入编辑模式"},
        {".hug原生应用", "赫普专属应用格式，轻量、安全、无追踪", "应用商店下载.hug应用"},
        {"创变自由模式", "无需ROOT，一键开启系统级修改，快照回滚不变砖", "高级用户推荐"},
        {"多用户隐私空间", "机主/访客/工作/隐私空间，应用双开", "保护个人隐私"},
        {"AI智能体验", "AI通知分级、智能资源调度、本地推理", "AI运行在独立沙盒"},
        {"开始使用", "赫普OS准备就绪，享受自由纯净的移动体验", "随时可在设置中重新查看引导"},
    };
    ob_type_t types[] = {OB_TYPE_WELCOME, OB_TYPE_MIGRATION, OB_TYPE_PRIVACY,
        OB_TYPE_GESTURE, OB_TYPE_DESKTOP, OB_TYPE_HUG_FORMAT,
        OB_TYPE_CREATOR_MODE, OB_TYPE_MULTI_USER, OB_TYPE_AI_FEATURES, OB_TYPE_COMPLETE};

    for (int i = 0; i < 10; i++) {
        onboarding_add_step(types[i], steps[i][0], steps[i][1], steps[i][2]);
    }

    /* 默认使用技巧 */
    const char *tips[][3] = {
        {"双击亮屏", "设置中开启双击亮屏，无需按电源键", "0"},
        {"三指截屏", "三指下滑快速截屏", "0"},
        {"应用双开", "设置-隐私空间中开启应用双开", "3"},
        {"后台冻结", "不常用应用自动冻结，省电省内存", "2"},
        {"创变模式", "设置-系统中开启创变自由模式", "4"},
        {"通知收纳", "AI自动将推广通知静默收纳", "2"},
        {"隐私空间", "不同密码进入不同空间，保护隐私", "3"},
        {"弹性桌面", "长按图标可自由拖动缩放", "4"},
        {"广告ID重置", "设置-隐私中可一键重置广告标识", "3"},
        {"低内存节流", "老设备自动开启节流模式，流畅运行", "1"},
    };
    for (int i = 0; i < 10; i++) {
        onboarding_add_tip(tips[i][0], tips[i][1], (tips[i][2][0]-'0'));
    }

    /* 迁移对比 */
    const char *migration[][3] = {
        {"安卓：长按应用-应用信息", "赫普：长按应用-详情，权限一目了然", "基础"},
        {"iOS：控制中心从右上角下滑", "赫普：顶部下滑打开控制中心，20个快捷开关", "基础"},
        {"安卓：返回键/手势条", "赫普：左右边缘滑动返回，底部上滑主页", "手势"},
        {"安卓：多任务键", "赫普：底部上滑悬停进入多任务", "手势"},
        {"iOS：App Store", "赫普：应用商店，.hug原生应用+APK兼容", "应用"},
        {"安卓：设置-关于手机", "赫普：设置-关于，内核来源标注清晰可见", "系统"},
    };
    for (int i = 0; i < 6; i++) {
        onboarding_add_migration(migration[i][0], migration[i][1], migration[i][2]);
    }

    vga_puts("[ONBOARD] 系统新手引导初始化完成\n");
    vga_printf("        引导步骤: %d, 使用技巧: %d, 迁移对比: %d\n",
               ob.step_count, ob.tip_count, ob.migration_count);
}

int onboarding_start(void)
{
    if (ob.state == OB_STATE_IN_PROGRESS) return 0;
    ob.state = OB_STATE_IN_PROGRESS;
    ob.current_step = 0;
    ob.completed_steps = 0;
    ob.total_starts++;
    return 0;
}

int onboarding_next(void)
{
    if (ob.state != OB_STATE_IN_PROGRESS) return -1;
    if (ob.current_step < ob.step_count - 1) {
        ob.current_step++;
        return 0;
    }
    /* 最后一步，完成引导 */
    ob.state = OB_STATE_COMPLETED;
    ob.total_completions++;
    return 1;
}

int onboarding_prev(void)
{
    if (ob.state != OB_STATE_IN_PROGRESS) return -1;
    if (ob.current_step > 0) {
        ob.current_step--;
        return 0;
    }
    return -1;
}

int onboarding_skip(void)
{
    ob.state = OB_STATE_SKIPPED;
    ob.total_skips++;
    return 0;
}

int onboarding_complete_step(int step_id)
{
    if (step_id < 0 || step_id >= OB_MAX_STEPS || !ob.steps[step_id].used) return -1;
    if (!ob.steps[step_id].completed) {
        ob.steps[step_id].completed = 1;
        ob.completed_steps++;
    }
    return 0;
}

int onboarding_get_current(ob_step_t *step)
{
    if (!step || ob.state != OB_STATE_IN_PROGRESS) return -1;
    if (ob.current_step < 0 || ob.current_step >= ob.step_count) return -1;
    memcpy(step, &ob.steps[ob.current_step], sizeof(ob_step_t));
    return 0;
}

int onboarding_get_progress(int *current, int *total)
{
    if (current) *current = ob.current_step + 1;
    if (total) *total = ob.step_count;
    return 0;
}

int onboarding_get_state(ob_state_t *state)
{
    if (!state) return -1;
    *state = ob.state;
    return 0;
}

int onboarding_reset(void)
{
    ob.state = OB_STATE_NOT_STARTED;
    ob.current_step = 0;
    ob.completed_steps = 0;
    for (int i = 0; i < OB_MAX_STEPS; i++)
        if (ob.steps[i].used) ob.steps[i].completed = 0;
    return 0;
}

int onboarding_add_step(ob_type_t type, const char *title, const char *desc, const char *tip)
{
    for (int i = 0; i < OB_MAX_STEPS; i++) {
        if (!ob.steps[i].used) {
            memset(&ob.steps[i], 0, sizeof(ob_step_t));
            ob.steps[i].used = 1;
            ob.steps[i].id = i;
            ob.steps[i].type = type;
            if (title) strncpy(ob.steps[i].title, title, OB_TITLE_LEN - 1);
            if (desc) strncpy(ob.steps[i].description, desc, OB_TEXT_LEN - 1);
            if (tip) strncpy(ob.steps[i].tip, tip, OB_TEXT_LEN - 1);
            ob.steps[i].required = (type == OB_TYPE_PRIVACY || type == OB_TYPE_WELCOME);
            ob.steps[i].skippable = (type != OB_TYPE_PRIVACY);
            ob.steps[i].duration_ms = 5000;
            ob.step_count++;
            return i;
        }
    }
    return -1;
}

int onboarding_list_steps(ob_step_t *steps, int max)
{
    if (!steps || max <= 0) return 0;
    int count = 0;
    for (int i = 0; i < OB_MAX_STEPS && count < max; i++) {
        if (ob.steps[i].used) memcpy(&steps[count++], &ob.steps[i], sizeof(ob_step_t));
    }
    return count;
}

int onboarding_get_step(int id, ob_step_t *step)
{
    if (id < 0 || id >= OB_MAX_STEPS || !ob.steps[id].used || !step) return -1;
    memcpy(step, &ob.steps[id], sizeof(ob_step_t));
    return 0;
}

int onboarding_add_tip(const char *title, const char *content, int category)
{
    for (int i = 0; i < OB_MAX_TIPS; i++) {
        if (!ob.tips[i].used) {
            memset(&ob.tips[i], 0, sizeof(ob_tip_t));
            ob.tips[i].used = 1;
            ob.tips[i].id = i;
            if (title) strncpy(ob.tips[i].title, title, OB_TITLE_LEN - 1);
            if (content) strncpy(ob.tips[i].content, content, OB_TEXT_LEN - 1);
            ob.tips[i].category_id = category;
            const char *cats[] = {"基础", "进阶", "效率", "隐私", "自定义"};
            if (category >= 0 && category < 5)
                strncpy(ob.tips[i].category, cats[category], 31);
            ob.tip_count++;
            return i;
        }
    }
    return -1;
}

int onboarding_get_random_tip(ob_tip_t *tip)
{
    if (!tip || ob.tip_count == 0) return -1;
    /* 简单伪随机：用tip_count做索引变化 */
    int idx = ((uint32_t)(ob.total_tips_shown + 7) % (uint32_t)ob.tip_count);
    int count = 0;
    for (int i = 0; i < OB_MAX_TIPS; i++) {
        if (ob.tips[i].used) {
            if (count == idx) {
                memcpy(tip, &ob.tips[i], sizeof(ob_tip_t));
                ob.tips[i].shown_count++;
                ob.total_tips_shown++;
                return 0;
            }
            count++;
        }
    }
    return -1;
}

int onboarding_get_tips_by_category(int category, ob_tip_t *tips, int max)
{
    if (!tips || max <= 0) return 0;
    int count = 0;
    for (int i = 0; i < OB_MAX_TIPS && count < max; i++) {
        if (ob.tips[i].used && ob.tips[i].category_id == category)
            memcpy(&tips[count++], &ob.tips[i], sizeof(ob_tip_t));
    }
    return count;
}

int onboarding_list_tips(ob_tip_t *tips, int max)
{
    if (!tips || max <= 0) return 0;
    int count = 0;
    for (int i = 0; i < OB_MAX_TIPS && count < max; i++) {
        if (ob.tips[i].used) memcpy(&tips[count++], &ob.tips[i], sizeof(ob_tip_t));
    }
    return count;
}

int onboarding_vote_tip(int tip_id, int useful)
{
    if (tip_id < 0 || tip_id >= OB_MAX_TIPS || !ob.tips[tip_id].used) return -1;
    if (useful) ob.tips[tip_id].useful_votes++;
    return 0;
}

int onboarding_add_migration(const char *android_way, const char *hepu_way, const char *category)
{
    for (int i = 0; i < 32; i++) {
        if (!ob.migration[i].used) {
            memset(&ob.migration[i], 0, sizeof(ob_migration_item_t));
            ob.migration[i].used = 1;
            ob.migration[i].id = i;
            if (android_way) strncpy(ob.migration[i].android_way, android_way, OB_TEXT_LEN - 1);
            if (hepu_way) strncpy(ob.migration[i].hepu_way, hepu_way, OB_TEXT_LEN - 1);
            if (category) strncpy(ob.migration[i].category, category, 31);
            ob.migration_count++;
            return i;
        }
    }
    return -1;
}

int onboarding_list_migration(ob_migration_item_t *items, int max)
{
    if (!items || max <= 0) return 0;
    int count = 0;
    for (int i = 0; i < 32 && count < max; i++) {
        if (ob.migration[i].used) memcpy(&items[count++], &ob.migration[i], sizeof(ob_migration_item_t));
    }
    return count;
}

int onboarding_set_config(const ob_config_t *config)
{
    if (!config) return -1;
    memcpy(&ob.config, config, sizeof(ob_config_t));
    return 0;
}

int onboarding_get_config(ob_config_t *config)
{
    if (!config) return -1;
    memcpy(config, &ob.config, sizeof(ob_config_t));
    return 0;
}

int onboarding_set_enabled(int enable)
{
    ob.enabled = enable ? 1 : 0;
    return 0;
}

int onboarding_get_stats(onboarding_t *stats)
{
    if (!stats) return -1;
    memcpy(stats, &ob, sizeof(onboarding_t));
    return 0;
}
