/* ============================================================================
 * 赫普OS - 统一初始化序列
 * 管理100+模块的分阶段初始化
 * ========================================================================== */

#include <stdint.h>
#include "types.h"
#include "init_sequence.h"
#include "vga.h"

/* 外部初始化函数声明（按阶段分组） */

/* === 阶段1：核心子系统 === */
extern void vfs_init(void);
extern void devfs_init(void);
extern void ipc_init(void);
extern void net_init(void);
extern void touch_init(void);
extern void smp_init(void);
extern void dynld_init(void);

/* === 阶段2：硬件驱动 === */
extern void usb_init(void);
extern void pm_init(void);
extern void audio_init(void);
extern void camera_init(void);
extern void bt_init(void);
extern void wifi_init(void);
extern void gpu_init(void);
extern void sensors_init(void);
extern void gps_init(void);
extern void codec_init(void);
extern void compositor_init(void);
extern void input_init(void);

/* === 阶段3：网络协议 === */
extern void arp_init(void);
extern void dhcp_init(void);
extern void hepu_dns_init(void);
extern void icmp_init(void);
extern void hepu_http_init(void);
extern void hepu_tls_init(void);
extern void tcp_init(void);
extern void ws_init(void);
extern void http2_init(void);
extern void tls_handshake_init(void);
extern void quic_init(void);
extern void http3_init(void);
extern void doq_init(void);
extern void quic_0rtt_init(void);
extern void quic_migration_init(void);
extern void mp_quic_init(void);
extern void eth_init(void);
extern void socket_init(void);

/* === 阶段4：安全加密 === */
extern void sec_init(void);
extern void x509_init(void);
extern void csprng_init(void);
extern void ecdhe_init(void);
extern void sha_init(void);
extern void hmac_init(void);
extern void hkdf_init(void);
extern void rsa_init(void);
extern void aes_init(void);
extern void secure_boot_init(void);
extern void permission_manager_init(void);
extern void privacy_compute_init(void);
extern void fscrypt_init(void);

/* === 阶段5：系统服务 === */
extern void services_init(void);
extern void services_start_boot(void);
extern void trace_init(void);
extern void perf_init(void);
extern void log_init(void);
extern void media_init(void);
extern void camhal_init(void);
extern void ril_init(void);
extern void ota_init(void);
extern void phone_service_init(void);
extern void sms_service_init(void);
extern void settings_init(void);
extern void notification_center_init(void);
extern void backup_restore_init(void);
extern void storage_manager_init(void);
extern void multi_user_init(void);
extern void system_stability_init(void);

/* === 阶段6：应用框架 === */
extern void appframework_init(void);
extern void packagemanager_init(void);
extern void notification_init(void);
extern void windowsystem_init(void);
extern void share_init(void);
extern void account_init(void);
extern void systemui_init(void);
extern void webengine_init(void);
extern void ai_init(void);
extern void security2_init(void);
extern void media2_init(void);
extern void desktopmode_init(void);
extern void gameframework_init(void);
extern void enterprise_init(void);
extern void devtools_init(void);
extern void compat_init(void);

/* === 阶段7：扩展模块 === */
extern void fs2_init(void);
extern void net2_init(void);
extern void bt2_init(void);
extern void usb2_init(void);
extern void gfx2_init(void);
extern void camera2_init(void);
extern void audio2_init(void);
extern void telecom2_init(void);
extern void ai2_init(void);
extern void carlink_init(void);
extern void enterprise2_init(void);
extern void kernel_opt_init(void);
extern void drivers2_init(void);
extern void fs3_init(void);
extern void net3_init(void);
extern void appeco_init(void);
extern void kernel_core_init(void);
extern void drivers_real_init(void);
extern void userland_init(void);
extern void fs_real_init(void);
extern void bootchain_init(void);
extern void kdebug_init(void);
extern void kperf_init(void);
extern void distributed_init(void);
extern void hdpk_init(void);
extern void device_support_init(void);
extern void fp_enhanced_init(void);
extern void file_manager_init(void);
extern void camera_app_init(void);
extern void gallery_init(void);
extern void browser_init(void);
extern void app_store_init(void);
extern void system_tools_init(void);
extern void music_player_init(void);
extern void video_player_init(void);
extern void photo_editor_init(void);
extern void voice_recorder_init(void);
extern void audio_effects_init(void);
extern void hug_sdk_init(void);
extern void hug_template_init(void);
extern void hug_debugger_init(void);
extern void hug_depman_init(void);
extern void apk_parser_init(void);
extern void microg_service_init(void);
extern void art_runtime_init(void);
extern void compat_layer_init(void);
extern void boot_optimizer_init(void);
extern void memory_optimizer_init(void);
extern void kernel_slimmer_init(void);
extern void perf_profiler_init(void);
extern void app_container_init(void);
extern void distributed_os_init(void);
extern void car_connect_init(void);
extern void rtk_kernel_init(void);
extern void power_optimizer_init(void);
extern void i18ns_system_init(void);
extern void multilingual_ime_init(void);
extern void app_freeze_init(void);
extern void id_randomizer_init(void);
extern void elastic_desktop_init(void);
extern void ai_notification_init(void);
extern void creator_mode_init(void);
extern void onboarding_init(void);
extern void lowmem_throttle_init(void);
extern void hdpk_template_init(void);
extern void android_api_init(void);
extern void bist_init(void);
extern void ai_assistant_init(void);
extern void mount_init(void);
extern void quota_init(void);
extern void fs_registry_init(void);
extern void vfat_init(void);
extern void vfat_register(void);
extern void journal_init(void);
extern void ide_init(void);
extern void ext4_init(void);
extern void ext4_register(void);
extern void partition_init(void);
extern void ahci_init(void);
extern void nvme_init(void);
extern void hepu_exfat_init(void);
extern void hepu_ntfs_init(void);

static init_stats_t init_stats;

/* 阶段名称 */
const char *hepu_init_phase_name(init_phase_t phase)
{
    switch (phase) {
        case INIT_PHASE_CORE: return "核心子系统";
        case INIT_PHASE_HARDWARE: return "硬件驱动";
        case INIT_PHASE_FS: return "文件系统";
        case INIT_PHASE_NETWORK: return "网络协议";
        case INIT_PHASE_SECURITY: return "安全加密";
        case INIT_PHASE_SERVICES: return "系统服务";
        case INIT_PHASE_APPS: return "应用框架";
        default: return "未知";
    }
}

/* 执行单个阶段 */
int hepu_init_phase(init_phase_t phase)
{
    u32 count = 0;

    vga_printf("=== %s ===\n", hepu_init_phase_name(phase));

    switch (phase) {
        case INIT_PHASE_CORE:
            vfs_init(); devfs_init(); ipc_init(); net_init();
            touch_init(); smp_init(); dynld_init();
            count = 7;
            break;

        case INIT_PHASE_HARDWARE:
            usb_init(); pm_init(); audio_init(); camera_init();
            bt_init(); wifi_init(); gpu_init(); sensors_init();
            gps_init(); codec_init(); compositor_init(); input_init();
            count = 12;
            break;

        case INIT_PHASE_FS:
            mount_init(); quota_init(); fs_registry_init();
            vfat_init(); vfat_register(); journal_init();
            ide_init(); ext4_init(); ext4_register();
            fscrypt_init(); partition_init(); ahci_init();
            nvme_init(); hepu_exfat_init(); hepu_ntfs_init();
            fs2_init(); fs3_init(); fs_real_init();
            count = 18;
            break;

        case INIT_PHASE_NETWORK:
            eth_init(); wifi_init(); arp_init(); dhcp_init();
            hepu_dns_init(); icmp_init(); hepu_http_init();
            hepu_tls_init(); tcp_init(); ws_init();
            http2_init(); tls_handshake_init();
            quic_init(); http3_init(); doq_init();
            quic_0rtt_init(); quic_migration_init(); mp_quic_init();
            socket_init(); net2_init(); net3_init();
            count = 21;
            break;

        case INIT_PHASE_SECURITY:
            sec_init(); x509_init(); csprng_init(); ecdhe_init();
            sha_init(); hmac_init(); hkdf_init(); rsa_init();
            aes_init(); secure_boot_init(); permission_manager_init();
            privacy_compute_init(); security2_init();
            count = 13;
            break;

        case INIT_PHASE_SERVICES:
            services_init(); services_start_boot();
            trace_init(); perf_init(); log_init();
            media_init(); camhal_init(); ril_init(); ota_init();
            phone_service_init(); sms_service_init(); settings_init();
            notification_center_init(); backup_restore_init();
            storage_manager_init(); multi_user_init();
            system_stability_init(); power_optimizer_init();
            memory_optimizer_init(); boot_optimizer_init();
            kernel_slimmer_init(); perf_profiler_init();
            count = 22;
            break;

        case INIT_PHASE_APPS:
            appframework_init(); packagemanager_init();
            notification_init(); windowsystem_init();
            share_init(); account_init(); systemui_init();
            webengine_init(); ai_init(); media2_init();
            desktopmode_init(); gameframework_init();
            enterprise_init(); devtools_init(); compat_init();
            bt2_init(); usb2_init(); gfx2_init();
            camera2_init(); audio2_init(); telecom2_init();
            ai2_init(); carlink_init(); enterprise2_init();
            kernel_opt_init(); drivers2_init(); appeco_init();
            kernel_core_init(); drivers_real_init();
            userland_init(); bootchain_init(); kdebug_init();
            kperf_init(); distributed_init(); hdpk_init();
            device_support_init(); fp_enhanced_init();
            file_manager_init(); camera_app_init(); gallery_init();
            browser_init(); app_store_init(); system_tools_init();
            music_player_init(); video_player_init();
            photo_editor_init(); voice_recorder_init();
            audio_effects_init(); hug_sdk_init();
            hug_template_init(); hug_debugger_init();
            hug_depman_init(); apk_parser_init();
            microg_service_init(); art_runtime_init();
            compat_layer_init(); app_container_init();
            distributed_os_init(); car_connect_init();
            rtk_kernel_init(); i18ns_system_init();
            multilingual_ime_init(); app_freeze_init();
            id_randomizer_init(); elastic_desktop_init();
            ai_notification_init(); creator_mode_init();
            onboarding_init(); lowmem_throttle_init();
            hdpk_template_init(); android_api_init();
            bist_init(); ai_assistant_init();
            count = 72;
            break;

        default:
            break;
    }

    init_stats.modules_initialized += count;
    vga_printf("  初始化 %u 个模块\n", count);
    return count;
}

/* 完整初始化序列 */
void hepu_init_sequence(void)
{
    init_stats.modules_initialized = 0;
    init_stats.modules_failed = 0;

    vga_puts("\n=== 赫普OS 统一初始化序列 ===\n\n");

    for (int phase = 0; phase < INIT_PHASE_COUNT; phase++) {
        hepu_init_phase((init_phase_t)phase);
        vga_putc('\n');
    }

    vga_puts("[INIT] QUIC DATAGRAM + QPACK动态表\n");
    vga_printf("\n=== 初始化完成: 共 %u 个模块 ===\n\n",
               init_stats.modules_initialized);
}

/* 获取统计 */
void hepu_init_get_stats(init_stats_t *stats)
{
    if (stats) *stats = init_stats;
}
