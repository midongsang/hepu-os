/* ============================================================================
 * 赫普OS - 系统调用：MEM
 * ========================================================================== */

#include "types.h"
#include <stdint.h>
#include <stddef.h>
#include "syscall.h"
#include "vga.h"
#include "kheap.h"
#include "sched.h"
#include "hepu.h"
#include "fingerprint.h"
#include "vfs.h"
#include "ipc.h"
extern const char *hepu_kernel_version;

u32 sys_malloc(u32 size, u32 arg2,
                           u32 arg3, u32 arg4)
{
    (void)arg2; (void)arg3; (void)arg4;
    return (u32)kmalloc(size);
}

u32 sys_free(u32 ptr, u32 arg2,
                         u32 arg3, u32 arg4)
{
    (void)arg2; (void)arg3; (void)arg4;
    kfree((void *)ptr);
    return 0;
}

u32 sys_shmget(u32 key, u32 size,
                           u32 arg3, u32 arg4)
{
    (void)arg3; (void)arg4;
    return ipc_shm_get(key, size);
}

u32 sys_shmat(u32 shm_id, u32 arg2,
                          u32 arg3, u32 arg4)
{
    (void)arg2; (void)arg3; (void)arg4;
    return (u32)ipc_shm_attach(shm_id, sched_current_pid());
}

u32 sys_mmap(u32 addr, u32 length, u32 prot, u32 flags)
{
    (void)addr; (void)prot; (void)flags;
    return (u32)kmalloc(length);
}

u32 sys_munmap(u32 addr, u32 length, u32 arg3, u32 arg4)
{
    (void)length; (void)arg3; (void)arg4;
    kfree((void *)addr);
    return 0;
}

u32 sys_mprotect(u32 addr, u32 length, u32 prot, u32 arg4)
{
    (void)addr; (void)length; (void)prot; (void)arg4;
    return 0;
}

