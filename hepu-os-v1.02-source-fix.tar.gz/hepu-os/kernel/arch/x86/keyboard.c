/* ============================================================================
 * 赫普OS - PS/2 键盘驱动 (IRQ1)
 * 功能: 扫描码转换、输入缓冲区、readline
 * ========================================================================== */

#include <stdint.h>
#include "keyboard.h"
#include "pic.h"
#include "vga.h"

#define KEYBOARD_DATA_PORT 0x60
#define KEYBOARD_STATUS_PORT 0x64
#define KEYBOARD_CMD_PORT 0x64

static inline uint8_t inb(uint16_t port)
{
    uint8_t ret;
    __asm__ volatile ("inb %1, %0" : "=a"(ret) : "Nd"(port));
    return ret;
}

static inline void outb(uint16_t port, uint8_t val)
{
    __asm__ volatile ("outb %0, %1" : : "a"(val), "Nd"(port));
}

/* 输入缓冲区 */
static char keyboard_buffer[KEYBOARD_BUFFER_SIZE];
static int  buffer_head = 0;  /* 写入位置 */
static int  buffer_tail = 0;  /* 读取位置 */
static int  buffer_count = 0;

/* Shift键状态 */
static int shift_pressed = 0;
static int caps_lock = 0;

/* 扫描码 -> ASCII 转换表 (Set 1, 无Shift) */
static const char scancode_ascii[] = {
    0,    0,    '1',  '2',  '3',  '4',  '5',  '6',  /* 0x00-0x07 */
    '7',  '8',  '9',  '0',  '-',  '=',  0x08, 0x09, /* 0x08-0x0F */
    'q',  'w',  'e',  'r',  't',  'y',  'u',  'i',  /* 0x10-0x17 */
    'o',  'p',  '[',  ']',  0x0A, 0,    'a',  's',  /* 0x18-0x1F */
    'd',  'f',  'g',  'h',  'j',  'k',  'l',  ';',  /* 0x20-0x27 */
    '\'', '`',  0,    '\\', 'z',  'x',  'c',  'v',  /* 0x28-0x2F */
    'b',  'n',  'm',  ',',  '.',  '/',  0,    '*',  /* 0x30-0x37 */
    0,    ' ',  0,    0,    0,    0,    0,    0,    /* 0x38-0x3F */
    0,    0,    0,    0,    0,    0,    0,    '7',  /* 0x40-0x47 */
    '8',  '9',  '-',  '4',  '5',  '6',  '+',  '1',  /* 0x48-0x4F */
    '2',  '3',  '0',  '.',  0,    0,    0,    0,    /* 0x50-0x57 */
};

/* Shift 状态下的扫描码表 */
static const char scancode_ascii_shift[] = {
    0,    0,    '!',  '@',  '#',  '$',  '%',  '^',
    '&',  '*',  '(',  ')',  '_',  '+',  0x08, 0x09,
    'Q',  'W',  'E',  'R',  'T',  'Y',  'U',  'I',
    'O',  'P',  '{',  '}',  0x0A, 0,    'A',  'S',
    'D',  'F',  'G',  'H',  'J',  'K',  'L',  ':',
    '"',  '~',  0,    '|',  'Z',  'X',  'C',  'V',
    'B',  'N',  'M',  '<',  '>',  '?',  0,    '*',
    0,    ' ',  0,    0,    0,    0,    0,    0,
    0,    0,    0,    0,    0,    0,    0,    '7',
    '8',  '9',  '-',  '4',  '5',  '6',  '+',  '1',
    '2',  '3',  '0',  '.',  0,    0,    0,    0,
};

/* 向缓冲区写入一个字符 */
static void buffer_put(char c)
{
    if (buffer_count >= KEYBOARD_BUFFER_SIZE) return;
    keyboard_buffer[buffer_head] = c;
    buffer_head = (buffer_head + 1) % KEYBOARD_BUFFER_SIZE;
    buffer_count++;
}

/* 键盘中断处理 */
void keyboard_handler(void)
{
    uint8_t scancode = inb(KEYBOARD_DATA_PORT);

    /* 释放键 (0x80以上) */
    if (scancode & 0x80) {
        uint8_t key = scancode & 0x7F;
        if (key == 0x2A || key == 0x36) {  /* Left/Right Shift */
            shift_pressed = 0;
        }
        return;
    }

    /* 按下键 */
    switch (scancode) {
        case 0x2A:  /* Left Shift */
        case 0x36:  /* Right Shift */
            shift_pressed = 1;
            return;
        case 0x3A:  /* Caps Lock */
            caps_lock = !caps_lock;
            return;
        case 0x0E:  /* Backspace */
            buffer_put(0x08);
            return;
    }

    /* 转换扫描码 */
    char c;
    if (shift_pressed) {
        c = (scancode < sizeof(scancode_ascii_shift)) ?
            scancode_ascii_shift[scancode] : 0;
    } else {
        c = (scancode < sizeof(scancode_ascii)) ?
            scancode_ascii[scancode] : 0;
    }

    /* Caps Lock 处理字母 */
    if (caps_lock && c >= 'a' && c <= 'z') {
        c = c - 'a' + 'A';
    } else if (caps_lock && c >= 'A' && c <= 'Z' && !shift_pressed) {
        c = c - 'A' + 'a';
    }

    if (c) {
        buffer_put(c);
    }
}

void keyboard_init(void)
{
    buffer_head = 0;
    buffer_tail = 0;
    buffer_count = 0;
    shift_pressed = 0;
    caps_lock = 0;

    /* 注册IRQ1 */
    extern void irq_register_handler(uint8_t, void (*)(void));
    irq_register_handler(IRQ_KEYBOARD, keyboard_handler);

    vga_puts("[KEYBOARD] PS/2 键盘驱动初始化完成 (IRQ1)\n");
}

char keyboard_getchar(void)
{
    while (buffer_count == 0) {
        __asm__ volatile ("hlt");
    }
    char c = keyboard_buffer[buffer_tail];
    buffer_tail = (buffer_tail + 1) % KEYBOARD_BUFFER_SIZE;
    buffer_count--;
    return c;
}

int keyboard_try_getchar(char *c)
{
    if (buffer_count == 0) return 0;
    *c = keyboard_buffer[buffer_tail];
    buffer_tail = (buffer_tail + 1) % KEYBOARD_BUFFER_SIZE;
    buffer_count--;
    return 1;
}

int keyboard_has_data(void)
{
    return buffer_count > 0;
}

int keyboard_readline(char *buf, int max_len)
{
    int pos = 0;
    while (pos < max_len - 1) {
        char c = keyboard_getchar();

        if (c == '\n' || c == '\r') {
            vga_putc('\n');
            break;
        }
        if (c == 0x08) {  /* Backspace */
            if (pos > 0) {
                pos--;
                vga_putc(0x08);
                vga_putc(' ');
                vga_putc(0x08);
            }
            continue;
        }
        if (c >= ' ' && c < 127) {
            buf[pos++] = c;
            vga_putc(c);
        }
    }
    buf[pos] = '\0';
    return pos;
}
