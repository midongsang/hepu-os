/* ============================================================================
 * 赫普OS - Swap交换子系统 (V1.02新增)
 * 实现：swap区域管理、页换出/换入、swap位图
 * ========================================================================== */
#include <stdint.h>
#include <stddef.h>
#include "swap.h"
#include "mm.h"
#include "vga.h"
#include "string.h"
#include "reclaim.h"

#define SWAP_MAGIC 0x53575031  /* "SWP1" */
#define SWAP_SLOT_MAX 512      /* 最多512个swap槽 */

/* Swap槽位 */
typedef struct {
    uint8_t  used;
    uint8_t  dirty;        /* 换出时是否脏页 */
    uint32_t page_phys;    /* 原物理页地址 */
    uint32_t age;          /* 换出时间 */
} swap_slot_t;

/* Swap区域（内存模拟，真实系统为磁盘分区） */
typedef struct {
    uint8_t         initialized;
    uint8_t         enabled;
    uint32_t        total_slots;
    uint32_t        used_slots;
    uint32_t        swap_in_count;
    uint32_t        swap_out_count;
    uint32_t        swap_area_addr;   /* 模拟swap区域物理地址 */
    uint32_t        swap_area_size;
    swap_slot_t     slots[SWAP_SLOT_MAX];
} swap_manager_t;

static swap_manager_t swapm;

void swap_init(void)
{
    memset(&swapm, 0, sizeof(swapm));
    swapm.initialized = 1;
    swapm.enabled = 0;
    swapm.total_slots = SWAP_SLOT_MAX;
    swapm.used_slots = 0;
    swapm.swap_in_count = 0;
    swapm.swap_out_count = 0;
    swapm.swap_area_addr = 0;
    swapm.swap_area_size = 0;

    /* 默认分配4MB swap区域（模拟） */
    swapm.swap_area_addr = mm_alloc_pages(1024);
    swapm.swap_area_size = 1024 * PAGE_SIZE;

    if (swapm.swap_area_addr) {
        swapm.enabled = 1;
        vga_printf("[SWAP] swap子系统初始化完成: %dKB区域 @0x%x\n",
                   swapm.swap_area_size / 1024, swapm.swap_area_addr);
    } else {
        vga_puts("[SWAP] swap区域分配失败，swap禁用\n");
    }
}

/* 启用/禁用swap */
int swap_set_enabled(uint8_t enable)
{
    if (!swapm.initialized) return -1;
    swapm.enabled = enable ? 1 : 0;
    return 0;
}

/* 换出一页到swap（返回swap槽号，-1失败） */
int swap_out(uint32_t phys_addr)
{
    if (!swapm.initialized || !swapm.enabled) return -1;
    if (swapm.used_slots >= swapm.total_slots) return -2;  /* swap满 */

    /* 找空闲槽 */
    int slot = -1;
    for (int i = 0; i < SWAP_SLOT_MAX; i++) {
        if (!swapm.slots[i].used) { slot = i; break; }
    }
    if (slot < 0) return -2;

    /* 复制页内容到swap区域（模拟） */
    uint32_t swap_offset = slot * PAGE_SIZE;
    if (swapm.swap_area_addr + swap_offset + PAGE_SIZE >
        swapm.swap_area_addr + swapm.swap_area_size) {
        return -3;  /* swap区域溢出 */
    }

    memcpy((void *)(swapm.swap_area_addr + swap_offset),
           (void *)phys_addr, PAGE_SIZE);

    /* 记录槽位 */
    swapm.slots[slot].used = 1;
    swapm.slots[slot].dirty = 1;
    swapm.slots[slot].page_phys = phys_addr;
    swapm.slots[slot].age = swapm.swap_out_count;
    swapm.used_slots++;
    swapm.swap_out_count++;

    /* 释放原物理页 */
    mm_free_page(phys_addr);
    return slot;
}

/* 从swap换入一页（返回新的物理地址，0失败） */
uint32_t swap_in(int slot)
{
    if (!swapm.initialized || !swapm.enabled) return 0;
    if (slot < 0 || slot >= SWAP_SLOT_MAX) return 0;
    if (!swapm.slots[slot].used) return 0;

    /* 分配新物理页 */
    uint32_t new_phys = mm_alloc_page();
    if (!new_phys) return 0;

    /* 从swap区域复制回物理页 */
    uint32_t swap_offset = slot * PAGE_SIZE;
    memcpy((void *)new_phys,
           (void *)(swapm.swap_area_addr + swap_offset), PAGE_SIZE);

    /* 释放槽位 */
    swapm.slots[slot].used = 0;
    swapm.slots[slot].dirty = 0;
    swapm.used_slots--;
    swapm.swap_in_count++;

    return new_phys;
}

/* 检查swap是否可用 */
int swap_is_enabled(void)
{
    return swapm.initialized && swapm.enabled;
}

/* 获取swap使用情况 */
void swap_stats(uint32_t *total_slots, uint32_t *used_slots,
                uint32_t *swap_in, uint32_t *swap_out)
{
    if (total_slots) *total_slots = swapm.total_slots;
    if (used_slots) *used_slots = swapm.used_slots;
    if (swap_in) *swap_in = swapm.swap_in_count;
    if (swap_out) *swap_out = swapm.swap_out_count;
}

/* 内存压力触发的换出（回收若干页到swap） */
int swap_swapout_until(uint32_t target_free_pages)
{
    int swapped = 0;
    while (free_pages_now() < target_free_pages) {
        /* 从LRU回收页，写入swap */
        uint32_t page = reclaim_reclaim_page();
        if (!page) break;
        if (swap_out(page) < 0) {
            /* swap失败，把页放回 */
            mm_free_page(page);
            break;
        }
        swapped++;
        if ((uint32_t)swapped > swapm.total_slots) break;
    }
    return swapped;
}
