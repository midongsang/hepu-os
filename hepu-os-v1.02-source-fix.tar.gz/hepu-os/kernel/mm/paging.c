/* ============================================================================
 * 赫普OS - 分页虚拟内存管理 (V0.98深化)
 * x86 二级分页：页目录(PD) + 页表(PT)
 * 新增：按需分配(Demand Paging) + 写时复制(COW) + 页错误统计
 * ========================================================================== */
#include <stdint.h>
#include <stddef.h>
#include "paging.h"
#include "mm.h"
#include "kheap.h"
#include "string.h"
#include "vga.h"

/* 汇编函数：加载 CR3 启用分页 */
extern void paging_load_dir(uint32_t dir_phys);
extern void paging_enable_paging(void);

static page_directory_t *kernel_dir = NULL;
static page_directory_t *current_dir = NULL;

/* 页错误统计 */
static uint32_t pf_total = 0;
static uint32_t pf_demand_alloc = 0;
static uint32_t pf_cow = 0;
static uint32_t pf_protection = 0;
static uint32_t pf_kernel = 0;
static uint32_t pf_user = 0;

/* COW标记：使用页表项的available位(bit 9)标记 */
#define PAGE_COW_FLAG  0x200  /* bit 9 */

/* 物理页分配（使用 pmm） */
static uint32_t alloc_frame(void)
{
    return mm_alloc_page();
}

static void __attribute__((unused)) free_frame(uint32_t phys)
{
    mm_free_page(phys);
}

/* 初始化分页 */
void paging_init(uint32_t mem_size_kb)
{
    (void)mem_size_kb;
    vga_puts("[PAGING] 初始化分页机制...\n");

    /* 分配内核页目录（物理地址连续） */
    uint32_t dir_phys = alloc_frame();
    kernel_dir = (page_directory_t *)dir_phys;
    memset(kernel_dir, 0, sizeof(page_directory_t));

    /* 身份映射前 16MB 内存（内核空间） */
    uint32_t max_pages = (16 * 1024 * 1024) / PAGE_SIZE;
    for (uint32_t i = 0; i < max_pages; i++) {
        uint32_t phys = i * PAGE_SIZE;
        uint32_t virt = i * PAGE_SIZE;
        paging_map(kernel_dir, virt, phys, PAGE_PRESENT | PAGE_WRITE);
    }

    /* 映射内核堆区域 (16MB - 32MB) */
    for (uint32_t i = 16 * 1024 * 1024; i < 32 * 1024 * 1024; i += PAGE_SIZE) {
        paging_map(kernel_dir, i, i, PAGE_PRESENT | PAGE_WRITE);
    }

    current_dir = kernel_dir;
    pf_total = pf_demand_alloc = pf_cow = pf_protection = 0;
    pf_kernel = pf_user = 0;

    vga_printf("[PAGING] 内核页目录创建完成 (物理地址=0x%x)\n", dir_phys);
    vga_puts("[PAGING] 身份映射: 0x00000000 - 0x01000000 (16MB)\n");
}

/* 启用分页 */
void paging_enable(void)
{
    if (!kernel_dir) return;
    uint32_t dir_phys = (uint32_t)kernel_dir;
    paging_load_dir(dir_phys);
    paging_enable_paging();
    vga_puts("[PAGING] 分页已启用\n");
}

/* 获取页表项指针 */
static page_entry_t *get_page_entry(page_directory_t *dir, uint32_t virt,
                                     int create)
{
    uint32_t dir_idx = virt >> 22;
    uint32_t table_idx = (virt >> 12) & 0x3FF;
    page_dir_entry_t *dir_e = &dir->entries[dir_idx];

    if (!dir_e->present) {
        if (!create) return NULL;
        uint32_t table_phys = alloc_frame();
        if (!table_phys) return NULL;
        page_table_t *table = (page_table_t *)table_phys;
        memset(table, 0, sizeof(page_table_t));
        dir_e->frame = table_phys >> 12;
        dir_e->present = 1;
        dir_e->writable = 1;
        dir_e->user = 1;
    }
    page_table_t *table = (page_table_t *)(dir_e->frame << 12);
    return &table->entries[table_idx];
}

/* 映射虚拟地址到物理地址 */
int paging_map(page_directory_t *dir, uint32_t virt, uint32_t phys,
               uint32_t flags)
{
    page_entry_t *entry = get_page_entry(dir, virt, 1);
    if (!entry) return -1;
    entry->frame = phys >> 12;
    entry->present = (flags & PAGE_PRESENT) ? 1 : 0;
    entry->writable = (flags & PAGE_WRITE) ? 1 : 0;
    entry->user = (flags & PAGE_USER) ? 1 : 0;
    return 0;
}

/* 取消映射 */
void paging_unmap(page_directory_t *dir, uint32_t virt)
{
    page_entry_t *entry = get_page_entry(dir, virt, 0);
    if (entry && entry->present) {
        entry->present = 0;
        entry->frame = 0;
    }
}

/* 获取虚拟地址对应的物理地址 */
uint32_t paging_get_phys(page_directory_t *dir, uint32_t virt)
{
    page_entry_t *entry = get_page_entry(dir, virt, 0);
    if (!entry || !entry->present) return 0;
    return (entry->frame << 12) | (virt & 0xFFF);
}

/* 设置页标志 */
int paging_set_flags(page_directory_t *dir, uint32_t virt, uint32_t flags)
{
    page_entry_t *entry = get_page_entry(dir, virt, 0);
    if (!entry) return -1;
    entry->writable = (flags & PAGE_WRITE) ? 1 : 0;
    entry->user = (flags & PAGE_USER) ? 1 : 0;
    return 0;
}

/* 标记COW页（只读+COW标记） */
int paging_mark_cow(page_directory_t *dir, uint32_t virt)
{
    page_entry_t *entry = get_page_entry(dir, virt, 0);
    if (!entry || !entry->present) return -1;
    entry->writable = 0;  /* 设为只读 */
    /* 使用available位标记COW */
    *(volatile uint32_t *)entry |= PAGE_COW_FLAG;
    return 0;
}

/* 检查是否COW页 */
int paging_is_cow(page_directory_t *dir, uint32_t virt)
{
    page_entry_t *entry = get_page_entry(dir, virt, 0);
    if (!entry) return 0;
    return (*(volatile uint32_t *)entry & PAGE_COW_FLAG) ? 1 : 0;
}

/* 切换页目录 */
void paging_switch_dir(page_directory_t *dir)
{
    if (!dir) return;
    current_dir = dir;
    paging_load_dir((uint32_t)dir);
}

page_directory_t *paging_get_current_dir(void)
{
    return current_dir;
}

/* 创建新的页目录（用于用户进程） */
page_directory_t *paging_create_dir(void)
{
    uint32_t dir_phys = alloc_frame();
    if (!dir_phys) return NULL;
    page_directory_t *dir = (page_directory_t *)dir_phys;
    memset(dir, 0, sizeof(page_directory_t));
    /* 复制内核空间映射 */
    for (int i = 0; i < 4; i++) {
        dir->entries[i] = kernel_dir->entries[i];
    }
    return dir;
}

/* 按需分配：页不存在时自动分配物理页 */
static int handle_demand_paging(uint32_t fault_addr)
{
    uint32_t virt = fault_addr & ~(PAGE_SIZE - 1);
    uint32_t phys = alloc_frame();
    if (!phys) return -1;

    /* 清零新页 */
    memset((void *)phys, 0, PAGE_SIZE);

    /* 映射到当前页目录 */
    int ret = paging_map(current_dir, virt, phys,
                         PAGE_PRESENT | PAGE_WRITE | PAGE_USER);
    if (ret < 0) {
        free_frame(phys);
        return -1;
    }
    pf_demand_alloc++;
    return 0;
}

/* 写时复制：COW页被写时复制 */
static int handle_cow(uint32_t fault_addr)
{
    uint32_t virt = fault_addr & ~(PAGE_SIZE - 1);
    page_entry_t *entry = get_page_entry(current_dir, virt, 0);
    if (!entry || !entry->present) return -1;

    uint32_t old_phys = entry->frame << 12;
    uint32_t new_phys = alloc_frame();
    if (!new_phys) return -1;

    /* 复制页面内容 */
    memcpy((void *)new_phys, (void *)old_phys, PAGE_SIZE);

    /* 更新映射：新物理页，可写，清除COW标记 */
    entry->frame = new_phys >> 12;
    entry->writable = 1;
    *(volatile uint32_t *)entry &= ~PAGE_COW_FLAG;

    pf_cow++;
    return 0;
}

/* 页错误处理 (ISR 14) — V0.98深化：支持按需分配+COW */
void page_fault_handler(uint32_t fault_addr, uint32_t error_code)
{
    int present = error_code & 0x1;
    int write = error_code & 0x2;
    int user = error_code & 0x4;
    int reserved = error_code & 0x8;

    pf_total++;
    if (user) pf_user++; else pf_kernel++;

    /* 保留位错误：不可恢复 */
    if (reserved) {
        goto fatal;
    }

    /* 内核空间地址范围检查：0-32MB为内核区域，不做按需分配 */
    if (fault_addr < 0x2000000 && !user) {
        goto fatal;
    }

    /* 情况1：页不存在 — 按需分配 */
    if (!present) {
        if (handle_demand_paging(fault_addr) == 0) {
            return;  /* 成功，从中断返回重试指令 */
        }
        goto fatal;  /* 内存不足 */
    }

    /* 情况2：保护违规 — 检查是否COW */
    if (write && paging_is_cow(current_dir, fault_addr)) {
        if (handle_cow(fault_addr) == 0) {
            return;  /* COW复制成功 */
        }
        goto fatal;
    }

    /* 其他保护违规 */
    pf_protection++;
    goto fatal;

fatal:
    vga_set_color(VGA_COLOR_RED, VGA_COLOR_BLACK);
    vga_printf("\n[PAGING] 致命页错误\n");
    vga_printf("  故障地址: 0x%x\n", fault_addr);
    vga_printf("  类型: %s %s %s%s\n",
               present ? "保护违规" : "页不存在",
               write ? "写" : "读",
               user ? "用户态" : "内核态",
               reserved ? " 保留位" : "");
    vga_printf("  统计: 总%d 按需%d COW%d 保护%d\n",
               pf_total, pf_demand_alloc, pf_cow, pf_protection);
    vga_puts("系统已停止。\n");
    for (;;) {
        __asm__ volatile ("hlt");
    }
}

/* 页错误统计 */
void paging_fault_stats(uint32_t *total, uint32_t *demand,
                        uint32_t *cow, uint32_t *protection)
{
    if (total) *total = pf_total;
    if (demand) *demand = pf_demand_alloc;
    if (cow) *cow = pf_cow;
    if (protection) *protection = pf_protection;
}
