/* ============================================================================
 * 赫普OS - 虚拟内存区域管理 (VMA)
 * 实现：进程地址空间的虚拟内存区域管理（类似Linux vm_area_struct）
 * ========================================================================== */
#include <stdint.h>
#include <stddef.h>
#include "vma.h"
#include "kheap.h"
#include "string.h"
#include "vga.h"

/* VMA标志 */
#define VMA_READ    0x1
#define VMA_WRITE   0x2
#define VMA_EXEC    0x4
#define VMA_SHARED  0x8

/* 虚拟内存区域 */
typedef struct vma_area {
    uint32_t start;           /* 起始虚拟地址（页对齐） */
    uint32_t end;             /* 结束虚拟地址（不含） */
    uint32_t flags;           /* 访问权限标志 */
    struct vma_area *next;    /* 链表，按地址排序 */
    struct vma_area *prev;
} vma_area_t;

/* 地址空间 */
struct vm_address_space {
    vma_area_t *areas;        /* VMA链表头 */
    uint32_t    area_count;   /* 区域数量 */
    uint32_t    total_pages;  /* 总映射页数 */
};

/* 创建地址空间 */
vm_address_space_t *vma_create_space(void)
{
    vm_address_space_t *space = (vm_address_space_t *)kmalloc(sizeof(vm_address_space_t));
    if (!space) return NULL;
    space->areas = NULL;
    space->area_count = 0;
    space->total_pages = 0;
    return space;
}

/* 销毁地址空间 */
void vma_destroy_space(vm_address_space_t *space)
{
    if (!space) return;
    vma_area_t *cur = space->areas;
    while (cur) {
        vma_area_t *next = cur->next;
        kfree(cur);
        cur = next;
    }
    kfree(space);
}

/* 检查地址范围是否与现有VMA重叠 */
static int vma_check_overlap(vm_address_space_t *space, uint32_t start, uint32_t end)
{
    vma_area_t *cur = space->areas;
    while (cur) {
        if (start < cur->end && end > cur->start) {
            return 1;  /* 重叠 */
        }
        cur = cur->next;
    }
    return 0;
}

/* 映射一段虚拟内存区域 */
int vma_map(vm_address_space_t *space, uint32_t start, uint32_t length, uint32_t flags)
{
    if (!space || length == 0) return -1;

    /* 页对齐 */
    start = start & ~(PAGE_SIZE - 1);
    uint32_t end = (start + length + PAGE_SIZE - 1) & ~(PAGE_SIZE - 1);

    if (end <= start) return -1;

    /* 检查重叠 */
    if (vma_check_overlap(space, start, end)) {
        return -2;  /* 地址重叠 */
    }

    /* 分配新VMA */
    vma_area_t *area = (vma_area_t *)kmalloc(sizeof(vma_area_t));
    if (!area) return -3;

    area->start = start;
    area->end = end;
    area->flags = flags;
    area->next = NULL;
    area->prev = NULL;

    /* 按地址排序插入链表 */
    if (!space->areas || start < space->areas->start) {
        /* 插入头部 */
        area->next = space->areas;
        if (space->areas) space->areas->prev = area;
        space->areas = area;
    } else {
        vma_area_t *cur = space->areas;
        while (cur->next && cur->next->start < start) {
            cur = cur->next;
        }
        area->next = cur->next;
        area->prev = cur;
        if (cur->next) cur->next->prev = area;
        cur->next = area;
    }

    space->area_count++;
    space->total_pages += (end - start) / PAGE_SIZE;
    return 0;
}

/* 取消映射 */
int vma_unmap(vm_address_space_t *space, uint32_t start, uint32_t length)
{
    if (!space || length == 0) return -1;

    start = start & ~(PAGE_SIZE - 1);
    uint32_t end = (start + length + PAGE_SIZE - 1) & ~(PAGE_SIZE - 1);

    vma_area_t *cur = space->areas;
    while (cur) {
        vma_area_t *next = cur->next;
        if (start <= cur->start && end >= cur->end) {
            /* 完全覆盖，删除整个区域 */
            if (cur->prev) cur->prev->next = cur->next;
            else space->areas = cur->next;
            if (cur->next) cur->next->prev = cur->prev;
            space->total_pages -= (cur->end - cur->start) / PAGE_SIZE;
            space->area_count--;
            kfree(cur);
        } else if (start <= cur->start && end > cur->start && end < cur->end) {
            /* 部分覆盖头部 */
            uint32_t removed = (end - cur->start) / PAGE_SIZE;
            cur->start = end;
            space->total_pages -= removed;
        } else if (start > cur->start && start < cur->end && end >= cur->end) {
            /* 部分覆盖尾部 */
            uint32_t removed = (cur->end - start) / PAGE_SIZE;
            cur->end = start;
            space->total_pages -= removed;
        } else if (start > cur->start && end < cur->end) {
            /* 中间覆盖，分裂为两个区域 */
            vma_area_t *second = (vma_area_t *)kmalloc(sizeof(vma_area_t));
            if (second) {
                second->start = end;
                second->end = cur->end;
                second->flags = cur->flags;
                second->next = cur->next;
                second->prev = cur;
                if (cur->next) cur->next->prev = second;
                cur->end = start;
                cur->next = second;
                space->area_count++;
                space->total_pages -= (end - start) / PAGE_SIZE;
            }
        }
        cur = next;
    }
    return 0;
}

/* 查找包含指定地址的VMA */
vma_area_t *vma_find(vm_address_space_t *space, uint32_t addr)
{
    if (!space) return NULL;
    vma_area_t *cur = space->areas;
    while (cur) {
        if (addr >= cur->start && addr < cur->end) {
            return cur;
        }
        cur = cur->next;
    }
    return NULL;
}

/* 检查地址是否可访问 */
int vma_check_access(vm_address_space_t *space, uint32_t addr, uint32_t access_flags)
{
    vma_area_t *area = vma_find(space, addr);
    if (!area) return -1;  /* 未映射 */
    if ((area->flags & access_flags) != access_flags) return -2;  /* 权限不足 */
    return 0;
}

/* 获取地址空间统计 */
void vma_stats(vm_address_space_t *space, uint32_t *areas, uint32_t *pages, uint32_t *bytes)
{
    if (!space) return;
    if (areas) *areas = space->area_count;
    if (pages) *pages = space->total_pages;
    if (bytes) *bytes = space->total_pages * PAGE_SIZE;
}

/* 打印VMA列表 */
void vma_dump(vm_address_space_t *space)
{
    if (!space) {
        vga_puts("[VMA] 空地址空间\n");
        return;
    }
    vga_printf("[VMA] 地址空间: %d个区域, %d页\n", space->area_count, space->total_pages);
    vma_area_t *cur = space->areas;
    while (cur) {
        vga_printf("  0x%x-0x%x (%dKB) %c%c%c%s\n",
                   cur->start, cur->end,
                   (cur->end - cur->start) / 1024,
                   (cur->flags & VMA_READ) ? 'r' : '-',
                   (cur->flags & VMA_WRITE) ? 'w' : '-',
                   (cur->flags & VMA_EXEC) ? 'x' : '-',
                   (cur->flags & VMA_SHARED) ? " shared" : "");
        cur = cur->next;
    }
}
