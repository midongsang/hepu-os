/* ============================================================================
 * 赫普OS - 大页支持 (V1.02新增)
 * 实现：2MB大页(PSE)和4MB大页(PSE-36)分配与映射，页表树大页检测
 * ========================================================================== */
#include <stdint.h>
#include <stddef.h>
#include "hugetlb.h"
#include "mm.h"
#include "paging.h"
#include "cpu.h"
#include "vga.h"
#include "string.h"

#define HUGE_PAGE_2M   (2 * 1024 * 1024)
#define HUGE_PAGE_4M   (4 * 1024 * 1024)

/* PSE页目录项标志：PS位(bit7)置位表示4MB大页 */
#define PDE_PSE_FLAG  0x80

/* 大页统计 */
static uint32_t huge_2m_pages = 0;
static uint32_t huge_4m_pages = 0;
static uint32_t huge_2m_alloc = 0;
static uint32_t huge_4m_alloc = 0;
static uint8_t  huge_initialized = 0;

/* 检查CPU是否支持大页 */
int hugetlb_supported(void)
{
    /* 2MB大页需要PSE，4MB大页需要PSE-36（PAE或PSE-36） */
    return cpu_has_feature(CPU_FEAT_PSE);
}

/* 初始化大页子系统 */
void hugetlb_init(void)
{
    huge_2m_pages = 0;
    huge_4m_pages = 0;
    huge_2m_alloc = 0;
    huge_4m_alloc = 0;
    huge_initialized = 1;

    vga_printf("[HUGETLB] 大页子系统初始化完成 (支持: %s)\n",
               hugetlb_supported() ? "是 (PSE)" : "否");
    if (hugetlb_supported()) {
        vga_puts("[HUGETLB] 支持: 2MB大页(PSE) + 4MB大页(PSE-36)\n");
    }
}

/* 分配2MB大页（512个连续物理页），返回物理地址 */
uint32_t hugetlb_alloc_2m(void)
{
    if (!huge_initialized || !hugetlb_supported()) return 0;

    uint32_t pages = HUGE_PAGE_2M / PAGE_SIZE;
    uint32_t phys = mm_alloc_pages(pages);
    if (!phys) return 0;

    /* 大页必须对齐到2MB边界 */
    if ((phys & (HUGE_PAGE_2M - 1)) != 0) {
        mm_free_pages(phys, pages);
        /* 尝试对齐分配 */
        phys = mm_alloc_pages(pages);
        if (!phys || (phys & (HUGE_PAGE_2M - 1)) != 0) {
            if (phys) mm_free_pages(phys, pages);
            return 0;
        }
    }

    huge_2m_pages++;
    huge_2m_alloc++;
    return phys;
}

/* 分配4MB大页（1024个连续物理页），返回物理地址 */
uint32_t hugetlb_alloc_4m(void)
{
    if (!huge_initialized) return 0;

    uint32_t pages = HUGE_PAGE_4M / PAGE_SIZE;
    uint32_t phys = mm_alloc_pages(pages);
    if (!phys) return 0;

    if ((phys & (HUGE_PAGE_4M - 1)) != 0) {
        mm_free_pages(phys, pages);
        phys = mm_alloc_pages(pages);
        if (!phys || (phys & (HUGE_PAGE_4M - 1)) != 0) {
            if (phys) mm_free_pages(phys, pages);
            return 0;
        }
    }

    huge_4m_pages++;
    huge_4m_alloc++;
    return phys;
}

/* 释放2MB大页 */
void hugetlb_free_2m(uint32_t phys_addr)
{
    if (!huge_initialized || !phys_addr) return;
    uint32_t pages = HUGE_PAGE_2M / PAGE_SIZE;
    mm_free_pages(phys_addr, pages);
    huge_2m_pages--;
}

/* 释放4MB大页 */
void hugetlb_free_4m(uint32_t phys_addr)
{
    if (!huge_initialized || !phys_addr) return;
    uint32_t pages = HUGE_PAGE_4M / PAGE_SIZE;
    mm_free_pages(phys_addr, pages);
    huge_4m_pages--;
}

/* 映射4MB大页（PSE，页目录项直接指向物理地址，PS位置位） */
int hugetlb_map_4m(page_directory_t *dir, uint32_t virt, uint32_t phys,
                   uint32_t flags)
{
    if (!dir || !hugetlb_supported()) return -1;
    if ((virt & (HUGE_PAGE_4M - 1)) != 0) return -2;  /* 虚拟地址需4MB对齐 */
    if ((phys & (HUGE_PAGE_4M - 1)) != 0) return -2;  /* 物理地址需4MB对齐 */

    uint32_t dir_idx = virt >> 22;
    page_dir_entry_t *dir_e = &dir->entries[dir_idx];

    /* 直接设置页目录项为大页 */
    uint32_t entry = phys;                    /* 物理地址（4MB对齐，低22位为0） */
    entry |= PAGE_PRESENT | PDE_PSE_FLAG;     /* present + PS(4MB大页) */
    if (flags & PAGE_WRITE) entry |= PAGE_WRITE;
    if (flags & PAGE_USER) entry |= PAGE_USER;

    *(volatile uint32_t *)dir_e = entry;
    return 0;
}

/* 映射2MB大页（PSE，通过大页页表项） */
int hugetlb_map_2m(page_directory_t *dir, uint32_t virt, uint32_t phys,
                   uint32_t flags)
{
    if (!dir || !hugetlb_supported()) return -1;
    if ((virt & (HUGE_PAGE_2M - 1)) != 0) return -2;
    if ((phys & (HUGE_PAGE_2M - 1)) != 0) return -2;

    uint32_t dir_idx = virt >> 22;
    uint32_t table_idx = (virt >> 21) & 0x1FF;  /* 2MB索引，半个页表 */
    page_dir_entry_t *dir_e = &dir->entries[dir_idx];

    /* 大页页表项使用页表的奇数索引（索引0-511对应第一个2MB，512-1023对应第二个） */
    page_entry_t *entry;

    /* 需要一个页表帧 */
    uint32_t table_phys = 0;
    if (!dir_e->present) {
        table_phys = mm_alloc_page();
        if (!table_phys) return -3;
        memset((void *)table_phys, 0, sizeof(page_table_t));
        dir_e->frame = table_phys >> 12;
        dir_e->present = 1;
        dir_e->writable = 1;
        dir_e->user = 1;
    }

    page_table_t *table = (page_table_t *)(dir_e->frame << 12);
    entry = &table->entries[table_idx];

    uint32_t raw = phys;
    raw |= PAGE_PRESENT | PDE_PSE_FLAG;   /* PS位用于大页页表项 */
    if (flags & PAGE_WRITE) raw |= PAGE_WRITE;
    if (flags & PAGE_USER) raw |= PAGE_USER;

    *(volatile uint32_t *)entry = raw;
    return 0;
}

/* 检查虚拟地址是否映射为大页，返回大页大小（0=普通页或未映射） */
uint32_t hugetlb_is_huge_page(page_directory_t *dir, uint32_t virt)
{
    if (!dir) return 0;
    uint32_t dir_idx = virt >> 22;
    page_dir_entry_t *dir_e = &dir->entries[dir_idx];

    if (!dir_e->present) return 0;
    if (*(volatile uint32_t *)dir_e & PDE_PSE_FLAG) {
        return HUGE_PAGE_4M;  /* 页目录项PS位=4MB大页 */
    }

    /* 检查页表项PS位（用memcpy读取原始值避免strict-aliasing） */
    page_table_t *table = (page_table_t *)(dir_e->frame << 12);
    uint32_t table_idx = (virt >> 12) & 0x3FF;
    uint32_t raw_entry;
    memcpy(&raw_entry, &table->entries[table_idx], sizeof(uint32_t));
    if (raw_entry & PDE_PSE_FLAG) {
        return HUGE_PAGE_2M;
    }
    return 0;
}

/* 大页统计 */
void hugetlb_stats(uint32_t *huge_2m, uint32_t *huge_4m,
                   uint32_t *alloc_2m, uint32_t *alloc_4m)
{
    if (huge_2m) *huge_2m = huge_2m_pages;
    if (huge_4m) *huge_4m = huge_4m_pages;
    if (alloc_2m) *alloc_2m = huge_2m_alloc;
    if (alloc_4m) *alloc_4m = huge_4m_alloc;
}
