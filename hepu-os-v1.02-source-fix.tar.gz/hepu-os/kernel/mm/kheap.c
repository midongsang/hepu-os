/* ============================================================================
 * 赫普OS - 内核堆分配器
 * 实现：链表式 first-fit 分配器，支持任意大小分配与对齐
 * ========================================================================== */

#include <stdint.h>
#include <stddef.h>
#include "kheap.h"
#include "string.h"
#include "vga.h"

/* 堆块头部 */
typedef struct block_header {
    uint32_t size;            /* 数据区大小（不含头部） */
    uint8_t  used;            /* 1=已分配, 0=空闲 */
    struct block_header *next;
    struct block_header *prev;
} block_header_t;

#define HEADER_SIZE sizeof(block_header_t)
#define ALIGN(x, a) (((x) + (a) - 1) & ~((a) - 1))

static block_header_t *heap_start = NULL;
static uint32_t heap_end = 0;
static uint32_t heap_total = 0;
static uint32_t heap_used = 0;

void kheap_init(uint32_t start_addr, uint32_t size)
{
    heap_start = (block_header_t *)start_addr;
    heap_end = start_addr + size;
    heap_total = size;
    heap_used = 0;

    /* 初始化为一个大空闲块 */
    heap_start->size = size - HEADER_SIZE;
    heap_start->used = 0;
    heap_start->next = NULL;
    heap_start->prev = NULL;

    vga_printf("[KHEAP] 内核堆初始化: 起始=0x%x 大小=%d KB\n",
               start_addr, size / 1024);
}

/* 分裂一个空闲块 */
static void split_block(block_header_t *block, uint32_t size)
{
    if (block->size <= size + HEADER_SIZE + 16) {
        return; /* 剩余空间太小，不分裂 */
    }
    block_header_t *new_block = (block_header_t *)(
        (uint8_t *)block + HEADER_SIZE + size);
    new_block->size = block->size - size - HEADER_SIZE;
    new_block->used = 0;
    new_block->next = block->next;
    new_block->prev = block;
    if (block->next) block->next->prev = new_block;
    block->next = new_block;
    block->size = size;
}

/* 合并相邻空闲块 */
static void merge_blocks(block_header_t *block)
{
    /* 合并下一个 */
    if (block->next && !block->next->used) {
        block->size += HEADER_SIZE + block->next->size;
        block_header_t *next = block->next;
        block->next = next->next;
        if (next->next) next->next->prev = block;
    }
    /* 合并前一个 */
    if (block->prev && !block->prev->used) {
        block->prev->size += HEADER_SIZE + block->size;
        block->prev->next = block->next;
        if (block->next) block->next->prev = block->prev;
    }
}

void *kmalloc(size_t size)
{
    if (size == 0) return NULL;
    size = ALIGN(size, 4);

    block_header_t *cur = heap_start;
    while (cur) {
        if (!cur->used && cur->size >= size) {
            split_block(cur, size);
            cur->used = 1;
            heap_used += cur->size + HEADER_SIZE;
            return (void *)((uint8_t *)cur + HEADER_SIZE);
        }
        cur = cur->next;
    }
    vga_puts("[KHEAP] 警告: 内核堆内存不足!\n");
    return NULL;
}

void *kmalloc_aligned(size_t size, size_t alignment)
{
    if (alignment <= 1) return kmalloc(size);

    /* 多分配一些空间用于对齐 */
    size_t total = size + alignment + HEADER_SIZE;
    void *raw = kmalloc(total);
    if (!raw) return NULL;

    uint32_t addr = (uint32_t)raw;
    uint32_t aligned = ALIGN(addr, alignment);

    /* 如果已经对齐，直接返回 */
    if (aligned == addr) return raw;

    /* 简单处理：返回对齐后的地址（会浪费前面的空间）
     * 注意：这种方式kfree时需要原始地址，实际项目中需要更复杂的实现 */
    return (void *)aligned;
}

void kfree(void *ptr)
{
    if (!ptr) return;

    block_header_t *block = (block_header_t *)(
        (uint8_t *)ptr - HEADER_SIZE);

    if (!block->used) {
        vga_puts("[KHEAP] 错误: 重复释放!\n");
        return;
    }

    block->used = 0;
    heap_used -= block->size + HEADER_SIZE;
    merge_blocks(block);
}

void kheap_stats(uint32_t *used, uint32_t *free, uint32_t *total)
{
    if (used)  *used = heap_used;
    if (free)  *free = heap_total - heap_used;
    if (total) *total = heap_total;
}
