/* ============================================================================
 * 赫普OS - 网络套接字子系统
 * 基于loopback的TCP/UDP原型实现
 * ========================================================================== */

#include <stdint.h>
#include "socket.h"
#include "vga.h"
#include "string.h"
#include "kheap.h"

static socket_t sockets[MAX_SOCKETS];
static int socket_initialized = 0;
static uint16_t next_port = 1024;

void socket_init(void)
{
    memset(sockets, 0, sizeof(sockets));
    socket_initialized = 1;
    vga_puts("[SOCKET] 网络套接字子系统初始化 (loopback TCP/UDP)\n");
}

static int find_free_socket(void)
{
    for (int i = 0; i < MAX_SOCKETS; i++) {
        if (!sockets[i].used) return i;
    }
    return -1;
}

int sys_socket_impl(int domain, int type, int protocol)
{
    if (!socket_initialized) return -1;
    if (domain != AF_INET && domain != AF_UNIX) return -1;
    if (type != SOCK_STREAM && type != SOCK_DGRAM) return -1;

    int fd = find_free_socket();
    if (fd < 0) return -1;

    memset(&sockets[fd], 0, sizeof(socket_t));
    sockets[fd].used = 1;
    sockets[fd].domain = domain;
    sockets[fd].type = type;
    sockets[fd].protocol = protocol;
    sockets[fd].state = SS_CREATED;

    vga_printf("[SOCKET] 创建: fd=%d type=%s\n", fd,
               type == SOCK_STREAM ? "TCP" : "UDP");
    return fd;
}

int sys_bind_impl(int fd, sockaddr_in_t *addr)
{
    if (fd < 0 || fd >= MAX_SOCKETS || !sockets[fd].used) return -1;
    if (!addr) return -1;

    sockets[fd].local_addr = *addr;
    sockets[fd].state = SS_BOUND;

    vga_printf("[SOCKET] 绑定: fd=%d port=%d\n", fd, addr->port);
    return 0;
}

int sys_listen_impl(int fd, int backlog)
{
    if (fd < 0 || fd >= MAX_SOCKETS || !sockets[fd].used) return -1;
    if (sockets[fd].state != SS_BOUND) return -1;

    sockets[fd].state = SS_LISTENING;
    sockets[fd].backlog = backlog;

    vga_printf("[SOCKET] 监听: fd=%d backlog=%d\n", fd, backlog);
    return 0;
}

int sys_accept_impl(int fd, sockaddr_in_t *addr)
{
    if (fd < 0 || fd >= MAX_SOCKETS || !sockets[fd].used) return -1;
    if (sockets[fd].state != SS_LISTENING) return -1;

    /* loopback: 创建新socket代表连接 */
    int new_fd = find_free_socket();
    if (new_fd < 0) return -1;

    memset(&sockets[new_fd], 0, sizeof(socket_t));
    sockets[new_fd].used = 1;
    sockets[new_fd].domain = sockets[fd].domain;
    sockets[new_fd].type = sockets[fd].type;
    sockets[new_fd].protocol = sockets[fd].protocol;
    sockets[new_fd].state = SS_ACCEPTED;
    sockets[new_fd].local_addr = sockets[fd].local_addr;
    sockets[new_fd].peer_fd = fd;

    if (addr) {
        addr->family = AF_INET;
        addr->port = next_port++;
        addr->addr = 0x0100007F;  /* 127.0.0.1 */
        sockets[new_fd].remote_addr = *addr;
    }

    vga_printf("[SOCKET] 接受: fd=%d -> newfd=%d\n", fd, new_fd);
    return new_fd;
}

int sys_connect_impl(int fd, sockaddr_in_t *addr)
{
    if (fd < 0 || fd >= MAX_SOCKETS || !sockets[fd].used) return -1;
    if (!addr) return -1;

    /* loopback: 直接连接成功 */
    sockets[fd].remote_addr = *addr;
    sockets[fd].state = SS_CONNECTED;

    vga_printf("[SOCKET] 连接: fd=%d -> %d.%d.%d.%d:%d\n", fd,
               (addr->addr >> 0) & 0xFF, (addr->addr >> 8) & 0xFF,
               (addr->addr >> 16) & 0xFF, (addr->addr >> 24) & 0xFF,
               addr->port);
    return 0;
}

int sys_send_impl(int fd, const void *buf, uint32_t len, int flags)
{
    (void)flags;
    if (fd < 0 || fd >= MAX_SOCKETS || !sockets[fd].used) return -1;
    if (sockets[fd].state != SS_CONNECTED &&
        sockets[fd].state != SS_ACCEPTED) return -1;
    if (!buf || len == 0) return 0;

    /* loopback: 如果有对端，写入对端接收缓冲区 */
    socket_t *s = &sockets[fd];
    if (s->peer_fd >= 0 && s->peer_fd < MAX_SOCKETS && sockets[s->peer_fd].used) {
        socket_t *peer = &sockets[s->peer_fd];
        uint32_t space = SOCKET_BUF_SIZE - peer->recv_len;
        uint32_t copy = len < space ? len : space;
        memcpy(peer->recv_buf + peer->recv_len, buf, copy);
        peer->recv_len += copy;
        return copy;
    }

    /* 无对端：丢弃数据（模拟发送成功） */
    return len;
}

int sys_recv_impl(int fd, void *buf, uint32_t len, int flags)
{
    (void)flags;
    if (fd < 0 || fd >= MAX_SOCKETS || !sockets[fd].used) return -1;
    if (!buf || len == 0) return 0;

    socket_t *s = &sockets[fd];
    if (s->recv_len == 0) return 0;  /* 无数据 */

    uint32_t available = s->recv_len - s->recv_pos;
    uint32_t copy = len < available ? len : available;
    memcpy(buf, s->recv_buf + s->recv_pos, copy);
    s->recv_pos += copy;

    /* 缓冲区读完后重置 */
    if (s->recv_pos >= s->recv_len) {
        s->recv_len = 0;
        s->recv_pos = 0;
    }

    return copy;
}

int sys_close_socket(int fd)
{
    if (fd < 0 || fd >= MAX_SOCKETS || !sockets[fd].used) return -1;
    sockets[fd].used = 0;
    sockets[fd].state = SS_CLOSED;
    vga_printf("[SOCKET] 关闭: fd=%d\n", fd);
    return 0;
}
