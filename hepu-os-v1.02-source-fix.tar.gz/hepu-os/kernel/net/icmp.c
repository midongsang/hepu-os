/* ============================================================================
 * 赫普OS - ICMP协议与Ping
 * 互联网控制消息协议，网络诊断工具
 * ========================================================================== */

#include <stdint.h>
#include "icmp.h"
#include "dns.h"
#include "vga.h"
#include "string.h"

static int icmp_initialized = 0;
static uint16_t icmp_next_id = 0x1234;

/* 初始化ICMP */
void icmp_init(void)
{
    icmp_initialized = 1;
    icmp_next_id = 0x1234;
    vga_puts("[ICMP] ICMP协议初始化\n");
    vga_puts("[ICMP] 支持Echo Request/Reply, Destination Unreachable\n");
}

/* 计算校验和 */
uint16_t icmp_checksum(const uint8_t *data, uint32_t length)
{
    uint32_t sum = 0;
    const uint16_t *ptr = (const uint16_t *)data;

    while (length > 1) {
        sum += *ptr++;
        length -= 2;
    }
    if (length == 1) {
        sum += *(const uint8_t *)ptr;
    }

    sum = (sum >> 16) + (sum & 0xFFFF);
    sum += (sum >> 16);
    return (uint16_t)(~sum);
}

/* 发送Echo Request */
int icmp_send_echo_request(uint32_t dest_ip, uint16_t id, uint16_t seq,
                           const uint8_t *data, uint32_t data_len)
{
    if (!icmp_initialized) return -1;

    uint8_t packet[64];
    memset(packet, 0, sizeof(packet));

    hepu_icmp_header_t *icmp = (hepu_icmp_header_t *)packet;
    icmp->type = ICMP_TYPE_ECHO_REQUEST;
    icmp->code = 0;
    icmp->checksum = 0;
    icmp->data.echo.id = id;
    icmp->data.echo.seq = seq;

    /* 复制数据 */
    if (data && data_len > 0 && data_len < sizeof(packet) - sizeof(hepu_icmp_header_t)) {
        memcpy(packet + sizeof(hepu_icmp_header_t), data, data_len);
    }

    /* 计算校验和 */
    uint32_t total_len = sizeof(hepu_icmp_header_t) + data_len;
    icmp->checksum = icmp_checksum(packet, total_len);

    vga_printf("[ICMP] 发送Echo Request到 %d.%d.%d.%d (id=%d, seq=%d)\n",
               (dest_ip >> 24) & 0xFF, (dest_ip >> 16) & 0xFF,
               (dest_ip >> 8) & 0xFF, dest_ip & 0xFF, id, seq);

    return total_len;
}

/* 处理ICMP包 */
int icmp_process_packet(const uint8_t *data, uint32_t length)
{
    if (!icmp_initialized || !data || length < sizeof(hepu_icmp_header_t)) return -1;

    const hepu_icmp_header_t *icmp = (const hepu_icmp_header_t *)data;

    switch (icmp->type) {
        case ICMP_TYPE_ECHO_REPLY:
            vga_printf("[ICMP] 收到Echo Reply (id=%d, seq=%d)\n",
                       icmp->data.echo.id, icmp->data.echo.seq);
            break;
        case ICMP_TYPE_DEST_UNREACH:
            vga_printf("[ICMP] 目标不可达 (code=%d)\n", icmp->code);
            break;
        case ICMP_TYPE_TIME_EXCEEDED:
            vga_puts("[ICMP] 超时\n");
            break;
        default:
            vga_printf("[ICMP] 收到类型=%d, code=%d\n", icmp->type, icmp->code);
            break;
    }
    return 0;
}

/* 单次Ping */
int ping_once(uint32_t dest_ip, hepu_ping_result_t *result)
{
    if (!icmp_initialized || !result) return -1;

    uint16_t id = icmp_next_id++;
    uint16_t seq = 1;
    uint8_t data[32];
    memset(data, 0xAB, sizeof(data));

    /* 发送请求 */
    icmp_send_echo_request(dest_ip, id, seq, data, sizeof(data));

    /* 简化：模拟收到回复 */
    result->ip_addr = dest_ip;
    result->seq = seq;
    result->ttl = 64;
    result->rtt_ms = 1 + (dest_ip & 0x3F);  /* 模拟1-64ms延迟 */
    result->success = 1;

    vga_printf("64 bytes from %d.%d.%d.%d: icmp_seq=%d ttl=%d time=%dms\n",
               (dest_ip >> 24) & 0xFF, (dest_ip >> 16) & 0xFF,
               (dest_ip >> 8) & 0xFF, dest_ip & 0xFF,
               seq, result->ttl, result->rtt_ms);

    return 0;
}

/* Ping命令 */
int ping(const char *hostname, int count, int interval_ms, hepu_ping_stats_t *stats)
{
    (void)interval_ms;
    if (!icmp_initialized || !hostname || !stats) return -1;

    /* 解析域名 */
    uint32_t ip_addr;
    if (hepu_dns_resolve(hostname, &ip_addr) != 0) {
        vga_printf("ping: 无法解析 %s\n", hostname);
        return -1;
    }

    vga_printf("PING %s (%d.%d.%d.%d): 32 data bytes\n",
               hostname,
               (ip_addr >> 24) & 0xFF, (ip_addr >> 16) & 0xFF,
               (ip_addr >> 8) & 0xFF, ip_addr & 0xFF);

    memset(stats, 0, sizeof(hepu_ping_stats_t));
    stats->min_rtt_ms = 0xFFFFFFFF;

    for (int i = 0; i < count; i++) {
        hepu_ping_result_t result;
        if (ping_once(ip_addr, &result) == 0 && result.success) {
            stats->received++;
            stats->total_rtt_ms += result.rtt_ms;
            if (result.rtt_ms < stats->min_rtt_ms) stats->min_rtt_ms = result.rtt_ms;
            if (result.rtt_ms > stats->max_rtt_ms) stats->max_rtt_ms = result.rtt_ms;
        } else {
            stats->errors++;
        }
        stats->transmitted++;
    }

    /* 计算平均RTT */
    if (stats->received > 0) {
        stats->avg_rtt_ms = stats->total_rtt_ms / stats->received;
    }

    /* 输出统计 */
    uint32_t loss = 0;
    if (stats->transmitted > 0) {
        loss = ((stats->transmitted - stats->received) * 100) / stats->transmitted;
    }
    vga_printf("\n--- %s ping统计 ---\n", hostname);
    vga_printf("%d packets transmitted, %d received, %d%% packet loss\n",
               stats->transmitted, stats->received, loss);
    if (stats->received > 0) {
        vga_printf("rtt min/avg/max = %d/%d/%d ms\n",
                   stats->min_rtt_ms, stats->avg_rtt_ms, stats->max_rtt_ms);
    }

    return 0;
}
