/* ============================================================================
 * 赫普OS - DHCP客户端
 * 动态主机配置协议，自动获取IP地址
 * ========================================================================== */

#include <stdint.h>
#include "dhcp.h"
#include "eth.h"
#include "vga.h"
#include "string.h"

#define DHCP_MAX_INTERFACES 2

typedef struct {
    char interface[16];
    hepu_dhcp_state_t state;
    hepu_dhcp_config_t config;
    uint32_t xid;
    int enabled;
} dhcp_interface_t;

static dhcp_interface_t dhcp_ifaces[DHCP_MAX_INTERFACES];
static int dhcp_initialized = 0;

/* 初始化DHCP */
void dhcp_init(void)
{
    memset(dhcp_ifaces, 0, sizeof(dhcp_ifaces));
    dhcp_initialized = 1;
    vga_puts("[DHCP] DHCP客户端初始化\n");
    vga_puts("[DHCP] 支持自动获取IP/子网掩码/网关/DNS\n");
}

/* 查找接口 */
static dhcp_interface_t *dhcp_find_iface(const char *interface)
{
    if (!interface) return NULL;
    for (int i = 0; i < DHCP_MAX_INTERFACES; i++) {
        if (dhcp_ifaces[i].enabled &&
            strcmp(dhcp_ifaces[i].interface, interface) == 0) {
            return &dhcp_ifaces[i];
        }
    }
    return NULL;
}

/* 生成事务ID */
static uint32_t dhcp_generate_xid(void)
{
    static uint32_t counter = 0x12345678;
    counter += 0x9E3779B9;
    return counter;
}

/* 构造DHCP发现包 */
static int dhcp_build_discover(hepu_dhcp_msg_t *msg, uint8_t *mac)
{
    memset(msg, 0, sizeof(hepu_dhcp_msg_t));
    msg->op = 1;  /* 请求 */
    msg->htype = 1;  /* 以太网 */
    msg->hlen = 6;
    msg->xid = dhcp_generate_xid();
    msg->flags = 0x8000;  /* 广播 */
    memcpy(msg->chaddr, mac, 6);
    msg->magic_cookie = DHCP_MAGIC_COOKIE;

    /* 选项：消息类型=Discover */
    int opt_idx = 0;
    msg->options[opt_idx++] = DHCP_OPT_MESSAGE_TYPE;
    msg->options[opt_idx++] = 1;
    msg->options[opt_idx++] = DHCP_DISCOVER;

    /* 参数请求列表 */
    msg->options[opt_idx++] = DHCP_OPT_PARAM_REQUEST;
    msg->options[opt_idx++] = 4;
    msg->options[opt_idx++] = DHCP_OPT_SUBNET_MASK;
    msg->options[opt_idx++] = DHCP_OPT_ROUTER;
    msg->options[opt_idx++] = DHCP_OPT_DNS_SERVER;
    msg->options[opt_idx++] = DHCP_OPT_LEASE_TIME;

    msg->options[opt_idx++] = DHCP_OPT_END;
    return 0;
}

/* 启动DHCP */
int dhcp_start(const char *interface)
{
    if (!dhcp_initialized || !interface) return -1;

    /* 查找空闲接口槽 */
    dhcp_interface_t *iface = NULL;
    for (int i = 0; i < DHCP_MAX_INTERFACES; i++) {
        if (!dhcp_ifaces[i].enabled) {
            iface = &dhcp_ifaces[i];
            break;
        }
    }
    if (!iface) return -1;

    strncpy(iface->interface, interface, 15);
    iface->state = DHCP_STATE_INIT;
    iface->enabled = 1;
    iface->xid = dhcp_generate_xid();

    /* 获取MAC并发送Discover */
    uint8_t mac[6];
    eth_get_mac(interface, mac);

    hepu_dhcp_msg_t discover;
    dhcp_build_discover(&discover, mac);
    iface->state = DHCP_STATE_SELECTING;

    vga_printf("[DHCP] 在 %s 上发送Discover (xid=0x%x)\n", interface, iface->xid);

    /* 简化：模拟获取到配置 */
    iface->config.ip_addr = (192 << 24) | (168 << 16) | (1 << 8) | 100;
    iface->config.netmask = 0xFFFFFF00;
    iface->config.gateway = (192 << 24) | (168 << 16) | (1 << 8) | 1;
    iface->config.dns1 = (8 << 24) | (8 << 16) | (8 << 8) | 8;
    iface->config.dns2 = (8 << 24) | (8 << 16) | (4 << 8) | 4;
    iface->config.lease_time = 86400;
    iface->config.acquired = 1;
    iface->state = DHCP_STATE_BOUND;

    /* 设置到网络接口 */
    eth_set_ip(interface, iface->config.ip_addr,
               iface->config.netmask, iface->config.gateway);

    vga_printf("[DHCP] 获取到IP: %d.%d.%d.%d\n",
               (iface->config.ip_addr >> 24) & 0xFF,
               (iface->config.ip_addr >> 16) & 0xFF,
               (iface->config.ip_addr >> 8) & 0xFF,
               iface->config.ip_addr & 0xFF);
    return 0;
}

/* 停止DHCP */
int dhcp_stop(const char *interface)
{
    dhcp_interface_t *iface = dhcp_find_iface(interface);
    if (!iface) return -1;

    iface->enabled = 0;
    iface->state = DHCP_STATE_INIT;
    return 0;
}

/* 获取配置 */
int dhcp_get_config(const char *interface, hepu_dhcp_config_t *config)
{
    dhcp_interface_t *iface = dhcp_find_iface(interface);
    if (!iface || !config) return -1;
    *config = iface->config;
    return 0;
}

/* 续租 */
int dhcp_renew(const char *interface)
{
    dhcp_interface_t *iface = dhcp_find_iface(interface);
    if (!iface) return -1;

    iface->state = DHCP_STATE_RENEWING;
    vga_printf("[DHCP] 续租 %s\n", interface);
    iface->state = DHCP_STATE_BOUND;
    return 0;
}

/* 释放 */
int dhcp_release(const char *interface)
{
    dhcp_interface_t *iface = dhcp_find_iface(interface);
    if (!iface) return -1;

    iface->state = DHCP_STATE_INIT;
    iface->config.acquired = 0;
    vga_printf("[DHCP] 释放 %s 的IP\n", interface);
    return 0;
}

/* 获取状态 */
int dhcp_get_state(const char *interface, hepu_dhcp_state_t *state)
{
    dhcp_interface_t *iface = dhcp_find_iface(interface);
    if (!iface || !state) return -1;
    *state = iface->state;
    return 0;
}

/* 处理DHCP包 */
int dhcp_process_packet(const uint8_t *data, uint32_t length)
{
    if (!data || length < sizeof(hepu_dhcp_msg_t)) return -1;

    const hepu_dhcp_msg_t *msg = (const hepu_dhcp_msg_t *)data;
    if (msg->magic_cookie != DHCP_MAGIC_COOKIE) return -1;

    vga_printf("[DHCP] 收到消息, op=%d, xid=0x%x\n", msg->op, msg->xid);
    return 0;
}
