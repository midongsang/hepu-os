/* ============================================================================
 * 赫普OS - DNS域名解析
 * 域名系统，将域名解析为IP地址
 * ========================================================================== */

#include <stdint.h>
#include "dns.h"
#include "vga.h"
#include "string.h"

static hepu_dns_cache_entry_t dns_cache[DNS_CACHE_SIZE];
static uint32_t dns_tick_count = 0;
static uint32_t dns_default_server = 0;
static int dns_initialized = 0;

/* 初始化DNS */
void hepu_dns_init(void)
{
    memset(dns_cache, 0, sizeof(dns_cache));
    dns_tick_count = 0;
    dns_default_server = (8 << 24) | (8 << 16) | (8 << 8) | 8;  /* 8.8.8.8 */
    dns_initialized = 1;
    vga_puts("[DNS] 域名解析初始化\n");
    vga_printf("[DNS] 默认DNS服务器: 8.8.8.8, 缓存: %d条目\n", DNS_CACHE_SIZE);
}

/* 解析域名 */
int hepu_dns_resolve(const char *hostname, uint32_t *ip_addr)
{
    return hepu_dns_resolve_with_server(hostname, dns_default_server, ip_addr);
}

/* 使用指定DNS服务器解析 */
int hepu_hepu_dns_resolve_with_server(const char *hostname, uint32_t dns_server, uint32_t *ip_addr)
{
    if (!dns_initialized || !hostname || !ip_addr) return -1;

    /* 先查缓存 */
    if (hepu_dns_lookup_cache(hostname, ip_addr) == 0) {
        vga_printf("[DNS] 缓存命中: %s -> %d.%d.%d.%d\n",
                   hostname,
                   (*ip_addr >> 24) & 0xFF, (*ip_addr >> 16) & 0xFF,
                   (*ip_addr >> 8) & 0xFF, *ip_addr & 0xFF);
        return 0;
    }

    /* 简化：模拟DNS解析 */
    vga_printf("[DNS] 查询 %s via %d.%d.%d.%d\n",
               hostname,
               (dns_server >> 24) & 0xFF, (dns_server >> 16) & 0xFF,
               (dns_server >> 8) & 0xFF, dns_server & 0xFF);

    /* 模拟一些常见域名 */
    if (strcmp(hostname, "www.hepu.os") == 0) {
        *ip_addr = (10 << 24) | (0 << 16) | (0 << 8) | 1;
    } else if (strcmp(hostname, "localhost") == 0) {
        *ip_addr = (127 << 24) | (0 << 16) | (0 << 8) | 1;
    } else {
        /* 模拟解析结果 */
        uint32_t hash = 0;
        for (int i = 0; hostname[i]; i++) {
            hash = hash * 31 + (uint8_t)hostname[i];
        }
        *ip_addr = (199 << 24) | (235 << 16) | ((hash >> 8) & 0xFF) << 8 | (hash & 0xFF);
    }

    /* 添加到缓存 */
    hepu_dns_add_cache(hostname, *ip_addr, HEPU_DNS_TYPE_A, 300);

    vga_printf("[DNS] 解析结果: %s -> %d.%d.%d.%d\n",
               hostname,
               (*ip_addr >> 24) & 0xFF, (*ip_addr >> 16) & 0xFF,
               (*ip_addr >> 8) & 0xFF, *ip_addr & 0xFF);
    return 0;
}

/* 添加缓存条目 */
int hepu_hepu_dns_add_cache(const char *hostname, uint32_t ip_addr, uint16_t type, uint32_t ttl)
{
    if (!hostname) return -1;

    /* 查找已有条目 */
    for (int i = 0; i < DNS_CACHE_SIZE; i++) {
        if (dns_cache[i].valid && strcmp(dns_cache[i].name, hostname) == 0) {
            dns_cache[i].ip_addr = ip_addr;
            dns_cache[i].type = type;
            dns_cache[i].ttl = ttl;
            dns_cache[i].timestamp = dns_tick_count;
            return 0;
        }
    }

    /* 找空闲条目 */
    for (int i = 0; i < DNS_CACHE_SIZE; i++) {
        if (!dns_cache[i].valid) {
            strncpy(dns_cache[i].name, hostname, DNS_MAX_NAME_LEN - 1);
            dns_cache[i].ip_addr = ip_addr;
            dns_cache[i].type = type;
            dns_cache[i].ttl = ttl;
            dns_cache[i].timestamp = dns_tick_count;
            dns_cache[i].valid = 1;
            return 0;
        }
    }

    /* 替换最旧的 */
    int oldest = 0;
    for (int i = 1; i < DNS_CACHE_SIZE; i++) {
        if (dns_cache[i].timestamp < dns_cache[oldest].timestamp) {
            oldest = i;
        }
    }
    strncpy(dns_cache[oldest].name, hostname, DNS_MAX_NAME_LEN - 1);
    dns_cache[oldest].ip_addr = ip_addr;
    dns_cache[oldest].type = type;
    dns_cache[oldest].ttl = ttl;
    dns_cache[oldest].timestamp = dns_tick_count;
    dns_cache[oldest].valid = 1;
    return 0;
}

/* 查找缓存 */
int hepu_hepu_dns_lookup_cache(const char *hostname, uint32_t *ip_addr)
{
    if (!hostname || !ip_addr) return -1;

    for (int i = 0; i < DNS_CACHE_SIZE; i++) {
        if (dns_cache[i].valid && strcmp(dns_cache[i].name, hostname) == 0) {
            /* 检查TTL */
            if ((dns_tick_count - dns_cache[i].timestamp) < dns_cache[i].ttl) {
                *ip_addr = dns_cache[i].ip_addr;
                return 0;
            } else {
                dns_cache[i].valid = 0;  /* 过期 */
            }
        }
    }
    return -1;
}

/* 清空缓存 */
int hepu_dns_flush_cache(void)
{
    memset(dns_cache, 0, sizeof(dns_cache));
    vga_puts("[DNS] 缓存已清空\n");
    return 0;
}

/* 获取缓存 */
int hepu_dns_get_cache(hepu_dns_cache_entry_t *cache, int max)
{
    if (!cache || max <= 0) return 0;
    int count = 0;
    for (int i = 0; i < DNS_CACHE_SIZE && count < max; i++) {
        if (dns_cache[i].valid) {
            cache[count++] = dns_cache[i];
        }
    }
    return count;
}

/* 定时处理 */
void hepu_dns_tick(void)
{
    dns_tick_count++;
    for (int i = 0; i < DNS_CACHE_SIZE; i++) {
        if (dns_cache[i].valid &&
            (dns_tick_count - dns_cache[i].timestamp) > dns_cache[i].ttl) {
            dns_cache[i].valid = 0;
        }
    }
}
