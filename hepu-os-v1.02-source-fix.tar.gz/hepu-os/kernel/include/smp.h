#ifndef SMP_H
#define SMP_H

#include <stdint.h>

#define MAX_CPUS 8

/* CPU状态 */
typedef struct {
    uint32_t cpu_id;
    int online;
    int current_pid;
    uint32_t kernel_stack;
    uint32_t user_stack;
    uint32_t lapic_id;
    volatile int ipi_pending;
    uint32_t ipi_msg;
} smp_cpu_t;

/* 初始化SMP */
void smp_init(void);

/* 启动应用处理器(AP) */
int smp_start_ap(uint32_t apic_id);

/* 获取当前CPU ID */
uint32_t smp_cpu_id(void);

/* 获取在线CPU数量 */
int smp_cpu_count(void);

/* 获取CPU状态 */
smp_cpu_t *smp_get_cpu_state(uint32_t cpu_id);

/* 发送处理器间中断(IPI) */
int smp_send_ipi(uint32_t target_cpu, uint32_t msg);

/* 处理IPI */
void smp_handle_ipi(void);

/* 多核调度: 选择下一个CPU运行进程 */
int smp_schedule(int pid);

/* 原子操作 */
uint32_t smp_atomic_inc(volatile uint32_t *val);
uint32_t smp_atomic_dec(volatile uint32_t *val);
int smp_atomic_cas(volatile uint32_t *val, uint32_t old, uint32_t new);

/* 自旋锁 */
typedef struct {
    volatile uint32_t lock;
} spinlock_t;

#define SPINLOCK_INIT {0}

void spin_lock(spinlock_t *lock);
void spin_unlock(spinlock_t *lock);
int spin_trylock(spinlock_t *lock);

#endif /* SMP_H */
