#ifndef PROCESS_H
#define PROCESS_H

#include <stdint.h>
#include <stddef.h>
#include "paging.h"

#include "constants.h"  /* 统一 MAX_PROCESSES/PROC_NAME_LEN/KERNEL_STACK_SIZE/USER_STACK_SIZE 定义来源 */

/* 进程状态 */
typedef enum {
    PROC_UNUSED = 0,
    PROC_READY,
    PROC_RUNNING,
    PROC_BLOCKED,
    PROC_FROZEN,      /* 后台冻结：完全挂起，零调度零耗电 */
    PROC_ZOMBIE
} proc_state_t;

/* 进程特权级 */
typedef enum {
    PRIV_KERNEL = 0,
    PRIV_USER = 3
} privilege_t;

/* CPU寄存器状态（用于上下文切换） */
typedef struct {
    uint32_t edi, esi, ebp, esp;
    uint32_t ebx, edx, ecx, eax;
    uint32_t eip, cs, eflags;
    uint32_t user_esp, ss;  /* 用户态栈（中断返回时用） */
} cpu_state_t;

/* 进程控制块 PCB */
typedef struct process {
    uint32_t    pid;
    uint32_t    parent_pid;   /* 父进程PID */
    char        name[PROC_NAME_LEN];
    proc_state_t state;
    privilege_t privilege;

    uint32_t    kernel_stack;   /* 内核栈顶 */
    uint32_t    kernel_esp;     /* 进程切换时的内核栈指针 */
    uint32_t    user_stack;     /* 用户栈顶 */
    uint32_t    entry_point;    /* 入口地址 */

    page_directory_t *page_dir; /* 进程页目录 */

    cpu_state_t *cpu_state;     /* 寄存器状态保存位置 */

    uint32_t    priority;
    uint32_t    time_slice;
    uint32_t    time_used;      /* 已用时间片 */
    uint32_t    sandbox_id;     /* 沙盒隔离ID */

    struct process *next;       /* 调度链表 */
} process_t;

/* 初始化进程管理 */
void process_init(void);

/* 全局进程表（供后台冻结等模块遍历） */
extern process_t proc_table[];

/* 创建进程 */
process_t *process_create(const char *name, uint32_t entry,
                          privilege_t priv, uint32_t priority);

/* 启动第一个用户进程（从内核态切换） */
void process_enter_user_mode(process_t *proc);

/* 上下文切换（汇编实现） */
extern void process_switch(process_t *next);

/* 调度器需要切换标志 */
extern volatile int need_resched;

/* 调度器主函数（选择下一个进程并切换） */
void schedule(void);

/* 获取当前进程 */
process_t *process_current(void);

/* 进程统计 */
void process_stats(uint32_t *total, uint32_t *running, uint32_t *ready);

#endif /* PROCESS_H */

/* === V0.42 新增：fork/execve 多进程支持 === */
int sys_fork_impl(void);
int sys_execve_impl(const char *path, char *const argv[], char *const envp[]);
int process_fork(void);
int process_execve(const char *path);
