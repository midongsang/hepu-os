#ifndef VGA_GFX_H
#define VGA_GFX_H

#include <stdint.h>

/* VGA 图形模式 0x13: 320x200 256色 */
#define GFX_WIDTH  320
#define GFX_HEIGHT 200
#define GFX_FB     0xA0000

/* 颜色索引 (256色调色板) */
#define GFX_COLOR_BLACK    0
#define GFX_COLOR_BLUE     1
#define GFX_COLOR_GREEN    2
#define GFX_COLOR_CYAN     3
#define GFX_COLOR_RED      4
#define GFX_COLOR_MAGENTA  5
#define GFX_COLOR_BROWN    6
#define GFX_COLOR_LIGHTGREY 7
#define GFX_COLOR_DARKGREY 8
#define GFX_COLOR_LIGHTBLUE 9
#define GFX_COLOR_LIGHTGREEN 10
#define GFX_COLOR_LIGHTCYAN 11
#define GFX_COLOR_LIGHTRED 12
#define GFX_COLOR_LIGHTMAGENTA 13
#define GFX_COLOR_YELLOW   14
#define GFX_COLOR_WHITE    15

/* 初始化VGA图形模式 */
void vga_gfx_init(void);

/* 切换回文本模式 */
void vga_gfx_text_mode(void);

/* 画点 */
void gfx_putpixel(int x, int y, uint8_t color);

/* 获取点颜色 */
uint8_t gfx_getpixel(int x, int y);

/* 画水平线 */
void gfx_hline(int x, int y, int w, uint8_t color);

/* 画垂直线 */
void gfx_vline(int x, int y, int h, uint8_t color);

/* 画矩形边框 */
void gfx_rect(int x, int y, int w, int h, uint8_t color);

/* 填充矩形 */
void gfx_fillrect(int x, int y, int w, int h, uint8_t color);

/* 画直线 (Bresenham) */
void gfx_line(int x0, int y0, int x1, int y1, uint8_t color);

/* 清屏 */
void gfx_clear(uint8_t color);

/* 绘制字符 (8x8字体) */
void gfx_putchar(int x, int y, char c, uint8_t color);

/* 绘制字符串 */
void gfx_puts(int x, int y, const char *s, uint8_t color);

/* 设置调色板 */
void gfx_set_palette(uint8_t index, uint8_t r, uint8_t g, uint8_t b);

/* 获取帧缓冲区指针 */
uint8_t *gfx_get_framebuffer(void);

#endif /* VGA_GFX_H */
