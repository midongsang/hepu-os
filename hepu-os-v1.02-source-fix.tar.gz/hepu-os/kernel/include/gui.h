#ifndef GUI_H
#define GUI_H

#include <stdint.h>

/* 初始化GUI桌面 */
void gui_init(void);

/* 绘制桌面 */
void gui_draw_desktop(void);

/* 绘制鼠标指针 */
void gui_draw_cursor(int x, int y);

/* 绘制窗口 */
void gui_draw_window(int x, int y, int w, int h, const char *title);

/* 绘制按钮 */
void gui_draw_button(int x, int y, int w, int h, const char *label, int pressed);

/* GUI主循环 (处理鼠标和重绘) */
void gui_main_loop(void);

#endif /* GUI_H */
