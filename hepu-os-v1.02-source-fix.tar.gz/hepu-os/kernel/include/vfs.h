#ifndef VFS_H
#define VFS_H

#include <stdint.h>
#include <stddef.h>

#define VFS_MAX_NAME 64
#define VFS_MAX_PATH 256
#define VFS_MAX_FILES 64
#define VFS_MAX_FDS 32

/* 文件类型 */
typedef enum {
    VFS_REGULAR = 0,
    VFS_DIRECTORY,
    VFS_CHAR_DEVICE,
    VFS_BLOCK_DEVICE,
    VFS_FIFO,
    VFS_SYMLINK
} vfs_node_type_t;

/* 打开标志 */
#define VFS_O_RDONLY  0x00
#define VFS_O_WRONLY  0x01
#define VFS_O_RDWR    0x02
#define VFS_O_APPEND  0x08
#define VFS_O_CREAT   0x40
#define VFS_O_TRUNC   0x200

/* seek 起始位置 */
#define VFS_SEEK_SET 0
#define VFS_SEEK_CUR 1
#define VFS_SEEK_END 2

/* 前向声明 */
struct vfs_node;
typedef struct vfs_node vfs_node_t;

/* 文件操作接口 */
typedef struct {
    int (*open)(vfs_node_t *node, int flags);
    int (*close)(vfs_node_t *node);
    int (*read)(vfs_node_t *node, uint32_t offset, void *buf, uint32_t size);
    int (*write)(vfs_node_t *node, uint32_t offset, const void *buf, uint32_t size);
    int (*ioctl)(vfs_node_t *node, uint32_t cmd, uint32_t arg);
} vfs_file_ops_t;

/* VFS 节点 (inode) */
struct vfs_node {
    char name[VFS_MAX_NAME];
    vfs_node_type_t type;
    uint32_t size;
    uint32_t inode_num;
    uint32_t permissions;
    uint32_t uid;
    uint32_t gid;
    uint32_t links;

    /* 子节点 (目录用) */
    vfs_node_t *children;
    vfs_node_t *next;       /* 同级链表 */
    vfs_node_t *parent;

    /* 文件操作 */
    vfs_file_ops_t *ops;

    /* 私有数据 (文件系统特定) */
    void *private_data;
};

/* 打开的文件描述符 */
typedef struct {
    int used;
    vfs_node_t *node;
    int flags;
    uint32_t position;
} vfs_fd_t;

/* 初始化VFS */
void vfs_init(void);

/* 创建节点 */
vfs_node_t *vfs_create_node(const char *name, vfs_node_type_t type);

/* 添加子节点 */
void vfs_add_child(vfs_node_t *parent, vfs_node_t *child);

/* 查找节点 (按路径) */
vfs_node_t *vfs_find(const char *path);

/* 获取根节点 */
vfs_node_t *vfs_get_root(void);

/* 挂载文件系统到路径 */
int vfs_mount(const char *path, vfs_node_t *root);

/* 文件操作 (通过文件描述符) */
int vfs_open(const char *path, int flags);
int vfs_close(int fd);
int vfs_read(int fd, void *buf, uint32_t size);
int vfs_write(int fd, const void *buf, uint32_t size);
int vfs_lseek(int fd, int32_t offset, int whence);
int vfs_fsize(int fd);

/* 目录操作 */
typedef struct {
    char name[VFS_MAX_NAME];
    vfs_node_type_t type;
    uint32_t size;
} vfs_dirent_t;

int vfs_readdir(const char *path, vfs_dirent_t *buf, int max_entries);
int vfs_readdir_fd(int fd, vfs_dirent_t *buf, int max_entries);

/* === V0.40 新增：完整文件操作 === */

/* 文件状态结构 */
typedef struct {
    uint32_t inode;
    uint32_t type;
    uint32_t size;
    uint32_t permissions;
    uint32_t uid;
    uint32_t gid;
    uint32_t links;
} vfs_stat_t;

/* 目录/文件操作 */
int vfs_mkdir(const char *path);
int vfs_rmdir(const char *path);
int vfs_unlink(const char *path);
int vfs_rename(const char *old_path, const char *new_path);
int vfs_stat(const char *path, vfs_stat_t *buf);
int vfs_fstat(int fd, vfs_stat_t *buf);
int vfs_access(const char *path);

/* 文件描述符操作 */
int vfs_dup(int oldfd);
int vfs_dup2(int oldfd, int newfd);

#endif /* VFS_H */
