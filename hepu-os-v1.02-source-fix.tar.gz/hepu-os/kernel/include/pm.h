#ifndef PM_H
#define PM_H

#include <stdint.h>

/* 电源状态 */
typedef enum {
    PM_STATE_ON = 0,      /* 正常运行 */
    PM_STATE_IDLE,        /* 空闲 (CPU暂停) */
    PM_STATE_STANDBY,     /* 待机 (内存自刷新) */
    PM_STATE_SUSPEND,     /* 挂起到内存 (S3) */
    PM_STATE_HIBERNATE,   /* 挂起到磁盘 (S4) */
    PM_STATE_OFF,         /* 关机 (S5) */
} pm_state_t;

/* 电源事件 */
typedef enum {
    PM_EVENT_WAKEUP = 0,
    PM_EVENT_SLEEP,
    PM_EVENT_BATTERY_LOW,
    PM_EVENT_BATTERY_CRITICAL,
    PM_EVENT_AC_CONNECT,
    PM_EVENT_AC_DISCONNECT,
} pm_event_t;

/* 电池状态 */
typedef struct {
    int present;
    int charging;
    int capacity;       /* 百分比 0-100 */
    int voltage;        /* mV */
    int current;        /* mA */
    int temperature;    /* 0.1°C */
    int design_capacity; /* mAh */
    int full_capacity;   /* mAh */
    int remaining_capacity; /* mAh */
} pm_battery_t;

/* 电源管理回调 */
typedef void (*pm_callback_t)(pm_event_t event);

/* 初始化电源管理 */
void pm_init(void);

/* 设置电源状态 */
int pm_set_state(pm_state_t state);

/* 获取当前电源状态 */
pm_state_t pm_get_state(void);

/* 注册电源事件回调 */
void pm_register_callback(pm_callback_t cb);

/* 唤醒系统 */
void pm_wakeup(void);

/* 进入休眠 */
void pm_sleep(pm_state_t state);

/* 获取电池状态 */
int pm_get_battery(pm_battery_t *battery);

/* 更新电池状态 (由驱动调用) */
void pm_update_battery(pm_battery_t *battery);

/* CPU空闲 (HLT) */
void pm_cpu_idle(void);

/* 检查是否应该进入省电模式 */
int pm_should_sleep(void);

/* 设置自动休眠超时 (秒) */
void pm_set_sleep_timeout(int seconds);

/* 获取自动休眠超时 */
int pm_get_sleep_timeout(void);

/* 重置空闲计时器 */
void pm_reset_idle_timer(void);

#endif /* PM_H */
