#ifndef WM_H
#define WM_H

#include <stdint.h>

#define WM_MAX_WINDOWS 8
#define WM_MAX_WIDGETS 16
#define WM_MAX_TITLE 32

/* 事件类型 */
typedef enum {
    WM_EVENT_MOUSE_DOWN = 0,
    WM_EVENT_MOUSE_UP,
    WM_EVENT_MOUSE_MOVE,
    WM_EVENT_KEY_DOWN,
    WM_EVENT_KEY_UP,
    WM_EVENT_REDRAW,
    WM_EVENT_CLOSE
} wm_event_type_t;

/* 鼠标按钮 */
#define WM_MOUSE_LEFT   0x01
#define WM_MOUSE_RIGHT  0x02
#define WM_MOUSE_MIDDLE 0x04

/* 事件结构 */
typedef struct {
    wm_event_type_t type;
    int x, y;           /* 鼠标位置 */
    uint8_t button;     /* 鼠标按钮 */
    char key;           /* 键盘字符 */
    int keycode;        /* 键盘扫描码 */
} wm_event_t;

/* 控件类型 */
typedef enum {
    WM_WIDGET_BUTTON = 0,
    WM_WIDGET_LABEL,
    WM_WIDGET_INPUT
} wm_widget_type_t;

/* 前向声明 */
struct wm_window;
typedef struct wm_window wm_window_t;

/* 控件结构 */
typedef struct wm_widget {
    wm_widget_type_t type;
    int x, y, w, h;
    char text[32];
    int pressed;        /* 按钮按下状态 */
    int focused;        /* 输入框焦点 */
    /* 回调 */
    void (*on_click)(wm_window_t *win, struct wm_widget *widget);
    void *user_data;
} wm_widget_t;

/* 窗口事件回调 */
typedef void (*wm_event_cb_t)(wm_window_t *win, wm_event_t *event);

/* 窗口结构 */
struct wm_window {
    int used;
    int x, y, w, h;
    char title[WM_MAX_TITLE];
    uint8_t bg_color;
    uint8_t title_color;
    uint8_t title_text_color;

    /* 控件 */
    wm_widget_t widgets[WM_MAX_WIDGETS];
    int widget_count;

    /* 事件回调 */
    wm_event_cb_t event_cb;

    /* 拖动状态 */
    int dragging;
    int drag_offset_x, drag_offset_y;

    /* Z-order (越大越靠前) */
    int z_order;

    /* 窗口状态 */
    int visible;
    int minimized;

    void *user_data;
};

/* 初始化窗口管理器 */
void wm_init(void);

/* 创建窗口 */
wm_window_t *wm_create_window(const char *title, int x, int y, int w, int h);

/* 销毁窗口 */
void wm_destroy_window(wm_window_t *win);

/* 添加控件 */
wm_widget_t *wm_add_button(wm_window_t *win, int x, int y, int w, int h,
                            const char *label, void (*on_click)(wm_window_t*, wm_widget_t*));
wm_widget_t *wm_add_label(wm_window_t *win, int x, int y, const char *text);
wm_widget_t *wm_add_input(wm_window_t *win, int x, int y, int w, const char *text);

/* 绘制所有窗口 */
void wm_draw_all(void);

/* 绘制单个窗口 */
void wm_draw_window(wm_window_t *win);

/* 处理事件 */
void wm_handle_event(wm_event_t *event);

/* 查找指定位置的窗口 */
wm_window_t *wm_window_at(int x, int y);

/* 将窗口置顶 */
void wm_bring_to_front(wm_window_t *win);

/* 主循环 */
void wm_main_loop(void);

/* 获取桌面窗口 */
wm_window_t *wm_get_desktop(void);

#endif /* WM_H */
