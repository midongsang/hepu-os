/* ============================================================================
 * 赫普OS - 桌面环境
 * 创建示例窗口、关于对话框、应用启动器
 * ========================================================================== */

#include <stdint.h>
#include "wm.h"
#include "vga_gfx.h"
#include "vga.h"
#include "string.h"

static wm_window_t *about_win = NULL;
static wm_window_t *launcher_win = NULL;
static wm_window_t *terminal_win = NULL;

/* 关于窗口的关闭按钮回调 */
static void on_close_about(wm_window_t *win, wm_widget_t *wgt)
{
    (void)wgt;
    wm_destroy_window(win);
}

/* 启动器按钮回调 */
static void on_launch_hello(wm_window_t *win, wm_widget_t *wgt)
{
    (void)win; (void)wgt;
    /* 创建一个"运行中"提示窗口 */
    wm_window_t *run = wm_create_window("Running", 100, 60, 140, 60);
    if (run) {
        wm_add_label(run, 10, 20, "hello.hug 启动中...");
        wm_add_button(run, 40, 40, 60, 14, "OK", on_close_about);
        wm_bring_to_front(run);
    }
}

static void on_launch_terminal(wm_window_t *win, wm_widget_t *wgt)
{
    (void)win; (void)wgt;
    if (!terminal_win || !terminal_win->used) {
        terminal_win = wm_create_window("Terminal", 60, 40, 200, 120);
        if (terminal_win) {
            wm_add_label(terminal_win, 8, 16, "HEPU OS Terminal v0.8");
            wm_add_label(terminal_win, 8, 28, "$ ");
            wm_add_label(terminal_win, 8, 40, "Type 'help' for commands");
            wm_add_label(terminal_win, 8, 52, "$ ");
            wm_add_label(terminal_win, 8, 64, "ls -la /");
            wm_add_label(terminal_win, 8, 76, "drwxr-xr-x dev");
            wm_add_label(terminal_win, 8, 88, "drwxr-xr-x initrd");
            wm_add_label(terminal_win, 8, 100, "$ _");
        }
    }
    if (terminal_win) wm_bring_to_front(terminal_win);
}

static void on_launch_about(wm_window_t *win, wm_widget_t *wgt)
{
    (void)win; (void)wgt;
    if (!about_win || !about_win->used) {
        about_win = wm_create_window("About HEPU OS", 70, 30, 180, 130);
        if (about_win) {
            wm_add_label(about_win, 50, 18, "HEPU HYPER EVOLVE OS");
            wm_add_label(about_win, 60, 30, "Version 0.8 Prototype");
            wm_add_label(about_win, 30, 44, "Microkernel + .hug apps");
            wm_add_label(about_win, 30, 54, "Open Source: GPLv3");
            wm_add_label(about_win, 30, 64, "Window Manager: WM v1");
            wm_add_label(about_win, 30, 74, "Graphics: VGA 320x200");
            wm_add_label(about_win, 30, 84, "Input: PS/2 Mouse+Kbd");
            wm_add_label(about_win, 40, 100, "System归人, Data归己");
            wm_add_button(about_win, 60, 110, 60, 14, "Close", on_close_about);
        }
    }
    if (about_win) wm_bring_to_front(about_win);
}

/* 启动器窗口的关闭 */
static void on_close_launcher(wm_window_t *win, wm_widget_t *wgt)
{
    (void)wgt;
    wm_destroy_window(win);
}

void desktop_init(void)
{
    /* 创建应用启动器窗口 */
    launcher_win = wm_create_window("App Launcher", 50, 20, 220, 150);
    if (launcher_win) {
        wm_add_label(launcher_win, 10, 16, "Select an application:");

        wm_add_button(launcher_win, 20, 32, 80, 18, "Hello", on_launch_hello);
        wm_add_button(launcher_win, 120, 32, 80, 18, "Terminal", on_launch_terminal);
        wm_add_button(launcher_win, 20, 56, 80, 18, "About", on_launch_about);
        wm_add_button(launcher_win, 120, 56, 80, 18, "Files", on_launch_about);
        wm_add_button(launcher_win, 20, 80, 80, 18, "Settings", on_launch_about);
        wm_add_button(launcher_win, 120, 80, 80, 18, "Browser", on_launch_about);

        wm_add_label(launcher_win, 10, 108, "Click titlebar to drag");
        wm_add_label(launcher_win, 10, 118, "Click X to close");
        wm_add_button(launcher_win, 70, 130, 80, 14, "Close", on_close_launcher);
    }

    vga_puts("[DESKTOP] 桌面环境初始化完成\n");
}
