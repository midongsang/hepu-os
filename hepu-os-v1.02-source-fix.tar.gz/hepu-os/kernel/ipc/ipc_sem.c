/* ============================================================================
 * 赫普OS - IPC信号量 (V0.96新增)
 * 实现：System V风格信号量，支持PV操作、二元/计数信号量
 * ========================================================================== */
#include <stdint.h>
#include <stddef.h>
#include "ipc_sem.h"
#include "vga.h"
#include "string.h"

#define SEM_MAX 32
#define SEM_MAGIC 0x53454D41  /* "SEMA" */

typedef struct {
    uint32_t magic;
    uint32_t key;
    int32_t  value;
    uint32_t owner_pid;
    uint8_t  used;
    uint8_t  binary;       /* 1=二元信号量, 0=计数信号量 */
    uint32_t wait_count;   /* 等待进程数 */
    uint32_t op_count;     /* 操作计数（统计用） */
} semaphore_t;

static semaphore_t semaphores[SEM_MAX];
static uint32_t sem_count = 0;

void ipc_sem_init(void)
{
    memset(semaphores, 0, sizeof(semaphores));
    sem_count = 0;
    vga_puts("[IPC-SEM] 信号量子系统初始化完成\n");
}

/* 创建或获取信号量 */
int ipc_semget(uint32_t key, int32_t init_value)
{
    /* 查找已存在的 */
    for (int i = 0; i < SEM_MAX; i++) {
        if (semaphores[i].used && semaphores[i].key == key) {
            return i;
        }
    }
    /* 创建新的 */
    for (int i = 0; i < SEM_MAX; i++) {
        if (!semaphores[i].used) {
            semaphores[i].magic = SEM_MAGIC;
            semaphores[i].key = key;
            semaphores[i].value = init_value;
            semaphores[i].owner_pid = 0;
            semaphores[i].used = 1;
            semaphores[i].binary = (init_value <= 1) ? 1 : 0;
            semaphores[i].wait_count = 0;
            semaphores[i].op_count = 0;
            sem_count++;
            return i;
        }
    }
    return -1;
}

/* P操作（等待/减1） */
int ipc_sem_wait(int sem_id)
{
    if (sem_id < 0 || sem_id >= SEM_MAX || !semaphores[sem_id].used) return -1;
    if (semaphores[sem_id].magic != SEM_MAGIC) return -1;

    /* 非阻塞尝试：如果value>0，直接减1 */
    if (semaphores[sem_id].value > 0) {
        semaphores[sem_id].value--;
        semaphores[sem_id].op_count++;
        return 0;
    }
    /* value==0，需要等待 */
    semaphores[sem_id].wait_count++;
    /* 在实际系统中这里会阻塞进程，简化实现返回-2表示需要等待 */
    return -2;
}

/* 非阻塞P操作 */
int ipc_sem_trywait(int sem_id)
{
    if (sem_id < 0 || sem_id >= SEM_MAX || !semaphores[sem_id].used) return -1;
    if (semaphores[sem_id].value > 0) {
        semaphores[sem_id].value--;
        semaphores[sem_id].op_count++;
        return 0;
    }
    return -1;  /* 会阻塞 */
}

/* V操作（释放/加1） */
int ipc_sem_post(int sem_id)
{
    if (sem_id < 0 || sem_id >= SEM_MAX || !semaphores[sem_id].used) return -1;
    if (semaphores[sem_id].magic != SEM_MAGIC) return -1;

    if (semaphores[sem_id].binary) {
        /* 二元信号量：value最大为1 */
        if (semaphores[sem_id].value >= 1) return -1;
    }
    semaphores[sem_id].value++;
    semaphores[sem_id].op_count++;
    if (semaphores[sem_id].wait_count > 0) {
        semaphores[sem_id].wait_count--;
    }
    return 0;
}

/* 获取信号量当前值 */
int ipc_sem_getvalue(int sem_id, int32_t *value)
{
    if (sem_id < 0 || sem_id >= SEM_MAX || !semaphores[sem_id].used) return -1;
    if (value) *value = semaphores[sem_id].value;
    return 0;
}

/* 删除信号量 */
int ipc_sem_remove(int sem_id)
{
    if (sem_id < 0 || sem_id >= SEM_MAX || !semaphores[sem_id].used) return -1;
    semaphores[sem_id].used = 0;
    semaphores[sem_id].magic = 0;
    sem_count--;
    return 0;
}

/* 信号量统计 */
void ipc_sem_stats(uint32_t *total, uint32_t *used)
{
    if (total) *total = SEM_MAX;
    if (used) *used = sem_count;
}
