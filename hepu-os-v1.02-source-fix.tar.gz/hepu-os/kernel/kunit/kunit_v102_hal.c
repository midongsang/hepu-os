/* ============================================================================
 * 赫普OS - V1.02 HAL侧新模块测试
 * 覆盖：IPC权限检查(ipc_perm)、ACPI、设备热插拔(hotplug)
 * ========================================================================== */

#include <stdint.h>
#include "kunit.h"
#include "vga.h"
#include "string.h"
#include "ipc_perm.h"
#include "acpi.h"
#include "hotplug.h"

/* === IPC权限检查测试 === */

static kunit_result_t test_ipc_perm_register(void)
{
    /* 注册/注销/重复注册 */
    KUNIT_ASSERT_EQ(ipc_perm_register(5, 100, IPC_OBJ_QUEUE, 0x01, 0x01), 0,
                    "注册队列权限");
    KUNIT_ASSERT_EQ(ipc_perm_register(5, 101, IPC_OBJ_PIPE, 0x01, 0x01), 0,
                    "注册管道权限");
    /* 重复注册同一对象返回-3 */
    KUNIT_ASSERT_EQ(ipc_perm_register(5, 100, IPC_OBJ_QUEUE, 0x01, 0x01), -3,
                    "重复注册返回-3");

    /* 所有者查询 */
    uint32_t owner = 0;
    KUNIT_ASSERT_EQ(ipc_perm_get_owner(100, IPC_OBJ_QUEUE, &owner), 0,
                    "查询所有者成功");
    KUNIT_ASSERT_EQ(owner, 5, "所有者PID=5");

    /* 注销 */
    KUNIT_ASSERT_EQ(ipc_perm_unregister(100, IPC_OBJ_QUEUE), 0, "注销成功");
    KUNIT_ASSERT_EQ(ipc_perm_unregister(100, IPC_OBJ_QUEUE), -1, "重复注销失败");
    ipc_perm_unregister(101, IPC_OBJ_PIPE);
    return KUNIT_PASS;
}

static kunit_result_t test_ipc_perm_check(void)
{
    /* 所有者访问 */
    ipc_perm_register(5, 200, IPC_OBJ_QUEUE, 0x01, 0x01);
    KUNIT_ASSERT_EQ(ipc_perm_check(5, 200, IPC_OBJ_QUEUE, IPC_OP_SEND, 1), 1,
                    "所有者允许写");

    /* 内核级进程放行 */
    KUNIT_ASSERT_EQ(ipc_perm_check(1, 200, IPC_OBJ_QUEUE, IPC_OP_RECV, 0), 1,
                    "内核级进程放行");

    /* 受信对象放行 */
    KUNIT_ASSERT_EQ(ipc_perm_set_trusted(200, IPC_OBJ_QUEUE, 1), 0, "设受信");
    KUNIT_ASSERT_EQ(ipc_perm_check(20, 200, IPC_OBJ_QUEUE, IPC_OP_SEND, 1), 1,
                    "受信对象任何进程可访问");
    ipc_perm_unregister(200, IPC_OBJ_QUEUE);

    /* 未注册对象：创建放行 */
    KUNIT_ASSERT_EQ(ipc_perm_check(10, 999, IPC_OBJ_QUEUE, IPC_OP_CREATE, 0), 1,
                    "创建操作放行");
    return KUNIT_PASS;
}

static kunit_result_t test_ipc_perm_stats(void)
{
    uint32_t entries, denied;
    ipc_perm_stats(&entries, &denied);
    KUNIT_ASSERT(entries <= 32, "权限条目数不超上限");
    KUNIT_ASSERT(denied <= 0xFFFFFF, "拒绝计数在合理范围");
    return KUNIT_PASS;
}

/* === ACPI测试 === */

static kunit_result_t test_acpi_struct_sizes(void)
{
    /* ACPI规范定义的结构大小 */
    KUNIT_ASSERT_EQ(sizeof(acpi_sdt_header_t), 36, "SDT表头=36字节");
    KUNIT_ASSERT_EQ(sizeof(acpi_rsdp_t), 36, "RSDP ACPI2.0=36字节");
    return KUNIT_PASS;
}

static kunit_result_t test_acpi_parse_null(void)
{
    /* 空RSDP必须安全返回（不崩溃） */
    KUNIT_ASSERT_EQ(acpi_parse_rsdp(0), -1, "空RSDP返回-1");
    return KUNIT_PASS;
}

static kunit_result_t test_acpi_get_table_initial(void)
{
    /* 未探测硬件时查询返回-1或不崩溃 */
    acpi_sdt_t t;
    int r = acpi_get_table(ACPI_TABLE_FADT, &t);
    KUNIT_ASSERT(r == -1 || r == 0, "查询FADT不崩溃");
    return KUNIT_PASS;
}

/* === 设备热插拔测试 === */

static uint32_t hotplug_cb_count = 0;
static uint32_t hotplug_cb_last_type = 0;

static void hotplug_test_cb(uint8_t bus, const char *name, uint32_t dev_id,
                            uint8_t event_type, void *data)
{
    hotplug_cb_count++;
    hotplug_cb_last_type = event_type;
    (void)bus; (void)name; (void)dev_id; (void)data;
}

static kunit_result_t test_hotplug_callback(void)
{
    hotplug_cb_count = 0;
    int h = hotplug_register_callback(hotplug_test_cb, NULL,
                                      (1u << HOTPLUG_BUS_USB));
    KUNIT_ASSERT(h >= 0, "注册回调成功");

    /* 通知USB总线插入，回调应触发 */
    KUNIT_ASSERT_EQ(hotplug_notify_insert(HOTPLUG_BUS_USB, "usb_test", 1), 0,
                    "USB插入通知成功");
    KUNIT_ASSERT_EQ(hotplug_cb_count, 1, "回调触发1次");
    KUNIT_ASSERT_EQ(hotplug_cb_last_type, HOTPLUG_EVT_INSERT, "插入事件类型");

    /* 通知PCI总线（未监听），回调不应触发 */
    hotplug_cb_count = 0;
    KUNIT_ASSERT_EQ(hotplug_notify_remove(HOTPLUG_BUS_PCI, "pci_test", 2), 0,
                    "PCI移除通知成功");
    KUNIT_ASSERT_EQ(hotplug_cb_count, 0, "未监听总线不触发回调");

    hotplug_unregister_callback(h);
    return KUNIT_PASS;
}

static kunit_result_t test_hotplug_stats(void)
{
    uint32_t inserts, removes, pending;
    hotplug_stats(&inserts, &removes, &pending);
    KUNIT_ASSERT(inserts <= 0xFFFFFF, "插入计数在合理范围");
    KUNIT_ASSERT(removes <= 0xFFFFFF, "移除计数在合理范围");
    KUNIT_ASSERT(pending <= 32, "事件队列不超过上限");
    return KUNIT_PASS;
}

/* === 测试套件 === */
static const kunit_test_t v102_hal_tests[] = {
    {"权限注册/注销", test_ipc_perm_register, "ipc_perm"},
    {"权限检查", test_ipc_perm_check, "ipc_perm"},
    {"权限统计", test_ipc_perm_stats, "ipc_perm"},
    {"ACPI结构大小", test_acpi_struct_sizes, "acpi"},
    {"ACPI空指针保护", test_acpi_parse_null, "acpi"},
    {"ACPI表查询", test_acpi_get_table_initial, "acpi"},
    {"热插拔回调", test_hotplug_callback, "hotplug"},
    {"热插拔统计", test_hotplug_stats, "hotplug"},
};
static const kunit_suite_t kunit_v102_hal_suite = {
    "V1.02 HAL侧模块", v102_hal_tests, 8
};

void kunit_v102_hal_register(void)
{
    kunit_register_suite(&kunit_v102_hal_suite);
    vga_puts("[KUNIT] V1.02 HAL侧模块测试套件已注册 (8用例)\n");
}
