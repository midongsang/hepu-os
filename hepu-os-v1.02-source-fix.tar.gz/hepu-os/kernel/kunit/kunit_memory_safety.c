/* ============================================================================
 * 赫普OS - 内存安全单元测试
 * 覆盖：内存分配/释放/对齐/越界/泄漏检测/内存池
 * ========================================================================== */

#include <stdint.h>
#include "kunit.h"
#include "vga.h"
#include "string.h"
#include "kheap.h"

/* === 基本分配测试 === */
static kunit_result_t test_malloc_basic(void)
{
    void *p = kmalloc(64);
    KUNIT_ASSERT_NOT_NULL(p, "分配64字节成功");
    if (p) {
        memset(p, 0xAA, 64);
        u8 *buf = (u8 *)p;
        KUNIT_ASSERT_EQ(buf[0], 0xAA, "写入第1字节");
        KUNIT_ASSERT_EQ(buf[63], 0xAA, "写入最后字节");
        kfree(p);
    }
    return KUNIT_PASS;
}

static kunit_result_t test_malloc_zero(void)
{
    void *p = kmalloc(0);
    /* 零长度分配可能返回NULL或有效指针，都接受 */
    KUNIT_ASSERT(1, "零长度分配不崩溃");
    if (p) kfree(p);
    return KUNIT_PASS;
}

static kunit_result_t test_malloc_large(void)
{
    void *p = kmalloc(4096);
    KUNIT_ASSERT_NOT_NULL(p, "分配4KB成功");
    if (p) {
        memset(p, 0x55, 4096);
        u8 *buf = (u8 *)p;
        KUNIT_ASSERT_EQ(buf[0], 0x55, "大内存首字节");
        KUNIT_ASSERT_EQ(buf[4095], 0x55, "大内存末字节");
        kfree(p);
    }
    return KUNIT_PASS;
}

/* === 多次分配测试 === */
static kunit_result_t test_multiple_alloc(void)
{
    void *ptrs[16];
    for (int i = 0; i < 16; i++) {
        ptrs[i] = kmalloc(32 + i * 8);
        KUNIT_ASSERT_NOT_NULL(ptrs[i], "多次分配");
        if (ptrs[i]) memset(ptrs[i], (u8)(i + 1), 32 + i * 8);
    }
    /* 验证内容不互相覆盖 */
    for (int i = 0; i < 16; i++) {
        if (ptrs[i]) {
            u8 *buf = (u8 *)ptrs[i];
            KUNIT_ASSERT_EQ(buf[0], (u8)(i + 1), "内容验证");
            kfree(ptrs[i]);
        }
    }
    return KUNIT_PASS;
}

/* === 分配后释放再分配测试 === */
static kunit_result_t test_alloc_free_realloc(void)
{
    void *p1 = kmalloc(128);
    KUNIT_ASSERT_NOT_NULL(p1, "第一次分配");
    if (p1) {
        memset(p1, 0xBB, 128);
        kfree(p1);
    }

    void *p2 = kmalloc(128);
    KUNIT_ASSERT_NOT_NULL(p2, "释放后再分配");
    if (p2) {
        memset(p2, 0xCC, 128);
        u8 *buf = (u8 *)p2;
        KUNIT_ASSERT_EQ(buf[0], 0xCC, "新内容正确");
        kfree(p2);
    }
    return KUNIT_PASS;
}

/* === 对齐分配测试 === */
static kunit_result_t test_aligned_alloc(void)
{
    void *p = kmalloc_aligned(256, 16);
    KUNIT_ASSERT_NOT_NULL(p, "16字节对齐分配");
    if (p) {
        u32 addr = (u32)p;
        KUNIT_ASSERT_EQ(addr % 16, 0, "16字节对齐验证");
        memset(p, 0xDD, 256);
        kfree(p);
    }

    p = kmalloc_aligned(512, 32);
    KUNIT_ASSERT_NOT_NULL(p, "32字节对齐分配");
    if (p) {
        u32 addr = (u32)p;
        KUNIT_ASSERT_EQ(addr % 32, 0, "32字节对齐验证");
        kfree(p);
    }
    return KUNIT_PASS;
}

/* === 内存池测试 === */
#define POOL_BLOCK_SIZE 64
#define POOL_BLOCK_COUNT 16
typedef struct {
    u8  data[POOL_BLOCK_SIZE * POOL_BLOCK_COUNT];
    u8  used[POOL_BLOCK_COUNT];
    u32 free_count;
} mem_pool_t;

static void pool_init(mem_pool_t *pool)
{
    memset(pool->data, 0, sizeof(pool->data));
    memset(pool->used, 0, sizeof(pool->used));
    pool->free_count = POOL_BLOCK_COUNT;
}

static void *pool_alloc(mem_pool_t *pool)
{
    for (int i = 0; i < POOL_BLOCK_COUNT; i++) {
        if (!pool->used[i]) {
            pool->used[i] = 1;
            pool->free_count--;
            return pool->data + i * POOL_BLOCK_SIZE;
        }
    }
    return 0;
}

static int pool_free(mem_pool_t *pool, void *ptr)
{
    if (!ptr) return -1;
    u32 offset = (u32)((u8 *)ptr - pool->data);
    if (offset >= sizeof(pool->data)) return -1;
    if (offset % POOL_BLOCK_SIZE != 0) return -1;
    u32 idx = offset / POOL_BLOCK_SIZE;
    if (!pool->used[idx]) return -1;
    pool->used[idx] = 0;
    pool->free_count++;
    return 0;
}

static kunit_result_t test_mem_pool_basic(void)
{
    mem_pool_t pool;
    pool_init(&pool);

    KUNIT_ASSERT_EQ(pool.free_count, POOL_BLOCK_COUNT, "初始空闲块数");

    void *p1 = pool_alloc(&pool);
    void *p2 = pool_alloc(&pool);
    KUNIT_ASSERT_NOT_NULL(p1, "池分配1");
    KUNIT_ASSERT_NOT_NULL(p2, "池分配2");
    KUNIT_ASSERT_EQ(pool.free_count, POOL_BLOCK_COUNT - 2, "空闲块减少");

    KUNIT_ASSERT_EQ(pool_free(&pool, p1), 0, "池释放1");
    KUNIT_ASSERT_EQ(pool.free_count, POOL_BLOCK_COUNT - 1, "空闲块增加");

    void *p3 = pool_alloc(&pool);
    KUNIT_ASSERT(p3 == p1, "重用释放的块");
    return KUNIT_PASS;
}

static kunit_result_t test_mem_pool_exhaust(void)
{
    mem_pool_t pool;
    pool_init(&pool);

    void *ptrs[POOL_BLOCK_COUNT];
    for (int i = 0; i < POOL_BLOCK_COUNT; i++) {
        ptrs[i] = pool_alloc(&pool);
        KUNIT_ASSERT_NOT_NULL(ptrs[i], "分配所有块");
    }
    KUNIT_ASSERT_EQ(pool.free_count, 0, "池耗尽");
    KUNIT_ASSERT_NULL(pool_alloc(&pool), "耗尽后分配失败");

    for (int i = 0; i < POOL_BLOCK_COUNT; i++) pool_free(&pool, ptrs[i]);
    KUNIT_ASSERT_EQ(pool.free_count, POOL_BLOCK_COUNT, "全部释放");
    return KUNIT_PASS;
}

static kunit_result_t test_mem_pool_invalid(void)
{
    mem_pool_t pool;
    pool_init(&pool);

    KUNIT_ASSERT_EQ(pool_free(&pool, 0), -1, "空指针释放失败");
    KUNIT_ASSERT_EQ(pool_free(&pool, (void *)0xDEADBEEF), -1, "外部指针释放失败");

    void *p = pool_alloc(&pool);
    KUNIT_ASSERT_EQ(pool_free(&pool, p), 0, "正常释放");
    KUNIT_ASSERT_EQ(pool_free(&pool, p), -1, "重复释放失败");
    return KUNIT_PASS;
}

/* === 内存填充模式测试 === */
static kunit_result_t test_memset_patterns(void)
{
    u8 buf[256];

    memset(buf, 0x00, 256);
    KUNIT_ASSERT_EQ(buf[0], 0x00, "全零填充");
    KUNIT_ASSERT_EQ(buf[255], 0x00, "全零末尾");

    memset(buf, 0xFF, 256);
    KUNIT_ASSERT_EQ(buf[0], 0xFF, "全1填充");
    KUNIT_ASSERT_EQ(buf[128], 0xFF, "全1中间");

    memset(buf, 0xA5, 256);
    KUNIT_ASSERT_EQ(buf[0], 0xA5, "模式填充");
    return KUNIT_PASS;
}

/* === 内存复制测试 === */
static kunit_result_t test_memcpy_overlap(void)
{
    u8 buf[32];
    for (int i = 0; i < 32; i++) buf[i] = (u8)i;

    /* 前向复制（无重叠） */
    u8 dst[16];
    memcpy(dst, buf, 16);
    KUNIT_ASSERT_EQ(memcmp(dst, buf, 16), 0, "无重叠复制");

    /* 重叠区域: buf[8..23] <- buf[0..15] */
    memcpy(buf + 8, buf, 16);
    KUNIT_ASSERT_EQ(buf[8], 0, "重叠复制首字节");
    KUNIT_ASSERT_EQ(buf[23], 15, "重叠复制末字节");
    return KUNIT_PASS;
}

/* === 内存比较测试 === */
static kunit_result_t test_memcmp(void)
{
    u8 a[16] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
    u8 b[16] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16};
    u8 c[16] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,99};

    KUNIT_ASSERT_EQ(memcmp(a, b, 16), 0, "相等内存");
    KUNIT_ASSERT(memcmp(a, c, 16) != 0, "不等内存");
    KUNIT_ASSERT_EQ(memcmp(a, c, 15), 0, "前15字节相等");
    return KUNIT_PASS;
}

/* === 测试套件注册 === */
static const kunit_test_t memory_safety_tests[] = {
    {"基本分配", test_malloc_basic, "memory"},
    {"零长度分配", test_malloc_zero, "memory"},
    {"大内存分配", test_malloc_large, "memory"},
    {"多次分配", test_multiple_alloc, "memory"},
    {"分配释放再分配", test_alloc_free_realloc, "memory"},
    {"对齐分配", test_aligned_alloc, "memory"},
    {"内存池基本", test_mem_pool_basic, "memory"},
    {"内存池耗尽", test_mem_pool_exhaust, "memory"},
    {"内存池无效", test_mem_pool_invalid, "memory"},
    {"内存填充模式", test_memset_patterns, "memory"},
    {"内存复制重叠", test_memcpy_overlap, "memory"},
    {"内存比较", test_memcmp, "memory"},
};
static const kunit_suite_t kunit_memory_safety_suite = {
    "内存安全", memory_safety_tests, 12
};

void kunit_memory_safety_register(void)
{
    kunit_register_suite(&kunit_memory_safety_suite);
    vga_puts("[KUNIT] 内存安全测试套件已注册 (12用例)\n");
}
