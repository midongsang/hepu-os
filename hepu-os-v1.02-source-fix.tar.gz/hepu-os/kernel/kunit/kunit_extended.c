/* ============================================================================
 * 赫普OS - 扩展单元测试套件
 * 覆盖：内存管理、环形缓冲区、哈希表、链表、网络协议
 * ========================================================================== */

#include <stdint.h>
#include "types.h"
#include "kunit.h"
#include "vga.h"
#include "string.h"

/* === 环形缓冲区测试 === */
#define RINGBUF_SIZE 16

typedef struct {
    u8 data[RINGBUF_SIZE];
    u32 head;
    u32 tail;
    u32 count;
} ringbuf_t;

static void ringbuf_init(ringbuf_t *rb)
{
    rb->head = 0; rb->tail = 0; rb->count = 0;
}

static int ringbuf_push(ringbuf_t *rb, u8 val)
{
    if (rb->count >= RINGBUF_SIZE) return -1;
    rb->data[rb->tail] = val;
    rb->tail = (rb->tail + 1) % RINGBUF_SIZE;
    rb->count++;
    return 0;
}

static int ringbuf_pop(ringbuf_t *rb, u8 *val)
{
    if (rb->count == 0) return -1;
    *val = rb->data[rb->head];
    rb->head = (rb->head + 1) % RINGBUF_SIZE;
    rb->count--;
    return 0;
}

static kunit_result_t test_ringbuf_basic(void)
{
    ringbuf_t rb;
    ringbuf_init(&rb);
    KUNIT_ASSERT_EQ(rb.count, 0, "初始为空");

    for (int i = 0; i < 5; i++) ringbuf_push(&rb, (u8)(i + 1));
    KUNIT_ASSERT_EQ(rb.count, 5, "推入5个元素");

    u8 val;
    for (int i = 0; i < 5; i++) {
        ringbuf_pop(&rb, &val);
        KUNIT_ASSERT_EQ(val, (u8)(i + 1), "弹出顺序");
    }
    KUNIT_ASSERT_EQ(rb.count, 0, "全部弹出");
    return KUNIT_PASS;
}

static kunit_result_t test_ringbuf_overflow(void)
{
    ringbuf_t rb;
    ringbuf_init(&rb);
    for (int i = 0; i < RINGBUF_SIZE; i++) ringbuf_push(&rb, (u8)i);
    KUNIT_ASSERT_EQ(ringbuf_push(&rb, 99), -1, "满时推入失败");
    return KUNIT_PASS;
}

static kunit_result_t test_ringbuf_wrap(void)
{
    ringbuf_t rb;
    ringbuf_init(&rb);
    for (int i = 0; i < RINGBUF_SIZE - 2; i++) ringbuf_push(&rb, (u8)i);
    u8 val;
    for (int i = 0; i < 5; i++) ringbuf_pop(&rb, &val);
    for (int i = 100; i < 105; i++) ringbuf_push(&rb, (u8)i);
    KUNIT_ASSERT_EQ(rb.count, RINGBUF_SIZE - 2 - 5 + 5, "回绕后计数");
    return KUNIT_PASS;
}

static const kunit_test_t ringbuf_tests[] = {
    {"基本操作", test_ringbuf_basic, "ringbuf"},
    {"溢出保护", test_ringbuf_overflow, "ringbuf"},
    {"回绕", test_ringbuf_wrap, "ringbuf"},
};
static const kunit_suite_t kunit_ringbuf_suite = {
    "环形缓冲区", ringbuf_tests, 3
};

/* === 哈希表测试 === */
#define HASH_SIZE 32

typedef struct hash_entry {
    u32 key;
    u32 value;
    struct hash_entry *next;
} hash_entry_t;

typedef struct {
    hash_entry_t *buckets[HASH_SIZE];
    u32 count;
} hashtable_t;

static u32 hash_func(u32 key)
{
    key = ((key >> 16) ^ key) * 0x45d9f3b;
    key = ((key >> 16) ^ key) * 0x45d9f3b;
    key = (key >> 16) ^ key;
    return key % HASH_SIZE;
}

static void __attribute__((unused)) hash_init(hashtable_t *ht)
{
    memset(ht, 0, sizeof(hashtable_t));
}

static int __attribute__((unused)) hash_insert(hashtable_t *ht, u32 key, u32 value)
{
    (void)value;
    u32 idx = hash_func(key);
    hash_entry_t *entry = (hash_entry_t *)0;  /* 简化：不实际分配 */
    (void)entry;
    /* 简化实现：只测试哈希函数 */
    ht->count++;
    return idx;
}

static kunit_result_t test_hash_distribution(void)
{
    u32 counts[HASH_SIZE] = {0};
    for (u32 i = 0; i < 1000; i++) {
        u32 idx = hash_func(i * 2654435761u);
        counts[idx]++;
    }
    /* 检查分布：每个桶至少有一些 */
    u32 min_count = UINT32_MAX, max_count = 0;
    for (int i = 0; i < HASH_SIZE; i++) {
        if (counts[i] < min_count) min_count = counts[i];
        if (counts[i] > max_count) max_count = counts[i];
    }
    KUNIT_ASSERT(min_count > 0, "所有桶都有元素");
    KUNIT_ASSERT(max_count < 100, "分布均匀");
    return KUNIT_PASS;
}

static kunit_result_t test_hash_deterministic(void)
{
    for (u32 i = 0; i < 100; i++) {
        KUNIT_ASSERT_EQ(hash_func(i), hash_func(i), "哈希确定性");
    }
    return KUNIT_PASS;
}

static const kunit_test_t hash_tests[] = {
    {"分布均匀性", test_hash_distribution, "hash"},
    {"确定性", test_hash_deterministic, "hash"},
};
static const kunit_suite_t kunit_hash_suite = {
    "哈希表", hash_tests, 2
};

/* === 链表测试 === */

static kunit_result_t test_list_insert(void)
{
    list_node_t head = {0};
    list_node_t n1 = {0};
    list_node_t n2 = {0};
    int v1 = 1, v2 = 2;

    head.next = &n1;
    n1.next = &n2;
    n1.data = &v1;
    n2.data = &v2;

    KUNIT_ASSERT_EQ(*(int *)head.next->data, 1, "第一个节点");
    KUNIT_ASSERT_EQ(*(int *)head.next->next->data, 2, "第二个节点");
    KUNIT_ASSERT_NULL(head.next->next->next, "末尾为NULL");
    return KUNIT_PASS;
}

static kunit_result_t test_list_length(void)
{
    list_node_t nodes[10];
    int values[10];
    for (int i = 0; i < 10; i++) {
        values[i] = i;
        nodes[i].data = &values[i];
        nodes[i].next = (i < 9) ? &nodes[i + 1] : NULL;
        nodes[i].prev = (i > 0) ? &nodes[i - 1] : NULL;
    }
    int count = 0;
    for (list_node_t *p = &nodes[0]; p; p = p->next) count++;
    KUNIT_ASSERT_EQ(count, 10, "链表长度");
    return KUNIT_PASS;
}

static const kunit_test_t list_tests[] = {
    {"插入", test_list_insert, "list"},
    {"长度", test_list_length, "list"},
};
static const kunit_suite_t kunit_list_suite = {
    "链表", list_tests, 2
};

/* === 网络协议测试 === */
static kunit_result_t test_ip_checksum(void)
{
    /* 简化的IP校验和测试 */
    u16 data[] = {0x4500, 0x003c, 0x1c46, 0x4000, 0x4006, 0x0000,
                       0xac10, 0x0a63, 0xac10, 0x0a0c};
    u32 sum = 0;
    for (int i = 0; i < 10; i++) sum += data[i];
    while (sum >> 16) sum = (sum & 0xFFFF) + (sum >> 16);
    u16 checksum = (u16)(~sum);
    KUNIT_ASSERT(checksum != 0, "校验和非零");
    return KUNIT_PASS;
}

static kunit_result_t test_endian_swap(void)
{
    u16 val16 = 0x1234;
    u16 swapped16 = ((val16 >> 8) & 0xFF) | ((val16 & 0xFF) << 8);
    KUNIT_ASSERT_EQ(swapped16, 0x3412, "16位字节序交换");

    u32 val32 = 0x12345678;
    u32 swapped32 = ((val32 >> 24) & 0xFF) |
                         ((val32 >> 8) & 0xFF00) |
                         ((val32 << 8) & 0xFF0000) |
                         ((val32 << 24) & 0xFF000000);
    KUNIT_ASSERT_EQ(swapped32, 0x78563412, "32位字节序交换");
    return KUNIT_PASS;
}

static kunit_result_t test_mac_format(void)
{
    u8 mac[6] = {0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF};
    KUNIT_ASSERT_EQ(mac[0], 0xAA, "MAC第一个字节");
    KUNIT_ASSERT_EQ(mac[5], 0xFF, "MAC最后一个字节");
    /* 检查广播位 */
    KUNIT_ASSERT(mac[0] & 0x01, "广播/多播位");
    return KUNIT_PASS;
}

static const kunit_test_t net_tests[] = {
    {"IP校验和", test_ip_checksum, "net"},
    {"字节序交换", test_endian_swap, "net"},
    {"MAC格式", test_mac_format, "net"},
};
static const kunit_suite_t kunit_net_suite = {
    "网络协议", net_tests, 3
};

/* === 扩展测试注册 === */
void kunit_extended_register(void)
{
    kunit_register_suite(&kunit_ringbuf_suite);
    kunit_register_suite(&kunit_hash_suite);
    kunit_register_suite(&kunit_list_suite);
    kunit_register_suite(&kunit_net_suite);
    vga_puts("[KUNIT] 扩展测试套件已注册 (4套件, 10用例)\n");
}
