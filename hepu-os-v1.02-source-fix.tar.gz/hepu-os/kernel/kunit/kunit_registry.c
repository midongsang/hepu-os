/* ============================================================================
 * 赫普OS - 测试套件统一注册
 * 从kernel.c拆分，集中管理所有KUnit测试套件注册
 * ========================================================================== */

#include <stdint.h>
#include "vga.h"

/* 所有测试套件注册函数声明 */
extern void kunit_extended_register(void);
extern void kunit_crypto_register(void);
extern void kunit_network_register(void);
extern void kunit_fs_register(void);
extern void kunit_drivers_register(void);
extern void kunit_sched_register(void);
extern void kunit_mm_register(void);
extern void kunit_ipc_register(void);
extern void kunit_irq_register(void);
extern void kunit_syscall_register(void);
extern void kunit_net_deep_register(void);
extern void kunit_crypto_deep_register(void);
extern void kunit_fs_deep_register(void);
extern void kunit_boot_register(void);
extern void kunit_drivers_deep_register(void);
extern void kunit_ds_deep_register(void);
extern void kunit_algo_register(void);
extern void kunit_concurrency_register(void);
extern void kunit_error_boundary_register(void);
extern void kunit_memory_safety_register(void);
extern void kunit_time_register(void);
extern void kunit_io_register(void);
extern void kunit_config_register(void);
extern void kunit_i18n_register(void);
extern void kunit_security_register(void);
extern void kunit_process_register(void);
extern void kunit_netsec_register(void);
extern void kunit_storage_register(void);
extern void kunit_power_register(void);

/* V1.02 新模块测试 */
extern void kunit_v102_mem_register(void);
extern void kunit_v102_hal_register(void);

/* 性能基准注册 */
extern void kbench_report_init(void);
extern void kunit_report_init(void);

void kunit_register_all_suites(void)
{
    vga_puts("[KUNIT] 开始注册测试套件...\n");

    /* V0.78 扩展测试 */
    kunit_extended_register();
    /* V0.80 加密/网络测试 */
    kunit_crypto_register();
    kunit_network_register();
    /* V0.81 文件系统测试 */
    kunit_fs_register();
    /* V0.81 测试报告 */
    kunit_report_init();
    /* V0.82 驱动测试 */
    kunit_drivers_register();
    /* V0.82 性能报告 */
    kbench_report_init();
    /* V0.83 调度器/内存测试 */
    kunit_sched_register();
    kunit_mm_register();
    /* V0.84 IPC/中断测试 */
    kunit_ipc_register();
    kunit_irq_register();
    /* V0.85 系统调用/网络深度测试 */
    kunit_syscall_register();
    kunit_net_deep_register();
    /* V0.86 加密/文件系统深度测试 */
    kunit_crypto_deep_register();
    kunit_fs_deep_register();
    /* V0.87 引导/驱动深度测试 */
    kunit_boot_register();
    kunit_drivers_deep_register();
    /* V0.88 数据结构/算法测试 */
    kunit_ds_deep_register();
    kunit_algo_register();
    /* V0.89 并发/错误边界测试 */
    kunit_concurrency_register();
    kunit_error_boundary_register();
    /* V0.90 内存安全/时间测试 */
    kunit_memory_safety_register();
    kunit_time_register();
    /* V0.91 输入输出/配置测试 */
    kunit_io_register();
    kunit_config_register();
    /* V0.92 多语言/安全测试 */
    kunit_i18n_register();
    kunit_security_register();
    /* V0.93 进程线程/网络安全测试 */
    kunit_process_register();
    kunit_netsec_register();
    /* V0.94 存储/电源测试 */
    kunit_storage_register();
    kunit_power_register();
    /* V1.02 新模块测试 */
    kunit_v102_mem_register();
    kunit_v102_hal_register();

    vga_puts("[KUNIT] 所有测试套件注册完成\n");
}
