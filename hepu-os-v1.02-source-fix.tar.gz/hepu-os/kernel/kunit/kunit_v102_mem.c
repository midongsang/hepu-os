/* ============================================================================
 * 赫普OS - V1.02内存侧新模块测试
 * 覆盖：内存回收(reclaim)、Swap(swap)、大页(hugetlb)
 * 测试侧重结构/逻辑验证，避免触发真实物理内存副作用
 * ========================================================================== */

#include <stdint.h>
#include "kunit.h"
#include "vga.h"
#include "string.h"
#include "reclaim.h"
#include "swap.h"
#include "hugetlb.h"

/* === 内存回收测试 === */

static kunit_result_t test_reclaim_lru_add_remove(void)
{
    /* 登记页到LRU（不触发真实物理页释放） */
    KUNIT_ASSERT_EQ(reclaim_add_page(0x100000), 0, "添加页0x100000");
    KUNIT_ASSERT_EQ(reclaim_add_page(0x200000), 0, "添加页0x200000");
    KUNIT_ASSERT_EQ(reclaim_add_page(0x300000), 0, "添加页0x300000");

    /* 移除中间页 */
    KUNIT_ASSERT_EQ(reclaim_remove_page(0x200000), 0, "移除页0x200000");
    /* 重复移除返回-1 */
    KUNIT_ASSERT_EQ(reclaim_remove_page(0x200000), -1, "重复移除返回-1");

    uint32_t reclaimed, calls, lru_used, pressure;
    reclaim_stats(&reclaimed, &calls, &lru_used, &pressure);
    KUNIT_ASSERT_EQ(lru_used, 2, "LRU剩余2页");

    /* 清理 */
    reclaim_remove_page(0x100000);
    reclaim_remove_page(0x300000);
    return KUNIT_PASS;
}

static kunit_result_t test_reclaim_lru_accessed(void)
{
    reclaim_add_page(0x400000);
    reclaim_add_page(0x500000);

    /* 标记访问不会破坏链表 */
    KUNIT_ASSERT_EQ(reclaim_mark_accessed(0x500000), 0, "标记访问0x500000");
    KUNIT_ASSERT_EQ(reclaim_mark_accessed(0x999999), -1, "不存在的页返回-1");

    reclaim_remove_page(0x400000);
    reclaim_remove_page(0x500000);
    return KUNIT_PASS;
}

static kunit_result_t test_reclaim_until_boundary(void)
{
    /* 无可回收页时reclaim_until应立即返回（不陷入死循环） */
    int reclaimed = reclaim_until(0xFFFFFFF0);
    KUNIT_ASSERT(reclaimed >= 0, "reclaim_until无页可回收时正常返回");
    return KUNIT_PASS;
}

static kunit_result_t test_reclaim_pressure_check(void)
{
    /* 压力检查必须返回合法等级且不崩溃（含CRITICAL路径非递归） */
    int p = reclaim_check_pressure();
    KUNIT_ASSERT(p >= MEM_OK && p <= MEM_PRESSURE_CRITICAL,
                 "压力等级在合法范围");
    return KUNIT_PASS;
}

/* === Swap测试 === */

static kunit_result_t test_swap_set_enabled(void)
{
    KUNIT_ASSERT(swap_is_enabled() == 0 || swap_is_enabled() == 1,
                 "swap状态合法");
    KUNIT_ASSERT_EQ(swap_set_enabled(0), 0, "禁用swap");
    KUNIT_ASSERT_EQ(swap_set_enabled(1), 0, "启用swap");

    uint32_t total, used, in, out;
    swap_stats(&total, &used, &in, &out);
    KUNIT_ASSERT(total >= 1, "swap槽总数>0");
    return KUNIT_PASS;
}

static kunit_result_t test_swap_out_invalid(void)
{
    /* swap未启用时换出失败 */
    swap_set_enabled(0);
    KUNIT_ASSERT(swap_out(0x100000) < 0, "swap禁用时换出失败");

    /* 非法槽换入返回0 */
    KUNIT_ASSERT_EQ(swap_in(999), 0, "非法槽换入返回0");
    KUNIT_ASSERT_EQ(swap_in(-1), 0, "负槽换入返回0");

    swap_set_enabled(1);
    return KUNIT_PASS;
}

/* === 大页测试 === */

static kunit_result_t test_hugetlb_constants(void)
{
    KUNIT_ASSERT_EQ(HUGE_PAGE_2M, 2 * 1024 * 1024, "2M大页=2MB");
    KUNIT_ASSERT_EQ(HUGE_PAGE_4M, 4 * 1024 * 1024, "4M大页=4MB");
    KUNIT_ASSERT(HUGE_PAGE_2M < HUGE_PAGE_4M, "2M<4M");
    return KUNIT_PASS;
}

static kunit_result_t test_hugetlb_supported(void)
{
    /* 支持标志必须是0或1 */
    int s = hugetlb_supported();
    KUNIT_ASSERT(s == 0 || s == 1, "大页支持标志合法");
    return KUNIT_PASS;
}

static kunit_result_t test_hugetlb_stats(void)
{
    uint32_t h2, h4, a2, a4;
    hugetlb_stats(&h2, &h4, &a2, &a4);
    /* 验证统计接口可调用且计数在合理范围 */
    KUNIT_ASSERT(h2 + h4 + a2 + a4 <= 0xFFFFFF, "大页统计在合理范围");
    return KUNIT_PASS;
}

/* === 测试套件 === */
static const kunit_test_t v102_mem_tests[] = {
    {"LRU页登记/移除", test_reclaim_lru_add_remove, "reclaim"},
    {"LRU访问标记", test_reclaim_lru_accessed, "reclaim"},
    {"批量回收边界", test_reclaim_until_boundary, "reclaim"},
    {"内存压力检查", test_reclaim_pressure_check, "reclaim"},
    {"swap启停", test_swap_set_enabled, "swap"},
    {"swap非法操作", test_swap_out_invalid, "swap"},
    {"大页常量", test_hugetlb_constants, "hugetlb"},
    {"大页支持检测", test_hugetlb_supported, "hugetlb"},
    {"大页统计", test_hugetlb_stats, "hugetlb"},
};
static const kunit_suite_t kunit_v102_mem_suite = {
    "V1.02内存侧模块", v102_mem_tests, 9
};

void kunit_v102_mem_register(void)
{
    kunit_register_suite(&kunit_v102_mem_suite);
    vga_puts("[KUNIT] V1.02内存侧模块测试套件已注册 (9用例)\n");
}
