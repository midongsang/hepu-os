/* ============================================================================
 * 赫普OS - 内核单元测试框架
 * ========================================================================== */

#include <stdint.h>
#include "types.h"
#include "kunit.h"
#include "vga.h"
#include "string.h"

#define KUNIT_MAX_SUITES 32

static const kunit_suite_t *suites[KUNIT_MAX_SUITES];
static u32 suite_count = 0;
static kunit_stats_t global_stats;
static int kunit_initialized = 0;

void kunit_init(void)
{
    memset(&global_stats, 0, sizeof(global_stats));
    suite_count = 0;
    kunit_initialized = 1;
    vga_puts("[KUNIT] 单元测试框架初始化\n");
    kunit_register_suite(&kunit_string_suite);
    kunit_register_suite(&kunit_math_suite);
    kunit_register_suite(&kunit_bitops_suite);
}

void kunit_register_suite(const kunit_suite_t *suite)
{
    if (!kunit_initialized || !suite) return;
    if (suite_count >= KUNIT_MAX_SUITES) return;
    suites[suite_count++] = suite;
    vga_printf("[KUNIT] 注册套件: %s (%u 个测试)\n",
               suite->name, suite->test_count);
}

int kunit_run_suite(const kunit_suite_t *suite)
{
    if (!suite) return -1;
    u32 passed = 0, failed = 0, skipped = 0;
    vga_printf("\n=== 测试套件: %s ===\n", suite->name);

    for (u32 i = 0; i < suite->test_count; i++) {
        const kunit_test_t *test = &suite->tests[i];
        vga_printf("  [%u/%u] %s ... ", i + 1, suite->test_count, test->name);
        kunit_result_t result = test->func();
        switch (result) {
            case KUNIT_PASS:
                vga_set_color(VGA_COLOR_GREEN, VGA_COLOR_BLACK);
                vga_puts("PASS\n"); passed++; break;
            case KUNIT_FAIL:
                vga_set_color(VGA_COLOR_RED, VGA_COLOR_BLACK);
                vga_puts("FAIL\n"); failed++; break;
            case KUNIT_SKIP:
                vga_set_color(VGA_COLOR_YELLOW, VGA_COLOR_BLACK);
                vga_puts("SKIP\n"); skipped++; break;
        }
        vga_set_color(VGA_COLOR_LIGHT_GREY, VGA_COLOR_BLACK);
    }
    vga_printf("  结果: %u 通过, %u 失败, %u 跳过\n", passed, failed, skipped);
    global_stats.total += suite->test_count;
    global_stats.passed += passed;
    global_stats.failed += failed;
    global_stats.skipped += skipped;
    return failed;
}

int kunit_run_all(void)
{
    if (!kunit_initialized) return -1;
    vga_puts("\n=== 赫普OS 内核单元测试 ===\n");
    u32 total_failed = 0;
    for (u32 i = 0; i < suite_count; i++) {
        total_failed += kunit_run_suite(suites[i]);
    }
    kunit_print_report();
    return total_failed;
}

void kunit_get_stats(kunit_stats_t *stats)
{
    if (stats) *stats = global_stats;
}

void kunit_print_report(void)
{
    vga_printf("\n=== 测试报告 ===\n");
    vga_printf("总计: %u  通过: %u  失败: %u  跳过: %u\n",
               global_stats.total, global_stats.passed,
               global_stats.failed, global_stats.skipped);
    vga_printf("通过率: %u%%\n",
               global_stats.total ?
               (global_stats.passed * 100 / global_stats.total) : 0);
    if (global_stats.failed == 0) {
        vga_set_color(VGA_COLOR_GREEN, VGA_COLOR_BLACK);
        vga_puts("所有测试通过!\n");
    } else {
        vga_set_color(VGA_COLOR_RED, VGA_COLOR_BLACK);
        vga_printf("有 %u 个测试失败!\n", global_stats.failed);
    }
    vga_set_color(VGA_COLOR_LIGHT_GREY, VGA_COLOR_BLACK);
}
