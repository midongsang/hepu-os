/* ============================================================================
 * 赫普OS - 进程与线程单元测试
 * 覆盖：进程状态/PCB/线程/上下文切换/优先级/进程间通信
 * ========================================================================== */

#include <stdint.h>
#include "kunit.h"
#include "vga.h"
#include "string.h"

/* === 进程状态测试 === */
#define PROC_STATE_NEW       0
#define PROC_STATE_READY     1
#define PROC_STATE_RUNNING   2
#define PROC_STATE_BLOCKED   3
#define PROC_STATE_TERMINATED 4
#define PROC_STATE_SLEEPING  5
#define PROC_STATE_ZOMBIE    6

static kunit_result_t test_process_states(void)
{
    KUNIT_ASSERT_EQ(PROC_STATE_NEW, 0, "新建状态");
    KUNIT_ASSERT_EQ(PROC_STATE_READY, 1, "就绪状态");
    KUNIT_ASSERT_EQ(PROC_STATE_RUNNING, 2, "运行状态");
    KUNIT_ASSERT_EQ(PROC_STATE_BLOCKED, 3, "阻塞状态");
    KUNIT_ASSERT_EQ(PROC_STATE_TERMINATED, 4, "终止状态");
    KUNIT_ASSERT_EQ(PROC_STATE_SLEEPING, 5, "睡眠状态");
    KUNIT_ASSERT_EQ(PROC_STATE_ZOMBIE, 6, "僵尸状态");
    return KUNIT_PASS;
}

static const char *state_names[] = {
    "NEW", "READY", "RUNNING", "BLOCKED", "TERMINATED", "SLEEPING", "ZOMBIE"
};

static kunit_result_t test_process_state_names(void)
{
    KUNIT_ASSERT_EQ(strcmp(state_names[PROC_STATE_NEW], "NEW"), 0, "NEW名称");
    KUNIT_ASSERT_EQ(strcmp(state_names[PROC_STATE_RUNNING], "RUNNING"), 0, "RUNNING名称");
    KUNIT_ASSERT_EQ(strcmp(state_names[PROC_STATE_ZOMBIE], "ZOMBIE"), 0, "ZOMBIE名称");
    return KUNIT_PASS;
}

/* === PCB测试 === */
#define PROC_NAME_MAX 32
typedef struct {
    u32 pid;
    u32 ppid;
    u8  state;
    u8  priority;
    u32 ticks_remaining;
    u32 total_ticks;
    u32 stack_ptr;
    u32 page_dir;
    char name[PROC_NAME_MAX];
} pcb_t;

static kunit_result_t test_pcb_init(void)
{
    pcb_t pcb;
    memset(&pcb, 0, sizeof(pcb));
    pcb.pid = 1;
    pcb.ppid = 0;
    pcb.state = PROC_STATE_NEW;
    pcb.priority = 10;
    pcb.ticks_remaining = 100;
    strcpy(pcb.name, "init");

    KUNIT_ASSERT_EQ(pcb.pid, 1, "PID=1");
    KUNIT_ASSERT_EQ(pcb.ppid, 0, "PPID=0");
    KUNIT_ASSERT_EQ(pcb.state, PROC_STATE_NEW, "状态=NEW");
    KUNIT_ASSERT_EQ(pcb.priority, 10, "优先级=10");
    KUNIT_ASSERT_EQ(strcmp(pcb.name, "init"), 0, "名称=init");
    return KUNIT_PASS;
}

static kunit_result_t test_pcb_state_transition(void)
{
    pcb_t pcb;
    memset(&pcb, 0, sizeof(pcb));
    pcb.state = PROC_STATE_NEW;

    /* NEW -> READY */
    pcb.state = PROC_STATE_READY;
    KUNIT_ASSERT_EQ(pcb.state, PROC_STATE_READY, "NEW→READY");

    /* READY -> RUNNING */
    pcb.state = PROC_STATE_RUNNING;
    KUNIT_ASSERT_EQ(pcb.state, PROC_STATE_RUNNING, "READY→RUNNING");

    /* RUNNING -> BLOCKED */
    pcb.state = PROC_STATE_BLOCKED;
    KUNIT_ASSERT_EQ(pcb.state, PROC_STATE_BLOCKED, "RUNNING→BLOCKED");

    /* BLOCKED -> READY */
    pcb.state = PROC_STATE_READY;
    KUNIT_ASSERT_EQ(pcb.state, PROC_STATE_READY, "BLOCKED→READY");

    /* RUNNING -> TERMINATED */
    pcb.state = PROC_STATE_TERMINATED;
    KUNIT_ASSERT_EQ(pcb.state, PROC_STATE_TERMINATED, "RUNNING→TERMINATED");
    return KUNIT_PASS;
}

/* === 优先级测试 === */
#define PRIORITY_MIN 0
#define PRIORITY_MAX 31
#define PRIORITY_DEFAULT 15

static kunit_result_t test_priority_range(void)
{
    KUNIT_ASSERT_EQ(PRIORITY_MIN, 0, "最低优先级=0");
    KUNIT_ASSERT_EQ(PRIORITY_MAX, 31, "最高优先级=31");
    KUNIT_ASSERT_EQ(PRIORITY_DEFAULT, 15, "默认优先级=15");

    /* 优先级验证 */
    KUNIT_ASSERT(PRIORITY_DEFAULT >= PRIORITY_MIN, "默认>=最低");
    KUNIT_ASSERT(PRIORITY_DEFAULT <= PRIORITY_MAX, "默认<=最高");
    return KUNIT_PASS;
}

static int priority_to_ticks(u8 priority)
{
    /* 高优先级 = 更多时间片 */
    if (priority > PRIORITY_MAX) priority = PRIORITY_MAX;
    return (priority + 1) * 10;
}

static kunit_result_t test_priority_ticks(void)
{
    KUNIT_ASSERT_EQ(priority_to_ticks(0), 10, "优先级0=10ticks");
    KUNIT_ASSERT_EQ(priority_to_ticks(15), 160, "优先级15=160ticks");
    KUNIT_ASSERT_EQ(priority_to_ticks(31), 320, "优先级31=320ticks");
    KUNIT_ASSERT_EQ(priority_to_ticks(99), 320, "超出上限钳位");
    return KUNIT_PASS;
}

/* === 线程测试 === */
#define THREAD_STATE_READY   0
#define THREAD_STATE_RUNNING 1
#define THREAD_STATE_BLOCKED 2
#define THREAD_STATE_DONE    3

typedef struct {
    u32 tid;
    u32 pid;
    u8  state;
    u32 stack_ptr;
    u32 entry_point;
    u32 arg;
} thread_t;

static kunit_result_t test_thread_basic(void)
{
    thread_t thread;
    memset(&thread, 0, sizeof(thread));
    thread.tid = 100;
    thread.pid = 1;
    thread.state = THREAD_STATE_READY;
    thread.entry_point = 0xC0100000;
    thread.arg = 42;

    KUNIT_ASSERT_EQ(thread.tid, 100, "TID=100");
    KUNIT_ASSERT_EQ(thread.pid, 1, "所属PID=1");
    KUNIT_ASSERT_EQ(thread.state, THREAD_STATE_READY, "线程就绪");
    KUNIT_ASSERT_EQ(thread.entry_point, 0xC0100000, "入口地址");
    KUNIT_ASSERT_EQ(thread.arg, 42, "线程参数");
    return KUNIT_PASS;
}

static kunit_result_t test_thread_states(void)
{
    KUNIT_ASSERT_EQ(THREAD_STATE_READY, 0, "线程就绪");
    KUNIT_ASSERT_EQ(THREAD_STATE_RUNNING, 1, "线程运行");
    KUNIT_ASSERT_EQ(THREAD_STATE_BLOCKED, 2, "线程阻塞");
    KUNIT_ASSERT_EQ(THREAD_STATE_DONE, 3, "线程完成");
    return KUNIT_PASS;
}

/* === 上下文切换测试 === */
typedef struct {
    u32 eax, ebx, ecx, edx;
    u32 esi, edi, ebp, esp;
    u32 eip, eflags;
    u16 cs, ds, es, fs, gs, ss;
} cpu_context_t;

static kunit_result_t test_context_size(void)
{
    /* 验证上下文结构大小 */
    KUNIT_ASSERT(sizeof(cpu_context_t) >= 40, "上下文结构足够大");
    return KUNIT_PASS;
}

static kunit_result_t test_context_save_restore(void)
{
    cpu_context_t ctx1, ctx2;
    memset(&ctx1, 0, sizeof(ctx1));
    memset(&ctx2, 0, sizeof(ctx2));

    /* 模拟保存上下文 */
    ctx1.eax = 0x12345678;
    ctx1.ebx = 0xABCDEF01;
    ctx1.esp = 0xC000FFF0;
    ctx1.eip = 0xC0100000;
    ctx1.eflags = 0x202;

    /* 模拟恢复 */
    memcpy(&ctx2, &ctx1, sizeof(ctx1));

    KUNIT_ASSERT_EQ(ctx2.eax, 0x12345678, "EAX恢复");
    KUNIT_ASSERT_EQ(ctx2.ebx, 0xABCDEF01, "EBX恢复");
    KUNIT_ASSERT_EQ(ctx2.esp, 0xC000FFF0, "ESP恢复");
    KUNIT_ASSERT_EQ(ctx2.eip, 0xC0100000, "EIP恢复");
    KUNIT_ASSERT_EQ(ctx2.eflags, 0x202, "EFLAGS恢复");
    return KUNIT_PASS;
}

/* === 进程表测试 === */
#define PROC_MAX 64
static pcb_t process_table[PROC_MAX];
static u32 next_pid;

static void proc_table_init(void)
{
    memset(process_table, 0, sizeof(process_table));
    next_pid = 1;
}

static int proc_create(const char *name, u8 priority)
{
    for (int i = 0; i < PROC_MAX; i++) {
        if (process_table[i].state == PROC_STATE_TERMINATED ||
            (process_table[i].pid == 0 && i > 0)) {
            memset(&process_table[i], 0, sizeof(pcb_t));
            process_table[i].pid = next_pid++;
            process_table[i].state = PROC_STATE_NEW;
            process_table[i].priority = priority;
            process_table[i].ticks_remaining = priority_to_ticks(priority);
            if (name) strncpy(process_table[i].name, name, PROC_NAME_MAX - 1);
            return process_table[i].pid;
        }
    }
    return -1;
}

static pcb_t *proc_find(u32 pid)
{
    for (int i = 0; i < PROC_MAX; i++) {
        if (process_table[i].pid == pid &&
            process_table[i].state != PROC_STATE_TERMINATED) {
            return &process_table[i];
        }
    }
    return 0;
}

static kunit_result_t test_proc_table_create(void)
{
    proc_table_init();

    int pid1 = proc_create("shell", 15);
    int pid2 = proc_create("editor", 10);
    int pid3 = proc_create("browser", 20);

    KUNIT_ASSERT_EQ(pid1, 1, "第一个进程PID=1");
    KUNIT_ASSERT_EQ(pid2, 2, "第二个进程PID=2");
    KUNIT_ASSERT_EQ(pid3, 3, "第三个进程PID=3");

    pcb_t *p = proc_find(2);
    KUNIT_ASSERT_NOT_NULL(p, "找到PID=2");
    KUNIT_ASSERT_EQ(strcmp(p->name, "editor"), 0, "进程名=editor");
    KUNIT_ASSERT_EQ(p->priority, 10, "优先级=10");
    return KUNIT_PASS;
}

static kunit_result_t test_proc_table_find_miss(void)
{
    proc_table_init();
    proc_create("test", 10);

    KUNIT_ASSERT_NULL(proc_find(999), "未找到PID=999");
    KUNIT_ASSERT_NULL(proc_find(0), "未找到PID=0");
    return KUNIT_PASS;
}

/* === 进程间通信测试 === */
#define IPC_MSG_MAX 64
typedef struct {
    u32 sender;
    u32 receiver;
    u8  data[64];
    u32 length;
} ipc_message_t;

static kunit_result_t test_ipc_message(void)
{
    ipc_message_t msg;
    memset(&msg, 0, sizeof(msg));
    msg.sender = 1;
    msg.receiver = 2;
    msg.length = 5;
    memcpy(msg.data, "HELLO", 5);

    KUNIT_ASSERT_EQ(msg.sender, 1, "发送者=1");
    KUNIT_ASSERT_EQ(msg.receiver, 2, "接收者=2");
    KUNIT_ASSERT_EQ(msg.length, 5, "消息长度=5");
    KUNIT_ASSERT_EQ(memcmp(msg.data, "HELLO", 5), 0, "消息内容");
    return KUNIT_PASS;
}

/* === 测试套件注册 === */
static const kunit_test_t process_tests[] = {
    {"进程状态", test_process_states, "process"},
    {"进程状态名", test_process_state_names, "process"},
    {"PCB初始化", test_pcb_init, "process"},
    {"PCB状态转换", test_pcb_state_transition, "process"},
    {"优先级范围", test_priority_range, "process"},
    {"优先级时间片", test_priority_ticks, "process"},
    {"线程基本", test_thread_basic, "process"},
    {"线程状态", test_thread_states, "process"},
    {"上下文大小", test_context_size, "process"},
    {"上下文保存恢复", test_context_save_restore, "process"},
    {"进程表创建", test_proc_table_create, "process"},
    {"进程表查找失败", test_proc_table_find_miss, "process"},
    {"IPC消息", test_ipc_message, "process"},
};
static const kunit_suite_t kunit_process_suite = {
    "进程与线程", process_tests, 13
};

void kunit_process_register(void)
{
    kunit_register_suite(&kunit_process_suite);
    vga_puts("[KUNIT] 进程与线程测试套件已注册 (13用例)\n");
}
