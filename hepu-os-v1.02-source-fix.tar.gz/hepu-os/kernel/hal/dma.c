/* ============================================================================
 * 赫普OS - DMA抽象层 (V1.00新增)
 * 实现：DMA通道管理、内存缓冲区、传输描述符
 * ========================================================================== */
#include <stdint.h>
#include <stddef.h>
#include "dma.h"
#include "mm.h"
#include "vga.h"
#include "string.h"

#define DMA_CHANNELS 8
#define DMA_BUF_MAX 16
#define DMA_MAGIC 0x444D4131  /* "DMA1" */

/* DMA通道 */
typedef struct {
    uint8_t      used;
    uint8_t      channel;
    dma_state_t  state;
    uint8_t      width;       /* 8/16/32位 */
    uint8_t      direction;   /* 0=读, 1=写 */
    uint32_t     phys_addr;   /* 物理地址 */
    uint32_t     length;      /* 传输长度 */
    uint32_t     transfer_count;
    uint32_t     error_count;
} dma_channel_t;

/* DMA缓冲区 */
typedef struct {
    uint32_t magic;
    uint8_t  used;
    uint32_t phys_addr;
    uint32_t size;
    uint32_t align;
} dma_buffer_t;

static dma_channel_t dma_channels[DMA_CHANNELS];
static dma_buffer_t  dma_buffers[DMA_BUF_MAX];
static uint8_t dma_initialized = 0;

void dma_init(void)
{
    memset(dma_channels, 0, sizeof(dma_channels));
    memset(dma_buffers, 0, sizeof(dma_buffers));

    /* 初始化通道0-7 */
    for (int i = 0; i < DMA_CHANNELS; i++) {
        dma_channels[i].channel = i;
        dma_channels[i].state = DMA_FREE;
        dma_channels[i].used = 0;
    }

    dma_initialized = 1;
    vga_puts("[DMA] DMA抽象层初始化完成 (8通道)\n");
}

/* 分配DMA通道 */
int dma_alloc_channel(uint8_t width, uint8_t direction)
{
    if (!dma_initialized) return -1;
    if (width != 8 && width != 16 && width != 32) return -1;
    if (direction > 1) return -1;

    for (int i = 0; i < DMA_CHANNELS; i++) {
        if (!dma_channels[i].used) {
            dma_channels[i].used = 1;
            dma_channels[i].state = DMA_ALLOCATED;
            dma_channels[i].width = width;
            dma_channels[i].direction = direction;
            return i;
        }
    }
    return -1;  /* 无空闲通道 */
}

/* 释放DMA通道 */
int dma_free_channel(int channel)
{
    if (!dma_initialized || channel < 0 || channel >= DMA_CHANNELS) return -1;
    if (!dma_channels[channel].used) return -1;
    dma_channels[channel].used = 0;
    dma_channels[channel].state = DMA_FREE;
    return 0;
}

/* 设置DMA传输参数 */
int dma_set_transfer(int channel, uint32_t phys_addr, uint32_t length)
{
    if (!dma_initialized || channel < 0 || channel >= DMA_CHANNELS) return -1;
    if (!dma_channels[channel].used) return -1;
    if (phys_addr & 0xFF) return -1;  /* DMA地址必须页对齐? 实际是16位边界 */
    if (length == 0 || length > 65536) return -1;

    dma_channels[channel].phys_addr = phys_addr;
    dma_channels[channel].length = length;
    return 0;
}

/* 启动DMA传输 */
int dma_start(int channel)
{
    if (!dma_initialized || channel < 0 || channel >= DMA_CHANNELS) return -1;
    if (!dma_channels[channel].used) return -1;
    if (dma_channels[channel].state != DMA_ALLOCATED &&
        dma_channels[channel].state != DMA_COMPLETE) return -1;

    /* 在实际硬件上，这里需要编程DMA控制器寄存器
     * 简化实现：直接标记为传输中 */
    dma_channels[channel].state = DMA_TRANSFERRING;
    dma_channels[channel].transfer_count++;

    /* 模拟传输完成（实际由中断通知） */
    dma_channels[channel].state = DMA_COMPLETE;
    return 0;
}

/* 停止DMA传输 */
int dma_stop(int channel)
{
    if (!dma_initialized || channel < 0 || channel >= DMA_CHANNELS) return -1;
    if (!dma_channels[channel].used) return -1;
    dma_channels[channel].state = DMA_ALLOCATED;
    return 0;
}

/* 获取通道状态 */
dma_state_t dma_get_state(int channel)
{
    if (!dma_initialized || channel < 0 || channel >= DMA_CHANNELS) return DMA_ERROR;
    return dma_channels[channel].state;
}

/* 分配DMA一致性缓冲区 */
void *dma_alloc_buffer(uint32_t size, uint32_t align)
{
    if (!dma_initialized || size == 0) return NULL;
    if (align == 0) align = 4096;

    for (int i = 0; i < DMA_BUF_MAX; i++) {
        if (!dma_buffers[i].used) {
            /* 分配连续物理页 */
            uint32_t pages = (size + align - 1) / align;
            uint32_t phys = mm_alloc_pages(pages);
            if (!phys) return NULL;

            memset((void *)phys, 0, pages * align);
            dma_buffers[i].magic = DMA_MAGIC;
            dma_buffers[i].used = 1;
            dma_buffers[i].phys_addr = phys;
            dma_buffers[i].size = pages * align;
            dma_buffers[i].align = align;
            return (void *)phys;
        }
    }
    return NULL;
}

/* 释放DMA缓冲区 */
int dma_free_buffer(void *addr)
{
    if (!dma_initialized || !addr) return -1;
    uint32_t phys = (uint32_t)addr;

    for (int i = 0; i < DMA_BUF_MAX; i++) {
        if (dma_buffers[i].used && dma_buffers[i].phys_addr == phys) {
            uint32_t pages = dma_buffers[i].size / dma_buffers[i].align;
            mm_free_pages(phys, pages);
            dma_buffers[i].used = 0;
            dma_buffers[i].magic = 0;
            return 0;
        }
    }
    return -1;
}

/* 获取缓冲区物理地址 */
uint32_t dma_get_phys(void *addr)
{
    if (!addr) return 0;
    /* 一致性缓冲区：虚拟地址=物理地址（身份映射区域） */
    return (uint32_t)addr;
}

/* DMA统计 */
void dma_stats(uint32_t *channels_used, uint32_t *buffers_used,
               uint32_t *total_transfers)
{
    uint32_t ch = 0, buf = 0, xfer = 0;
    for (int i = 0; i < DMA_CHANNELS; i++) {
        if (dma_channels[i].used) ch++;
        xfer += dma_channels[i].transfer_count;
    }
    for (int i = 0; i < DMA_BUF_MAX; i++) {
        if (dma_buffers[i].used) buf++;
    }
    if (channels_used) *channels_used = ch;
    if (buffers_used) *buffers_used = buf;
    if (total_transfers) *total_transfers = xfer;
}
