/* ============================================================================
 * 赫普OS - 文件系统日志 (Journaling)
 * 提供崩溃一致性保障，类似ext3/ext4的日志机制
 * ========================================================================== */

#include <stdint.h>
#include "journal.h"
#include "vga.h"
#include "string.h"

static journal_t journal;
static int journal_initialized = 0;
static int in_transaction = 0;
static uint32_t transaction_start = 0;
static uint64_t journal_time = 0;

void journal_init(void)
{
    memset(&journal, 0, sizeof(journal));
    journal.magic = JOURNAL_MAGIC;
    journal.version = 1;
    journal.head = 0;
    journal.tail = 0;
    journal.count = 0;
    journal.committed = 0;
    journal_initialized = 1;
    in_transaction = 0;
    vga_puts("[JOURNAL] 文件系统日志初始化 (环形缓冲区)\n");
}

int journal_start_transaction(void)
{
    if (!journal_initialized) return -1;
    if (in_transaction) return -1;  /* 已有事务进行中 */

    in_transaction = 1;
    transaction_start = journal.head;
    journal_time++;
    return 0;
}

int journal_write(journal_op_t op, uint32_t inode, const void *data, uint32_t len)
{
    if (!journal_initialized || !in_transaction) return -1;
    if (len > JOURNAL_MAX_DATA) return -1;

    /* 检查日志是否已满 */
    if (journal.count >= JOURNAL_MAX_ENTRIES) {
        vga_puts("[JOURNAL] 日志已满，需要提交\n");
        return -1;
    }

    journal_entry_t *entry = &journal.entries[journal.head];
    entry->magic = JOURNAL_MAGIC;
    entry->seq = journal.committed + journal.count;
    entry->op = op;
    entry->inode_num = inode;
    entry->timestamp = journal_time;
    entry->data_len = len;
    if (data && len > 0) {
        memcpy(entry->data, data, len);
    }

    journal.head = (journal.head + 1) % JOURNAL_MAX_ENTRIES;
    journal.count++;

    return 0;
}

int journal_commit_transaction(void)
{
    if (!journal_initialized || !in_transaction) return -1;

    uint32_t committed = journal.count;
    journal.committed += committed;
    journal.count = 0;
    in_transaction = 0;

    vga_printf("[JOURNAL] 提交事务: %d条记录 (总计已提交=%d)\n",
               committed, journal.committed);
    return committed;
}

int journal_abort_transaction(void)
{
    if (!journal_initialized || !in_transaction) return -1;

    /* 回滚：恢复head到事务开始位置 */
    journal.head = transaction_start;
    journal.count = 0;
    in_transaction = 0;

    vga_puts("[JOURNAL] 中止事务，已回滚\n");
    return 0;
}

int journal_replay(void)
{
    if (!journal_initialized) return -1;
    if (journal.count == 0) {
        vga_puts("[JOURNAL] 无待重放记录\n");
        return 0;
    }

    vga_printf("[JOURNAL] 重放日志: %d条待提交记录\n", journal.count);

    /* 简化：标记所有记录为已提交 */
    journal.committed += journal.count;
    journal.count = 0;

    vga_puts("[JOURNAL] 日志重放完成\n");
    return 0;
}

int journal_get_status(uint32_t *pending, uint32_t *committed)
{
    if (!journal_initialized) return -1;
    if (pending) *pending = journal.count;
    if (committed) *committed = journal.committed;
    return 0;
}
