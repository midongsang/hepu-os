/* ============================================================================
 * 赫普OS - .hug 应用加载器
 * 解析 .hug (Hyper User Gear) 应用包，加载并执行用户态应用
 * ========================================================================== */

#include <stdint.h>
#include <stddef.h>
#include "hug_loader.h"
#include "initrd.h"
#include "vga.h"
#include "string.h"
#include "process.h"

int hug_verify(const void *data, uint32_t size)
{
    if (!data || size < sizeof(hug_header_t)) {
        return -1;
    }

    const hug_header_t *header = (const hug_header_t *)data;

    if (header->magic != HUG_MAGIC) {
        return -2;
    }

    if (header->version != HUG_VERSION) {
        return -3;
    }

    /* 检查各段偏移是否在文件范围内 */
    if (header->manifest_offset + header->manifest_size > size) return -4;
    if (header->code_offset + header->code_size > size) return -5;
    if (header->data_offset + header->data_size > size) return -6;

    return 0;
}

int hug_parse(const void *data, uint32_t size, hug_app_t *app)
{
    if (!data || !app) return -1;

    int ret = hug_verify(data, size);
    if (ret != 0) return ret;

    const hug_header_t *header = (const hug_header_t *)data;
    memcpy(&app->header, header, sizeof(hug_header_t));

    /* 设置各段指针 */
    app->manifest = (const char *)data + header->manifest_offset;
    app->code = (uint8_t *)data + header->code_offset;
    app->data = (uint8_t *)data + header->data_offset;
    app->entry = header->entry_point;

    return 0;
}

void hug_info(const hug_app_t *app)
{
    if (!app) return;

    vga_puts("=== .hug 应用信息 ===\n");
    vga_printf("  版本: %d\n", app->header.version);
    vga_printf("  代码段: %d bytes @ 0x%x\n",
               app->header.code_size, app->header.code_offset);
    vga_printf("  数据段: %d bytes @ 0x%x\n",
               app->header.data_size, app->header.data_offset);
    vga_printf("  Manifest: %d bytes\n", app->header.manifest_size);
    vga_printf("  入口点: 0x%x\n", app->header.entry_point);

    /* 显示manifest前128字节 */
    if (app->manifest && app->header.manifest_size > 0) {
        vga_puts("  Manifest (前128字节):\n");
        uint32_t len = app->header.manifest_size;
        if (len > 128) len = 128;
        for (uint32_t i = 0; i < len; i++) {
            vga_putc(app->manifest[i]);
        }
        vga_putc('\n');
    }
}

int hug_run(const char *path)
{
    if (!path) return -1;

    vga_printf("[HUG] 加载应用: %s\n", path);

    /* 从initrd打开文件 */
    int fd = initrd_open(path);
    if (fd < 0) {
        vga_printf("[HUG] 错误: 找不到文件 %s\n", path);
        return -1;
    }

    int size = initrd_size(fd);
    if (size < (int)sizeof(hug_header_t)) {
        vga_puts("[HUG] 错误: 文件太小\n");
        initrd_close(fd);
        return -1;
    }

    /* 读取整个文件到临时缓冲区
     * 注意: 原型阶段直接用initrd中的数据指针，不复制 */
    int index = initrd_find(path);
    if (index < 0) {
        initrd_close(fd);
        return -1;
    }

    void *data = initrd_get_data(index);
    initrd_close(fd);

    if (!data) {
        vga_puts("[HUG] 错误: 获取数据指针失败\n");
        return -1;
    }

    /* 解析.hug */
    hug_app_t app;
    int ret = hug_parse(data, size, &app);
    if (ret != 0) {
        vga_printf("[HUG] 错误: 解析失败 (code=%d)\n", ret);
        return -1;
    }

    hug_info(&app);

    /* 创建用户态进程执行应用
     * 原型阶段: 直接用代码段地址作为入口
     * 未来: 需要复制到用户空间并设置正确的页映射 */
    uint32_t entry = (uint32_t)app.code + app.entry;

    vga_printf("[HUG] 创建进程, 入口=0x%x\n", entry);

    process_t *proc = process_create(path, entry, PRIV_USER, 100);
    if (!proc) {
        vga_puts("[HUG] 错误: 进程创建失败\n");
        return -1;
    }

    vga_printf("[HUG] 应用启动: PID=%d\n", proc->pid);

    /* 进入用户态执行 */
    process_enter_user_mode(proc);

    return 0;
}
