/* ============================================================================
 * 赫普OS - ext2分配与写入（从ext2.c拆分）
 * 块分配/释放, inode分配/释放/写入, 数据写入
 * ========================================================================== */

#include <stdint.h>
#include "ext2.h"
#include "vga.h"
#include "string.h"

extern uint32_t ext2_disk_size;
extern uint32_t ext2_block_size;
extern int ext2_mounted;
extern ext2_superblock_t *ext2_sb;

uint32_t ext2_alloc_block(void)
{
    if (!ext2_mounted) return 0;
    uint32_t groups = (ext2_sb->s_blocks_count + ext2_sb->s_blocks_per_group - 1) / ext2_sb->s_blocks_per_group;
    for (uint32_t g = 0; g < groups; g++) {
        if (ext2_gdt[g].bg_free_blocks_count == 0) continue;
        uint8_t *bitmap = ext2_disk + ext2_gdt[g].bg_block_bitmap * ext2_block_size;
        for (uint32_t b = 0; b < ext2_sb->s_blocks_per_group; b++) {
            if (!(bitmap[b / 8] & (1 << (b % 8)))) {
                bitmap[b / 8] |= (1 << (b % 8));
                ext2_gdt[g].bg_free_blocks_count--;
                ext2_sb->s_free_blocks_count--;
                uint32_t block_num = g * ext2_sb->s_blocks_per_group + b + ext2_sb->s_first_data_block;
                memset(ext2_disk + block_num * ext2_block_size, 0, ext2_block_size);
                return block_num;
            }
        }
    }
    return 0;
}

void ext2_free_block(uint32_t block)
{
    if (!ext2_mounted || block == 0) return;
    uint32_t g = (block - ext2_sb->s_first_data_block) / ext2_sb->s_blocks_per_group;
    uint32_t b = (block - ext2_sb->s_first_data_block) % ext2_sb->s_blocks_per_group;
    uint8_t *bitmap = ext2_disk + ext2_gdt[g].bg_block_bitmap * ext2_block_size;
    bitmap[b / 8] &= ~(1 << (b % 8));
    ext2_gdt[g].bg_free_blocks_count++;
    ext2_sb->s_free_blocks_count++;
}

uint32_t ext2_alloc_inode(void)
{
    if (!ext2_mounted) return 0;
    uint32_t groups = (ext2_sb->s_inodes_count + ext2_sb->s_inodes_per_group - 1) / ext2_sb->s_inodes_per_group;
    for (uint32_t g = 0; g < groups; g++) {
        if (ext2_gdt[g].bg_free_inodes_count == 0) continue;
        uint8_t *bitmap = ext2_disk + ext2_gdt[g].bg_inode_bitmap * ext2_block_size;
        for (uint32_t i = 0; i < ext2_sb->s_inodes_per_group; i++) {
            if (!(bitmap[i / 8] & (1 << (i % 8)))) {
                bitmap[i / 8] |= (1 << (i % 8));
                ext2_gdt[g].bg_free_inodes_count--;
                ext2_sb->s_free_inodes_count--;
                return g * ext2_sb->s_inodes_per_group + i + 1;
            }
        }
    }
    return 0;
}

void ext2_free_inode(uint32_t inode_num)
{
    if (!ext2_mounted || inode_num == 0) return;
    uint32_t g = (inode_num - 1) / ext2_sb->s_inodes_per_group;
    uint32_t i = (inode_num - 1) % ext2_sb->s_inodes_per_group;
    uint8_t *bitmap = ext2_disk + ext2_gdt[g].bg_inode_bitmap * ext2_block_size;
    bitmap[i / 8] &= ~(1 << (i % 8));
    ext2_gdt[g].bg_free_inodes_count++;
    ext2_sb->s_free_inodes_count++;
}

int ext2_write_inode(uint32_t inode_num, ext2_inode_t *inode)
{
    if (!ext2_mounted || inode_num == 0 || !inode) return -1;
    uint32_t group = (inode_num - 1) / ext2_sb->s_inodes_per_group;
    uint32_t index = (inode_num - 1) % ext2_sb->s_inodes_per_group;
    uint32_t inode_table = ext2_gdt[group].bg_inode_table;
    uint32_t offset = inode_table * ext2_block_size + index * sizeof(ext2_inode_t);
    memcpy(ext2_disk + offset, inode, sizeof(ext2_inode_t));
    return 0;
}

int ext2_write_data(ext2_inode_t *inode, uint32_t offset, const void *buf, uint32_t size)
{
    if (!ext2_mounted || !inode || !buf) return -1;
    uint32_t block_idx = offset / ext2_block_size;
    uint32_t block_off = offset % ext2_block_size;
    const uint8_t *src = (const uint8_t *)buf;
    uint32_t remaining = size;
    while (remaining > 0) {
        uint32_t phys_block = ext2_get_block(inode, block_idx);
        if (phys_block == 0) {
            phys_block = ext2_alloc_block();
            if (phys_block == 0) break;
            if (block_idx < 12) {
                inode->i_block[block_idx] = phys_block;
            } else {
                if (inode->i_block[12] == 0) inode->i_block[12] = ext2_alloc_block();
                uint32_t *indirect = (uint32_t *)(ext2_disk + inode->i_block[12] * ext2_block_size);
                indirect[block_idx - 12] = phys_block;
            }
        }
        uint32_t chunk = ext2_block_size - block_off;
        if (chunk > remaining) chunk = remaining;
        memcpy(ext2_disk + phys_block * ext2_block_size + block_off, src, chunk);
        src += chunk;
        remaining -= chunk;
        block_idx++;
        block_off = 0;
    }
    uint32_t written = size - remaining;
    if (offset + written > inode->i_size) inode->i_size = offset + written;
    inode->i_blocks = (inode->i_size + 511) / 512;
    inode->i_mtime = ext2_get_time();
    return written;
}

/* === V0.45 新增：ext2高层文件操作 === */

/* 在目录中添加目录项 */
