#ifndef VGA_H
#define VGA_H

#include <stdint.h>
#include <stddef.h>

enum vga_color {
    VGA_COLOR_BLACK = 0,
    VGA_COLOR_BLUE = 1,
    VGA_COLOR_GREEN = 2,
    VGA_COLOR_CYAN = 3,
    VGA_COLOR_RED = 4,
    VGA_COLOR_MAGENTA = 5,
    VGA_COLOR_BROWN = 6,
    VGA_COLOR_LIGHT_GREY = 7,
    VGA_COLOR_DARK_GREY = 8,
    VGA_COLOR_LIGHT_BLUE = 9,
    VGA_COLOR_LIGHT_GREEN = 10,
    VGA_COLOR_LIGHT_CYAN = 11,
    VGA_COLOR_LIGHT_RED = 12,
    VGA_COLOR_LIGHT_MAGENTA = 13,
    VGA_COLOR_LIGHT_BROWN = 14,
    VGA_COLOR_YELLOW = 14,
    VGA_COLOR_WHITE = 15,
};

void    vga_init(void);
void    vga_clear(void);
void    vga_gotoxy(size_t row, size_t col);
void    vga_set_color(uint8_t fg, uint8_t bg);
uint8_t vga_make_color(enum vga_color fg, enum vga_color bg);
void    vga_putc(char c);
void    vga_puts(const char *str);
void    vga_printf(const char *fmt, ...);
void    vga_write(const void *buf, uint32_t len);

/* 抗锯齿字体渲染 (vga_gfx_aa.c) */
void    gfx_aa_putc(int x, int y, char c, uint8_t color);
void    gfx_aa_puts(int x, int y, const char *s, uint8_t color);
int     gfx_aa_text_width(const char *s);

#endif
