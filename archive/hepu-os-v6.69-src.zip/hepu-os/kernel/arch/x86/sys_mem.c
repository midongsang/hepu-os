/* ============================================================================
 * 赫普OS - 系统调用：MEM
 * ========================================================================== */

#include "types.h"
#include <stdint.h>
#include <stddef.h>
#include "syscall.h"
#include "vga.h"
#include "kheap.h"
#include "sched.h"
#include "hepu.h"
#include "fingerprint.h"
#include "vfs.h"
#include "ipc.h"
#include "process.h"
#include "paging.h"
#include "mm.h"
#include "constants.h"
extern const char *hepu_kernel_version;

/* V3.87: 进程堆顶设置/查询 (Linux brk 兼容——标准库 malloc 的基础).
 * 语义 (Linux i386 公开 ABI):
 *   brk(0)        → 返回当前堆顶 (查询)
 *   brk(new_brk)  → 尝试设置堆顶, 返回实际堆顶 (失败时保持原值)
 * 堆区间 [heap_start, heap_end), 由 ELF 加载器初始化 heap_start;
 * 增长逐页 mm_alloc_page + 映射到进程用户目录, 收缩 paging_unmap. */
u32 sys_brk(u32 new_brk, u32 arg2,
                         u32 arg3, u32 arg4)
{
    (void)arg2; (void)arg3; (void)arg4;
    extern process_t *current;
    if (!current || current->heap_start == 0) {
        return 0;   /* 无堆区进程 (原生 .hug/内核): 不支持 */
    }
    if (new_brk == 0) {
        return current->heap_end;   /* 查询当前堆顶 */
    }
    if (new_brk < current->heap_start) {
        return current->heap_end;   /* 低于堆起点: 拒绝 */
    }
    if (new_brk > USER_STACK_ADDR - 0x10000) {
        return current->heap_end;   /* 撞用户栈区 (栈顶之下留 64KB): 拒绝 */
    }

    uint32_t old_pg_end = (current->heap_end + PAGE_SIZE - 1) & ~(PAGE_SIZE - 1);
    uint32_t new_pg_end = (new_brk + PAGE_SIZE - 1) & ~(PAGE_SIZE - 1);

    if (new_pg_end > old_pg_end) {
        /* 增长: 逐页分配物理帧并映射 (用户可读写) */
        for (uint32_t a = old_pg_end; a < new_pg_end; a += PAGE_SIZE) {
            uint32_t frame = mm_alloc_page();
            if (!frame) {
                return current->heap_end;   /* 内存不足: 保持原堆顶 */
            }
            if (paging_map(current->page_dir, a, frame,
                           PAGE_PRESENT | PAGE_WRITE | PAGE_USER) < 0) {
                return current->heap_end;
            }
        }
    } else if (new_pg_end < old_pg_end) {
        /* 收缩: 解除映射 (物理帧由 paging_unmap 归还) */
        for (uint32_t a = new_pg_end; a < old_pg_end; a += PAGE_SIZE) {
            paging_unmap(current->page_dir, a);
        }
    }

    current->heap_end = new_brk;
    return new_brk;
}

u32 sys_malloc(u32 size, u32 arg2,
                           u32 arg3, u32 arg4)
{
    (void)arg2; (void)arg3; (void)arg4;
    return (u32)kmalloc(size);
}

u32 sys_free(u32 ptr, u32 arg2,
                         u32 arg3, u32 arg4)
{
    (void)arg2; (void)arg3; (void)arg4;
    kfree((void *)ptr);
    return 0;
}

u32 sys_shmget(u32 key, u32 size,
                           u32 arg3, u32 arg4)
{
    (void)arg3; (void)arg4;
    return ipc_shm_get(key, size);
}

u32 sys_shmat(u32 shm_id, u32 arg2,
                          u32 arg3, u32 arg4)
{
    (void)arg2; (void)arg3; (void)arg4;
    return (u32)ipc_shm_attach(shm_id, sched_current_pid());
}

/* V3.77: 释放共享内存段（补 shmget 回收路径, 防止反复分配耗尽 kheap） */
u32 sys_shmdt(u32 shm_id, u32 arg2,
                          u32 arg3, u32 arg4)
{
    (void)arg2; (void)arg3; (void)arg4;
    return (u32)ipc_shm_release(shm_id, sched_current_pid());
}

u32 sys_mmap(u32 addr, u32 length, u32 prot, u32 flags)
{
    (void)addr; (void)prot; (void)flags;
    return (u32)kmalloc(length);
}

u32 sys_munmap(u32 addr, u32 length, u32 arg3, u32 arg4)
{
    (void)length; (void)arg3; (void)arg4;
    kfree((void *)addr);
    return 0;
}

u32 sys_mprotect(u32 addr, u32 length, u32 prot, u32 arg4)
{
    (void)addr; (void)length; (void)prot; (void)arg4;
    return 0;
}

/* V4.02: 初始化VGA图形模式 (320x200 256色, 供gfxtest等用户态应用使用) */
u32 sys_gfx_init(u32 arg1, u32 arg2, u32 arg3, u32 arg4)
{
    (void)arg1; (void)arg2; (void)arg3; (void)arg4;
    extern void vga_gfx_init(void);
    extern void serial_puts(uint16_t, const char *);
    serial_puts(0x3F8, "[GFX] sys_gfx_init: entering VGA 320x200x256 mode\n");
    vga_gfx_init();
    serial_puts(0x3F8, "[GFX] sys_gfx_init: graphics mode active\n");
    return 0;
}

/* V4.02: 切换回VGA文本模式 (80x25) */
u32 sys_gfx_text(u32 arg1, u32 arg2, u32 arg3, u32 arg4)
{
    (void)arg1; (void)arg2; (void)arg3; (void)arg4;
    extern void vga_gfx_text_mode(void);
    vga_gfx_text_mode();
    return 0;
}

/* V6.50: 提交后台缓冲区到显存 (双缓冲flip, 解决gfxtest写入后不显示的问题) */
u32 sys_gfx_flip(u32 arg1, u32 arg2, u32 arg3, u32 arg4)
{
    (void)arg1; (void)arg2; (void)arg3; (void)arg4;
    extern void gfx_flip(void);
    gfx_flip();
    return 0;
}

/* V6.50: 内核图形演示 — 展示所有绘图API (圆形/椭圆/三角形/渐变/文字) */
u32 sys_gfx_demo(u32 arg1, u32 arg2, u32 arg3, u32 arg4)
{
    (void)arg1; (void)arg2; (void)arg3; (void)arg4;
    extern void gfx_clear(uint8_t);
    extern void gfx_fillrect(int, int, int, int, uint8_t);
    extern void gfx_rect(int, int, int, int, uint8_t);
    extern void gfx_line(int, int, int, int, uint8_t);
    extern void gfx_circle(int, int, int, uint8_t);
    extern void gfx_fillcircle(int, int, int, uint8_t);
    extern void gfx_ellipse(int, int, int, int, uint8_t);
    extern void gfx_triangle(int, int, int, int, int, int, uint8_t);
    extern void gfx_gradient_h(int, int, int, int, uint8_t, uint8_t);
    extern void gfx_gradient_v(int, int, int, int, uint8_t, uint8_t);
    extern void gfx_puts(int, int, const char *, uint8_t);
    extern void gfx_flip(void);
    extern void serial_puts(uint16_t, const char *);

    serial_puts(0x3F8, "[GFX-DEMO] 开始绘制图形演示...\n");

    /* 清屏为深蓝色 */
    gfx_clear(1);

    /* 标题 */
    gfx_puts(80, 5, "HepuOS Graphics Demo", 15);

    /* 1. 渐变背景条 */
    gfx_gradient_h(0, 15, 320, 8, 9, 12);

    /* 2. 圆形 (空心+填充) */
    gfx_circle(40, 50, 20, 14);       /* 黄色空心圆 */
    gfx_fillcircle(90, 50, 15, 12);    /* 红色填充圆 */
    gfx_circle(140, 50, 25, 10);       /* 绿色大圆 */

    /* 3. 椭圆 */
    gfx_ellipse(200, 50, 30, 15, 13);  /* 紫色椭圆 */
    gfx_ellipse(260, 50, 20, 25, 11);  /* 青色竖椭圆 */

    /* 4. 三角形 */
    gfx_triangle(30, 90, 60, 70, 90, 90, 14);
    gfx_triangle(110, 90, 140, 70, 170, 90, 12);
    gfx_triangle(190, 90, 220, 70, 250, 90, 10);

    /* 5. 矩形 (边框+填充) */
    gfx_rect(10, 105, 50, 30, 15);
    gfx_fillrect(70, 105, 50, 30, 9);
    gfx_rect(130, 105, 50, 30, 14);
    gfx_fillrect(190, 105, 50, 30, 13);

    /* 6. 直线 */
    gfx_line(10, 150, 300, 150, 7);
    gfx_line(10, 160, 300, 170, 8);
    gfx_line(10, 170, 300, 160, 8);

    /* 7. 底部渐变条 */
    gfx_gradient_v(0, 180, 320, 20, 1, 9);

    /* 8. 底部文字 */
    gfx_puts(60, 188, "Circles Ellipses Triangles Gradients", 15);

    /* 提交到显存 */
    gfx_flip();
    serial_puts(0x3F8, "[GFX-DEMO] 图形演示绘制完成并flip提交\n");
    return 0;
}

/* V6.50: 窗口管理器+UI控件演示 — 创建多窗口和控件并渲染 */
u32 sys_wm_demo(u32 arg1, u32 arg2, u32 arg3, u32 arg4)
{
    (void)arg1; (void)arg2; (void)arg3; (void)arg4;
    extern void wm_init(void);
    extern void *wm_create_window(const char *, int, int, int, int);
    extern void *wm_add_button(void *, int, int, int, int, const char *, void *);
    extern void *wm_add_label(void *, int, int, const char *);
    extern void *wm_add_input(void *, int, int, int, const char *);
    extern void *wm_add_checkbox(void *, int, int, const char *, int);
    extern void *wm_add_progress(void *, int, int, int, int, int);
    extern void wm_draw_all(void);
    extern void serial_puts(uint16_t, const char *);

    serial_puts(0x3F8, "[WM-DEMO] 初始化窗口管理器...\n");
    wm_init();

    /* 创建3个测试窗口 */
    serial_puts(0x3F8, "[WM-DEMO] 创建窗口1: File Manager\n");
    wm_create_window("File Manager", 10, 20, 130, 90);

    serial_puts(0x3F8, "[WM-DEMO] 创建窗口2: Terminal\n");
    wm_create_window("Terminal", 40, 45, 110, 70);

    /* 创建控件演示窗口 */
    serial_puts(0x3F8, "[WM-DEMO] 创建窗口3: Control Panel (UI控件演示)\n");
    void *panel = wm_create_window("Control Panel", 160, 30, 140, 150);

    /* 添加UI控件 */
    wm_add_label(panel, 10, 18, "UI Widgets Demo:");
    wm_add_button(panel, 10, 32, 50, 14, "OK", 0);
    wm_add_button(panel, 70, 32, 50, 14, "Cancel", 0);
    wm_add_label(panel, 10, 52, "Name:");
    wm_add_input(panel, 45, 50, 80, "HepuOS");
    wm_add_checkbox(panel, 10, 68, "Enable feature", 1);
    wm_add_checkbox(panel, 10, 82, "Debug mode", 0);
    wm_add_label(panel, 10, 98, "Progress:");
    wm_add_progress(panel, 10, 110, 110, 8, 65);
    wm_add_label(panel, 10, 124, "65% complete");

    /* 绘制所有窗口 */
    serial_puts(0x3F8, "[WM-DEMO] 绘制所有窗口(含UI控件)...\n");
    wm_draw_all();
    serial_puts(0x3F8, "[WM-DEMO] 窗口+控件绘制完成\n");
    return 0;
}

/* V6.50: 贪吃蛇游戏 — 赫普OS第一个游戏，验证图形/输入/窗口子系统 */
u32 sys_game_snake(u32 arg1, u32 arg2, u32 arg3, u32 arg4)
{
    (void)arg2; (void)arg3; (void)arg4;
    extern int snake_game_run(int max_frames);
    extern void serial_puts(uint16_t, const char *);

    int frames = (int)arg1;
    if (frames <= 0) frames = 300;  /* 默认运行300帧约15秒 */

    serial_puts(0x3F8, "[GAME] 启动贪吃蛇游戏...\n");
    int score = snake_game_run(frames);
    serial_puts(0x3F8, "[GAME] 贪吃蛇结束，得分: ");
    /* 简单输出分数 */
    char buf[16];
    int si = 0;
    int s = score;
    if (s == 0) buf[si++] = '0';
    while (s > 0) { buf[si++] = '0' + s % 10; s /= 10; }
    buf[si] = 0;
    /* 反转 */
    for (int i = 0; i < si / 2; i++) {
        char t = buf[i]; buf[i] = buf[si - 1 - i]; buf[si - 1 - i] = t;
    }
    serial_puts(0x3F8, buf);
    serial_puts(0x3F8, "\n");
    return (u32)score;
}

/* V6.50: 俄罗斯方块游戏 — 赫普OS第二个游戏 */
u32 sys_game_tetris(u32 arg1, u32 arg2, u32 arg3, u32 arg4)
{
    (void)arg2; (void)arg3; (void)arg4;
    extern int tetris_game_run(int max_frames);
    extern void serial_puts(uint16_t, const char *);

    int frames = (int)arg1;
    if (frames <= 0) frames = 400;

    serial_puts(0x3F8, "[GAME] 启动俄罗斯方块...\n");
    int score = tetris_game_run(frames);
    serial_puts(0x3F8, "[GAME] 俄罗斯方块结束，得分: ");
    char buf[16];
    int si = 0;
    int s = score;
    if (s == 0) buf[si++] = '0';
    while (s > 0) { buf[si++] = '0' + s % 10; s /= 10; }
    buf[si] = 0;
    for (int i = 0; i < si / 2; i++) {
        char t = buf[i]; buf[i] = buf[si - 1 - i]; buf[si - 1 - i] = t;
    }
    serial_puts(0x3F8, buf);
    serial_puts(0x3F8, "\n");
    return (u32)score;
}

/* V6.50: 扫雷游戏 — 赫普OS第三个游戏 */
u32 sys_game_minesweeper(u32 arg1, u32 arg2, u32 arg3, u32 arg4)
{
    (void)arg2; (void)arg3; (void)arg4;
    extern int minesweeper_game_run(int max_frames);
    extern void serial_puts(uint16_t, const char *);

    int frames = (int)arg1;
    if (frames <= 0) frames = 300;

    serial_puts(0x3F8, "[GAME] 启动扫雷...\n");
    int revealed = minesweeper_game_run(frames);
    serial_puts(0x3F8, "[GAME] 扫雷结束\n");
    return (u32)revealed;
}

