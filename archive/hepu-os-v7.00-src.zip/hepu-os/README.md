# 赫普OS / HEPU Hyper Evolve OS

> 系统归人，数据归己，自由可控，极致纯净

赫普OS是一款自研微内核架构的下一代移动操作系统，致力于打破安卓/iOS双垄断，真正实现用户数据主权、AI原生、安全与自由共存。

## 特性

- **自研纯微内核**：故障隔离，单应用崩溃不影响整机
- **`.hug` 原生应用格式**：轻量化、沙盒强制、权限透明
- **用户数据金库**：系统零收集，隐私绝对主权
- **AI原生基座**：AI是系统底层服务，非外挂APP
- **双模式安全**：普通安全模式 / 创变自由模式一键切换
- **新老设备通刷**：H-HAL硬件抽象层 + H-DPK机型适配包
- **保护性开源**：GPLv3 + 内核只读版权指纹，防止厂商白嫖

## 项目结构

```
hepu-os/
├── docs/                    # 设计文档
│   ├── DESIGN.md            # 完整系统设计文档
│   ├── HUG_FORMAT.md        # .hug应用格式规范
│   └── OPEN_SOURCE_POLICY.md # 开源与厂商分发政策
├── kernel/                  # 微内核源码
│   ├── boot/                # 启动引导 (multiboot)
│   ├── arch/x86/            # x86架构相关
│   ├── mm/                  # 内存管理
│   ├── sched/               # 进程调度
│   ├── ipc/                 # 进程间通信
│   ├── hal/                 # 硬件抽象层 H-HAL
│   └── include/             # 内核头文件
├── services/                # 用户态服务
│   ├── file-server/         # 文件服务
│   ├── net-server/          # 网络服务
│   ├── graphics-server/     # 图形合成服务
│   ├── ai-runtime/          # AI运行时基座
│   └── privacy-vault/       # 隐私数据金库
├── hug-sdk/                 # .hug应用开发工具链
│   ├── spec/                # 格式规范
│   └── tools/               # 打包/解包/校验工具
├── tools/                   # 构建与刷机工具
├── LICENSE                  # GPLv3 许可证
└── Makefile                 # 构建系统
```

## 快速开始

### 环境依赖
- gcc / ld (i686-elf 交叉编译工具链，或系统gcc)
- nasm
- make
- qemu-system-i386（用于运行测试）
- grub-mkrescue（生成ISO镜像，可选）

### 编译内核原型
```bash
make            # 编译内核，生成 build/hepu-kernel.bin
make run        # 在 QEMU 中启动
make iso        # 生成可启动 ISO 镜像（需要grub）
```

### 使用 .hug 工具
```bash
python3 hug-sdk/tools/hugtool.py info example.hug
python3 hug-sdk/tools/hugtool.py pack ./myapp myapp.hug
python3 hug-sdk/tools/hugtool.py verify myapp.hug
```

## 当前状态

本项目为**原型阶段**，已实现：
- ✅ Multiboot 可启动微内核骨架
- ✅ VGA 文本模式输出
- ✅ 基础内核打印函数
- ✅ 全局描述符表(GDT)框架
- ✅ 中断描述符表(IDT)框架
- ✅ 内核只读版权指纹
- ✅ `.hug` 格式规范与Python工具链
- ✅ 完整设计文档与开源政策

待实现：
- 内存管理（分页、物理页分配）
- 进程调度与上下文切换
- IPC消息传递
- 用户态服务框架
- H-HAL硬件抽象层完整实现
- 文件系统
- 网络协议栈
- 图形子系统
- AI运行时

## 开源协议

核心代码采用 **GPLv3** 许可证，附加赫普OS补充条款（详见 `docs/OPEN_SOURCE_POLICY.md`）。

## 系统框架图

> 系统结构总览：五层分层隔离架构（应用生态 / AI基座 / 系统服务 / 微内核 / 硬件引导链）+ 安全体系。

[查看系统框架图（SVG）](docs/diagrams/hepu-system-architecture.svg) ｜ [PNG 版](docs/diagrams/hepu-system-architecture.png)

## 文档

> 完整文档导航见 [docs/INDEX.md](docs/INDEX.md)；开发待办与未完成项见 [docs/TODO.md](docs/TODO.md)。

- [项目文档导航（推荐入口）](docs/INDEX.md)
- [开发待办与项目记录](docs/TODO.md)
- [系统设计文档（活文档·迭代史）](docs/DESIGN.md)
- [系统设计规范（V1.11 定稿）](docs/DESIGN_V1.11.md)
- [GUI 设计总纲](docs/GUI_DESIGN.md)
- [.hug应用格式规范](docs/HUG_FORMAT.md)
- [开源与厂商分发政策](docs/OPEN_SOURCE_POLICY.md)
- [安装与试用指南](docs/INSTALL_GUIDE.md)
- [品牌视觉识别规范](docs/BRAND_GUIDE.md)

## 命名释义

- **赫**：赫然革新、突破壁垒
- **普**：普惠自由、全设备通用
- **HEPU**：Hyper Evolve Pure Union
