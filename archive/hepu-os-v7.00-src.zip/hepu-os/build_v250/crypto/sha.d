build_v250/crypto/sha.o: kernel/crypto/sha.c kernel/include/sha.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/sha.h:
kernel/include/vga.h:
kernel/include/string.h:
