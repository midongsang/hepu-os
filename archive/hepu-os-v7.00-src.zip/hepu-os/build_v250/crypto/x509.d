build_v250/crypto/x509.o: kernel/crypto/x509.c kernel/include/x509.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/x509.h:
kernel/include/vga.h:
kernel/include/string.h:
