build_v250/crypto/hkdf.o: kernel/crypto/hkdf.c kernel/include/hkdf.h \
 kernel/include/sha.h kernel/include/hmac.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/hkdf.h:
kernel/include/sha.h:
kernel/include/hmac.h:
kernel/include/vga.h:
kernel/include/string.h:
