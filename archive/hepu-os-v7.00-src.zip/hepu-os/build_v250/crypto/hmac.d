build_v250/crypto/hmac.o: kernel/crypto/hmac.c kernel/include/hmac.h \
 kernel/include/sha.h kernel/include/vga.h kernel/include/string.h
kernel/include/hmac.h:
kernel/include/sha.h:
kernel/include/vga.h:
kernel/include/string.h:
