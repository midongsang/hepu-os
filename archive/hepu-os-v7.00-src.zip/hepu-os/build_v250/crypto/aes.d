build_v250/crypto/aes.o: kernel/crypto/aes.c kernel/include/aes.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/aes.h:
kernel/include/vga.h:
kernel/include/string.h:
