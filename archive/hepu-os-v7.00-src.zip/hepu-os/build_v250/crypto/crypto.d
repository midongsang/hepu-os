build_v250/crypto/crypto.o: kernel/crypto/crypto.c \
 kernel/include/string.h kernel/include/crypto.h kernel/include/vga.h
kernel/include/string.h:
kernel/include/crypto.h:
kernel/include/vga.h:
