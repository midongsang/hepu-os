build_v250/crypto/csprng.o: kernel/crypto/csprng.c \
 kernel/include/csprng.h kernel/include/vga.h kernel/include/string.h
kernel/include/csprng.h:
kernel/include/vga.h:
kernel/include/string.h:
