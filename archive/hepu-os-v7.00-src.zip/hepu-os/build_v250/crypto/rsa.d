build_v250/crypto/rsa.o: kernel/crypto/rsa.c kernel/include/rsa.h \
 kernel/include/sha.h kernel/include/vga.h kernel/include/string.h
kernel/include/rsa.h:
kernel/include/sha.h:
kernel/include/vga.h:
kernel/include/string.h:
