build_v250/crypto/sha512.o: kernel/crypto/sha512.c kernel/include/sha.h \
 kernel/include/string.h
kernel/include/sha.h:
kernel/include/string.h:
