build_v250/crypto/ecdhe.o: kernel/crypto/ecdhe.c kernel/include/ecdhe.h \
 kernel/include/csprng.h kernel/include/vga.h kernel/include/string.h
kernel/include/ecdhe.h:
kernel/include/csprng.h:
kernel/include/vga.h:
kernel/include/string.h:
