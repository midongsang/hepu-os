build_v250/block/iosched.o: kernel/block/iosched.c \
 kernel/include/iosched.h kernel/include/ide.h kernel/include/kheap.h \
 kernel/include/string.h
kernel/include/iosched.h:
kernel/include/ide.h:
kernel/include/kheap.h:
kernel/include/string.h:
