build_v250/block/blk_mq.o: kernel/block/blk_mq.c kernel/include/string.h \
 kernel/include/blk_mq.h kernel/include/kheap.h kernel/include/vga.h
kernel/include/string.h:
kernel/include/blk_mq.h:
kernel/include/kheap.h:
kernel/include/vga.h:
