build_v250/mm/buddy.o: kernel/mm/buddy.c kernel/include/mm.h
kernel/include/mm.h:
