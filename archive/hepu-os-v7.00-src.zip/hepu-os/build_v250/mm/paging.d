build_v250/mm/paging.o: kernel/mm/paging.c kernel/include/paging.h \
 kernel/include/process.h kernel/include/paging.h \
 kernel/include/constants.h kernel/include/mm.h kernel/include/kheap.h \
 kernel/include/string.h kernel/include/vga.h kernel/include/pae.h
kernel/include/paging.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
kernel/include/mm.h:
kernel/include/kheap.h:
kernel/include/string.h:
kernel/include/vga.h:
kernel/include/pae.h:
