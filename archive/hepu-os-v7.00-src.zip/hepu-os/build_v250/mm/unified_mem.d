build_v250/mm/unified_mem.o: kernel/mm/unified_mem.c \
 kernel/include/string.h kernel/include/unified_mem.h \
 kernel/include/kheap.h kernel/include/vga.h
kernel/include/string.h:
kernel/include/unified_mem.h:
kernel/include/kheap.h:
kernel/include/vga.h:
