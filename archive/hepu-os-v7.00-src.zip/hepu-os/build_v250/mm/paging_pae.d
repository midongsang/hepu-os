build_v250/mm/paging_pae.o: kernel/mm/paging_pae.c \
 kernel/include/string.h kernel/include/paging.h kernel/include/pae.h \
 kernel/include/kheap.h kernel/include/vga.h kernel/include/serial.h
kernel/include/string.h:
kernel/include/paging.h:
kernel/include/pae.h:
kernel/include/kheap.h:
kernel/include/vga.h:
kernel/include/serial.h:
