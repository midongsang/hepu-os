build_v250/mm/swap.o: kernel/mm/swap.c kernel/include/swap.h \
 kernel/include/mm.h kernel/include/vga.h kernel/include/string.h \
 kernel/include/reclaim.h kernel/include/kheap.h
kernel/include/swap.h:
kernel/include/mm.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/reclaim.h:
kernel/include/kheap.h:
