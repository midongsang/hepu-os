build_v250/mm/mempool.o: kernel/mm/mempool.c kernel/include/mempool.h \
 kernel/include/kheap.h kernel/include/vga.h
kernel/include/mempool.h:
kernel/include/kheap.h:
kernel/include/vga.h:
