build_v250/mm/page_cache.o: kernel/mm/page_cache.c \
 kernel/include/page_cache.h
kernel/include/page_cache.h:
