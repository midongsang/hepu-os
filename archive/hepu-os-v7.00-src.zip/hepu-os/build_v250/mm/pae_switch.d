build_v250/mm/pae_switch.o: kernel/mm/pae_switch.c \
 kernel/include/paging.h kernel/include/pae.h kernel/include/vga.h \
 kernel/include/serial.h
kernel/include/paging.h:
kernel/include/pae.h:
kernel/include/vga.h:
kernel/include/serial.h:
