build_v250/mm/reclaim.o: kernel/mm/reclaim.c kernel/include/reclaim.h \
 kernel/include/mm.h kernel/include/vga.h kernel/include/string.h
kernel/include/reclaim.h:
kernel/include/mm.h:
kernel/include/vga.h:
kernel/include/string.h:
