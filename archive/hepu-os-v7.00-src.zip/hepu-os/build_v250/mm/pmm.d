build_v250/mm/pmm.o: kernel/mm/pmm.c kernel/include/mm.h \
 kernel/include/vga.h
kernel/include/mm.h:
kernel/include/vga.h:
