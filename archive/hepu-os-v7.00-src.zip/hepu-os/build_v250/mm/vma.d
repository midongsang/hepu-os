build_v250/mm/vma.o: kernel/mm/vma.c kernel/include/vma.h \
 kernel/include/kheap.h kernel/include/string.h kernel/include/vga.h \
 kernel/include/paging.h kernel/include/mm.h
kernel/include/vma.h:
kernel/include/kheap.h:
kernel/include/string.h:
kernel/include/vga.h:
kernel/include/paging.h:
kernel/include/mm.h:
