build_v250/mm/slab.o: kernel/mm/slab.c kernel/include/slab.h \
 kernel/include/kheap.h kernel/include/mm.h kernel/include/string.h \
 kernel/include/vga.h
kernel/include/slab.h:
kernel/include/kheap.h:
kernel/include/mm.h:
kernel/include/string.h:
kernel/include/vga.h:
