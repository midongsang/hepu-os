build_v250/mm/paging_compat.o: kernel/mm/paging_compat.c \
 kernel/include/paging.h kernel/include/pae.h kernel/include/vga.h \
 kernel/include/serial.h
kernel/include/paging.h:
kernel/include/pae.h:
kernel/include/vga.h:
kernel/include/serial.h:
