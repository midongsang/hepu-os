build_v250/mm/kheap.o: kernel/mm/kheap.c kernel/include/kheap.h \
 kernel/include/string.h kernel/include/smp.h kernel/include/vga.h
kernel/include/kheap.h:
kernel/include/string.h:
kernel/include/smp.h:
kernel/include/vga.h:
