build_v250/mm/hugetlb.o: kernel/mm/hugetlb.c kernel/include/hugetlb.h \
 kernel/include/paging.h kernel/include/mm.h kernel/include/paging.h \
 kernel/include/cpu.h kernel/include/vga.h kernel/include/string.h
kernel/include/hugetlb.h:
kernel/include/paging.h:
kernel/include/mm.h:
kernel/include/paging.h:
kernel/include/cpu.h:
kernel/include/vga.h:
kernel/include/string.h:
