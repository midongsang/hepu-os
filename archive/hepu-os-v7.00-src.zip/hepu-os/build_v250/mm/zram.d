build_v250/mm/zram.o: kernel/mm/zram.c kernel/include/zram.h \
 kernel/include/kheap.h kernel/include/string.h kernel/include/vga.h
kernel/include/zram.h:
kernel/include/kheap.h:
kernel/include/string.h:
kernel/include/vga.h:
