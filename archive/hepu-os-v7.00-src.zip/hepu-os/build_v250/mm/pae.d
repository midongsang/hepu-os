build_v250/mm/pae.o: kernel/mm/pae.c kernel/include/string.h \
 kernel/include/vga.h kernel/include/kheap.h kernel/include/serial.h
kernel/include/string.h:
kernel/include/vga.h:
kernel/include/kheap.h:
kernel/include/serial.h:
