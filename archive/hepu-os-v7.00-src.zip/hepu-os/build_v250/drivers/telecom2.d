build_v250/drivers/telecom2.o: kernel/drivers/telecom2.c \
 kernel/include/telecom2.h kernel/include/vga.h kernel/include/string.h
kernel/include/telecom2.h:
kernel/include/vga.h:
kernel/include/string.h:
