build_v250/drivers/ide.o: kernel/drivers/ide.c kernel/include/ide.h \
 kernel/include/vga.h kernel/include/string.h kernel/include/serial.h
kernel/include/ide.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/serial.h:
