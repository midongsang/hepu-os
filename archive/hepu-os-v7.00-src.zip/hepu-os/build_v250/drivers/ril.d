build_v250/drivers/ril.o: kernel/drivers/ril.c kernel/include/ril.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/ril.h:
kernel/include/vga.h:
kernel/include/string.h:
