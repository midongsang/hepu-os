build_v250/drivers/touch_hw.o: kernel/drivers/touch_hw.c \
 kernel/include/touch_hw.h kernel/include/input.h kernel/include/input.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/touch_hw.h:
kernel/include/input.h:
kernel/include/input.h:
kernel/include/vga.h:
kernel/include/string.h:
