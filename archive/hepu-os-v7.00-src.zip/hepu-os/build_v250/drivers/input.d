build_v250/drivers/input.o: kernel/drivers/input.c kernel/include/input.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/input.h:
kernel/include/vga.h:
kernel/include/string.h:
