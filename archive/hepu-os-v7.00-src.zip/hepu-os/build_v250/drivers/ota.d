build_v250/drivers/ota.o: kernel/drivers/ota.c kernel/include/ota.h \
 kernel/include/vga.h kernel/include/string.h kernel/include/kheap.h
kernel/include/ota.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kheap.h:
