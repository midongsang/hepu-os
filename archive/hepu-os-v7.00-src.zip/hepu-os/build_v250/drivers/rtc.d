build_v250/drivers/rtc.o: kernel/drivers/rtc.c kernel/include/rtc.h \
 kernel/include/vga.h
kernel/include/rtc.h:
kernel/include/vga.h:
