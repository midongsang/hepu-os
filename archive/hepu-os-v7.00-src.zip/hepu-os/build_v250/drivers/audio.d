build_v250/drivers/audio.o: kernel/drivers/audio.c kernel/include/audio.h \
 kernel/include/vga.h kernel/include/string.h kernel/include/kheap.h \
 kernel/include/pit.h
kernel/include/audio.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kheap.h:
kernel/include/pit.h:
