build_v250/drivers/touch.o: kernel/drivers/touch.c kernel/include/touch.h \
 kernel/include/vga.h kernel/include/irq.h kernel/include/string.h
kernel/include/touch.h:
kernel/include/vga.h:
kernel/include/irq.h:
kernel/include/string.h:
