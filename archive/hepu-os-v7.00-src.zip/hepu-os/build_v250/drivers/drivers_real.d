build_v250/drivers/drivers_real.o: kernel/drivers/drivers_real.c \
 kernel/include/drivers_real.h kernel/include/constants.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/drivers_real.h:
kernel/include/constants.h:
kernel/include/vga.h:
kernel/include/string.h:
