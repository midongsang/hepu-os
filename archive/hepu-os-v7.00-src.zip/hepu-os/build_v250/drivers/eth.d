build_v250/drivers/eth.o: kernel/drivers/eth.c kernel/include/eth.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/eth.h:
kernel/include/vga.h:
kernel/include/string.h:
