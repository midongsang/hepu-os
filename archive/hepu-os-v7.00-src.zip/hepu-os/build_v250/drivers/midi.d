build_v250/drivers/midi.o: kernel/drivers/midi.c kernel/include/audio2.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/audio2.h:
kernel/include/vga.h:
kernel/include/string.h:
