build_v250/drivers/gpu.o: kernel/drivers/gpu.c kernel/include/gpu.h \
 kernel/include/vga.h kernel/include/string.h kernel/include/kheap.h
kernel/include/gpu.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kheap.h:
