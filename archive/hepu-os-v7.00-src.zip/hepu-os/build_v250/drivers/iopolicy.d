build_v250/drivers/iopolicy.o: kernel/drivers/iopolicy.c \
 kernel/include/iopolicy.h kernel/include/vga.h kernel/include/string.h \
 kernel/include/serial.h
kernel/include/iopolicy.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/serial.h:
