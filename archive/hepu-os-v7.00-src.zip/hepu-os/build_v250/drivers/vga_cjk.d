build_v250/drivers/vga_cjk.o: kernel/drivers/vga_cjk.c \
 kernel/include/font_cjk16.h kernel/include/font_cjk_big.h \
 kernel/include/font_cjk16.h kernel/include/vga.h
kernel/include/font_cjk16.h:
kernel/include/font_cjk_big.h:
kernel/include/font_cjk16.h:
kernel/include/vga.h:
