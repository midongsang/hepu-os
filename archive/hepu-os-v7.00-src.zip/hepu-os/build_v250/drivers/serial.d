build_v250/drivers/serial.o: kernel/drivers/serial.c \
 kernel/include/serial.h kernel/include/vga.h
kernel/include/serial.h:
kernel/include/vga.h:
