build_v250/drivers/storage_vram.o: kernel/drivers/storage_vram.c \
 kernel/include/string.h kernel/include/vga.h kernel/include/kheap.h \
 kernel/include/serial.h
kernel/include/string.h:
kernel/include/vga.h:
kernel/include/kheap.h:
kernel/include/serial.h:
