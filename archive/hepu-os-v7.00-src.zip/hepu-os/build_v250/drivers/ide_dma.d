build_v250/drivers/ide_dma.o: kernel/drivers/ide_dma.c \
 kernel/include/ide.h kernel/include/vga.h kernel/include/string.h \
 kernel/include/serial.h
kernel/include/ide.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/serial.h:
