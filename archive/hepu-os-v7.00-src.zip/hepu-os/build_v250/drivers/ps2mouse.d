build_v250/drivers/ps2mouse.o: kernel/drivers/ps2mouse.c \
 kernel/include/ps2mouse.h kernel/include/vga.h
kernel/include/ps2mouse.h:
kernel/include/vga.h:
