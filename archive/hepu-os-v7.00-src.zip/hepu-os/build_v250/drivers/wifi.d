build_v250/drivers/wifi.o: kernel/drivers/wifi.c kernel/include/wifi.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/wifi.h:
kernel/include/vga.h:
kernel/include/string.h:
