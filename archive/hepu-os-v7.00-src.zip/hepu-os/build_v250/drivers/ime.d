build_v250/drivers/ime.o: kernel/drivers/ime.c kernel/include/vga.h \
 kernel/include/string.h
kernel/include/vga.h:
kernel/include/string.h:
