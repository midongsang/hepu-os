build_v250/drivers/codec.o: kernel/drivers/codec.c kernel/include/codec.h \
 kernel/include/vga.h kernel/include/string.h kernel/include/kheap.h
kernel/include/codec.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kheap.h:
