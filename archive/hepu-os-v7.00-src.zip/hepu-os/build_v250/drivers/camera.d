build_v250/drivers/camera.o: kernel/drivers/camera.c \
 kernel/include/camera.h kernel/include/vga.h kernel/include/string.h \
 kernel/include/kheap.h
kernel/include/camera.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kheap.h:
