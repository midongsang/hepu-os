build_v250/drivers/audio2_advanced.o: kernel/drivers/audio2_advanced.c \
 kernel/include/audio2.h kernel/include/vga.h kernel/include/string.h
kernel/include/audio2.h:
kernel/include/vga.h:
kernel/include/string.h:
