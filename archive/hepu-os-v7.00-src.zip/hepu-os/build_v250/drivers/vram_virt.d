build_v250/drivers/vram_virt.o: kernel/drivers/vram_virt.c \
 kernel/include/string.h kernel/include/vram_virt.h kernel/include/vram.h \
 kernel/include/kheap.h kernel/include/vga.h
kernel/include/string.h:
kernel/include/vram_virt.h:
kernel/include/vram.h:
kernel/include/kheap.h:
kernel/include/vga.h:
