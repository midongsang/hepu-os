build_v250/drivers/dtb.o: kernel/drivers/dtb.c kernel/include/dtb.h \
 kernel/include/vga.h kernel/include/string.h kernel/include/kstdio.h
kernel/include/dtb.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kstdio.h:
