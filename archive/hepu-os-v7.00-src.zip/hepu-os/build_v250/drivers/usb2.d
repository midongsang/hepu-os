build_v250/drivers/usb2.o: kernel/drivers/usb2.c kernel/include/usb2.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/usb2.h:
kernel/include/vga.h:
kernel/include/string.h:
