build_v250/drivers/pci_bind.o: kernel/drivers/pci_bind.c \
 kernel/include/pci.h kernel/include/hal_device.h kernel/include/vga.h
kernel/include/pci.h:
kernel/include/hal_device.h:
kernel/include/vga.h:
