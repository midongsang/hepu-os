build_v250/drivers/unified_driver.o: kernel/drivers/unified_driver.c \
 kernel/include/unified_driver.h kernel/include/driver_manager.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/unified_driver.h:
kernel/include/driver_manager.h:
kernel/include/vga.h:
kernel/include/string.h:
