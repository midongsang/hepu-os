build_v250/drivers/usb_hid.o: kernel/drivers/usb_hid.c \
 kernel/include/usb.h kernel/include/vga.h
kernel/include/usb.h:
kernel/include/vga.h:
