build_v250/drivers/virtual_vram.o: kernel/drivers/virtual_vram.c \
 kernel/include/string.h kernel/include/virtual_vram.h \
 kernel/include/vram.h kernel/include/kheap.h kernel/include/vga.h \
 kernel/include/storage_vram.h
kernel/include/string.h:
kernel/include/virtual_vram.h:
kernel/include/vram.h:
kernel/include/kheap.h:
kernel/include/vga.h:
kernel/include/storage_vram.h:
