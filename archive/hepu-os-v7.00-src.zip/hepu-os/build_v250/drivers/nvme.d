build_v250/drivers/nvme.o: kernel/drivers/nvme.c kernel/include/nvme.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/nvme.h:
kernel/include/vga.h:
kernel/include/string.h:
