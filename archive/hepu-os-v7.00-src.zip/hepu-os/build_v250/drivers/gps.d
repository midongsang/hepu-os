build_v250/drivers/gps.o: kernel/drivers/gps.c kernel/include/gps.h \
 kernel/include/vga.h kernel/include/string.h kernel/include/pit.h
kernel/include/gps.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/pit.h:
