build_v250/drivers/audio2.o: kernel/drivers/audio2.c \
 kernel/include/audio2.h kernel/include/vga.h kernel/include/string.h
kernel/include/audio2.h:
kernel/include/vga.h:
kernel/include/string.h:
