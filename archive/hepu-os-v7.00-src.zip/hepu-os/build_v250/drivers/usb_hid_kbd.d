build_v250/drivers/usb_hid_kbd.o: kernel/drivers/usb_hid_kbd.c \
 kernel/include/usb.h kernel/include/vga.h kernel/include/serial.h
kernel/include/usb.h:
kernel/include/vga.h:
kernel/include/serial.h:
