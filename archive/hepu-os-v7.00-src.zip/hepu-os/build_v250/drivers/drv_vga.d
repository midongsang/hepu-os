build_v250/drivers/drv_vga.o: kernel/drivers/drv_vga.c \
 kernel/include/drivers_real.h kernel/include/vga.h \
 kernel/include/string.h kernel/include/constants.h
kernel/include/drivers_real.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/constants.h:
