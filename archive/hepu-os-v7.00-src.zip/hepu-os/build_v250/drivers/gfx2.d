build_v250/drivers/gfx2.o: kernel/drivers/gfx2.c kernel/include/gfx2.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/gfx2.h:
kernel/include/vga.h:
kernel/include/string.h:
