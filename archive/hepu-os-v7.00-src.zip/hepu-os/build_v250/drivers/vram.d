build_v250/drivers/vram.o: kernel/drivers/vram.c kernel/include/vram.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/vram.h:
kernel/include/vga.h:
kernel/include/string.h:
