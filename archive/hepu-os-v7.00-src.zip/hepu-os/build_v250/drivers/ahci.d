build_v250/drivers/ahci.o: kernel/drivers/ahci.c kernel/include/ahci.h \
 kernel/include/vga.h kernel/include/string.h kernel/include/pci.h \
 kernel/include/mm.h kernel/include/paging.h
kernel/include/ahci.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/pci.h:
kernel/include/mm.h:
kernel/include/paging.h:
