build_v250/drivers/partition.o: kernel/drivers/partition.c \
 kernel/include/partition.h kernel/include/vga.h kernel/include/string.h \
 kernel/include/kstdio.h
kernel/include/partition.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kstdio.h:
