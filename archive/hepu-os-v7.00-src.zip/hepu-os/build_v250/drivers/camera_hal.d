build_v250/drivers/camera_hal.o: kernel/drivers/camera_hal.c \
 kernel/include/camera_hal.h kernel/include/vga.h kernel/include/string.h \
 kernel/include/kheap.h
kernel/include/camera_hal.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kheap.h:
