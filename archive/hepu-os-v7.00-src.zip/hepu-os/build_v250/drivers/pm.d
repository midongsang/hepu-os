build_v250/drivers/pm.o: kernel/drivers/pm.c kernel/include/pm.h \
 kernel/include/vga.h kernel/include/pit.h kernel/include/serial.h \
 kernel/include/string.h kernel/include/app_freeze.h \
 kernel/include/process.h kernel/include/paging.h \
 kernel/include/constants.h
kernel/include/pm.h:
kernel/include/vga.h:
kernel/include/pit.h:
kernel/include/serial.h:
kernel/include/string.h:
kernel/include/app_freeze.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
