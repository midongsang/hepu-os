build_v250/drivers/sensors.o: kernel/drivers/sensors.c \
 kernel/include/sensors.h kernel/include/vga.h kernel/include/string.h \
 kernel/include/pit.h
kernel/include/sensors.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/pit.h:
