build_v250/drivers/camera2.o: kernel/drivers/camera2.c \
 kernel/include/camera2.h kernel/include/vga.h kernel/include/string.h
kernel/include/camera2.h:
kernel/include/vga.h:
kernel/include/string.h:
