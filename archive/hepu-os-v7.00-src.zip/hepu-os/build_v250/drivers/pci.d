build_v250/drivers/pci.o: kernel/drivers/pci.c kernel/include/pci.h \
 kernel/include/vga.h
kernel/include/pci.h:
kernel/include/vga.h:
