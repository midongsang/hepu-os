build_v250/drivers/compositor.o: kernel/drivers/compositor.c \
 kernel/include/compositor.h kernel/include/vga.h kernel/include/string.h \
 kernel/include/kheap.h
kernel/include/compositor.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kheap.h:
