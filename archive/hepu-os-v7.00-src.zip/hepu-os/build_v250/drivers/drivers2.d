build_v250/drivers/drivers2.o: kernel/drivers/drivers2.c \
 kernel/include/drivers2.h kernel/include/vga.h kernel/include/string.h
kernel/include/drivers2.h:
kernel/include/vga.h:
kernel/include/string.h:
