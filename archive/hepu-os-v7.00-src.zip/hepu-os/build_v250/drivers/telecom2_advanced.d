build_v250/drivers/telecom2_advanced.o: \
 kernel/drivers/telecom2_advanced.c kernel/include/telecom2.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/telecom2.h:
kernel/include/vga.h:
kernel/include/string.h:
