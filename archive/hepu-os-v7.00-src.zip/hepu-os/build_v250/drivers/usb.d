build_v250/drivers/usb.o: kernel/drivers/usb.c kernel/include/usb.h \
 kernel/include/pci.h kernel/include/vga.h kernel/include/serial.h \
 kernel/include/string.h kernel/include/kheap.h
kernel/include/usb.h:
kernel/include/pci.h:
kernel/include/vga.h:
kernel/include/serial.h:
kernel/include/string.h:
kernel/include/kheap.h:
