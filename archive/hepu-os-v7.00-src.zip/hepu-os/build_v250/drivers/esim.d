build_v250/drivers/esim.o: kernel/drivers/esim.c \
 kernel/include/telecom2.h kernel/include/vga.h kernel/include/string.h
kernel/include/telecom2.h:
kernel/include/vga.h:
kernel/include/string.h:
