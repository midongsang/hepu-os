build_v250/drivers/trace.o: kernel/drivers/trace.c kernel/include/trace.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/trace.h:
kernel/include/vga.h:
kernel/include/string.h:
