build_v250/drivers/media.o: kernel/drivers/media.c kernel/include/media.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/media.h:
kernel/include/vga.h:
kernel/include/string.h:
