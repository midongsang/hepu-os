build_v250/drivers/media2.o: kernel/drivers/media2.c \
 kernel/include/media2.h kernel/include/vga.h kernel/include/string.h
kernel/include/media2.h:
kernel/include/vga.h:
kernel/include/string.h:
