build_v250/loader/dynld.o: kernel/loader/dynld.c kernel/include/dynld.h \
 kernel/include/vga.h kernel/include/string.h kernel/include/kheap.h
kernel/include/dynld.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kheap.h:
