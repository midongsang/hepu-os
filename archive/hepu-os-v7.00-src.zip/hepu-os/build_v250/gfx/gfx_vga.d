build_v250/gfx/gfx_vga.o: kernel/gfx/gfx_vga.c kernel/include/string.h \
 kernel/include/graphics.h kernel/include/serial.h
kernel/include/string.h:
kernel/include/graphics.h:
kernel/include/serial.h:
