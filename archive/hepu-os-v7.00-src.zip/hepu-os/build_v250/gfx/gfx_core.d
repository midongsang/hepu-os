build_v250/gfx/gfx_core.o: kernel/gfx/gfx_core.c kernel/include/string.h \
 kernel/include/graphics.h kernel/include/vga.h kernel/include/kheap.h \
 kernel/include/serial.h
kernel/include/string.h:
kernel/include/graphics.h:
kernel/include/vga.h:
kernel/include/kheap.h:
kernel/include/serial.h:
