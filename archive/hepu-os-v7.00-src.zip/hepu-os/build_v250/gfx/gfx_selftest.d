build_v250/gfx/gfx_selftest.o: kernel/gfx/gfx_selftest.c \
 kernel/include/string.h kernel/include/graphics.h \
 kernel/include/serial.h kernel/include/vga.h
kernel/include/string.h:
kernel/include/graphics.h:
kernel/include/serial.h:
kernel/include/vga.h:
