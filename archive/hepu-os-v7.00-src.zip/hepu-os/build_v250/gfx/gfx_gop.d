build_v250/gfx/gfx_gop.o: kernel/gfx/gfx_gop.c kernel/include/string.h \
 kernel/include/graphics.h kernel/include/vga_gfx.h \
 kernel/include/serial.h
kernel/include/string.h:
kernel/include/graphics.h:
kernel/include/vga_gfx.h:
kernel/include/serial.h:
