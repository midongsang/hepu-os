build_v250/boot/early_console.o: kernel/boot/early_console.c \
 kernel/include/early_console.h
kernel/include/early_console.h:
