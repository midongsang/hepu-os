build_v250/boot/acpi.o: kernel/boot/acpi.c kernel/include/acpi.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/acpi.h:
kernel/include/vga.h:
kernel/include/string.h:
