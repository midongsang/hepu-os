build_v250/boot/cpu.o: kernel/boot/cpu.c kernel/include/cpu.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/cpu.h:
kernel/include/vga.h:
kernel/include/string.h:
