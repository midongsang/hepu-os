build_v250/boot/multiboot.o: kernel/boot/multiboot.c \
 kernel/include/multiboot.h kernel/include/vga.h kernel/include/string.h \
 kernel/include/kstdio.h
kernel/include/multiboot.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kstdio.h:
