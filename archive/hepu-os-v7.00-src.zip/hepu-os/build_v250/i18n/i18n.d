build_v250/i18n/i18n.o: kernel/i18n/i18n.c kernel/include/i18n.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/i18n.h:
kernel/include/vga.h:
kernel/include/string.h:
