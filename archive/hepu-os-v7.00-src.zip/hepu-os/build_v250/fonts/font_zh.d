build_v250/fonts/font_zh.o: kernel/fonts/font_zh.c \
 kernel/include/font_zh.h kernel/include/vga_gfx.h \
 kernel/fonts/font_zh_data.h
kernel/include/font_zh.h:
kernel/include/vga_gfx.h:
kernel/fonts/font_zh_data.h:
