build_v250/net/http2.o: kernel/net/http2.c kernel/include/http2.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/http2.h:
kernel/include/vga.h:
kernel/include/string.h:
