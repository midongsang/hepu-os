build_v250/net/http3.o: kernel/net/http3.c kernel/include/types.h \
 kernel/include/http3.h kernel/include/types.h kernel/include/quic.h \
 kernel/include/quic.h kernel/include/vga.h kernel/include/string.h
kernel/include/types.h:
kernel/include/http3.h:
kernel/include/types.h:
kernel/include/quic.h:
kernel/include/quic.h:
kernel/include/vga.h:
kernel/include/string.h:
