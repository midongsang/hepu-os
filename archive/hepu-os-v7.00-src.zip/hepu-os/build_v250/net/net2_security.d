build_v250/net/net2_security.o: kernel/net/net2_security.c \
 kernel/include/net2.h kernel/include/vga.h kernel/include/string.h
kernel/include/net2.h:
kernel/include/vga.h:
kernel/include/string.h:
