build_v250/net/dns.o: kernel/net/dns.c kernel/include/dns.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/dns.h:
kernel/include/vga.h:
kernel/include/string.h:
