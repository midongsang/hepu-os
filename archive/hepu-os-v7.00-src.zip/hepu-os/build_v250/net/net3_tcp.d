build_v250/net/net3_tcp.o: kernel/net/net3_tcp.c kernel/include/net3.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/net3.h:
kernel/include/vga.h:
kernel/include/string.h:
