build_v250/net/dhcp.o: kernel/net/dhcp.c kernel/include/dhcp.h \
 kernel/include/eth.h kernel/include/vga.h kernel/include/string.h
kernel/include/dhcp.h:
kernel/include/eth.h:
kernel/include/vga.h:
kernel/include/string.h:
