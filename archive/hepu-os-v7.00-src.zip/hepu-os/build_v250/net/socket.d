build_v250/net/socket.o: kernel/net/socket.c kernel/include/socket.h \
 kernel/include/vga.h kernel/include/string.h kernel/include/kheap.h
kernel/include/socket.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kheap.h:
