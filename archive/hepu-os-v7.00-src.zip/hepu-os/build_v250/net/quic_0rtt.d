build_v250/net/quic_0rtt.o: kernel/net/quic_0rtt.c kernel/include/types.h \
 kernel/include/quic_0rtt.h kernel/include/types.h kernel/include/quic.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/types.h:
kernel/include/quic_0rtt.h:
kernel/include/types.h:
kernel/include/quic.h:
kernel/include/vga.h:
kernel/include/string.h:
