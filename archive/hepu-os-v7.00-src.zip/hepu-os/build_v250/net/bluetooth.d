build_v250/net/bluetooth.o: kernel/net/bluetooth.c \
 kernel/include/bluetooth.h kernel/include/vga.h kernel/include/string.h \
 kernel/include/kheap.h
kernel/include/bluetooth.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kheap.h:
