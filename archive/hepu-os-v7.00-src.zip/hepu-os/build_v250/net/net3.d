build_v250/net/net3.o: kernel/net/net3.c kernel/include/types.h \
 kernel/include/net3.h kernel/include/vga.h kernel/include/string.h
kernel/include/types.h:
kernel/include/net3.h:
kernel/include/vga.h:
kernel/include/string.h:
