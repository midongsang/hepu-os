build_v250/net/icmp.o: kernel/net/icmp.c kernel/include/icmp.h \
 kernel/include/dns.h kernel/include/vga.h kernel/include/string.h
kernel/include/icmp.h:
kernel/include/dns.h:
kernel/include/vga.h:
kernel/include/string.h:
