build_v250/net/net2.o: kernel/net/net2.c kernel/include/net2.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/net2.h:
kernel/include/vga.h:
kernel/include/string.h:
