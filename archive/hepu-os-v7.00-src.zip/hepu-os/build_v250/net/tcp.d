build_v250/net/tcp.o: kernel/net/tcp.c kernel/include/tcp.h \
 kernel/include/vga.h kernel/include/string.h kernel/include/kheap.h
kernel/include/tcp.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kheap.h:
