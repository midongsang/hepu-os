build_v250/net/webengine.o: kernel/net/webengine.c \
 kernel/include/webengine.h kernel/include/vga.h kernel/include/string.h \
 kernel/include/kheap.h
kernel/include/webengine.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kheap.h:
