build_v250/net/quic_recovery.o: kernel/net/quic_recovery.c \
 kernel/include/types.h kernel/include/quic_recovery.h \
 kernel/include/types.h kernel/include/quic.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/types.h:
kernel/include/quic_recovery.h:
kernel/include/types.h:
kernel/include/quic.h:
kernel/include/vga.h:
kernel/include/string.h:
