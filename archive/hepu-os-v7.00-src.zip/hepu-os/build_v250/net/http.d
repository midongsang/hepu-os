build_v250/net/http.o: kernel/net/http.c kernel/include/http.h \
 kernel/include/dns.h kernel/include/vga.h kernel/include/string.h \
 kernel/include/kstdio.h
kernel/include/http.h:
kernel/include/dns.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kstdio.h:
