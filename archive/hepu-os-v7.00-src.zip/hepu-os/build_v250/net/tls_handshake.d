build_v250/net/tls_handshake.o: kernel/net/tls_handshake.c \
 kernel/include/tls_handshake.h kernel/include/ecdhe.h \
 kernel/include/x509.h kernel/include/rsa.h kernel/include/csprng.h \
 kernel/include/hkdf.h kernel/include/sha.h kernel/include/sha.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/tls_handshake.h:
kernel/include/ecdhe.h:
kernel/include/x509.h:
kernel/include/rsa.h:
kernel/include/csprng.h:
kernel/include/hkdf.h:
kernel/include/sha.h:
kernel/include/sha.h:
kernel/include/vga.h:
kernel/include/string.h:
