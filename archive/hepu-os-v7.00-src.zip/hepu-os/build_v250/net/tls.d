build_v250/net/tls.o: kernel/net/tls.c kernel/include/tls.h \
 kernel/include/aes.h kernel/include/vga.h kernel/include/string.h
kernel/include/tls.h:
kernel/include/aes.h:
kernel/include/vga.h:
kernel/include/string.h:
