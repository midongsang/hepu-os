build_v250/net/doq.o: kernel/net/doq.c kernel/include/types.h \
 kernel/include/doq.h kernel/include/types.h kernel/include/quic.h \
 kernel/include/quic.h kernel/include/csprng.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/types.h:
kernel/include/doq.h:
kernel/include/types.h:
kernel/include/quic.h:
kernel/include/quic.h:
kernel/include/csprng.h:
kernel/include/vga.h:
kernel/include/string.h:
