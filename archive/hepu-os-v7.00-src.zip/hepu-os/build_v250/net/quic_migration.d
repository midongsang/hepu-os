build_v250/net/quic_migration.o: kernel/net/quic_migration.c \
 kernel/include/types.h kernel/include/quic_migration.h \
 kernel/include/types.h kernel/include/quic.h kernel/include/csprng.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/types.h:
kernel/include/quic_migration.h:
kernel/include/types.h:
kernel/include/quic.h:
kernel/include/csprng.h:
kernel/include/vga.h:
kernel/include/string.h:
