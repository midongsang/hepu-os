build_v250/net/arp.o: kernel/net/arp.c kernel/include/arp.h \
 kernel/include/eth.h kernel/include/vga.h kernel/include/string.h
kernel/include/arp.h:
kernel/include/eth.h:
kernel/include/vga.h:
kernel/include/string.h:
