build_v250/net/qpack_dynamic.o: kernel/net/qpack_dynamic.c \
 kernel/include/types.h kernel/include/qpack_dynamic.h \
 kernel/include/types.h kernel/include/vga.h kernel/include/string.h
kernel/include/types.h:
kernel/include/qpack_dynamic.h:
kernel/include/types.h:
kernel/include/vga.h:
kernel/include/string.h:
