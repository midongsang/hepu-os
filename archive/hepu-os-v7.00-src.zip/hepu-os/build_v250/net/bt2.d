build_v250/net/bt2.o: kernel/net/bt2.c kernel/include/bt2.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/bt2.h:
kernel/include/vga.h:
kernel/include/string.h:
