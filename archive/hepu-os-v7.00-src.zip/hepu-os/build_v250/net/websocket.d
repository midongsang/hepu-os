build_v250/net/websocket.o: kernel/net/websocket.c \
 kernel/include/websocket.h kernel/include/http.h kernel/include/vga.h \
 kernel/include/string.h kernel/include/kstdio.h
kernel/include/websocket.h:
kernel/include/http.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kstdio.h:
