build_v250/net/quic_datagram.o: kernel/net/quic_datagram.c \
 kernel/include/types.h kernel/include/quic_datagram.h \
 kernel/include/types.h kernel/include/quic.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/types.h:
kernel/include/quic_datagram.h:
kernel/include/types.h:
kernel/include/quic.h:
kernel/include/vga.h:
kernel/include/string.h:
