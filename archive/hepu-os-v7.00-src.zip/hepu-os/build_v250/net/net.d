build_v250/net/net.o: kernel/net/net.c kernel/include/net.h \
 kernel/include/vga.h kernel/include/string.h kernel/include/kheap.h
kernel/include/net.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kheap.h:
