build_v250/net/bt_gatt.o: kernel/net/bt_gatt.c kernel/include/bt2.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/bt2.h:
kernel/include/vga.h:
kernel/include/string.h:
