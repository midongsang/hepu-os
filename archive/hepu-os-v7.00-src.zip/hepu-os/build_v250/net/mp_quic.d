build_v250/net/mp_quic.o: kernel/net/mp_quic.c kernel/include/types.h \
 kernel/include/mp_quic.h kernel/include/types.h kernel/include/quic.h \
 kernel/include/quic_recovery.h kernel/include/csprng.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/types.h:
kernel/include/mp_quic.h:
kernel/include/types.h:
kernel/include/quic.h:
kernel/include/quic_recovery.h:
kernel/include/csprng.h:
kernel/include/vga.h:
kernel/include/string.h:
