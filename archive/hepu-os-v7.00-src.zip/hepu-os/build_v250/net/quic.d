build_v250/net/quic.o: kernel/net/quic.c kernel/include/quic.h \
 kernel/include/csprng.h kernel/include/vga.h kernel/include/string.h
kernel/include/quic.h:
kernel/include/csprng.h:
kernel/include/vga.h:
kernel/include/string.h:
