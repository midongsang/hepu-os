build_v250/fs/hug_install.o: kernel/fs/hug_install.c \
 kernel/include/hug_loader.h kernel/include/ide_ext2.h \
 kernel/include/initrd.h kernel/include/vga.h kernel/include/string.h
kernel/include/hug_loader.h:
kernel/include/ide_ext2.h:
kernel/include/initrd.h:
kernel/include/vga.h:
kernel/include/string.h:
