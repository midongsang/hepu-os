build_v250/fs/ext2_path.o: kernel/fs/ext2_path.c kernel/include/ext2.h \
 kernel/include/vfs.h kernel/include/vga.h kernel/include/string.h
kernel/include/ext2.h:
kernel/include/vfs.h:
kernel/include/vga.h:
kernel/include/string.h:
