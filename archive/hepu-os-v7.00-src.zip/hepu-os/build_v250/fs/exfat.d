build_v250/fs/exfat.o: kernel/fs/exfat.c kernel/include/exfat.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/exfat.h:
kernel/include/vga.h:
kernel/include/string.h:
