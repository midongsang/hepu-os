build_v250/fs/ext2.o: kernel/fs/ext2.c kernel/include/ext2.h \
 kernel/include/vfs.h kernel/include/ide_ext2.h kernel/include/vfs.h \
 kernel/include/vga.h kernel/include/string.h kernel/include/mac.h \
 kernel/include/process.h kernel/include/paging.h \
 kernel/include/constants.h kernel/include/kheap.h
kernel/include/ext2.h:
kernel/include/vfs.h:
kernel/include/ide_ext2.h:
kernel/include/vfs.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/mac.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
kernel/include/kheap.h:
