build_v250/fs/devfs.o: kernel/fs/devfs.c kernel/include/vfs.h \
 kernel/include/vga.h kernel/include/vga_gfx.h kernel/include/string.h
kernel/include/vfs.h:
kernel/include/vga.h:
kernel/include/vga_gfx.h:
kernel/include/string.h:
