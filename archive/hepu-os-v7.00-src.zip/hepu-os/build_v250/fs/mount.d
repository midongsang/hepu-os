build_v250/fs/mount.o: kernel/fs/mount.c kernel/include/mount.h \
 kernel/include/vfs.h kernel/include/vga.h kernel/include/string.h
kernel/include/mount.h:
kernel/include/vfs.h:
kernel/include/vga.h:
kernel/include/string.h:
