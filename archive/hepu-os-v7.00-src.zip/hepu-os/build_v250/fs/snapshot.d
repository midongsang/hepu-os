build_v250/fs/snapshot.o: kernel/fs/snapshot.c kernel/include/string.h \
 kernel/include/snapshot.h kernel/include/kheap.h kernel/include/vga.h
kernel/include/string.h:
kernel/include/snapshot.h:
kernel/include/kheap.h:
kernel/include/vga.h:
