build_v250/fs/hepufs.o: kernel/fs/hepufs.c kernel/include/string.h \
 kernel/include/hepufs.h kernel/include/ide.h kernel/include/kheap.h \
 kernel/include/vga.h
kernel/include/string.h:
kernel/include/hepufs.h:
kernel/include/ide.h:
kernel/include/kheap.h:
kernel/include/vga.h:
