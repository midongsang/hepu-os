build_v250/fs/fsr_ext2.o: kernel/fs/fsr_ext2.c kernel/include/fs_real.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/fs_real.h:
kernel/include/vga.h:
kernel/include/string.h:
