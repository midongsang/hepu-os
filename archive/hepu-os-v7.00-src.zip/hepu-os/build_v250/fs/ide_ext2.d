build_v250/fs/ide_ext2.o: kernel/fs/ide_ext2.c kernel/include/string.h \
 kernel/include/ide.h kernel/include/ext2.h kernel/include/vfs.h \
 kernel/include/i18n.h kernel/include/ide_ext2.h kernel/include/kheap.h \
 kernel/include/vga.h kernel/include/serial.h kernel/include/page_cache.h
kernel/include/string.h:
kernel/include/ide.h:
kernel/include/ext2.h:
kernel/include/vfs.h:
kernel/include/i18n.h:
kernel/include/ide_ext2.h:
kernel/include/kheap.h:
kernel/include/vga.h:
kernel/include/serial.h:
kernel/include/page_cache.h:
