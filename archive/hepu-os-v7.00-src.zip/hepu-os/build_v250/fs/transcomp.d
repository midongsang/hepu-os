build_v250/fs/transcomp.o: kernel/fs/transcomp.c kernel/include/string.h \
 kernel/include/transcomp.h kernel/include/kheap.h kernel/include/vga.h
kernel/include/string.h:
kernel/include/transcomp.h:
kernel/include/kheap.h:
kernel/include/vga.h:
