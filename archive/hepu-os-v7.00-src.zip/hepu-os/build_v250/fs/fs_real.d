build_v250/fs/fs_real.o: kernel/fs/fs_real.c kernel/include/fs_real.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/fs_real.h:
kernel/include/vga.h:
kernel/include/string.h:
