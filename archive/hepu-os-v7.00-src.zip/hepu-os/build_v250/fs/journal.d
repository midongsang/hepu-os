build_v250/fs/journal.o: kernel/fs/journal.c kernel/include/journal.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/journal.h:
kernel/include/vga.h:
kernel/include/string.h:
