build_v250/fs/vfat.o: kernel/fs/vfat.c kernel/include/vfat.h \
 kernel/include/vga.h kernel/include/string.h kernel/include/vfs.h \
 kernel/include/fs_registry.h kernel/include/vfs.h
kernel/include/vfat.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/vfs.h:
kernel/include/fs_registry.h:
kernel/include/vfs.h:
