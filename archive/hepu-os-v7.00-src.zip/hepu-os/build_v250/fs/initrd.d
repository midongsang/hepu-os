build_v250/fs/initrd.o: kernel/fs/initrd.c kernel/include/initrd.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/initrd.h:
kernel/include/vga.h:
kernel/include/string.h:
