build_v250/fs/fs3.o: kernel/fs/fs3.c kernel/include/fs3.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/fs3.h:
kernel/include/vga.h:
kernel/include/string.h:
