build_v250/fs/ide_ext2_fm.o: kernel/fs/ide_ext2_fm.c \
 kernel/include/string.h kernel/include/ext2.h kernel/include/vfs.h \
 kernel/include/ide_ext2.h kernel/include/vga.h kernel/include/kheap.h
kernel/include/string.h:
kernel/include/ext2.h:
kernel/include/vfs.h:
kernel/include/ide_ext2.h:
kernel/include/vga.h:
kernel/include/kheap.h:
