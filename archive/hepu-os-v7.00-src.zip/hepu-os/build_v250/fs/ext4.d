build_v250/fs/ext4.o: kernel/fs/ext4.c kernel/include/ext4.h \
 kernel/include/vga.h kernel/include/string.h kernel/include/vfs.h \
 kernel/include/fs_registry.h kernel/include/vfs.h
kernel/include/ext4.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/vfs.h:
kernel/include/fs_registry.h:
kernel/include/vfs.h:
