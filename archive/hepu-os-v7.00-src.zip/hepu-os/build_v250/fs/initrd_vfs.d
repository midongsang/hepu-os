build_v250/fs/initrd_vfs.o: kernel/fs/initrd_vfs.c kernel/include/vfs.h \
 kernel/include/initrd.h kernel/include/vga.h kernel/include/string.h \
 kernel/include/kheap.h kernel/include/serial.h
kernel/include/vfs.h:
kernel/include/initrd.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kheap.h:
kernel/include/serial.h:
