build_v250/fs/fs2.o: kernel/fs/fs2.c kernel/include/fs2.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/fs2.h:
kernel/include/vga.h:
kernel/include/string.h:
