build_v250/fs/ntfs.o: kernel/fs/ntfs.c kernel/include/ntfs.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/ntfs.h:
kernel/include/vga.h:
kernel/include/string.h:
