build_v250/fs/vfs.o: kernel/fs/vfs.c kernel/include/types.h \
 kernel/include/vfs.h kernel/include/vga.h kernel/include/string.h \
 kernel/include/kheap.h
kernel/include/types.h:
kernel/include/vfs.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kheap.h:
