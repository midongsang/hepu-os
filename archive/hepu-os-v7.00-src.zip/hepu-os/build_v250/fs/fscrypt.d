build_v250/fs/fscrypt.o: kernel/fs/fscrypt.c kernel/include/fscrypt.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/fscrypt.h:
kernel/include/vga.h:
kernel/include/string.h:
