build_v250/fs/ext2_alloc.o: kernel/fs/ext2_alloc.c kernel/include/ext2.h \
 kernel/include/vfs.h kernel/include/ide_ext2.h kernel/include/vga.h \
 kernel/include/string.h kernel/include/quota.h kernel/include/process.h \
 kernel/include/paging.h kernel/include/constants.h
kernel/include/ext2.h:
kernel/include/vfs.h:
kernel/include/ide_ext2.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/quota.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
