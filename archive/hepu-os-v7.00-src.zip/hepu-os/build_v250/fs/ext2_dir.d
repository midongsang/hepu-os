build_v250/fs/ext2_dir.o: kernel/fs/ext2_dir.c kernel/include/ext2.h \
 kernel/include/vfs.h kernel/include/vga.h kernel/include/string.h \
 kernel/include/mac.h kernel/include/process.h kernel/include/paging.h \
 kernel/include/constants.h
kernel/include/ext2.h:
kernel/include/vfs.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/mac.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
