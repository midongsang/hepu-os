build_v250/fs/fsck.o: kernel/fs/fsck.c kernel/include/ext2.h \
 kernel/include/vfs.h kernel/include/ide_ext2.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/ext2.h:
kernel/include/vfs.h:
kernel/include/ide_ext2.h:
kernel/include/vga.h:
kernel/include/string.h:
