build_v250/fs/quota.o: kernel/fs/quota.c kernel/include/quota.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/quota.h:
kernel/include/vga.h:
kernel/include/string.h:
