build_v250/fs/fs_registry.o: kernel/fs/fs_registry.c \
 kernel/include/fs_registry.h kernel/include/vfs.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/fs_registry.h:
kernel/include/vfs.h:
kernel/include/vga.h:
kernel/include/string.h:
