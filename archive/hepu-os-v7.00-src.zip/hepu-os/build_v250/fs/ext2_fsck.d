build_v250/fs/ext2_fsck.o: kernel/fs/ext2_fsck.c \
 kernel/include/ext2_fsck.h kernel/include/ext2.h kernel/include/vfs.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/ext2_fsck.h:
kernel/include/ext2.h:
kernel/include/vfs.h:
kernel/include/vga.h:
kernel/include/string.h:
