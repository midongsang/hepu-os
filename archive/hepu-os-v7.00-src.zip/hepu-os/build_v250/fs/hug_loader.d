build_v250/fs/hug_loader.o: kernel/fs/hug_loader.c \
 kernel/include/hug_loader.h kernel/include/initrd.h \
 kernel/include/ide_ext2.h kernel/include/vga.h kernel/include/string.h \
 kernel/include/process.h kernel/include/paging.h \
 kernel/include/constants.h kernel/include/paging.h
kernel/include/hug_loader.h:
kernel/include/initrd.h:
kernel/include/ide_ext2.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
kernel/include/paging.h:
