build_v250/fs/ide_ext2_selftest.o: kernel/fs/ide_ext2_selftest.c \
 kernel/include/string.h kernel/include/ide.h kernel/include/ext2.h \
 kernel/include/vfs.h kernel/include/ide_ext2.h kernel/include/vga.h \
 kernel/include/serial.h
kernel/include/string.h:
kernel/include/ide.h:
kernel/include/ext2.h:
kernel/include/vfs.h:
kernel/include/ide_ext2.h:
kernel/include/vga.h:
kernel/include/serial.h:
