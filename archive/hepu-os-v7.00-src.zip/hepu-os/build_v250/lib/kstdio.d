build_v250/lib/kstdio.o: kernel/lib/kstdio.c kernel/include/kstdio.h \
 kernel/include/string.h
kernel/include/kstdio.h:
kernel/include/string.h:
