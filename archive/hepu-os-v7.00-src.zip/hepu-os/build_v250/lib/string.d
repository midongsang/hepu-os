build_v250/lib/string.o: kernel/lib/string.c kernel/include/string.h
kernel/include/string.h:
