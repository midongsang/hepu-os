build_v250/hal/hal_clock.o: kernel/hal/hal_clock.c \
 kernel/include/hal_clock.h kernel/include/vga.h kernel/include/string.h
kernel/include/hal_clock.h:
kernel/include/vga.h:
kernel/include/string.h:
