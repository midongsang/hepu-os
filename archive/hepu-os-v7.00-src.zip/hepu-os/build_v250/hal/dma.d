build_v250/hal/dma.o: kernel/hal/dma.c kernel/include/dma.h \
 kernel/include/mm.h kernel/include/vga.h kernel/include/string.h
kernel/include/dma.h:
kernel/include/mm.h:
kernel/include/vga.h:
kernel/include/string.h:
