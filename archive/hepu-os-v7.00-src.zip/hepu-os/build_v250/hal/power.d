build_v250/hal/power.o: kernel/hal/power.c kernel/include/power.h \
 kernel/include/vga.h kernel/include/string.h kernel/include/acpi.h
kernel/include/power.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/acpi.h:
