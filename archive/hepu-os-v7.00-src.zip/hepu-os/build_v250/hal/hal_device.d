build_v250/hal/hal_device.o: kernel/hal/hal_device.c \
 kernel/include/hal_device.h kernel/include/vga.h kernel/include/string.h \
 kernel/include/kheap.h
kernel/include/hal_device.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kheap.h:
