build_v250/hal/hal_irq.o: kernel/hal/hal_irq.c kernel/include/hal_irq.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/hal_irq.h:
kernel/include/vga.h:
kernel/include/string.h:
