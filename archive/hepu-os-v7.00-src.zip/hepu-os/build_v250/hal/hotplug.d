build_v250/hal/hotplug.o: kernel/hal/hotplug.c kernel/include/hotplug.h \
 kernel/include/hal_device.h kernel/include/hal_device.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/hotplug.h:
kernel/include/hal_device.h:
kernel/include/hal_device.h:
kernel/include/vga.h:
kernel/include/string.h:
