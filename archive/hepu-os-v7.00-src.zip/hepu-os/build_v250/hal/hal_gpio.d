build_v250/hal/hal_gpio.o: kernel/hal/hal_gpio.c \
 kernel/include/hal_gpio.h kernel/include/vga.h kernel/include/string.h
kernel/include/hal_gpio.h:
kernel/include/vga.h:
kernel/include/string.h:
