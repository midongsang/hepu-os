build_v250/hal/hal.o: kernel/hal/hal.c kernel/include/hal.h \
 kernel/include/vga.h
kernel/include/hal.h:
kernel/include/vga.h:
