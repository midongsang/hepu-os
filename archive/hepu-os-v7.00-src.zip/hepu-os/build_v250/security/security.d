build_v250/security/security.o: kernel/security/security.c \
 kernel/include/security.h kernel/include/permission_manager.h \
 kernel/include/vga.h kernel/include/serial.h kernel/include/string.h
kernel/include/security.h:
kernel/include/permission_manager.h:
kernel/include/vga.h:
kernel/include/serial.h:
kernel/include/string.h:
