build_v250/security/security2.o: kernel/security/security2.c \
 kernel/include/security2.h kernel/include/vga.h kernel/include/string.h
kernel/include/security2.h:
kernel/include/vga.h:
kernel/include/string.h:
