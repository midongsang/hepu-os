build_v250/security/security_app.o: kernel/security/security_app.c \
 kernel/include/string.h kernel/include/security.h kernel/include/vga.h \
 kernel/include/permission_manager.h
kernel/include/string.h:
kernel/include/security.h:
kernel/include/vga.h:
kernel/include/permission_manager.h:
