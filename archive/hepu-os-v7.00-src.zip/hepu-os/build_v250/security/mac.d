build_v250/security/mac.o: kernel/security/mac.c kernel/include/mac.h \
 kernel/include/vga.h kernel/include/string.h kernel/include/ext2.h \
 kernel/include/vfs.h kernel/include/vfs.h kernel/include/kstdio.h
kernel/include/mac.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/ext2.h:
kernel/include/vfs.h:
kernel/include/vfs.h:
kernel/include/kstdio.h:
