build_v250/security/enterprise2.o: kernel/security/enterprise2.c \
 kernel/include/enterprise2.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/enterprise2.h:
kernel/include/vga.h:
kernel/include/string.h:
