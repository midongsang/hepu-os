build_v250/sched/carlink.o: kernel/sched/carlink.c \
 kernel/include/carlink.h kernel/include/vga.h kernel/include/string.h
kernel/include/carlink.h:
kernel/include/vga.h:
kernel/include/string.h:
