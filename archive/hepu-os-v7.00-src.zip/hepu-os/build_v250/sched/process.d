build_v250/sched/process.o: kernel/sched/process.c kernel/include/types.h \
 kernel/include/process.h kernel/include/paging.h \
 kernel/include/constants.h kernel/include/smp.h kernel/include/serial.h \
 kernel/include/assert.h kernel/include/paging.h kernel/include/kheap.h \
 kernel/include/string.h kernel/include/vga.h kernel/include/sched.h \
 kernel/include/constants.h
kernel/include/types.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
kernel/include/smp.h:
kernel/include/serial.h:
kernel/include/assert.h:
kernel/include/paging.h:
kernel/include/kheap.h:
kernel/include/string.h:
kernel/include/vga.h:
kernel/include/sched.h:
kernel/include/constants.h:
