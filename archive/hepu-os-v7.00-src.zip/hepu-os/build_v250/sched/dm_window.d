build_v250/sched/dm_window.o: kernel/sched/dm_window.c \
 kernel/include/desktopmode.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/desktopmode.h:
kernel/include/vga.h:
kernel/include/string.h:
