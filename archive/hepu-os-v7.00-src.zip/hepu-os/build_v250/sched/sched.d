build_v250/sched/sched.o: kernel/sched/sched.c kernel/include/string.h \
 kernel/include/process.h kernel/include/paging.h \
 kernel/include/constants.h kernel/include/sched.h \
 kernel/include/paging.h kernel/include/vga.h kernel/include/syscall.h \
 kernel/include/constants.h kernel/include/kheap.h kernel/include/smp.h
kernel/include/string.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
kernel/include/sched.h:
kernel/include/paging.h:
kernel/include/vga.h:
kernel/include/syscall.h:
kernel/include/constants.h:
kernel/include/kheap.h:
kernel/include/smp.h:
