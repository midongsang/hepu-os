build_v250/sched/gf_assets.o: kernel/sched/gf_assets.c \
 kernel/include/gameframework.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/gameframework.h:
kernel/include/vga.h:
kernel/include/string.h:
