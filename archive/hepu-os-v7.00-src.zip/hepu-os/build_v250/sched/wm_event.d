build_v250/sched/wm_event.o: kernel/sched/wm_event.c kernel/include/wm.h \
 kernel/include/input.h kernel/include/widgets.h kernel/include/wm.h \
 kernel/include/theme.h kernel/include/vga_gfx.h kernel/include/mouse.h \
 kernel/include/vga.h kernel/include/string.h kernel/include/pit.h \
 kernel/include/hepu.h kernel/include/keyboard.h kernel/include/input.h
kernel/include/wm.h:
kernel/include/input.h:
kernel/include/widgets.h:
kernel/include/wm.h:
kernel/include/theme.h:
kernel/include/vga_gfx.h:
kernel/include/mouse.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/pit.h:
kernel/include/hepu.h:
kernel/include/keyboard.h:
kernel/include/input.h:
