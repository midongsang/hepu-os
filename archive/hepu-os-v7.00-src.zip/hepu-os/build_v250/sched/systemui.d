build_v250/sched/systemui.o: kernel/sched/systemui.c \
 kernel/include/systemui.h kernel/include/constants.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/systemui.h:
kernel/include/constants.h:
kernel/include/vga.h:
kernel/include/string.h:
