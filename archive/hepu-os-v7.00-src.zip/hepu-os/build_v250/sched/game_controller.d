build_v250/sched/game_controller.o: kernel/sched/game_controller.c \
 kernel/include/gameframework.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/gameframework.h:
kernel/include/vga.h:
kernel/include/string.h:
