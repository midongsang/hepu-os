build_v250/sched/splash.o: kernel/sched/splash.c kernel/include/vga.h \
 kernel/include/theme.h
kernel/include/vga.h:
kernel/include/theme.h:
