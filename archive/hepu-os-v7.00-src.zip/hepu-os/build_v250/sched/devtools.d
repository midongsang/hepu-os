build_v250/sched/devtools.o: kernel/sched/devtools.c \
 kernel/include/devtools.h kernel/include/vga.h kernel/include/string.h
kernel/include/devtools.h:
kernel/include/vga.h:
kernel/include/string.h:
