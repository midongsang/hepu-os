build_v250/sched/dfs.o: kernel/sched/dfs.c kernel/include/distributed.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/distributed.h:
kernel/include/vga.h:
kernel/include/string.h:
