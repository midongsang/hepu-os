build_v250/sched/shell_help.o: kernel/sched/shell_help.c \
 kernel/include/string.h kernel/include/vga.h kernel/include/i18n.h \
 kernel/include/shell.h kernel/include/keyboard.h kernel/include/pit.h \
 kernel/include/hepu.h kernel/include/process.h kernel/include/paging.h \
 kernel/include/constants.h
kernel/include/string.h:
kernel/include/vga.h:
kernel/include/i18n.h:
kernel/include/shell.h:
kernel/include/keyboard.h:
kernel/include/pit.h:
kernel/include/hepu.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
