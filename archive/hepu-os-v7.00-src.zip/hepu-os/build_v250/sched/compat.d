build_v250/sched/compat.o: kernel/sched/compat.c kernel/include/compat.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/compat.h:
kernel/include/vga.h:
kernel/include/string.h:
