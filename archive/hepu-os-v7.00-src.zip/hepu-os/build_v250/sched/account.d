build_v250/sched/account.o: kernel/sched/account.c \
 kernel/include/account.h kernel/include/vga.h kernel/include/string.h
kernel/include/account.h:
kernel/include/vga.h:
kernel/include/string.h:
