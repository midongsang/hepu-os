build_v250/sched/appeco.o: kernel/sched/appeco.c kernel/include/appeco.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/appeco.h:
kernel/include/vga.h:
kernel/include/string.h:
