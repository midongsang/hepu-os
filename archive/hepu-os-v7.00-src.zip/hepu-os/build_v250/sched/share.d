build_v250/sched/share.o: kernel/sched/share.c kernel/include/share.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/share.h:
kernel/include/vga.h:
kernel/include/string.h:
