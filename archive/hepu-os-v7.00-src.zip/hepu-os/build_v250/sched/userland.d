build_v250/sched/userland.o: kernel/sched/userland.c \
 kernel/include/userland.h kernel/include/vga.h kernel/include/string.h
kernel/include/userland.h:
kernel/include/vga.h:
kernel/include/string.h:
