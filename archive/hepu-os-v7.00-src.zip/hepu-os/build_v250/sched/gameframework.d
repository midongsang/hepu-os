build_v250/sched/gameframework.o: kernel/sched/gameframework.c \
 kernel/include/gameframework.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/gameframework.h:
kernel/include/vga.h:
kernel/include/string.h:
