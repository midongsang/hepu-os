build_v250/sched/devtools_advanced.o: kernel/sched/devtools_advanced.c \
 kernel/include/devtools.h kernel/include/vga.h kernel/include/string.h
kernel/include/devtools.h:
kernel/include/vga.h:
kernel/include/string.h:
