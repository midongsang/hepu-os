build_v250/sched/mobile_power.o: kernel/sched/mobile_power.c \
 kernel/include/mobile.h kernel/include/permission_manager.h \
 kernel/include/wm.h kernel/include/input.h kernel/include/mouse.h \
 kernel/include/keyboard.h kernel/include/ide_ext2.h kernel/include/pit.h \
 kernel/include/vga_gfx.h kernel/include/font_zh.h \
 kernel/include/serial.h kernel/include/string.h
kernel/include/mobile.h:
kernel/include/permission_manager.h:
kernel/include/wm.h:
kernel/include/input.h:
kernel/include/mouse.h:
kernel/include/keyboard.h:
kernel/include/ide_ext2.h:
kernel/include/pit.h:
kernel/include/vga_gfx.h:
kernel/include/font_zh.h:
kernel/include/serial.h:
kernel/include/string.h:
