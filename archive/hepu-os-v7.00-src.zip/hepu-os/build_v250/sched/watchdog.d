build_v250/sched/watchdog.o: kernel/sched/watchdog.c \
 kernel/include/watchdog.h kernel/include/pit.h kernel/include/serial.h
kernel/include/watchdog.h:
kernel/include/pit.h:
kernel/include/serial.h:
