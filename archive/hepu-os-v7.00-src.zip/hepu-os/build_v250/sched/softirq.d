build_v250/sched/softirq.o: kernel/sched/softirq.c \
 kernel/include/softirq.h kernel/include/vga.h
kernel/include/softirq.h:
kernel/include/vga.h:
