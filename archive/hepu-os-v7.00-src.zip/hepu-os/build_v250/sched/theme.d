build_v250/sched/theme.o: kernel/sched/theme.c kernel/include/theme.h \
 kernel/include/vga_gfx.h
kernel/include/theme.h:
kernel/include/vga_gfx.h:
