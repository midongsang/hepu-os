build_v250/sched/windowsystem.o: kernel/sched/windowsystem.c \
 kernel/include/windowsystem.h kernel/include/vga.h \
 kernel/include/string.h kernel/include/kheap.h
kernel/include/windowsystem.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kheap.h:
