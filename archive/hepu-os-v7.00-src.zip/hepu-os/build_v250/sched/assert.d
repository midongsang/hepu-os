build_v250/sched/assert.o: kernel/sched/assert.c kernel/include/vga.h \
 kernel/include/serial.h
kernel/include/vga.h:
kernel/include/serial.h:
