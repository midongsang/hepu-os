build_v250/sched/desktop_terminal.o: kernel/sched/desktop_terminal.c \
 kernel/include/string.h kernel/include/wm.h kernel/include/input.h \
 kernel/include/vga_gfx.h kernel/include/hepu.h
kernel/include/string.h:
kernel/include/wm.h:
kernel/include/input.h:
kernel/include/vga_gfx.h:
kernel/include/hepu.h:
