build_v250/sched/wm_controls.o: kernel/sched/wm_controls.c \
 kernel/include/string.h kernel/include/wm.h kernel/include/input.h \
 kernel/include/widgets.h kernel/include/wm.h
kernel/include/string.h:
kernel/include/wm.h:
kernel/include/input.h:
kernel/include/widgets.h:
kernel/include/wm.h:
