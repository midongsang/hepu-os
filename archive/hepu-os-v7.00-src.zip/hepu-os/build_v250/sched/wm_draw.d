build_v250/sched/wm_draw.o: kernel/sched/wm_draw.c \
 kernel/include/string.h kernel/include/wm.h kernel/include/input.h \
 kernel/include/widgets.h kernel/include/wm.h kernel/include/theme.h \
 kernel/include/vga_gfx.h kernel/include/vga.h kernel/include/hepu.h
kernel/include/string.h:
kernel/include/wm.h:
kernel/include/input.h:
kernel/include/widgets.h:
kernel/include/wm.h:
kernel/include/theme.h:
kernel/include/vga_gfx.h:
kernel/include/vga.h:
kernel/include/hepu.h:
