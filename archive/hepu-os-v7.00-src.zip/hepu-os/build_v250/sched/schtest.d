build_v250/sched/schtest.o: kernel/sched/schtest.c kernel/include/vga.h \
 kernel/include/process.h kernel/include/paging.h \
 kernel/include/constants.h
kernel/include/vga.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
