build_v250/sched/smp.o: kernel/sched/smp.c kernel/include/smp.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/smp.h:
kernel/include/vga.h:
kernel/include/string.h:
