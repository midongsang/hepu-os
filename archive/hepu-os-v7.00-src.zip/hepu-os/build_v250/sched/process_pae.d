build_v250/sched/process_pae.o: kernel/sched/process_pae.c \
 kernel/include/paging.h kernel/include/pae.h kernel/include/process.h \
 kernel/include/paging.h kernel/include/constants.h kernel/include/vga.h \
 kernel/include/serial.h
kernel/include/paging.h:
kernel/include/pae.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
kernel/include/vga.h:
kernel/include/serial.h:
