build_v250/sched/packagemanager.o: kernel/sched/packagemanager.c \
 kernel/include/packagemanager.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/packagemanager.h:
kernel/include/vga.h:
kernel/include/string.h:
