build_v250/sched/distributed.o: kernel/sched/distributed.c \
 kernel/include/distributed.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/distributed.h:
kernel/include/vga.h:
kernel/include/string.h:
