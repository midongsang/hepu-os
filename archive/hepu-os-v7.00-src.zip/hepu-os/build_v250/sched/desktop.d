build_v250/sched/desktop.o: kernel/sched/desktop.c kernel/include/wm.h \
 kernel/include/input.h kernel/include/vga_gfx.h kernel/include/vga.h \
 kernel/include/hepu.h kernel/include/string.h kernel/include/appreg.h
kernel/include/wm.h:
kernel/include/input.h:
kernel/include/vga_gfx.h:
kernel/include/vga.h:
kernel/include/hepu.h:
kernel/include/string.h:
kernel/include/appreg.h:
