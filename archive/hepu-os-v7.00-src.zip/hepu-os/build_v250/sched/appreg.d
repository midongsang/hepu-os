build_v250/sched/appreg.o: kernel/sched/appreg.c kernel/include/appreg.h \
 kernel/include/vga.h
kernel/include/appreg.h:
kernel/include/vga.h:
