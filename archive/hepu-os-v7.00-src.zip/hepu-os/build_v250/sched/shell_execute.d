build_v250/sched/shell_execute.o: kernel/sched/shell_execute.c \
 kernel/include/string.h kernel/include/vga.h kernel/include/process.h \
 kernel/include/paging.h kernel/include/constants.h \
 kernel/include/shell.h kernel/include/serial.h kernel/include/pit.h \
 kernel/include/hepu.h kernel/include/i18n.h kernel/include/vfs.h \
 kernel/include/ext2.h kernel/include/vfs.h kernel/include/ide_ext2.h \
 kernel/include/wm.h kernel/include/input.h kernel/include/ide.h \
 kernel/include/power.h kernel/include/usb.h kernel/include/appreg.h \
 kernel/include/touch.h kernel/include/touch_hw.h
kernel/include/string.h:
kernel/include/vga.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
kernel/include/shell.h:
kernel/include/serial.h:
kernel/include/pit.h:
kernel/include/hepu.h:
kernel/include/i18n.h:
kernel/include/vfs.h:
kernel/include/ext2.h:
kernel/include/vfs.h:
kernel/include/ide_ext2.h:
kernel/include/wm.h:
kernel/include/input.h:
kernel/include/ide.h:
kernel/include/power.h:
kernel/include/usb.h:
kernel/include/appreg.h:
kernel/include/touch.h:
kernel/include/touch_hw.h:
