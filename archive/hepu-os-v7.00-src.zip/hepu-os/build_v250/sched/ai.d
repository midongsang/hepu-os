build_v250/sched/ai.o: kernel/sched/ai.c kernel/include/ai.h \
 kernel/include/vga.h kernel/include/string.h kernel/include/kheap.h
kernel/include/ai.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kheap.h:
