build_v250/sched/ai2.o: kernel/sched/ai2.c kernel/include/ai2.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/ai2.h:
kernel/include/vga.h:
kernel/include/string.h:
