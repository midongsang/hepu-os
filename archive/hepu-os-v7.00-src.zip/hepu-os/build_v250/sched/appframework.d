build_v250/sched/appframework.o: kernel/sched/appframework.c \
 kernel/include/appframework.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/appframework.h:
kernel/include/vga.h:
kernel/include/string.h:
