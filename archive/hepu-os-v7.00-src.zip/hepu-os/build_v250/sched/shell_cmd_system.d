build_v250/sched/shell_cmd_system.o: kernel/sched/shell_cmd_system.c \
 kernel/include/string.h kernel/include/vga.h kernel/include/process.h \
 kernel/include/paging.h kernel/include/constants.h \
 kernel/include/shell.h kernel/include/serial.h kernel/include/pit.h \
 kernel/include/hepu.h kernel/include/dtb.h kernel/include/i18n.h
kernel/include/string.h:
kernel/include/vga.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
kernel/include/shell.h:
kernel/include/serial.h:
kernel/include/pit.h:
kernel/include/hepu.h:
kernel/include/dtb.h:
kernel/include/i18n.h:
