build_v250/sched/enterprise.o: kernel/sched/enterprise.c \
 kernel/include/enterprise.h kernel/include/vga.h kernel/include/string.h
kernel/include/enterprise.h:
kernel/include/vga.h:
kernel/include/string.h:
