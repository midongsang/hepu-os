build_v250/sched/services.o: kernel/sched/services.c \
 kernel/include/services.h kernel/include/vga.h kernel/include/string.h \
 kernel/include/pit.h
kernel/include/services.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/pit.h:
