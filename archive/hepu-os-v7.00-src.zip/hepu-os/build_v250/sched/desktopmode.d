build_v250/sched/desktopmode.o: kernel/sched/desktopmode.c \
 kernel/include/desktopmode.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/desktopmode.h:
kernel/include/vga.h:
kernel/include/string.h:
