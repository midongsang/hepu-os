build_v250/sched/shell.o: kernel/sched/shell.c kernel/include/shell.h \
 kernel/include/mac.h kernel/include/i18n.h kernel/include/dtb.h \
 kernel/include/font_cjk16.h kernel/include/vfs.h \
 kernel/include/keyboard.h kernel/include/ext2.h kernel/include/vfs.h \
 kernel/include/ide_ext2.h kernel/include/vga.h kernel/include/pit.h \
 kernel/include/hepu.h kernel/include/string.h kernel/include/process.h \
 kernel/include/paging.h kernel/include/constants.h \
 kernel/include/serial.h kernel/include/hdpk_template.h \
 kernel/include/sched.h kernel/include/initrd.h \
 kernel/include/hug_loader.h kernel/include/vga_gfx.h \
 kernel/include/mouse.h kernel/include/wm.h kernel/include/input.h \
 kernel/include/touch_hw.h kernel/include/appreg.h kernel/include/power.h \
 kernel/include/ide.h kernel/include/kheap.h kernel/include/usb.h
kernel/include/shell.h:
kernel/include/mac.h:
kernel/include/i18n.h:
kernel/include/dtb.h:
kernel/include/font_cjk16.h:
kernel/include/vfs.h:
kernel/include/keyboard.h:
kernel/include/ext2.h:
kernel/include/vfs.h:
kernel/include/ide_ext2.h:
kernel/include/vga.h:
kernel/include/pit.h:
kernel/include/hepu.h:
kernel/include/string.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
kernel/include/serial.h:
kernel/include/hdpk_template.h:
kernel/include/sched.h:
kernel/include/initrd.h:
kernel/include/hug_loader.h:
kernel/include/vga_gfx.h:
kernel/include/mouse.h:
kernel/include/wm.h:
kernel/include/input.h:
kernel/include/touch_hw.h:
kernel/include/appreg.h:
kernel/include/power.h:
kernel/include/ide.h:
kernel/include/kheap.h:
kernel/include/usb.h:
