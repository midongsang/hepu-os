build_v250/sched/notification.o: kernel/sched/notification.c \
 kernel/include/notification.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/notification.h:
kernel/include/vga.h:
kernel/include/string.h:
