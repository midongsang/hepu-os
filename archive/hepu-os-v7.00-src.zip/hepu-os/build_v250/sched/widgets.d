build_v250/sched/widgets.o: kernel/sched/widgets.c \
 kernel/include/widgets.h kernel/include/wm.h kernel/include/input.h \
 kernel/include/theme.h kernel/include/vga_gfx.h
kernel/include/widgets.h:
kernel/include/wm.h:
kernel/include/input.h:
kernel/include/theme.h:
kernel/include/vga_gfx.h:
