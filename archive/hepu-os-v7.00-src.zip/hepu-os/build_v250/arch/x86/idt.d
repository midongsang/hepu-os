build_v250/arch/x86/idt.o: kernel/arch/x86/idt.c kernel/include/idt.h \
 kernel/include/constants.h kernel/include/vga.h kernel/include/paging.h \
 kernel/include/syscall.h kernel/include/process.h \
 kernel/include/paging.h kernel/include/constants.h \
 kernel/include/serial.h kernel/include/bsod.h
kernel/include/idt.h:
kernel/include/constants.h:
kernel/include/vga.h:
kernel/include/paging.h:
kernel/include/syscall.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
kernel/include/serial.h:
kernel/include/bsod.h:
