build_v250/arch/x86/keyboard.o: kernel/arch/x86/keyboard.c \
 kernel/include/keyboard.h kernel/include/pic.h kernel/include/vga.h \
 kernel/include/power.h
kernel/include/keyboard.h:
kernel/include/pic.h:
kernel/include/vga.h:
kernel/include/power.h:
