build_v250/arch/x86/boot_optimizer.o: kernel/arch/x86/boot_optimizer.c \
 kernel/include/boot_optimizer.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/boot_optimizer.h:
kernel/include/vga.h:
kernel/include/string.h:
