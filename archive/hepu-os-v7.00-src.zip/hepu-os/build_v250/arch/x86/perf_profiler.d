build_v250/arch/x86/perf_profiler.o: kernel/arch/x86/perf_profiler.c \
 kernel/include/perf_profiler.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/perf_profiler.h:
kernel/include/vga.h:
kernel/include/string.h:
