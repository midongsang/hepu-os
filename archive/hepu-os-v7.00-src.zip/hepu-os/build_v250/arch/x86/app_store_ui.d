build_v250/arch/x86/app_store_ui.o: kernel/arch/x86/app_store_ui.c \
 kernel/include/app_store.h kernel/include/vga_gfx.h \
 kernel/include/string.h
kernel/include/app_store.h:
kernel/include/vga_gfx.h:
kernel/include/string.h:
