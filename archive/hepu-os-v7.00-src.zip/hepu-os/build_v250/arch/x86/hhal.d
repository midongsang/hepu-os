build_v250/arch/x86/hhal.o: kernel/arch/x86/hhal.c kernel/include/hhal.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/hhal.h:
kernel/include/vga.h:
kernel/include/string.h:
