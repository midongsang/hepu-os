build_v250/arch/x86/sys_ipc.o: kernel/arch/x86/sys_ipc.c \
 kernel/include/types.h kernel/include/syscall.h kernel/include/vga.h \
 kernel/include/kheap.h kernel/include/sched.h kernel/include/hepu.h \
 kernel/include/fingerprint.h kernel/include/vfs.h kernel/include/ipc.h
kernel/include/types.h:
kernel/include/syscall.h:
kernel/include/vga.h:
kernel/include/kheap.h:
kernel/include/sched.h:
kernel/include/hepu.h:
kernel/include/fingerprint.h:
kernel/include/vfs.h:
kernel/include/ipc.h:
