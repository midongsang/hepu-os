build_v250/arch/x86/privacy_compute.o: kernel/arch/x86/privacy_compute.c \
 kernel/include/privacy_compute.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/privacy_compute.h:
kernel/include/vga.h:
kernel/include/string.h:
