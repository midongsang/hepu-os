build_v250/arch/x86/fingerprint.o: kernel/arch/x86/fingerprint.c \
 kernel/include/fingerprint.h
kernel/include/fingerprint.h:
