build_v250/arch/x86/voice_recorder.o: kernel/arch/x86/voice_recorder.c \
 kernel/include/voice_recorder.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/voice_recorder.h:
kernel/include/vga.h:
kernel/include/string.h:
