build_v250/arch/x86/app_store.o: kernel/arch/x86/app_store.c \
 kernel/include/app_store.h kernel/include/vga.h kernel/include/string.h
kernel/include/app_store.h:
kernel/include/vga.h:
kernel/include/string.h:
