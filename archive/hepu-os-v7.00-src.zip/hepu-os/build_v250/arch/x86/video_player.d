build_v250/arch/x86/video_player.o: kernel/arch/x86/video_player.c \
 kernel/include/video_player.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/video_player.h:
kernel/include/vga.h:
kernel/include/string.h:
