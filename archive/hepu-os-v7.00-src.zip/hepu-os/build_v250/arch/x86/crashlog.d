build_v250/arch/x86/crashlog.o: kernel/arch/x86/crashlog.c
