build_v250/arch/x86/app_freeze.o: kernel/arch/x86/app_freeze.c \
 kernel/include/app_freeze.h kernel/include/process.h \
 kernel/include/paging.h kernel/include/constants.h \
 kernel/include/process.h kernel/include/vga.h kernel/include/string.h
kernel/include/app_freeze.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
kernel/include/process.h:
kernel/include/vga.h:
kernel/include/string.h:
