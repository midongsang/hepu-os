build_v250/arch/x86/secure_boot.o: kernel/arch/x86/secure_boot.c \
 kernel/include/secure_boot.h kernel/include/vga.h \
 kernel/include/string.h kernel/include/kstdio.h
kernel/include/secure_boot.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kstdio.h:
