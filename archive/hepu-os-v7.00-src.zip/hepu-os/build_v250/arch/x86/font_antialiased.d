build_v250/arch/x86/font_antialiased.o: \
 kernel/arch/x86/font_antialiased.c kernel/include/vga_gfx.h \
 kernel/include/font8x16.h kernel/include/string.h
kernel/include/vga_gfx.h:
kernel/include/font8x16.h:
kernel/include/string.h:
