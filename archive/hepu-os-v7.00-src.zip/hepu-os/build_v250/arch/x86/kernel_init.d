build_v250/arch/x86/kernel_init.o: kernel/arch/x86/kernel_init.c \
 kernel/include/hepu.h kernel/include/vga.h kernel/include/types.h \
 kernel/include/gdt.h kernel/include/idt.h kernel/include/fingerprint.h \
 kernel/include/mm.h kernel/include/paging.h kernel/include/kheap.h \
 kernel/include/iosched.h kernel/include/sched.h kernel/include/process.h \
 kernel/include/paging.h kernel/include/constants.h \
 kernel/include/syscall.h kernel/include/hal.h kernel/include/ipc.h \
 kernel/include/string.h kernel/include/pic.h kernel/include/pit.h \
 kernel/include/irq.h kernel/include/keyboard.h kernel/include/tss.h \
 kernel/include/initrd.h kernel/include/vfs.h kernel/include/devfs.h \
 kernel/include/net.h kernel/include/touch.h kernel/include/smp.h \
 kernel/include/dynld.h kernel/include/usb.h kernel/include/pm.h \
 kernel/include/security.h kernel/include/dtb.h kernel/include/audio.h \
 kernel/include/camera.h kernel/include/bluetooth.h kernel/include/wifi.h \
 kernel/include/arp.h kernel/include/dhcp.h kernel/include/dns.h \
 kernel/include/icmp.h kernel/include/http.h kernel/include/tls.h \
 kernel/include/tcp.h kernel/include/websocket.h kernel/include/x509.h \
 kernel/include/csprng.h kernel/include/ecdhe.h kernel/include/sha.h \
 kernel/include/hmac.h kernel/include/sha.h kernel/include/hkdf.h \
 kernel/include/rsa.h kernel/include/http2.h \
 kernel/include/tls_handshake.h kernel/include/ecdhe.h \
 kernel/include/x509.h kernel/include/rsa.h kernel/include/quic.h \
 kernel/include/http3.h kernel/include/types.h kernel/include/quic.h \
 kernel/include/doq.h kernel/include/quic_0rtt.h \
 kernel/include/quic_migration.h kernel/include/quic_recovery.h \
 kernel/include/mp_quic.h kernel/include/quic_recovery.h \
 kernel/include/quic_datagram.h kernel/include/qpack_dynamic.h \
 kernel/include/init_sequence.h kernel/include/klog.h \
 kernel/include/kunit.h kernel/include/kbench.h \
 kernel/include/kunit_log.h kernel/include/kunit.h \
 kernel/include/services.h kernel/include/gpu.h kernel/include/sensors.h \
 kernel/include/gps.h kernel/include/ota.h kernel/include/codec.h \
 kernel/include/compositor.h kernel/include/input.h \
 kernel/include/trace.h kernel/include/media.h \
 kernel/include/camera_hal.h kernel/include/ril.h \
 kernel/include/appframework.h kernel/include/packagemanager.h \
 kernel/include/notification.h kernel/include/windowsystem.h \
 kernel/include/share.h kernel/include/account.h \
 kernel/include/systemui.h kernel/include/webengine.h kernel/include/ai.h \
 kernel/include/security2.h kernel/include/media2.h \
 kernel/include/desktopmode.h kernel/include/gameframework.h \
 kernel/include/multiboot.h
kernel/include/hepu.h:
kernel/include/vga.h:
kernel/include/types.h:
kernel/include/gdt.h:
kernel/include/idt.h:
kernel/include/fingerprint.h:
kernel/include/mm.h:
kernel/include/paging.h:
kernel/include/kheap.h:
kernel/include/iosched.h:
kernel/include/sched.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
kernel/include/syscall.h:
kernel/include/hal.h:
kernel/include/ipc.h:
kernel/include/string.h:
kernel/include/pic.h:
kernel/include/pit.h:
kernel/include/irq.h:
kernel/include/keyboard.h:
kernel/include/tss.h:
kernel/include/initrd.h:
kernel/include/vfs.h:
kernel/include/devfs.h:
kernel/include/net.h:
kernel/include/touch.h:
kernel/include/smp.h:
kernel/include/dynld.h:
kernel/include/usb.h:
kernel/include/pm.h:
kernel/include/security.h:
kernel/include/dtb.h:
kernel/include/audio.h:
kernel/include/camera.h:
kernel/include/bluetooth.h:
kernel/include/wifi.h:
kernel/include/arp.h:
kernel/include/dhcp.h:
kernel/include/dns.h:
kernel/include/icmp.h:
kernel/include/http.h:
kernel/include/tls.h:
kernel/include/tcp.h:
kernel/include/websocket.h:
kernel/include/x509.h:
kernel/include/csprng.h:
kernel/include/ecdhe.h:
kernel/include/sha.h:
kernel/include/hmac.h:
kernel/include/sha.h:
kernel/include/hkdf.h:
kernel/include/rsa.h:
kernel/include/http2.h:
kernel/include/tls_handshake.h:
kernel/include/ecdhe.h:
kernel/include/x509.h:
kernel/include/rsa.h:
kernel/include/quic.h:
kernel/include/http3.h:
kernel/include/types.h:
kernel/include/quic.h:
kernel/include/doq.h:
kernel/include/quic_0rtt.h:
kernel/include/quic_migration.h:
kernel/include/quic_recovery.h:
kernel/include/mp_quic.h:
kernel/include/quic_recovery.h:
kernel/include/quic_datagram.h:
kernel/include/qpack_dynamic.h:
kernel/include/init_sequence.h:
kernel/include/klog.h:
kernel/include/kunit.h:
kernel/include/kbench.h:
kernel/include/kunit_log.h:
kernel/include/kunit.h:
kernel/include/services.h:
kernel/include/gpu.h:
kernel/include/sensors.h:
kernel/include/gps.h:
kernel/include/ota.h:
kernel/include/codec.h:
kernel/include/compositor.h:
kernel/include/input.h:
kernel/include/trace.h:
kernel/include/media.h:
kernel/include/camera_hal.h:
kernel/include/ril.h:
kernel/include/appframework.h:
kernel/include/packagemanager.h:
kernel/include/notification.h:
kernel/include/windowsystem.h:
kernel/include/share.h:
kernel/include/account.h:
kernel/include/systemui.h:
kernel/include/webengine.h:
kernel/include/ai.h:
kernel/include/security2.h:
kernel/include/media2.h:
kernel/include/desktopmode.h:
kernel/include/gameframework.h:
kernel/include/multiboot.h:
