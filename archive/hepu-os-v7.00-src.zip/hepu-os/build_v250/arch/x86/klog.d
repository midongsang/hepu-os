build_v250/arch/x86/klog.o: kernel/arch/x86/klog.c kernel/include/klog.h \
 kernel/include/kstdio.h kernel/include/vga.h
kernel/include/klog.h:
kernel/include/kstdio.h:
kernel/include/vga.h:
