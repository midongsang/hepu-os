build_v250/arch/x86/multi_user.o: kernel/arch/x86/multi_user.c \
 kernel/include/multi_user.h kernel/include/vga.h kernel/include/string.h
kernel/include/multi_user.h:
kernel/include/vga.h:
kernel/include/string.h:
