build_v250/arch/x86/sys_fs.o: kernel/arch/x86/sys_fs.c \
 kernel/include/types.h kernel/include/string.h kernel/include/syscall.h \
 kernel/include/vga.h kernel/include/kheap.h kernel/include/sched.h \
 kernel/include/hepu.h kernel/include/fingerprint.h kernel/include/vfs.h \
 kernel/include/ipc.h kernel/include/process.h kernel/include/paging.h \
 kernel/include/constants.h
kernel/include/types.h:
kernel/include/string.h:
kernel/include/syscall.h:
kernel/include/vga.h:
kernel/include/kheap.h:
kernel/include/sched.h:
kernel/include/hepu.h:
kernel/include/fingerprint.h:
kernel/include/vfs.h:
kernel/include/ipc.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
