build_v250/arch/x86/sys_process.o: kernel/arch/x86/sys_process.c \
 kernel/include/types.h kernel/include/syscall.h kernel/include/vga.h \
 kernel/include/kheap.h kernel/include/sched.h kernel/include/hepu.h \
 kernel/include/fingerprint.h kernel/include/vfs.h kernel/include/ipc.h \
 kernel/include/process.h kernel/include/paging.h \
 kernel/include/constants.h
kernel/include/types.h:
kernel/include/syscall.h:
kernel/include/vga.h:
kernel/include/kheap.h:
kernel/include/sched.h:
kernel/include/hepu.h:
kernel/include/fingerprint.h:
kernel/include/vfs.h:
kernel/include/ipc.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
