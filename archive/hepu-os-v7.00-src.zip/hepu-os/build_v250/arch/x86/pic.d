build_v250/arch/x86/pic.o: kernel/arch/x86/pic.c kernel/include/pic.h \
 kernel/include/vga.h
kernel/include/pic.h:
kernel/include/vga.h:
