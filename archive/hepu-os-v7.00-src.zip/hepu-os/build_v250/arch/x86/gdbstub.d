build_v250/arch/x86/gdbstub.o: kernel/arch/x86/gdbstub.c \
 kernel/include/gdbstub.h kernel/include/string.h
kernel/include/gdbstub.h:
kernel/include/string.h:
