build_v250/arch/x86/hdpk_template.o: kernel/arch/x86/hdpk_template.c \
 kernel/include/hdpk_template.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/hdpk_template.h:
kernel/include/vga.h:
kernel/include/string.h:
