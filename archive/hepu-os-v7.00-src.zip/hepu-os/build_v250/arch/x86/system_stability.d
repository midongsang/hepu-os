build_v250/arch/x86/system_stability.o: \
 kernel/arch/x86/system_stability.c kernel/include/system_stability.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/system_stability.h:
kernel/include/vga.h:
kernel/include/string.h:
