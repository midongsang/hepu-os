build_v250/arch/x86/hdpk.o: kernel/arch/x86/hdpk.c kernel/include/hdpk.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/hdpk.h:
kernel/include/vga.h:
kernel/include/string.h:
