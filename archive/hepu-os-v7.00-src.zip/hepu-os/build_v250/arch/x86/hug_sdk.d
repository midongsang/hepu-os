build_v250/arch/x86/hug_sdk.o: kernel/arch/x86/hug_sdk.c \
 kernel/include/hug_sdk.h kernel/include/vga.h kernel/include/string.h
kernel/include/hug_sdk.h:
kernel/include/vga.h:
kernel/include/string.h:
