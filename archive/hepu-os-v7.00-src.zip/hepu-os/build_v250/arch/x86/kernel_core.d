build_v250/arch/x86/kernel_core.o: kernel/arch/x86/kernel_core.c \
 kernel/include/kernel_core.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/kernel_core.h:
kernel/include/vga.h:
kernel/include/string.h:
