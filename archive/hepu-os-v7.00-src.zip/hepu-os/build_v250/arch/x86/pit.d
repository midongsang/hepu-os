build_v250/arch/x86/pit.o: kernel/arch/x86/pit.c kernel/include/pit.h \
 kernel/include/pic.h kernel/include/irq.h kernel/include/vga.h \
 kernel/include/sched.h
kernel/include/pit.h:
kernel/include/pic.h:
kernel/include/irq.h:
kernel/include/vga.h:
kernel/include/sched.h:
