build_v250/arch/x86/device_support.o: kernel/arch/x86/device_support.c \
 kernel/include/device_support.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/device_support.h:
kernel/include/vga.h:
kernel/include/string.h:
