build_v250/arch/x86/init_sequence.o: kernel/arch/x86/init_sequence.c \
 kernel/include/types.h kernel/include/init_sequence.h \
 kernel/include/types.h kernel/include/vga.h kernel/include/security.h \
 kernel/include/permission_manager.h
kernel/include/types.h:
kernel/include/init_sequence.h:
kernel/include/types.h:
kernel/include/vga.h:
kernel/include/security.h:
kernel/include/permission_manager.h:
