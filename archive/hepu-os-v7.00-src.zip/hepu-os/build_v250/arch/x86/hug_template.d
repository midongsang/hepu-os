build_v250/arch/x86/hug_template.o: kernel/arch/x86/hug_template.c \
 kernel/include/hug_template.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/hug_template.h:
kernel/include/vga.h:
kernel/include/string.h:
