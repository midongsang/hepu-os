build_v250/arch/x86/ai_assistant.o: kernel/arch/x86/ai_assistant.c \
 kernel/include/ai_assistant.h kernel/include/vga.h \
 kernel/include/string.h kernel/include/kheap.h
kernel/include/ai_assistant.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kheap.h:
