build_v250/arch/x86/multilingual_ime.o: \
 kernel/arch/x86/multilingual_ime.c kernel/include/multilingual_ime.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/multilingual_ime.h:
kernel/include/vga.h:
kernel/include/string.h:
