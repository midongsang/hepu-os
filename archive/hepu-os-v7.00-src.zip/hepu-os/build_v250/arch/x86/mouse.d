build_v250/arch/x86/mouse.o: kernel/arch/x86/mouse.c \
 kernel/include/mouse.h kernel/include/vga.h kernel/include/irq.h \
 kernel/include/vga_gfx.h kernel/include/softirq.h
kernel/include/mouse.h:
kernel/include/vga.h:
kernel/include/irq.h:
kernel/include/vga_gfx.h:
kernel/include/softirq.h:
