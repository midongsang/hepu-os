build_v250/arch/x86/distributed_os.o: kernel/arch/x86/distributed_os.c \
 kernel/include/distributed_os.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/distributed_os.h:
kernel/include/vga.h:
kernel/include/string.h:
