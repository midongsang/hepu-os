build_v250/arch/x86/creator_mode.o: kernel/arch/x86/creator_mode.c \
 kernel/include/creator_mode.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/creator_mode.h:
kernel/include/vga.h:
kernel/include/string.h:
