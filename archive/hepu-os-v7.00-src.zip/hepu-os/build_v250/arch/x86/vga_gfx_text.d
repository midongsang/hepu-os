build_v250/arch/x86/vga_gfx_text.o: kernel/arch/x86/vga_gfx_text.c \
 kernel/include/vga.h
kernel/include/vga.h:
