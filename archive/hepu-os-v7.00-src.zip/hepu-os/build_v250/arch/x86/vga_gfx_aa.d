build_v250/arch/x86/vga_gfx_aa.o: kernel/arch/x86/vga_gfx_aa.c \
 kernel/include/font_aa16.h kernel/include/vga.h
kernel/include/font_aa16.h:
kernel/include/vga.h:
