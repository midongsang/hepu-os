build_v250/arch/x86/vga.o: kernel/arch/x86/vga.c kernel/include/vga.h
kernel/include/vga.h:
