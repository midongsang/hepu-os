build_v250/arch/x86/gallery_app.o: kernel/arch/x86/gallery_app.c \
 kernel/include/gallery_app.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/gallery_app.h:
kernel/include/vga.h:
kernel/include/string.h:
