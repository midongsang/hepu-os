build_v250/arch/x86/vga_gfx.o: kernel/arch/x86/vga_gfx.c \
 kernel/include/string.h kernel/include/vga_gfx.h kernel/include/vga.h \
 kernel/include/font8x16.h kernel/include/paging.h
kernel/include/string.h:
kernel/include/vga_gfx.h:
kernel/include/vga.h:
kernel/include/font8x16.h:
kernel/include/paging.h:
