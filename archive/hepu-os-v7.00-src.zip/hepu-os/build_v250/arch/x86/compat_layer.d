build_v250/arch/x86/compat_layer.o: kernel/arch/x86/compat_layer.c \
 kernel/include/compat_layer.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/compat_layer.h:
kernel/include/vga.h:
kernel/include/string.h:
