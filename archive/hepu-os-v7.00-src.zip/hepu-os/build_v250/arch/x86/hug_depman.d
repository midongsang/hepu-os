build_v250/arch/x86/hug_depman.o: kernel/arch/x86/hug_depman.c \
 kernel/include/hug_depman.h kernel/include/vga.h kernel/include/string.h
kernel/include/hug_depman.h:
kernel/include/vga.h:
kernel/include/string.h:
