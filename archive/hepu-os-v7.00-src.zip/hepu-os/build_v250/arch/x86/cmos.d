build_v250/arch/x86/cmos.o: kernel/arch/x86/cmos.c kernel/include/cmos.h
kernel/include/cmos.h:
