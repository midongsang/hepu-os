build_v250/arch/x86/art_runtime.o: kernel/arch/x86/art_runtime.c \
 kernel/include/art_runtime.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/art_runtime.h:
kernel/include/vga.h:
kernel/include/string.h:
