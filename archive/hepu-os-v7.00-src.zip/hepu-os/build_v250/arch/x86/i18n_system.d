build_v250/arch/x86/i18n_system.o: kernel/arch/x86/i18n_system.c \
 kernel/include/i18n_system.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/i18n_system.h:
kernel/include/vga.h:
kernel/include/string.h:
