build_v250/arch/x86/kdbg_gdb.o: kernel/arch/x86/kdbg_gdb.c \
 kernel/include/kdebug.h kernel/include/vga.h kernel/include/string.h
kernel/include/kdebug.h:
kernel/include/vga.h:
kernel/include/string.h:
