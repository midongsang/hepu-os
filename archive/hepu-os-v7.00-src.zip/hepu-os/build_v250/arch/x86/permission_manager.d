build_v250/arch/x86/permission_manager.o: \
 kernel/arch/x86/permission_manager.c kernel/include/kstdio.h \
 kernel/include/permission_manager.h kernel/include/ide_ext2.h \
 kernel/include/vga.h kernel/include/serial.h kernel/include/string.h
kernel/include/kstdio.h:
kernel/include/permission_manager.h:
kernel/include/ide_ext2.h:
kernel/include/vga.h:
kernel/include/serial.h:
kernel/include/string.h:
