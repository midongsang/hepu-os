build_v250/arch/x86/gfx_selftest.o: kernel/arch/x86/gfx_selftest.c \
 kernel/include/vga_gfx.h kernel/include/vga.h kernel/include/string.h
kernel/include/vga_gfx.h:
kernel/include/vga.h:
kernel/include/string.h:
