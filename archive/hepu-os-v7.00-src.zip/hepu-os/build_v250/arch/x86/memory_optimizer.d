build_v250/arch/x86/memory_optimizer.o: \
 kernel/arch/x86/memory_optimizer.c kernel/include/memory_optimizer.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/memory_optimizer.h:
kernel/include/vga.h:
kernel/include/string.h:
