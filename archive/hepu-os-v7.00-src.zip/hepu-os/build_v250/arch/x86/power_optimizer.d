build_v250/arch/x86/power_optimizer.o: kernel/arch/x86/power_optimizer.c \
 kernel/include/power_optimizer.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/power_optimizer.h:
kernel/include/vga.h:
kernel/include/string.h:
