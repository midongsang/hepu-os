build_v250/arch/x86/ai_notification.o: kernel/arch/x86/ai_notification.c \
 kernel/include/ai_notification.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/ai_notification.h:
kernel/include/vga.h:
kernel/include/string.h:
