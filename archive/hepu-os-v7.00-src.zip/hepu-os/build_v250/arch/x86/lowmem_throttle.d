build_v250/arch/x86/lowmem_throttle.o: kernel/arch/x86/lowmem_throttle.c \
 kernel/include/lowmem_throttle.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/lowmem_throttle.h:
kernel/include/vga.h:
kernel/include/string.h:
