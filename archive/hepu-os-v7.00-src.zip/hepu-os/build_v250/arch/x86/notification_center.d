build_v250/arch/x86/notification_center.o: \
 kernel/arch/x86/notification_center.c \
 kernel/include/notification_center.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/notification_center.h:
kernel/include/vga.h:
kernel/include/string.h:
