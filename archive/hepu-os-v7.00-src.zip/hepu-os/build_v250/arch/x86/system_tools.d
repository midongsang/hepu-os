build_v250/arch/x86/system_tools.o: kernel/arch/x86/system_tools.c \
 kernel/include/system_tools.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/system_tools.h:
kernel/include/vga.h:
kernel/include/string.h:
