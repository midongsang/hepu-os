build_v250/arch/x86/browser_app.o: kernel/arch/x86/browser_app.c \
 kernel/include/browser_app.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/browser_app.h:
kernel/include/vga.h:
kernel/include/string.h:
