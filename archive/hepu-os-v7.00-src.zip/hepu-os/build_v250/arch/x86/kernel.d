build_v250/arch/x86/kernel.o: kernel/arch/x86/kernel.c \
 kernel/include/hepu.h kernel/include/vga.h kernel/include/types.h \
 kernel/include/gdt.h kernel/include/idt.h kernel/include/fingerprint.h \
 kernel/include/mm.h kernel/include/paging.h kernel/include/kheap.h \
 kernel/include/sched.h kernel/include/process.h kernel/include/paging.h \
 kernel/include/constants.h kernel/include/syscall.h kernel/include/hal.h \
 kernel/include/ipc.h kernel/include/string.h kernel/include/pic.h \
 kernel/include/pit.h kernel/include/irq.h kernel/include/keyboard.h \
 kernel/include/tss.h kernel/include/initrd.h kernel/include/vfs.h \
 kernel/include/devfs.h kernel/include/net.h kernel/include/touch.h \
 kernel/include/smp.h kernel/include/dynld.h kernel/include/usb.h \
 kernel/include/pm.h kernel/include/security.h kernel/include/dtb.h \
 kernel/include/audio.h kernel/include/camera.h \
 kernel/include/bluetooth.h kernel/include/wifi.h kernel/include/arp.h \
 kernel/include/dhcp.h kernel/include/dns.h kernel/include/icmp.h \
 kernel/include/http.h kernel/include/tls.h kernel/include/tcp.h \
 kernel/include/websocket.h kernel/include/x509.h kernel/include/csprng.h \
 kernel/include/ecdhe.h kernel/include/sha.h kernel/include/hmac.h \
 kernel/include/sha.h kernel/include/hkdf.h kernel/include/rsa.h \
 kernel/include/http2.h kernel/include/tls_handshake.h \
 kernel/include/ecdhe.h kernel/include/x509.h kernel/include/rsa.h \
 kernel/include/quic.h kernel/include/http3.h kernel/include/types.h \
 kernel/include/quic.h kernel/include/doq.h kernel/include/quic_0rtt.h \
 kernel/include/quic_migration.h kernel/include/quic_recovery.h \
 kernel/include/mp_quic.h kernel/include/quic_recovery.h \
 kernel/include/quic_datagram.h kernel/include/qpack_dynamic.h \
 kernel/include/init_sequence.h kernel/include/klog.h \
 kernel/include/kunit.h kernel/include/kbench.h \
 kernel/include/kunit_log.h kernel/include/kunit.h \
 kernel/include/services.h kernel/include/gpu.h kernel/include/sensors.h \
 kernel/include/gps.h kernel/include/ota.h kernel/include/codec.h \
 kernel/include/compositor.h kernel/include/input.h \
 kernel/include/trace.h kernel/include/media.h \
 kernel/include/camera_hal.h kernel/include/ril.h \
 kernel/include/appframework.h kernel/include/packagemanager.h \
 kernel/include/notification.h kernel/include/windowsystem.h \
 kernel/include/share.h kernel/include/account.h \
 kernel/include/systemui.h kernel/include/webengine.h kernel/include/ai.h \
 kernel/include/security2.h kernel/include/media2.h \
 kernel/include/desktopmode.h kernel/include/gameframework.h \
 kernel/include/enterprise.h kernel/include/devtools.h \
 kernel/include/compat.h kernel/include/fs2.h kernel/include/net2.h \
 kernel/include/bt2.h kernel/include/usb2.h kernel/include/gfx2.h \
 kernel/include/camera2.h kernel/include/audio2.h \
 kernel/include/telecom2.h kernel/include/ai2.h kernel/include/carlink.h \
 kernel/include/enterprise2.h kernel/include/kernel_opt.h \
 kernel/include/drivers2.h kernel/include/fs3.h kernel/include/net3.h \
 kernel/include/appeco.h kernel/include/kernel_core.h \
 kernel/include/drivers_real.h kernel/include/userland.h \
 kernel/include/fs_real.h kernel/include/bootchain.h \
 kernel/include/kdebug.h kernel/include/kperf.h \
 kernel/include/distributed.h kernel/include/hhal.h kernel/include/hdpk.h \
 kernel/include/device_support.h kernel/include/fp_enhanced.h \
 kernel/include/phone_service.h kernel/include/sms_service.h \
 kernel/include/settings_app.h kernel/include/file_manager.h \
 kernel/include/camera_app.h kernel/include/gallery_app.h \
 kernel/include/browser_app.h kernel/include/app_store.h \
 kernel/include/system_tools.h kernel/include/music_player.h \
 kernel/include/video_player.h kernel/include/photo_editor.h \
 kernel/include/voice_recorder.h kernel/include/audio_effects.h \
 kernel/include/hug_sdk.h kernel/include/hug_template.h \
 kernel/include/hug_debugger.h kernel/include/hug_depman.h \
 kernel/include/apk_parser.h kernel/include/microg_service.h \
 kernel/include/art_runtime.h kernel/include/compat_layer.h \
 kernel/include/secure_boot.h kernel/include/boot_optimizer.h \
 kernel/include/memory_optimizer.h kernel/include/kernel_slimmer.h \
 kernel/include/perf_profiler.h kernel/include/hepu_brand.h \
 kernel/include/app_container.h kernel/include/distributed_os.h \
 kernel/include/car_connect.h kernel/include/privacy_compute.h \
 kernel/include/realtime_kernel.h kernel/include/power_optimizer.h \
 kernel/include/permission_manager.h kernel/include/notification_center.h \
 kernel/include/i18n_system.h kernel/include/multilingual_ime.h \
 kernel/include/backup_restore.h kernel/include/storage_manager.h \
 kernel/include/multi_user.h kernel/include/system_stability.h \
 kernel/include/app_freeze.h kernel/include/process.h \
 kernel/include/id_randomizer.h kernel/include/elastic_desktop.h \
 kernel/include/ai_notification.h kernel/include/creator_mode.h \
 kernel/include/onboarding.h kernel/include/lowmem_throttle.h \
 kernel/include/hdpk_template.h kernel/include/android_api.h \
 kernel/include/driver_manager.h kernel/include/bist.h \
 kernel/include/ai_assistant.h kernel/include/socket.h \
 kernel/include/mount.h kernel/include/vfs.h kernel/include/quota.h \
 kernel/include/fs_registry.h kernel/include/vfat.h \
 kernel/include/journal.h kernel/include/ide.h kernel/include/ext4.h \
 kernel/include/fscrypt.h kernel/include/partition.h \
 kernel/include/unified_driver.h kernel/include/driver_manager.h \
 kernel/include/ahci.h kernel/include/nvme.h kernel/include/exfat.h \
 kernel/include/ntfs.h kernel/include/aes.h kernel/include/eth.h
kernel/include/hepu.h:
kernel/include/vga.h:
kernel/include/types.h:
kernel/include/gdt.h:
kernel/include/idt.h:
kernel/include/fingerprint.h:
kernel/include/mm.h:
kernel/include/paging.h:
kernel/include/kheap.h:
kernel/include/sched.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
kernel/include/syscall.h:
kernel/include/hal.h:
kernel/include/ipc.h:
kernel/include/string.h:
kernel/include/pic.h:
kernel/include/pit.h:
kernel/include/irq.h:
kernel/include/keyboard.h:
kernel/include/tss.h:
kernel/include/initrd.h:
kernel/include/vfs.h:
kernel/include/devfs.h:
kernel/include/net.h:
kernel/include/touch.h:
kernel/include/smp.h:
kernel/include/dynld.h:
kernel/include/usb.h:
kernel/include/pm.h:
kernel/include/security.h:
kernel/include/dtb.h:
kernel/include/audio.h:
kernel/include/camera.h:
kernel/include/bluetooth.h:
kernel/include/wifi.h:
kernel/include/arp.h:
kernel/include/dhcp.h:
kernel/include/dns.h:
kernel/include/icmp.h:
kernel/include/http.h:
kernel/include/tls.h:
kernel/include/tcp.h:
kernel/include/websocket.h:
kernel/include/x509.h:
kernel/include/csprng.h:
kernel/include/ecdhe.h:
kernel/include/sha.h:
kernel/include/hmac.h:
kernel/include/sha.h:
kernel/include/hkdf.h:
kernel/include/rsa.h:
kernel/include/http2.h:
kernel/include/tls_handshake.h:
kernel/include/ecdhe.h:
kernel/include/x509.h:
kernel/include/rsa.h:
kernel/include/quic.h:
kernel/include/http3.h:
kernel/include/types.h:
kernel/include/quic.h:
kernel/include/doq.h:
kernel/include/quic_0rtt.h:
kernel/include/quic_migration.h:
kernel/include/quic_recovery.h:
kernel/include/mp_quic.h:
kernel/include/quic_recovery.h:
kernel/include/quic_datagram.h:
kernel/include/qpack_dynamic.h:
kernel/include/init_sequence.h:
kernel/include/klog.h:
kernel/include/kunit.h:
kernel/include/kbench.h:
kernel/include/kunit_log.h:
kernel/include/kunit.h:
kernel/include/services.h:
kernel/include/gpu.h:
kernel/include/sensors.h:
kernel/include/gps.h:
kernel/include/ota.h:
kernel/include/codec.h:
kernel/include/compositor.h:
kernel/include/input.h:
kernel/include/trace.h:
kernel/include/media.h:
kernel/include/camera_hal.h:
kernel/include/ril.h:
kernel/include/appframework.h:
kernel/include/packagemanager.h:
kernel/include/notification.h:
kernel/include/windowsystem.h:
kernel/include/share.h:
kernel/include/account.h:
kernel/include/systemui.h:
kernel/include/webengine.h:
kernel/include/ai.h:
kernel/include/security2.h:
kernel/include/media2.h:
kernel/include/desktopmode.h:
kernel/include/gameframework.h:
kernel/include/enterprise.h:
kernel/include/devtools.h:
kernel/include/compat.h:
kernel/include/fs2.h:
kernel/include/net2.h:
kernel/include/bt2.h:
kernel/include/usb2.h:
kernel/include/gfx2.h:
kernel/include/camera2.h:
kernel/include/audio2.h:
kernel/include/telecom2.h:
kernel/include/ai2.h:
kernel/include/carlink.h:
kernel/include/enterprise2.h:
kernel/include/kernel_opt.h:
kernel/include/drivers2.h:
kernel/include/fs3.h:
kernel/include/net3.h:
kernel/include/appeco.h:
kernel/include/kernel_core.h:
kernel/include/drivers_real.h:
kernel/include/userland.h:
kernel/include/fs_real.h:
kernel/include/bootchain.h:
kernel/include/kdebug.h:
kernel/include/kperf.h:
kernel/include/distributed.h:
kernel/include/hhal.h:
kernel/include/hdpk.h:
kernel/include/device_support.h:
kernel/include/fp_enhanced.h:
kernel/include/phone_service.h:
kernel/include/sms_service.h:
kernel/include/settings_app.h:
kernel/include/file_manager.h:
kernel/include/camera_app.h:
kernel/include/gallery_app.h:
kernel/include/browser_app.h:
kernel/include/app_store.h:
kernel/include/system_tools.h:
kernel/include/music_player.h:
kernel/include/video_player.h:
kernel/include/photo_editor.h:
kernel/include/voice_recorder.h:
kernel/include/audio_effects.h:
kernel/include/hug_sdk.h:
kernel/include/hug_template.h:
kernel/include/hug_debugger.h:
kernel/include/hug_depman.h:
kernel/include/apk_parser.h:
kernel/include/microg_service.h:
kernel/include/art_runtime.h:
kernel/include/compat_layer.h:
kernel/include/secure_boot.h:
kernel/include/boot_optimizer.h:
kernel/include/memory_optimizer.h:
kernel/include/kernel_slimmer.h:
kernel/include/perf_profiler.h:
kernel/include/hepu_brand.h:
kernel/include/app_container.h:
kernel/include/distributed_os.h:
kernel/include/car_connect.h:
kernel/include/privacy_compute.h:
kernel/include/realtime_kernel.h:
kernel/include/power_optimizer.h:
kernel/include/permission_manager.h:
kernel/include/notification_center.h:
kernel/include/i18n_system.h:
kernel/include/multilingual_ime.h:
kernel/include/backup_restore.h:
kernel/include/storage_manager.h:
kernel/include/multi_user.h:
kernel/include/system_stability.h:
kernel/include/app_freeze.h:
kernel/include/process.h:
kernel/include/id_randomizer.h:
kernel/include/elastic_desktop.h:
kernel/include/ai_notification.h:
kernel/include/creator_mode.h:
kernel/include/onboarding.h:
kernel/include/lowmem_throttle.h:
kernel/include/hdpk_template.h:
kernel/include/android_api.h:
kernel/include/driver_manager.h:
kernel/include/bist.h:
kernel/include/ai_assistant.h:
kernel/include/socket.h:
kernel/include/mount.h:
kernel/include/vfs.h:
kernel/include/quota.h:
kernel/include/fs_registry.h:
kernel/include/vfat.h:
kernel/include/journal.h:
kernel/include/ide.h:
kernel/include/ext4.h:
kernel/include/fscrypt.h:
kernel/include/partition.h:
kernel/include/unified_driver.h:
kernel/include/driver_manager.h:
kernel/include/ahci.h:
kernel/include/nvme.h:
kernel/include/exfat.h:
kernel/include/ntfs.h:
kernel/include/aes.h:
kernel/include/eth.h:
