build_v250/arch/x86/mli_advanced.o: kernel/arch/x86/mli_advanced.c \
 kernel/include/multilingual_ime.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/multilingual_ime.h:
kernel/include/vga.h:
kernel/include/string.h:
