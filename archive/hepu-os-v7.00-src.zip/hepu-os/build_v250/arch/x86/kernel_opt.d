build_v250/arch/x86/kernel_opt.o: kernel/arch/x86/kernel_opt.c \
 kernel/include/kernel_opt.h kernel/include/vga.h kernel/include/string.h
kernel/include/kernel_opt.h:
kernel/include/vga.h:
kernel/include/string.h:
