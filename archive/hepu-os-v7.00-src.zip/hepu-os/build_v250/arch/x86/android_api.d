build_v250/arch/x86/android_api.o: kernel/arch/x86/android_api.c \
 kernel/include/android_api.h kernel/include/vga.h \
 kernel/include/string.h kernel/include/kheap.h
kernel/include/android_api.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kheap.h:
