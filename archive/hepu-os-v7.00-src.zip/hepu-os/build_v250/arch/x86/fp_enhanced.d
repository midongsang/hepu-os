build_v250/arch/x86/fp_enhanced.o: kernel/arch/x86/fp_enhanced.c \
 kernel/include/fp_enhanced.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/fp_enhanced.h:
kernel/include/vga.h:
kernel/include/string.h:
