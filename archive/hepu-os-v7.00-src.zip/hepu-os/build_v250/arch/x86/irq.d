build_v250/arch/x86/irq.o: kernel/arch/x86/irq.c kernel/include/irq.h \
 kernel/include/pic.h kernel/include/pit.h kernel/include/smp.h \
 kernel/include/vga.h
kernel/include/irq.h:
kernel/include/pic.h:
kernel/include/pit.h:
kernel/include/smp.h:
kernel/include/vga.h:
