build_v250/arch/x86/desktop_render.o: kernel/arch/x86/desktop_render.c \
 kernel/include/elastic_desktop.h kernel/include/vga_gfx.h \
 kernel/include/string.h kernel/include/kstdio.h \
 kernel/include/font_antialiased.h
kernel/include/elastic_desktop.h:
kernel/include/vga_gfx.h:
kernel/include/string.h:
kernel/include/kstdio.h:
kernel/include/font_antialiased.h:
