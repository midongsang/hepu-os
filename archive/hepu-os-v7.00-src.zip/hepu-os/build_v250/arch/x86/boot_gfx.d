build_v250/arch/x86/boot_gfx.o: kernel/arch/x86/boot_gfx.c \
 kernel/include/boot_gfx.h kernel/include/font8x16.h \
 kernel/include/string.h kernel/include/paging.h
kernel/include/boot_gfx.h:
kernel/include/font8x16.h:
kernel/include/string.h:
kernel/include/paging.h:
