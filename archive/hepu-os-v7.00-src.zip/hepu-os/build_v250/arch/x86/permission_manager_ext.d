build_v250/arch/x86/permission_manager_ext.o: \
 kernel/arch/x86/permission_manager_ext.c kernel/include/string.h \
 kernel/include/permission_manager.h
kernel/include/string.h:
kernel/include/permission_manager.h:
