build_v250/arch/x86/app_container.o: kernel/arch/x86/app_container.c \
 kernel/include/app_container.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/app_container.h:
kernel/include/vga.h:
kernel/include/string.h:
