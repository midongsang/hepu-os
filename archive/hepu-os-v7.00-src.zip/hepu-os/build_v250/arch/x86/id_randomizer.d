build_v250/arch/x86/id_randomizer.o: kernel/arch/x86/id_randomizer.c \
 kernel/include/id_randomizer.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/id_randomizer.h:
kernel/include/vga.h:
kernel/include/string.h:
