build_v250/arch/x86/kperf.o: kernel/arch/x86/kperf.c \
 kernel/include/kperf.h kernel/include/vga.h kernel/include/string.h
kernel/include/kperf.h:
kernel/include/vga.h:
kernel/include/string.h:
