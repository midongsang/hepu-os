build_v250/arch/x86/sms_service.o: kernel/arch/x86/sms_service.c \
 kernel/include/sms_service.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/sms_service.h:
kernel/include/vga.h:
kernel/include/string.h:
