build_v250/arch/x86/kernel_slimmer.o: kernel/arch/x86/kernel_slimmer.c \
 kernel/include/kernel_slimmer.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/kernel_slimmer.h:
kernel/include/vga.h:
kernel/include/string.h:
