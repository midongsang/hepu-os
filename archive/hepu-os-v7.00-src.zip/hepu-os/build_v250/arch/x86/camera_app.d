build_v250/arch/x86/camera_app.o: kernel/arch/x86/camera_app.c \
 kernel/include/camera_app.h kernel/include/vga.h kernel/include/string.h \
 kernel/include/kstdio.h
kernel/include/camera_app.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kstdio.h:
