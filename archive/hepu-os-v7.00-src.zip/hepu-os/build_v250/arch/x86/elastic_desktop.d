build_v250/arch/x86/elastic_desktop.o: kernel/arch/x86/elastic_desktop.c \
 kernel/include/elastic_desktop.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/elastic_desktop.h:
kernel/include/vga.h:
kernel/include/string.h:
