build_v250/arch/x86/apic.o: kernel/arch/x86/apic.c kernel/include/apic.h \
 kernel/include/acpi.h kernel/include/vga.h kernel/include/paging.h
kernel/include/apic.h:
kernel/include/acpi.h:
kernel/include/vga.h:
kernel/include/paging.h:
