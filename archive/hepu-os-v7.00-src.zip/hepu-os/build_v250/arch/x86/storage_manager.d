build_v250/arch/x86/storage_manager.o: kernel/arch/x86/storage_manager.c \
 kernel/include/storage_manager.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/storage_manager.h:
kernel/include/vga.h:
kernel/include/string.h:
