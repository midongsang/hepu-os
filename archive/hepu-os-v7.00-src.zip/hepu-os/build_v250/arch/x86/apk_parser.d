build_v250/arch/x86/apk_parser.o: kernel/arch/x86/apk_parser.c \
 kernel/include/apk_parser.h kernel/include/vga.h kernel/include/string.h
kernel/include/apk_parser.h:
kernel/include/vga.h:
kernel/include/string.h:
