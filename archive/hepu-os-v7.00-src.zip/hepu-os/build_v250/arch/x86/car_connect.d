build_v250/arch/x86/car_connect.o: kernel/arch/x86/car_connect.c \
 kernel/include/car_connect.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/car_connect.h:
kernel/include/vga.h:
kernel/include/string.h:
