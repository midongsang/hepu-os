build_v250/arch/x86/music_player.o: kernel/arch/x86/music_player.c \
 kernel/include/music_player.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/music_player.h:
kernel/include/vga.h:
kernel/include/string.h:
