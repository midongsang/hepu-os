build_v250/arch/x86/audio_effects.o: kernel/arch/x86/audio_effects.c \
 kernel/include/audio_effects.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/audio_effects.h:
kernel/include/vga.h:
kernel/include/string.h:
