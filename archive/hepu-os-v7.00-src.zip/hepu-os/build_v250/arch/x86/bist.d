build_v250/arch/x86/bist.o: kernel/arch/x86/bist.c kernel/include/bist.h \
 kernel/include/vga.h kernel/include/string.h kernel/include/kheap.h \
 kernel/include/process.h kernel/include/paging.h \
 kernel/include/constants.h
kernel/include/bist.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kheap.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
