build_v250/arch/x86/settings_app.o: kernel/arch/x86/settings_app.c \
 kernel/include/settings_app.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/settings_app.h:
kernel/include/vga.h:
kernel/include/string.h:
