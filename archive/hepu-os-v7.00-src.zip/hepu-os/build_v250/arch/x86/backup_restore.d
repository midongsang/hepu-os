build_v250/arch/x86/backup_restore.o: kernel/arch/x86/backup_restore.c \
 kernel/include/backup_restore.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/backup_restore.h:
kernel/include/vga.h:
kernel/include/string.h:
