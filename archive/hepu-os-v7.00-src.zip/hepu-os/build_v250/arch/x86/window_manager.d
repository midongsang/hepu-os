build_v250/arch/x86/window_manager.o: kernel/arch/x86/window_manager.c \
 kernel/include/window_manager.h kernel/include/vga_gfx.h \
 kernel/include/string.h
kernel/include/window_manager.h:
kernel/include/vga_gfx.h:
kernel/include/string.h:
