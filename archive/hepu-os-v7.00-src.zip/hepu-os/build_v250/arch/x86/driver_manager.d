build_v250/arch/x86/driver_manager.o: kernel/arch/x86/driver_manager.c \
 kernel/include/driver_manager.h kernel/include/vga.h \
 kernel/include/string.h kernel/include/kheap.h
kernel/include/driver_manager.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kheap.h:
