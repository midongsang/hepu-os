build_v250/arch/x86/microg_service.o: kernel/arch/x86/microg_service.c \
 kernel/include/microg_service.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/microg_service.h:
kernel/include/vga.h:
kernel/include/string.h:
