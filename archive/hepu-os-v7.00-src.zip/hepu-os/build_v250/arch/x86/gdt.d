build_v250/arch/x86/gdt.o: kernel/arch/x86/gdt.c kernel/include/gdt.h \
 kernel/include/constants.h
kernel/include/gdt.h:
kernel/include/constants.h:
