build_v250/arch/x86/ui_widgets.o: kernel/arch/x86/ui_widgets.c \
 kernel/include/ui_widgets.h kernel/include/vga_gfx.h \
 kernel/include/string.h
kernel/include/ui_widgets.h:
kernel/include/vga_gfx.h:
kernel/include/string.h:
