build_v250/arch/x86/bootchain.o: kernel/arch/x86/bootchain.c \
 kernel/include/bootchain.h kernel/include/constants.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/bootchain.h:
kernel/include/constants.h:
kernel/include/vga.h:
kernel/include/string.h:
