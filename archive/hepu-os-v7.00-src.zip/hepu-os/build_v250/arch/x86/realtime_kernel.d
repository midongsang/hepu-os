build_v250/arch/x86/realtime_kernel.o: kernel/arch/x86/realtime_kernel.c \
 kernel/include/realtime_kernel.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/realtime_kernel.h:
kernel/include/vga.h:
kernel/include/string.h:
