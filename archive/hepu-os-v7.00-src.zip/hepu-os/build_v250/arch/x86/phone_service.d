build_v250/arch/x86/phone_service.o: kernel/arch/x86/phone_service.c \
 kernel/include/phone_service.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/phone_service.h:
kernel/include/vga.h:
kernel/include/string.h:
