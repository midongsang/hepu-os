build_v250/arch/x86/onboarding.o: kernel/arch/x86/onboarding.c \
 kernel/include/onboarding.h kernel/include/vga.h kernel/include/string.h
kernel/include/onboarding.h:
kernel/include/vga.h:
kernel/include/string.h:
