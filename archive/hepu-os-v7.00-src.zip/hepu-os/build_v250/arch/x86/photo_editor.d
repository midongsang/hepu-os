build_v250/arch/x86/photo_editor.o: kernel/arch/x86/photo_editor.c \
 kernel/include/photo_editor.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/photo_editor.h:
kernel/include/vga.h:
kernel/include/string.h:
