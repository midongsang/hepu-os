build_v250/arch/x86/sys_net.o: kernel/arch/x86/sys_net.c \
 kernel/include/types.h kernel/include/syscall.h kernel/include/socket.h \
 kernel/include/vga.h kernel/include/string.h kernel/include/process.h \
 kernel/include/paging.h kernel/include/constants.h
kernel/include/types.h:
kernel/include/syscall.h:
kernel/include/socket.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
