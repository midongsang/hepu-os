build_v250/arch/x86/syscall_debug.o: kernel/arch/x86/syscall_debug.c
