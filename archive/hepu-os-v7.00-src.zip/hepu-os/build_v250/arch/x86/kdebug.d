build_v250/arch/x86/kdebug.o: kernel/arch/x86/kdebug.c \
 kernel/include/kdebug.h kernel/include/vga.h kernel/include/string.h
kernel/include/kdebug.h:
kernel/include/vga.h:
kernel/include/string.h:
