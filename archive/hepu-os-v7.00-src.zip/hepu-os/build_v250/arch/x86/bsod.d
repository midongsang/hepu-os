build_v250/arch/x86/bsod.o: kernel/arch/x86/bsod.c kernel/include/bsod.h \
 kernel/include/vga.h kernel/include/vga_gfx.h kernel/include/serial.h
kernel/include/bsod.h:
kernel/include/vga.h:
kernel/include/vga_gfx.h:
kernel/include/serial.h:
