build_v250/arch/x86/file_manager.o: kernel/arch/x86/file_manager.c \
 kernel/include/file_manager.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/file_manager.h:
kernel/include/vga.h:
kernel/include/string.h:
