build_v250/arch/x86/tss.o: kernel/arch/x86/tss.c kernel/include/tss.h \
 kernel/include/gdt.h kernel/include/vga.h
kernel/include/tss.h:
kernel/include/gdt.h:
kernel/include/vga.h:
