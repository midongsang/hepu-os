build_v250/arch/x86/hug_debugger.o: kernel/arch/x86/hug_debugger.c \
 kernel/include/hug_debugger.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/hug_debugger.h:
kernel/include/vga.h:
kernel/include/string.h:
