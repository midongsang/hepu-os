build_v250/ipc/service.o: kernel/ipc/service.c kernel/include/types.h \
 kernel/include/string.h kernel/include/vga.h kernel/include/sched.h
kernel/include/types.h:
kernel/include/string.h:
kernel/include/vga.h:
kernel/include/sched.h:
