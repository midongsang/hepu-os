build_v250/ipc/ipc.o: kernel/ipc/ipc.c kernel/include/ipc.h \
 kernel/include/vga.h kernel/include/string.h kernel/include/kheap.h \
 kernel/include/sched.h
kernel/include/ipc.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kheap.h:
kernel/include/sched.h:
