build_v250/ipc/ipc_fifo.o: kernel/ipc/ipc_fifo.c \
 kernel/include/ipc_fifo.h kernel/include/vga.h kernel/include/string.h
kernel/include/ipc_fifo.h:
kernel/include/vga.h:
kernel/include/string.h:
