build_v250/ipc/ipc_mutex.o: kernel/ipc/ipc_mutex.c \
 kernel/include/ipc_mutex.h kernel/include/vga.h kernel/include/string.h \
 kernel/include/pit.h
kernel/include/ipc_mutex.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/pit.h:
