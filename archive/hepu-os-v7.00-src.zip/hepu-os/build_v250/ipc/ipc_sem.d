build_v250/ipc/ipc_sem.o: kernel/ipc/ipc_sem.c kernel/include/ipc_sem.h \
 kernel/include/vga.h kernel/include/pit.h kernel/include/string.h
kernel/include/ipc_sem.h:
kernel/include/vga.h:
kernel/include/pit.h:
kernel/include/string.h:
