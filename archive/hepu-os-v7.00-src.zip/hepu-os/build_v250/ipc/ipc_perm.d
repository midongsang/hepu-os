build_v250/ipc/ipc_perm.o: kernel/ipc/ipc_perm.c \
 kernel/include/ipc_perm.h kernel/include/vga.h kernel/include/string.h
kernel/include/ipc_perm.h:
kernel/include/vga.h:
kernel/include/string.h:
