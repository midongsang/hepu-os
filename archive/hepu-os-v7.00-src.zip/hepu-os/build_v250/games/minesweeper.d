build_v250/games/minesweeper.o: kernel/games/minesweeper.c \
 kernel/include/vga_gfx.h
kernel/include/vga_gfx.h:
