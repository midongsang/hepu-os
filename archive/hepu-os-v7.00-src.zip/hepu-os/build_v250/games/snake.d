build_v250/games/snake.o: kernel/games/snake.c kernel/include/vga_gfx.h \
 kernel/include/keyboard.h kernel/include/pit.h
kernel/include/vga_gfx.h:
kernel/include/keyboard.h:
kernel/include/pit.h:
