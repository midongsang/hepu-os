build_v250/games/tetris.o: kernel/games/tetris.c kernel/include/vga_gfx.h
kernel/include/vga_gfx.h:
