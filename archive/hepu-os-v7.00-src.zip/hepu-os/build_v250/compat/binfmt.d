build_v250/compat/binfmt.o: kernel/compat/binfmt.c \
 kernel/include/binfmt.h kernel/include/elf32.h kernel/include/vga.h
kernel/include/binfmt.h:
kernel/include/elf32.h:
kernel/include/vga.h:
