build_v250/compat/binfmt_elf.o: kernel/compat/binfmt_elf.c \
 kernel/include/string.h kernel/include/binfmt.h kernel/include/elf32.h \
 kernel/include/constants.h kernel/include/paging.h \
 kernel/include/process.h kernel/include/paging.h \
 kernel/include/constants.h kernel/include/vfs.h kernel/include/vga.h
kernel/include/string.h:
kernel/include/binfmt.h:
kernel/include/elf32.h:
kernel/include/constants.h:
kernel/include/paging.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
kernel/include/vfs.h:
kernel/include/vga.h:
