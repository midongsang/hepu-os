build_v250/compat/darwin_abi.o: kernel/compat/darwin_abi.c \
 kernel/include/darwin_abi.h kernel/include/syscall.h
kernel/include/darwin_abi.h:
kernel/include/syscall.h:
