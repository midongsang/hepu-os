build_v250/compat/linux_abi.o: kernel/compat/linux_abi.c \
 kernel/include/linux_abi.h kernel/include/syscall.h
kernel/include/linux_abi.h:
kernel/include/syscall.h:
