build_v250/compat/binfmt_pe_util.o: kernel/compat/binfmt_pe_util.c \
 kernel/include/string.h kernel/include/process.h kernel/include/paging.h \
 kernel/include/constants.h kernel/include/paging.h \
 kernel/include/binfmt.h
kernel/include/string.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
kernel/include/paging.h:
kernel/include/binfmt.h:
