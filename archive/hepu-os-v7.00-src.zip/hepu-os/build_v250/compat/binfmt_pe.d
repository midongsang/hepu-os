build_v250/compat/binfmt_pe.o: kernel/compat/binfmt_pe.c \
 kernel/include/string.h kernel/include/binfmt.h \
 kernel/include/constants.h kernel/include/paging.h \
 kernel/include/process.h kernel/include/paging.h \
 kernel/include/constants.h kernel/include/vfs.h kernel/include/vga.h \
 kernel/include/serial.h
kernel/include/string.h:
kernel/include/binfmt.h:
kernel/include/constants.h:
kernel/include/paging.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
kernel/include/vfs.h:
kernel/include/vga.h:
kernel/include/serial.h:
