build_v250/compat/binfmt_macho.o: kernel/compat/binfmt_macho.c \
 kernel/include/binfmt.h kernel/include/vga.h kernel/include/string.h \
 kernel/include/process.h kernel/include/paging.h \
 kernel/include/constants.h kernel/include/paging.h kernel/include/vfs.h
kernel/include/binfmt.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
kernel/include/paging.h:
kernel/include/vfs.h:
