build_v250/compat/binfmt_pe_stub.o: kernel/compat/binfmt_pe_stub.c
