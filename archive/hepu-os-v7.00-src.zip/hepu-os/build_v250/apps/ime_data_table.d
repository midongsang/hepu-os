build_v250/apps/ime_data_table.o: kernel/apps/ime_data_table.c
