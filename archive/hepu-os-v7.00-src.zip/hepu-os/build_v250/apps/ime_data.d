build_v250/apps/ime_data.o: kernel/apps/ime_data.c
