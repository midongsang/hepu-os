build_v250/apps/notes.o: kernel/apps/notes.c \
 kernel/include/system_tools.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/system_tools.h:
kernel/include/vga.h:
kernel/include/string.h:
