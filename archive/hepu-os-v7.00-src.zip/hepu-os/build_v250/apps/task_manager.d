build_v250/apps/task_manager.o: kernel/apps/task_manager.c \
 kernel/include/string.h kernel/include/vga.h kernel/include/process.h \
 kernel/include/paging.h kernel/include/constants.h kernel/include/mm.h \
 kernel/include/vram.h kernel/include/virtual_vram.h \
 kernel/include/kheap.h kernel/include/keyboard.h
kernel/include/string.h:
kernel/include/vga.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
kernel/include/mm.h:
kernel/include/vram.h:
kernel/include/virtual_vram.h:
kernel/include/kheap.h:
kernel/include/keyboard.h:
