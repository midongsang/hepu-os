build_v250/apps/ime.o: kernel/apps/ime.c kernel/include/ime.h \
 kernel/include/string.h kernel/include/ide_ext2.h
kernel/include/ime.h:
kernel/include/string.h:
kernel/include/ide_ext2.h:
