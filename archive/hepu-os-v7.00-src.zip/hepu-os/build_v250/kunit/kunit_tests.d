build_v250/kunit/kunit_tests.o: kernel/kunit/kunit_tests.c \
 kernel/include/types.h kernel/include/kunit.h kernel/include/types.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/types.h:
kernel/include/kunit.h:
kernel/include/types.h:
kernel/include/vga.h:
kernel/include/string.h:
