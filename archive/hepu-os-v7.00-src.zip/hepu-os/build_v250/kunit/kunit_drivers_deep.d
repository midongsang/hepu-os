build_v250/kunit/kunit_drivers_deep.o: kernel/kunit/kunit_drivers_deep.c \
 kernel/include/kunit.h kernel/include/types.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/kunit.h:
kernel/include/types.h:
kernel/include/vga.h:
kernel/include/string.h:
