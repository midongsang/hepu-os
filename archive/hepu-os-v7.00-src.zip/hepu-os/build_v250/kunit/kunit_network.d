build_v250/kunit/kunit_network.o: kernel/kunit/kunit_network.c \
 kernel/include/kunit.h kernel/include/types.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/kunit.h:
kernel/include/types.h:
kernel/include/vga.h:
kernel/include/string.h:
