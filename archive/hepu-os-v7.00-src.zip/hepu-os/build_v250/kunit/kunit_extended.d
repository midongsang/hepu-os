build_v250/kunit/kunit_extended.o: kernel/kunit/kunit_extended.c \
 kernel/include/types.h kernel/include/kunit.h kernel/include/types.h \
 kernel/include/vga.h kernel/include/string.h
kernel/include/types.h:
kernel/include/kunit.h:
kernel/include/types.h:
kernel/include/vga.h:
kernel/include/string.h:
