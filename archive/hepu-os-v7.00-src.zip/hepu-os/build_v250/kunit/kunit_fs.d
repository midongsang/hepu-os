build_v250/kunit/kunit_fs.o: kernel/kunit/kunit_fs.c \
 kernel/include/kunit.h kernel/include/types.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/kunit.h:
kernel/include/types.h:
kernel/include/vga.h:
kernel/include/string.h:
