build_v250/kunit/kunit_v102_mem.o: kernel/kunit/kunit_v102_mem.c \
 kernel/include/kunit.h kernel/include/types.h kernel/include/vga.h \
 kernel/include/string.h kernel/include/reclaim.h kernel/include/swap.h \
 kernel/include/hugetlb.h kernel/include/paging.h
kernel/include/kunit.h:
kernel/include/types.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/reclaim.h:
kernel/include/swap.h:
kernel/include/hugetlb.h:
kernel/include/paging.h:
