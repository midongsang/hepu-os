build_v250/kunit/kunit.o: kernel/kunit/kunit.c kernel/include/types.h \
 kernel/include/kunit.h kernel/include/types.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/types.h:
kernel/include/kunit.h:
kernel/include/types.h:
kernel/include/vga.h:
kernel/include/string.h:
