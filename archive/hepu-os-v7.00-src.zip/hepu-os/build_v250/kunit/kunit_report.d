build_v250/kunit/kunit_report.o: kernel/kunit/kunit_report.c \
 kernel/include/kunit.h kernel/include/types.h kernel/include/kunit_log.h \
 kernel/include/kunit.h kernel/include/vga.h kernel/include/string.h
kernel/include/kunit.h:
kernel/include/types.h:
kernel/include/kunit_log.h:
kernel/include/kunit.h:
kernel/include/vga.h:
kernel/include/string.h:
