build_v250/kunit/kunit_boot.o: kernel/kunit/kunit_boot.c \
 kernel/include/kunit.h kernel/include/types.h kernel/include/vga.h \
 kernel/include/string.h kernel/include/constants.h
kernel/include/kunit.h:
kernel/include/types.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/constants.h:
