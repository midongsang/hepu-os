build_v250/kunit/kbench.o: kernel/kunit/kbench.c kernel/include/types.h \
 kernel/include/kbench.h kernel/include/types.h kernel/include/vga.h
kernel/include/types.h:
kernel/include/kbench.h:
kernel/include/types.h:
kernel/include/vga.h:
