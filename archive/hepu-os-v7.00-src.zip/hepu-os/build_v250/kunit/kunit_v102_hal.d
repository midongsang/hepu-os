build_v250/kunit/kunit_v102_hal.o: kernel/kunit/kunit_v102_hal.c \
 kernel/include/kunit.h kernel/include/types.h kernel/include/vga.h \
 kernel/include/string.h kernel/include/ipc_perm.h kernel/include/acpi.h \
 kernel/include/hotplug.h kernel/include/hal_device.h
kernel/include/kunit.h:
kernel/include/types.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/ipc_perm.h:
kernel/include/acpi.h:
kernel/include/hotplug.h:
kernel/include/hal_device.h:
