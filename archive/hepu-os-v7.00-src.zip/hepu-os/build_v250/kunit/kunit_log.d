build_v250/kunit/kunit_log.o: kernel/kunit/kunit_log.c \
 kernel/include/types.h kernel/include/kunit_log.h kernel/include/types.h \
 kernel/include/kunit.h kernel/include/vga.h kernel/include/string.h
kernel/include/types.h:
kernel/include/kunit_log.h:
kernel/include/types.h:
kernel/include/kunit.h:
kernel/include/vga.h:
kernel/include/string.h:
