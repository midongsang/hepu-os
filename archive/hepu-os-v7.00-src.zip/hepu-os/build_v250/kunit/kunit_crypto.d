build_v250/kunit/kunit_crypto.o: kernel/kunit/kunit_crypto.c \
 kernel/include/kunit.h kernel/include/types.h kernel/include/vga.h \
 kernel/include/string.h kernel/include/sha.h kernel/include/hmac.h \
 kernel/include/sha.h kernel/include/aes.h
kernel/include/kunit.h:
kernel/include/types.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/sha.h:
kernel/include/hmac.h:
kernel/include/sha.h:
kernel/include/aes.h:
