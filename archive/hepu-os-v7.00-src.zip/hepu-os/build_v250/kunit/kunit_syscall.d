build_v250/kunit/kunit_syscall.o: kernel/kunit/kunit_syscall.c \
 kernel/include/kunit.h kernel/include/types.h kernel/include/vga.h \
 kernel/include/string.h kernel/include/syscall.h
kernel/include/kunit.h:
kernel/include/types.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/syscall.h:
