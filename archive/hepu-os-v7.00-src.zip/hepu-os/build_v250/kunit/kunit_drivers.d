build_v250/kunit/kunit_drivers.o: kernel/kunit/kunit_drivers.c \
 kernel/include/kunit.h kernel/include/types.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/kunit.h:
kernel/include/types.h:
kernel/include/vga.h:
kernel/include/string.h:
