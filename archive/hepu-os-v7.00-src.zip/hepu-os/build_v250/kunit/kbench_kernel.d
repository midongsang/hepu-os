build_v250/kunit/kbench_kernel.o: kernel/kunit/kbench_kernel.c \
 kernel/include/types.h kernel/include/kbench.h kernel/include/types.h \
 kernel/include/ipc.h kernel/include/ipc_sem.h kernel/include/ipc_mutex.h \
 kernel/include/mm.h kernel/include/string.h kernel/include/vga.h
kernel/include/types.h:
kernel/include/kbench.h:
kernel/include/types.h:
kernel/include/ipc.h:
kernel/include/ipc_sem.h:
kernel/include/ipc_mutex.h:
kernel/include/mm.h:
kernel/include/string.h:
kernel/include/vga.h:
