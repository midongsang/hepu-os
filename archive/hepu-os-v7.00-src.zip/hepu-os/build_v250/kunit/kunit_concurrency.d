build_v250/kunit/kunit_concurrency.o: kernel/kunit/kunit_concurrency.c \
 kernel/include/kunit.h kernel/include/types.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/kunit.h:
kernel/include/types.h:
kernel/include/vga.h:
kernel/include/string.h:
