build_v250/kunit/kbench_report.o: kernel/kunit/kbench_report.c \
 kernel/include/kbench.h kernel/include/types.h kernel/include/vga.h \
 kernel/include/string.h
kernel/include/kbench.h:
kernel/include/types.h:
kernel/include/vga.h:
kernel/include/string.h:
