build_v250/kunit/kunit_memory_safety.o: \
 kernel/kunit/kunit_memory_safety.c kernel/include/kunit.h \
 kernel/include/types.h kernel/include/vga.h kernel/include/string.h \
 kernel/include/kheap.h
kernel/include/kunit.h:
kernel/include/types.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/kheap.h:
