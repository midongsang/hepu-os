build_v250/kunit/kunit_error_boundary.o: \
 kernel/kunit/kunit_error_boundary.c kernel/include/kunit.h \
 kernel/include/types.h kernel/include/vga.h kernel/include/string.h
kernel/include/kunit.h:
kernel/include/types.h:
kernel/include/vga.h:
kernel/include/string.h:
