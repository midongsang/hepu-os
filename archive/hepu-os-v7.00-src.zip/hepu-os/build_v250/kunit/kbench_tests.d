build_v250/kunit/kbench_tests.o: kernel/kunit/kbench_tests.c \
 kernel/include/types.h kernel/include/kbench.h kernel/include/types.h \
 kernel/include/string.h
kernel/include/types.h:
kernel/include/kbench.h:
kernel/include/types.h:
kernel/include/string.h:
