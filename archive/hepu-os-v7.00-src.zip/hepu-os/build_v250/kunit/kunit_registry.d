build_v250/kunit/kunit_registry.o: kernel/kunit/kunit_registry.c \
 kernel/include/vga.h
kernel/include/vga.h:
