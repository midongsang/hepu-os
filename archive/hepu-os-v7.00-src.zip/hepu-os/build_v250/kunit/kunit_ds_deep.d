build_v250/kunit/kunit_ds_deep.o: kernel/kunit/kunit_ds_deep.c \
 kernel/include/kunit.h kernel/include/types.h kernel/include/vga.h \
 kernel/include/string.h kernel/include/types.h kernel/include/kheap.h
kernel/include/kunit.h:
kernel/include/types.h:
kernel/include/vga.h:
kernel/include/string.h:
kernel/include/types.h:
kernel/include/kheap.h:
