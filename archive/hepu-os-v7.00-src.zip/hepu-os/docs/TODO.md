# 赫普OS 开发待办与项目记录（DEV BACKLOG）

> 集中整理项目内分散的未完成项、版本里程碑与环境限制，作为开发 backlog 与项目记录。
> 创建日期：2026-09-20 ｜ 最后更新：2026-09-23 ｜ 状态字段：`待办 / 进行中 / 已解决 / 环境限制`
> 
> ⚠️ **本文档已部分过时**，最新状态请参考 [DEVELOPMENT_STATUS.md](DEVELOPMENT_STATUS.md)

---

## 1. 未完成项清单（按优先级）

### P0 · 当前引导链阻塞项（最高优先级）

| # | 待办项 | 说明 | 来源 | 状态 |
|---|--------|------|------|------|
| 0 | **回实模式后 BIOS INT13 递归中断致 SEG2 无法加载** | 保护模式→实模式切换后 BIOS 中断/磁盘状态被扰乱，INT13 AH=42 切换栈且不切回→IRET 弹出垃圾返回地址→递归中断。**V6.45 已修复**：回实模式后显式 lidt 加载 BIOS IVT + INT13 AH=00 磁盘重置。系统已成功启动到内核，运行用户态进程。详见 docs/BOOTLOADER_BUG_HISTORY.md BUG-10 | V6.35-V6.45 排障 | **已解决** |

### P0 · 真机硬件适配类（需真机，QEMU 无法验证）

| # | 待办项 | 说明 | 来源 | 状态 |
|---|--------|------|------|------|
| 1 | 触屏驱动真机适配 | touch_hw.c 的 I2C 控制器（Goodix GT9xx / FocalTech FT5x06）：i2c_base/i2c_addr/rst_gpio/int_gpio、坐标分辨率与反向校准（代码中 `TODO_HW` 标记） | DESIGN.md V2.50、GUI_DESIGN 阶段E | 待办 |
| 2 | 触摸/电源键唤醒 | 自动休眠后当前仅键盘任意键唤醒，触摸/电源键唤醒未接入（触屏 TODO_HW 前置） | DESIGN.md V2.60-61 | 待办 |
| 3 | 真机显示器电源关断 | 当前为原型级黑屏模拟，需 ACPI/APM 真正关断（S 阶段 TODO） | DESIGN.md V2.61 | 待办 |
| 4 | VGA 字体 plane 2 恢复生效 | QEMU std VGA 读回恒 0x0F 属环境限制；恢复代码已保留，待真机验证生效 | DESIGN.md V3.82 | 待办 |

### P1 · 验证未闭环（E-121 发布门槛）

| # | 待办项 | 说明 | 来源 | 状态 |
|---|--------|------|------|------|
| 5 | CHS 读盘兜底路径验证 | 模拟 LBA 失败走 INT13 AH=02h CHS 读盘的兜底路径未验证 | DESIGN.md E-121 4.4 | 待办 |
| 6 | LBA 读盘成功路径复验 | 发布前通过 QEMU SeaBIOS 全链路启动 + LBA 成功路径 | DESIGN.md E-121 4.4 | 待办 |
| 7 | 错误显示完整性确认 | E AH=xx D=xx 错误显示（AH/DL） | DESIGN.md E-121 4.4 | 待办 |

### P2 · 代码级工程项

| # | 待办项 | 说明 | 来源 | 状态 |
|---|--------|------|------|------|
| 8 | 用户态内存隔离（分页启用） | 原型阶段分页未启用，用户态无内存隔离（mm_alloc_page 低地址分配可能碰 IVT/BIOS 区，低风险记录） | DESIGN.md V2.24 边界记录 | 待办 |
| 9 | 文档重复清理 | DESIGN.md 与 DESIGN_V1.11.md 章节重叠；版本记录表缺 V3.83+ 条目 | DESIGN.md I.4、INDEX.md 2.1 | 待办 |
| 10 | 遗留 TBD 标记清理 | 文档/日志中历史 TBD 标记（如早期 TSS 标记）更新为实际状态 | DESIGN.md V2.22 | 待办 |

### P3 · 环境与工具（非代码缺陷）

| # | 项 | 说明 | 状态 |
|---|-----|------|------|
| 11 | QEMU 未安装 | 编译不受影响；运行验证需安装 qemu-system-i386 或使用项目文档中的 QEMU 验证流程 | **已解决**（qemu-system-x86_64已安装） |
| 12 | 无真机硬件 | 驱动真机适配（触屏/电源/字体）无法验证 | 环境限制 |
| 13 | QEMU 已知局限 | 图形模式 sendkey 不可达、screendump 花屏（文本模式应 dump VGA 缓冲） | 环境限制（文档已记录） |

---

## 2. 版本里程碑时间线（V0.26 → V6.64）

| 阶段 | 版本 | 关键成果 |
|------|------|----------|
| 能力扩张 | V0.26-V0.31 | H-HAL/H-DPK、系统套件、.hug SDK、APK 兼容层、AI 自适应、企业安全（内核 876KB/148文件） |
| 概念验证 | V0.32-V0.35 | 5G/折叠屏/端侧LLM/容器/分布式；八大手机刚需；内核精简 989→800KB；后台冻结/ID随机化/弹性桌面/AI通知 |
| 文档落地 | V0.36 | 创变自由模式/新手引导/低内存节流/H-DPK模板 —— 文档承诺 6 项全部落地 |
| 系统调用 | V0.37 | 系统调用 21→63；4 个实用 .hug 应用 |
| 工程优化 | V0.42-V0.44 | 内核体积 1015→334KB（-67%）；fork/execve；socket 子系统；constants.h 统一 |
| 文件系统 | V0.45-V0.57 | ext2 写入→多级路径→symlink→时间戳→挂载→VFAT/ext4→IDE/AHCI→NVMe→exFAT/NTFS→fscrypt/quota/journal |
| 网络与安全 | V0.58-V0.76 | AES/ECDHE/SHA/RSA/HKDF 全套密码学；eth0/WiFi/蓝牙；DHCP/DNS/ICMP；HTTP/TLS/WebSocket；QUIC/HTTP3 协议族；syscall.c 拆分，所有文件 <500行 |
| 测试体系 | V0.77-V0.94 | KUnit 框架，35 套件 341 用例；类型统一 type_promote.py |
| 核心深化 | V0.95-V1.02 | mm（pmm/slab/vma/hugetlb/reclaim/swap）、IPC（sem/mutex/fifo）、HAL 深化、COW、ACPI、热插拔；V1.01 编译警告清零 |
| 引导与镜像 | V1.84-V2.20 | 自研 MBR+stage2+ISO9660/El Torito；isohybrid；真机排错长链（A20/E820/保护模式/跳转）；QEMU IMG 全链路启动 |
| GUI 桌面 | V2.21-V2.40 | ring3/TSS；PCI/IDE 真实驱动；ext2 落盘；GUI 双缓冲；主题/控件库/中文渲染/VBE 高分辨率 |
| GUI 手机模式 | V2.42-V2.53 | mobile.c 手机框架；8 应用全可交互；触屏框架；双模式互切+持久化 |
| 电源与安全 | V2.54-V2.76 | 休眠/唤醒/省电/屏幕电源；USB 栈；MAC/SELinux 式；沙箱/权限/隐私看板/数据域 |
| 应用深化 | V2.77-V3.25 | 通话/相机/相册/浏览器/音乐/时钟/计算器/RTC 闹钟；14 轮全量检查批次 |
| 中文系统 | V3.26-V3.82 | 中文字库 2151 字；IME 拼音；短信/通讯录全功能；TRON 主题；多语言；combo 镜像；VGA 花屏根治 |
| 工程深化 | V3.88-V4.64 | softirq/锁监控/亲和性/压测自动化/异常自恢复/DTB/i18n/CJK 管线/IME/手势/WM 缩放/fs 管理/SELinux 持久化/USB 真实化/电源/RTC 闹钟/TCP 状态机/man 手册 |
| 引导链规范 | V4.75 (E-121) | 引导链兼容层（LBA/CHS 三级容错）+ 内核开发规范（硬约束） |
| **UEFI引导** | **V5.x-V6.46** | **HepuBoot UEFI引导系统，GOP高分辨率，三模式降级，F8引导菜单** |
| **内存修复** | **V6.60** | **BUG-17/18修复：multiboot magic保存，BSS段从108MB降至57MB，动态内核堆** |
| **Rust生态** | **V6.60-V6.63** | **hepu-sys库（14+系统调用），6个Rust程序，file-server/fs-client，IPC机制** |
| **服务发现** | **V6.64** | **BUG-19修复（返回值偏移量36→32），service_register/lookup正常工作** |

---

## 3. 开发规范速查（硬性约束，详见 DESIGN.md 头部与 E-121）

1. **兼容层用户态化**：EXE/ELF/macOS 加载翻译禁止入内核
2. **统一沙盒**：所有应用类型同一沙盒，权限只降不升
3. **预期管理**：兼容等级标注，禁止"完美运行"绝对化表述
4. **stage2 ≤ 2048B**：超限必须精简
5. **引导兼容最高准则**：任何新老 x86 设备只要能引导就必须能启动赫普OS
6. **禁止事项**：中断内复杂计算、持锁睡眠、内核/用户态混用指针、释放后不置空、全局大锁
7. **发布验证**：QEMU SeaBIOS 全链路 / LBA 成功 / CHS 兜底 / 错误显示完整

---

## 4. 构建与验证环境

| 项 | 状态 |
|----|------|
| gcc 11.4 / ld / make / python3.12 | ✅ 可用 |
| nasm | 不需要（GAS 汇编，gcc 预处理） |
| qemu-system-x86_64 | ✅ 已安装（OVMF UEFI固件） |
| Rust工具链 | ✅ 已安装（中科大镜像源） |
| gnu-efi / parted / dosfstools / mtools / xorriso | ✅ 已安装 |
| 构建命令 | `bash tools/hepboot/uefi/build_uefi_image.sh`（统一构建） |
| Rust编译 | `cd user/rust && cargo build --target hepu-i686.json -Zbuild-std=core,alloc,compiler_builtins -Zjson-target-spec` |
| 回归 | QEMU UEFI启动 + 串口日志验证所有程序rc=0 |

---

## 5. 更新记录

| 日期 | 动作 |
|------|------|
| 2026-09-20 | 创建本文档；汇总 P0-P3 未完成项 13 项；建立版本里程碑时间线 |
| 2026-09-23 | 更新：标记QEMU已安装；补充V5.x-V6.64里程碑；链接到DEVELOPMENT_STATUS.md |
