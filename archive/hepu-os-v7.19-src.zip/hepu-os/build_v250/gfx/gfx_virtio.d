build_v250/gfx/gfx_virtio.o: kernel/gfx/gfx_virtio.c \
 kernel/include/string.h kernel/include/graphics.h \
 kernel/include/serial.h kernel/include/pci.h
kernel/include/string.h:
kernel/include/graphics.h:
kernel/include/serial.h:
kernel/include/pci.h:
