build_v250/gfx/gfx_font_aa.o: kernel/gfx/gfx_font_aa.c \
 kernel/include/string.h kernel/include/graphics.h \
 kernel/include/font8x16.h
kernel/include/string.h:
kernel/include/graphics.h:
kernel/include/font8x16.h:
