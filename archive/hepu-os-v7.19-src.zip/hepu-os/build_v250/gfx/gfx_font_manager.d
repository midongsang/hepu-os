build_v250/gfx/gfx_font_manager.o: kernel/gfx/gfx_font_manager.c \
 kernel/include/string.h kernel/include/graphics.h \
 kernel/include/serial.h kernel/include/font8x16.h
kernel/include/string.h:
kernel/include/graphics.h:
kernel/include/serial.h:
kernel/include/font8x16.h:
