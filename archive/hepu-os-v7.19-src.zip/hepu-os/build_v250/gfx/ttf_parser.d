build_v250/gfx/ttf_parser.o: kernel/gfx/ttf_parser.c \
 kernel/include/string.h kernel/include/serial.h
kernel/include/string.h:
kernel/include/serial.h:
