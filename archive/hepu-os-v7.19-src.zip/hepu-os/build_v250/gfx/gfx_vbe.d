build_v250/gfx/gfx_vbe.o: kernel/gfx/gfx_vbe.c kernel/include/string.h \
 kernel/include/graphics.h kernel/include/serial.h \
 kernel/include/font8x16.h
kernel/include/string.h:
kernel/include/graphics.h:
kernel/include/serial.h:
kernel/include/font8x16.h:
