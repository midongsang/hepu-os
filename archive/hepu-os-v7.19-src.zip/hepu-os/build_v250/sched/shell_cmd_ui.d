build_v250/sched/shell_cmd_ui.o: kernel/sched/shell_cmd_ui.c \
 kernel/include/string.h kernel/include/vga.h kernel/include/process.h \
 kernel/include/paging.h kernel/include/constants.h \
 kernel/include/shell.h kernel/include/serial.h kernel/include/pit.h \
 kernel/include/hepu.h kernel/include/i18n.h kernel/include/dtb.h \
 kernel/include/mac.h kernel/include/font_cjk16.h \
 kernel/include/graphics.h
kernel/include/string.h:
kernel/include/vga.h:
kernel/include/process.h:
kernel/include/paging.h:
kernel/include/constants.h:
kernel/include/shell.h:
kernel/include/serial.h:
kernel/include/pit.h:
kernel/include/hepu.h:
kernel/include/i18n.h:
kernel/include/dtb.h:
kernel/include/mac.h:
kernel/include/font_cjk16.h:
kernel/include/graphics.h:
