/* ============================================================================
 * 赫普OS - 应用商店
 * ========================================================================== */

#include <stdint.h>
#include "app_store.h"
#include "vga.h"
#include "string.h"

static void tools_strcat(char *dst, const char *src, int max) {
    int dlen = 0; while (dst[dlen] && dlen < max-1) dlen++;
    int i = 0;
    while (src[i] && dlen < max-1) { dst[dlen++] = src[i++]; }
    dst[dlen] = 0;
}


static app_store_t store;

/* 分类名称（V7.43 完全中文化） */
static const char *cat_names[] = {
    "工具", "社交", "效率", "游戏", "娱乐", "新闻", "财经", "健康",
    "教育", "购物", "旅行", "摄影", "音乐", "视频", "地图", "商务",
    "天气", "实用工具", "通讯", "其他"
};

void app_store_init(void)
{
    memset(&store, 0, sizeof(app_store_t));
    store.initialized = 1;
    store.enabled = 1;
    store.auto_update = 1;
    store.update_on_wifi_only = 0;
    store.install_unknown_sources = 0;
    store.parental_control = 0;

    /* 注册分类 */
    for (int i = 0; i < 20; i++) {
        store.categories[i].id = (store_category_t)i;
        strncpy(store.categories[i].name, cat_names[i], 63);
        store.category_count++;
    }

    /* 示例应用（V7.43 完全中文化） */
    const char *apps[][4] = {
        {"赫普浏览器", "赫普官方浏览器，安全快速", "赫普", "0"},
        {"赫普相机", "专业相机应用", "赫普", "11"},
        {"赫普音乐", "本地音乐播放器", "赫普", "12"},
        {"赫普视频", "视频播放器", "赫普", "13"},
        {"赫普地图", "离线地图导航", "赫普", "14"},
        {"赫普笔记", "简洁笔记应用", "赫普", "2"},
        {"赫普天气", "实时天气预报", "赫普", "16"},
        {"赫普计算器", "科学计算器", "赫普", "17"},
        {"赫普日历", "智能日历", "赫普", "2"},
        {"赫普时钟", "闹钟/世界时钟/秒表", "赫普", "17"},
        {"赫普文件", "文件管理器", "赫普", "17"},
        {"赫普设置", "系统设置", "赫普", "17"},
        {"微信", "即时通讯", "腾讯", "1"},
        {"支付宝", "移动支付", "蚂蚁集团", "6"},
        {"抖音", "短视频", "字节跳动", "4"},
        {"淘宝", "购物", "阿里巴巴", "9"},
    };

    for (int i = 0; i < 16; i++) {
        store.apps[i].used = 1;
        store.apps[i].id = i;
        strncpy(store.apps[i].name, apps[i][0], 127);
        strncpy(store.apps[i].description, apps[i][1], 511);
        strncpy(store.apps[i].author, apps[i][2], 63);
        strncpy(store.apps[i].package_name, "com.hepu.", 127);
        tools_strcat(store.apps[i].package_name, apps[i][0], 256);
        strncpy(store.apps[i].version, "1.0.0", 31);
        store.apps[i].size = (i + 1) * 1024 * 1024;
        store.apps[i].category = (store_category_t)(apps[i][3][0] - '0');
        store.apps[i].rating = 4.0f + (i % 10) * 0.1f;
        store.apps[i].rating_count = 1000 + i * 100;
        store.apps[i].download_count = 10000 + i * 5000;
        store.apps[i].free = 1;
        store.apps[i].age_rating = 0;
        store.apps[i].installed = (i < 12) ? 1 : 0;
        store.apps[i].status = store.apps[i].installed ? APP_STATUS_INSTALLED : APP_STATUS_NOT_INSTALLED;
        store.app_count++;
        if (store.apps[i].installed) store.installed_count++;
    }

    /* 模拟2个更新 */
    store.apps[0].has_update = 1;
    strncpy(store.apps[0].new_version, "2.0.0", 31);
    store.apps[1].has_update = 1;
    strncpy(store.apps[1].new_version, "1.5.0", 31);
    store.updates_available = 2;

    vga_puts("[STORE] app store init done \n");
    vga_printf(" app: %d, installed: %d, updatable: %d\n",
               store.app_count, store.installed_count, store.updates_available);
}

/* 应用浏览 */
int app_store_get_app(int id, appstore_app_t *app)
{
    if (id < 0 || id >= STORE_MAX_APPS || !store.apps[id].used || !app) return -1;
    memcpy(app, &store.apps[id], sizeof(appstore_app_t));
    return 0;
}

int app_store_list_apps(appstore_app_t *apps, int max)
{
    if (!apps || max <= 0) return 0;
    int count = store.app_count < max ? store.app_count : max;
    for (int i = 0; i < count; i++)
        memcpy(&apps[i], &store.apps[i], sizeof(appstore_app_t));
    return count;
}

int app_store_list_by_category(store_category_t cat, appstore_app_t *apps, int max)
{
    if (!apps || max <= 0) return 0;
    int count = 0;
    for (int i = 0; i < STORE_MAX_APPS && count < max; i++) {
        if (store.apps[i].used && store.apps[i].category == cat)
            memcpy(&apps[count++], &store.apps[i], sizeof(appstore_app_t));
    }
    return count;
}

int app_store_list_installed(appstore_app_t *apps, int max)
{
    if (!apps || max <= 0) return 0;
    int count = 0;
    for (int i = 0; i < STORE_MAX_APPS && count < max; i++) {
        if (store.apps[i].used && store.apps[i].installed)
            memcpy(&apps[count++], &store.apps[i], sizeof(appstore_app_t));
    }
    return count;
}

int app_store_list_updates(appstore_app_t *apps, int max)
{
    if (!apps || max <= 0) return 0;
    int count = 0;
    for (int i = 0; i < STORE_MAX_APPS && count < max; i++) {
        if (store.apps[i].used && store.apps[i].has_update)
            memcpy(&apps[count++], &store.apps[i], sizeof(appstore_app_t));
    }
    return count;
}

int app_store_list_featured(appstore_app_t *apps, int max)
{
    if (!apps || max <= 0) return 0;
    int count = 0;
    for (int i = 0; i < STORE_MAX_APPS && count < max && i < 6; i++) {
        if (store.apps[i].used) memcpy(&apps[count++], &store.apps[i], sizeof(appstore_app_t));
    }
    return count;
}

int app_store_search(const char *query, appstore_app_t *results, int max)
{
    if (!query || !results || max <= 0) return 0;
    int count = 0;
    for (int i = 0; i < STORE_MAX_APPS && count < max; i++) {
        if (store.apps[i].used) {
            int match = 1;
            int qlen = 0; while (query[qlen]) qlen++;
            for (int j = 0; j < qlen; j++) {
                int found = 0;
                for (int k = 0; store.apps[i].name[k]; k++) {
                    if (store.apps[i].name[k] == query[j]) { found = 1; break; }
                }
                if (!found) { match = 0; break; }
            }
            if (match) memcpy(&results[count++], &store.apps[i], sizeof(appstore_app_t));
        }
    }
    return count;
}

/* 安装/卸载 */
int app_store_install(int app_id)
{
    if (app_id < 0 || app_id >= STORE_MAX_APPS || !store.apps[app_id].used) return -1;
    if (store.apps[app_id].installed) return -1;
    store.apps[app_id].status = APP_STATUS_INSTALLING;
    store.apps[app_id].installed = 1;
    store.apps[app_id].status = APP_STATUS_INSTALLED;
    store.installed_count++;
    store.total_installs++;
    return 0;
}

int app_store_uninstall(int app_id)
{
    if (app_id < 0 || app_id >= STORE_MAX_APPS || !store.apps[app_id].used) return -1;
    if (!store.apps[app_id].installed) return -1;
    store.apps[app_id].status = APP_STATUS_UNINSTALLING;
    store.apps[app_id].installed = 0;
    store.apps[app_id].status = APP_STATUS_NOT_INSTALLED;
    store.installed_count--;
    store.total_uninstalls++;
    return 0;
}

int app_store_update(int app_id)
{
    if (app_id < 0 || app_id >= STORE_MAX_APPS || !store.apps[app_id].used) return -1;
    if (!store.apps[app_id].has_update) return -1;
    store.apps[app_id].status = APP_STATUS_UPDATING;
    strncpy(store.apps[app_id].version, store.apps[app_id].new_version, 31);
    store.apps[app_id].has_update = 0;
    store.apps[app_id].status = APP_STATUS_INSTALLED;
    if (store.updates_available > 0) store.updates_available--;
    store.total_updates++;
    return 0;
}

int app_store_update_all(void)
{
    int count = 0;
    for (int i = 0; i < STORE_MAX_APPS; i++) {
        if (store.apps[i].used && store.apps[i].has_update) {
            app_store_update(i);
            count++;
        }
    }
    return count;
}

int app_store_cancel_install(int app_id)
{
    if (app_id < 0 || app_id >= STORE_MAX_APPS || !store.apps[app_id].used) return -1;
    if (store.apps[app_id].status == APP_STATUS_INSTALLING) {
        store.apps[app_id].status = APP_STATUS_NOT_INSTALLED;
        return 0;
    }
    return -1;
}

int app_store_get_install_progress(int app_id, int *progress)
{
    if (app_id < 0 || app_id >= STORE_MAX_APPS || !store.apps[app_id].used || !progress) return -1;
    *progress = (store.apps[app_id].status == APP_STATUS_INSTALLED) ? 100 : 50;
    return 0;
}

/* 评论 */
int app_store_add_review(int app_id, float rating, const char *title, const char *content)
{
    for (int i = 0; i < STORE_MAX_REVIEWS; i++) {
        if (!store.reviews[i].used) {
            memset(&store.reviews[i], 0, sizeof(store_review_t));
            store.reviews[i].used = 1;
            store.reviews[i].id = i;
            store.reviews[i].app_id = app_id;
            strncpy(store.reviews[i].author, " user ", 63);
            store.reviews[i].rating = rating;
            if (title) strncpy(store.reviews[i].title, title, 127);
            if (content) strncpy(store.reviews[i].content, content, 511);
            store.reviews[i].timestamp = 1;
            store.review_count++;
            return i;
        }
    }
    return -1;
}

int app_store_list_reviews(int app_id, store_review_t *reviews, int max)
{
    if (!reviews || max <= 0) return 0;
    int count = 0;
    for (int i = 0; i < STORE_MAX_REVIEWS && count < max; i++) {
        if (store.reviews[i].used && store.reviews[i].app_id == app_id)
            memcpy(&reviews[count++], &store.reviews[i], sizeof(store_review_t));
    }
    return count;
}

int app_store_get_review(int id, store_review_t *review)
{
    if (id < 0 || id >= STORE_MAX_REVIEWS || !store.reviews[id].used || !review) return -1;
    memcpy(review, &store.reviews[id], sizeof(store_review_t));
    return 0;
}

/* 分类 */
int app_store_list_categories(store_category_info_t *categories, int max)
{
    if (!categories || max <= 0) return 0;
    int count = store.category_count < max ? store.category_count : max;
    for (int i = 0; i < count; i++)
        memcpy(&categories[i], &store.categories[i], sizeof(store_category_info_t));
    return count;
}

int app_store_get_category(store_category_t id, store_category_info_t *cat)
{
    if (id >= STORE_MAX_CATEGORIES || !cat) return -1;
    memcpy(cat, &store.categories[id], sizeof(store_category_info_t));
    return 0;
}

/* 设置 */
int app_store_set_auto_update(int enable)
{
    store.auto_update = enable ? 1 : 0;
    return 0;
}

int app_store_set_wifi_only(int enable)
{
    store.update_on_wifi_only = enable ? 1 : 0;
    return 0;
}

int app_store_set_unknown_sources(int allow)
{
    store.install_unknown_sources = allow ? 1 : 0;
    return 0;
}

int app_store_set_parental_control(int enable, int age_limit)
{
    (void)age_limit;
    store.parental_control = enable ? 1 : 0;
    return 0;
}

/* 统计 */
int app_store_get_stats(app_store_t *stats)
{
    if (!stats) return -1;
    memcpy(stats, &store, sizeof(app_store_t));
    return 0;
}
