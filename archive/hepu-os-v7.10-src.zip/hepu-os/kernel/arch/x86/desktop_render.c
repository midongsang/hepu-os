/* ============================================================================
 * 赫普OS - 现代桌面渲染器 (V6.80 重设计)
 * 现代渐变背景 + 圆角图标 + 半透明状态栏 + Dock栏
 * ========================================================================== */
#include <stdint.h>
#include <stddef.h>
#include "elastic_desktop.h"
#include "vga_gfx.h"
#include "graphics.h"
#include "string.h"
#include "kstdio.h"
#include "font_antialiased.h"

/* ============================================================================
 * 颜色定义 (V6.90 32位真彩色)
 * ========================================================================== */
/* 背景渐变 */
#define RGB_BG_TOP      0x0A0E27  /* 深蓝黑 */
#define RGB_BG_MID      0x1A1F3A  /* 深蓝 */
#define RGB_BG_BOTTOM   0x2D1B4E  /* 深紫 */
/* 面板色 */
#define RGB_PANEL       0x1E1E2E  /* 深灰面板 */
#define RGB_PANEL_LIGHT 0x2A2A3C  /* 浅灰面板 */
#define RGB_PANEL_HOVER 0x3A3A5C  /* 悬停面板 */
/* 文字色 */
#define RGB_TEXT        0xFFFFFF  /* 白色 */
#define RGB_TEXT_DIM    0xA0A0B0  /* 灰色 */
/* 强调色 */
#define RGB_ACCENT      0x4A9EFF  /* 蓝色 */
#define RGB_ACCENT_LIGHT 0x7AB8FF /* 亮蓝 */
/* 图标渐变色 */
#define RGB_ICON_BLUE1   0x4A9EFF
#define RGB_ICON_BLUE2   0x2D7ADB
#define RGB_ICON_GREEN1  0x52C41A
#define RGB_ICON_GREEN2  0x389E08
#define RGB_ICON_CYAN1   0x36CFC9
#define RGB_ICON_CYAN2   0x13A8A8
#define RGB_ICON_PURPLE1 0x9254DE
#define RGB_ICON_PURPLE2 0x722ED1
#define RGB_ICON_RED1    0xFF6B6B
#define RGB_ICON_RED2    0xDB4A4A
#define RGB_ICON_ORANGE1 0xFFA940
#define RGB_ICON_ORANGE2 0xDB8A20
#define RGB_ICON_YELLOW1 0xFFC53D
#define RGB_ICON_YELLOW2 0xDBA920
/* 边框和阴影 */
#define RGB_BORDER      0x3A3A5C
#define RGB_SHADOW      0x000000

/* VGA调色板颜色转RGB */
static inline uint32_t vga_color_to_rgb(uint8_t vga_color)
{
    static const uint32_t vga_palette[16] = {
        0x000000, /* 0: 黑 */
        0x0000AA, /* 1: 蓝 */
        0x00AA00, /* 2: 绿 */
        0x00AAAA, /* 3: 青 */
        0xAA0000, /* 4: 红 */
        0xAA00AA, /* 5: 紫 */
        0xAA5500, /* 6: 棕 */
        0xC0C0C0, /* 7: 浅灰 */
        0x555555, /* 8: 深灰 */
        0x5555FF, /* 9: 亮蓝 */
        0x55FF55, /* 10: 亮绿 */
        0x55FFFF, /* 11: 亮青 */
        0xFF5555, /* 12: 亮红 */
        0xFF55FF, /* 13: 亮紫 */
        0xFFFF55, /* 14: 黄 */
        0xFFFFFF  /* 15: 白 */
    };
    return vga_palette[vga_color & 0x0F];
}

/* 桌面文字绘制（兼容8位调色板颜色，使用统一API） */
static inline void desktop_puts(int x, int y, const char *s, uint8_t color)
{
    gfx_draw_string((uint32_t)x, (uint32_t)y, s, vga_color_to_rgb(color), 0x00000000);
}

/* 图标位置缓存（用于点击检测） */
static int icon_positions[8][2]; /* x, y */
static int dock_icon_positions[8][2]; /* Dock栏图标位置 */
static int selected_icon = -1;

/* V6.94: UI缩放因子 (根据分辨率自动调整) */
static int ui_scale = 100;  /* 百分比, 100=正常 */
static void calc_ui_scale(void)
{
    int scale_w = (gfx_width * 100) / 1024;
    int scale_h = (gfx_height * 100) / 768;
    ui_scale = (scale_w < scale_h) ? scale_w : scale_h;
    if (ui_scale < 75) ui_scale = 75;
    if (ui_scale > 200) ui_scale = 200;
}
#define SCALE(x) ((x) * ui_scale / 100)

/* 多窗口支持 */
#define MAX_WINDOWS 4
typedef struct {
    int used;
    int app_id;
    int x, y;
    int z_order;  /* Z轴顺序，越大越上层 */
    int anim_state; /* 0=正常, 1=打开动画, 2=关闭动画 */
    int anim_frame;  /* 动画帧计数 */
    /* V6.98: 窗口状态 */
    int minimized;   /* 1=最小化 */
    int maximized;   /* 1=最大化 */
    int prev_x, prev_y;  /* 最大化前的位置 */
} window_t;
static window_t windows[MAX_WINDOWS];
static int window_count = 0;
static int next_z = 0;
static int dragging_window = -1;
static int drag_offset_x = 0, drag_offset_y = 0;

/* 状态栏高度 */
#define STATUSBAR_HEIGHT    28
/* Dock栏高度 */
#define DOCK_HEIGHT         70
/* 图标大小 */
#define ICON_SIZE           56
#define ICON_RADIUS         8
/* 图标间距 */
#define ICON_SPACING        20

/* 鼠标光标位置 */
static int mouse_x = 0;
static int mouse_y = 0;
static int mouse_visible = 1;

/* 右键菜单状态 */
static int context_menu_visible = 0;
static int context_menu_x = 0;
static int context_menu_y = 0;
static int context_menu_selected = -1;

/* 前向声明 */
static int create_window(int app_id);

/* 右键菜单项 */
static const char *context_menu_items[] = {
    "Open Terminal",
    "Open File Manager",
    "---",
    "Refresh Desktop",
    "Close All Windows",
    "---",
    "Change Wallpaper",
    "Display Settings",
    "System Settings",
    "---",
    "Restart",
    "Shut Down",
    "---",
    "Exit to Shell"
};
#define CONTEXT_MENU_COUNT (sizeof(context_menu_items)/sizeof(context_menu_items[0]))
#define CONTEXT_MENU_WIDTH 180
#define CONTEXT_MENU_ITEM_HEIGHT 24

/* V6.97: 关机/重启确认对话框状态 */
static int power_dialog_visible = 0;
static int power_dialog_type = 0; /* 0=关机, 1=重启 */
static int power_dialog_selected = 0; /* 0=确认, 1=取消 */

/* ============================================================================
 * 右键菜单
 * ========================================================================== */
static void draw_context_menu(void)
{
    if (!context_menu_visible) return;

    int x = context_menu_x;
    int y = context_menu_y;
    int total_h = CONTEXT_MENU_COUNT * CONTEXT_MENU_ITEM_HEIGHT + 8;

    /* 扁平化菜单背景 - 去掉阴影 */
    gfx_fill_rounded_rect(x, y, CONTEXT_MENU_WIDTH, total_h, 6, 0xFFFFFF);
    gfx_fill_rounded_rect(x - 1, y - 1, CONTEXT_MENU_WIDTH + 2, total_h + 2, 7, 0xCBD5E0);
    gfx_fill_rounded_rect(x, y, CONTEXT_MENU_WIDTH, total_h, 6, 0xFFFFFF);

    /* 菜单项 */
    for (int i = 0; i < (int)CONTEXT_MENU_COUNT; i++) {
        int item_y = y + 4 + i * CONTEXT_MENU_ITEM_HEIGHT;

        /* 分隔线 */
        if (context_menu_items[i][0] == '-') {
            gfx_draw_hline(x + 10, item_y + CONTEXT_MENU_ITEM_HEIGHT / 2,
                          CONTEXT_MENU_WIDTH - 20, 0xE2E8F0);
            continue;
        }

        /* 悬停高亮 - 扁平化浅蓝色 */
        if (i == context_menu_selected) {
            gfx_fill_rect(x + 4, item_y, CONTEXT_MENU_WIDTH - 8,
                             CONTEXT_MENU_ITEM_HEIGHT - 2, 0xEBF8FF);
        }

        /* 菜单项文字 */
        desktop_puts(x + 16, item_y + 6, context_menu_items[i],
                 (i == context_menu_selected) ? 0x09 : 0x00);
    }
}

/* 检测右键菜单点击 */
static int hit_test_context_menu(int mx, int my)
{
    if (!context_menu_visible) return -1;
    int x = context_menu_x;
    int y = context_menu_y;
    if (mx < x || mx > x + CONTEXT_MENU_WIDTH ||
        my < y || my > y + CONTEXT_MENU_COUNT * CONTEXT_MENU_ITEM_HEIGHT + 8) {
        return -1;
    }
    int idx = (my - y - 4) / CONTEXT_MENU_ITEM_HEIGHT;
    if (idx < 0 || idx >= (int)CONTEXT_MENU_COUNT) return -1;
    if (context_menu_items[idx][0] == '-') return -1;
    return idx;
}

/* 执行右键菜单项 */
static void execute_context_menu(int idx)
{
    extern void serial_puts(uint16_t, const char *);
    switch (idx) {
        case 0: /* Open Terminal */
            create_window(1);
            serial_puts(0x3F8, "[MENU] Open Terminal\n");
            break;
        case 1: /* Open File Manager */
            create_window(0);
            serial_puts(0x3F8, "[MENU] Open File Manager\n");
            break;
        case 3: /* Refresh Desktop */
            serial_puts(0x3F8, "[MENU] Refresh Desktop\n");
            break;
        case 4: /* Close All Windows */
            for (int i = 0; i < MAX_WINDOWS; i++) {
                windows[i].used = 0;
            }
            window_count = 0;
            serial_puts(0x3F8, "[MENU] Close All Windows\n");
            break;
        case 6: /* Change Wallpaper */
            serial_puts(0x3F8, "[MENU] Change Wallpaper\n");
            break;
        case 7: /* Display Settings */
            create_window(3);
            serial_puts(0x3F8, "[MENU] Display Settings\n");
            break;
        case 8: /* System Settings */
            create_window(3); /* 复用设置窗口 */
            serial_puts(0x3F8, "[MENU] System Settings\n");
            break;
        case 10: /* Restart */
            power_dialog_type = 1;
            power_dialog_visible = 1;
            power_dialog_selected = 0;
            serial_puts(0x3F8, "[MENU] Restart dialog\n");
            break;
        case 11: /* Shut Down */
            power_dialog_type = 0;
            power_dialog_visible = 1;
            power_dialog_selected = 0;
            serial_puts(0x3F8, "[MENU] Shutdown dialog\n");
            break;
        case 13: /* Exit to Shell */
            context_menu_visible = 0;
            extern void vga_gfx_text_mode(void);
            vga_gfx_text_mode();
            extern void sys_reboot_after_gfx(void);
            sys_reboot_after_gfx();
            break;
    }
    context_menu_visible = 0;
}

/* ============================================================================
 * V6.97: 关机/重启确认对话框
 * ========================================================================== */
static void draw_power_dialog(void)
{
    if (!power_dialog_visible) return;

    int dlg_w = 360;
    int dlg_h = 160;
    int dlg_x = (gfx_width - dlg_w) / 2;
    int dlg_y = (gfx_height - dlg_h) / 2;

    /* 半透明遮罩 */
    for (int y = 0; y < gfx_height; y += 2) {
        gfx_draw_hline(0, y, gfx_width, 0x000000);
    }

    /* 对话框背景 - 白色 */
    gfx_fill_rounded_rect(dlg_x, dlg_y, dlg_w, dlg_h, 12, 0xFFFFFF);

    /* 标题栏 */
    gfx_fill_rounded_rect(dlg_x, dlg_y, dlg_w, 40, 12, 0x2D3748);
    gfx_fill_rect(dlg_x, dlg_y + 20, dlg_w, 20, 0x2D3748);

    /* 标题图标和文字 */
    const char *title = (power_dialog_type == 0) ? "Shut Down" : "Restart";
    desktop_puts(dlg_x + 20, dlg_y + 14, title, 0x0F);

    /* 提示文字 */
    const char *msg = (power_dialog_type == 0) ?
        "Are you sure you want to shut down?" :
        "Are you sure you want to restart?";
    desktop_puts(dlg_x + 30, dlg_y + 65, msg, 0x00);

    /* 按钮 */
    int btn_w = 100;
    int btn_h = 36;
    int btn_y = dlg_y + dlg_h - 55;
    int btn1_x = dlg_x + 40;  /* 确认 */
    int btn2_x = dlg_x + dlg_w - btn_w - 40;  /* 取消 */

    /* 确认按钮 */
    uint32_t confirm_color = (power_dialog_type == 0) ? 0xE53E3E : 0x3182CE;
    if (power_dialog_selected == 0) {
        gfx_fill_rounded_rect(btn1_x - 2, btn_y - 2, btn_w + 4, btn_h + 4, 8, 0x1A202C);
    }
    gfx_fill_rounded_rect(btn1_x, btn_y, btn_w, btn_h, 6, confirm_color);
    desktop_puts(btn1_x + (btn_w - 48) / 2, btn_y + 12,
             (power_dialog_type == 0) ? "Shut Down" : "Restart", 0x0F);

    /* 取消按钮 */
    if (power_dialog_selected == 1) {
        gfx_fill_rounded_rect(btn2_x - 2, btn_y - 2, btn_w + 4, btn_h + 4, 8, 0x1A202C);
    }
    gfx_fill_rounded_rect(btn2_x, btn_y, btn_w, btn_h, 6, 0xE2E8F0);
    desktop_puts(btn2_x + (btn_w - 32) / 2, btn_y + 12, "Cancel", 0x00);
}

/* 处理关机对话框点击 */
static void handle_power_dialog_click(int mx, int my)
{
    if (!power_dialog_visible) return;

    int dlg_w = 360;
    int dlg_h = 160;
    int dlg_x = (gfx_width - dlg_w) / 2;
    int dlg_y = (gfx_height - dlg_h) / 2;
    int btn_w = 100;
    int btn_h = 36;
    int btn_y = dlg_y + dlg_h - 55;
    int btn1_x = dlg_x + 40;
    int btn2_x = dlg_x + dlg_w - btn_w - 40;

    if (mx >= btn1_x && mx <= btn1_x + btn_w &&
        my >= btn_y && my <= btn_y + btn_h) {
        /* 确认关机/重启 */
        power_dialog_visible = 0;
        extern void vga_gfx_text_mode(void);
        vga_gfx_text_mode();
        if (power_dialog_type == 0) {
            extern void machine_poweroff(void);
            machine_poweroff();
        } else {
            extern void machine_reboot(void);
            machine_reboot();
        }
    } else if (mx >= btn2_x && mx <= btn2_x + btn_w &&
               my >= btn_y && my <= btn_y + btn_h) {
        /* 取消 */
        power_dialog_visible = 0;
    }
}

/* ============================================================================
 * 鼠标控制
 * ========================================================================== */
void desktop_set_mouse(int x, int y)
{
    if (x < 0) x = 0;
    if (y < 0) y = 0;
    if (x >= gfx_width) x = gfx_width - 1;
    if (y >= gfx_height) y = gfx_height - 1;
    mouse_x = x;
    mouse_y = y;
}

void desktop_get_mouse(int *x, int *y)
{
    if (x) *x = mouse_x;
    if (y) *y = mouse_y;
}

void desktop_show_mouse(int show)
{
    mouse_visible = show;
}

/* 绘制鼠标光标（箭头形状） */
static void draw_mouse_cursor(void)
{
    if (!mouse_visible) return;
    int x = mouse_x, y = mouse_y;
    static const uint8_t cursor_mask[] = {
        0x01,0x00, 0x03,0x00, 0x07,0x00, 0x0F,0x00,
        0x1F,0x00, 0x3F,0x00, 0x7F,0x00, 0xFF,0x00,
        0xFF,0x01, 0xE7,0x01, 0xC3,0x01, 0x81,0x03,
        0x01,0x03, 0x01,0x06, 0x01,0x0C, 0x00,0x08,
    };
    for (int row = 0; row < 16; row++) {
        for (int col = 0; col < 11; col++) {
            int byte_idx = row * 2 + (col >= 8 ? 1 : 0);
            int bit_idx = col % 8;
            if (cursor_mask[byte_idx] & (1 << bit_idx)) {
                gfx_put_pixel(x + col, y + row, 0x000000);
                if (col > 0 && row > 0 && col < 10 && row < 15) {
                    int ic = col - 1, ir = row - 1;
                    int ib = ir * 2 + (ic >= 8 ? 1 : 0);
                    if (cursor_mask[ib] & (1 << (ic % 8)))
                        gfx_put_pixel(x + col, y + row, 0xFFFFFF);
                }
            }
        }
    }
}

/* ============================================================================
 * 扁平化背景绘制 (V6.93)
 * ========================================================================== */
static void draw_modern_background(void)
{
    /* 扁平化纯色背景 - 深灰蓝 */
    gfx_fill_rect(0, 0, gfx_width, gfx_height, 0x2D3748);

    /* 顶部细微分隔线 */
    gfx_draw_hline(0, STATUSBAR_HEIGHT, gfx_width, 0x1A202C);
}

/* ============================================================================
 * 顶部状态栏 (V6.93 扁平化)
 * ========================================================================== */
/* 绘制系统托盘图标 */
static void draw_tray_icons(int x, int y)
{
    /* 电池图标 (24x12) */
    int bx = x, by = y + 4;
    /* 电池边框 */
    gfx_draw_hline(bx, by, 22, 0xFFFFFF);
    gfx_draw_hline(bx, by + 11, 22, 0xFFFFFF);
    gfx_draw_vline(bx, by, 12, 0xFFFFFF);
    gfx_draw_vline(bx + 21, by, 12, 0xFFFFFF);
    /* 电池正极 */
    gfx_fill_rect(bx + 22, by + 3, 2, 6, 0xFFFFFF);
    /* 电池电量 (75%) */
    gfx_fill_rect(bx + 2, by + 2, 15, 8, 0x52C41A);

    /* 声音图标 (扬声器) */
    int sx = x + 34, sy = y + 2;
    gfx_fill_rect(sx, sy + 4, 6, 6, 0xFFFFFF);
    gfx_fill_rect(sx + 6, sy + 2, 3, 10, 0xFFFFFF);
    /* 声波 */
    gfx_draw_hline(sx + 11, sy + 4, 2, 0xFFFFFF);
    gfx_draw_hline(sx + 11, sy + 10, 2, 0xFFFFFF);
    gfx_draw_vline(sx + 13, sy + 3, 10, 0xFFFFFF);

    /* 网络图标 (WiFi信号) */
    int nx = x + 60, ny = y + 2;
    /* WiFi弧线 */
    gfx_draw_hline(nx + 2, ny + 10, 12, 0xFFFFFF);  /* 最底层 */
    gfx_draw_hline(nx + 4, ny + 7, 8, 0xFFFFFF);   /* 中间层 */
    gfx_draw_hline(nx + 6, ny + 4, 4, 0xFFFFFF);   /* 最上层 */
    gfx_fill_circle(nx + 8, ny + 12, 2, 0xFFFFFF); /* 中心点 */
}

static void draw_statusbar(void)
{
    /* 扁平化纯色状态栏 - 深灰 */
    gfx_fill_rect(0, 0, gfx_width, STATUSBAR_HEIGHT, 0x1A202C);
    /* 底部分隔线 */
    gfx_draw_hline(0, STATUSBAR_HEIGHT - 1, gfx_width, 0x2D3748);

    /* 左侧：系统名称 + 分辨率/刷新率 */
    /* V6.98: 使用真彩色抗锯齿字体 */
    gfx_draw_string_aa(12, 6, "Hepu OS", 0xFFFFFF);
    /* V6.96: 显示分辨率和刷新率 */
    extern int gfx_refresh_rate;
    char res_buf[32];
    snprintf(res_buf, sizeof(res_buf), "%dx%d@%dHz", gfx_width, gfx_height, gfx_refresh_rate);
    gfx_draw_string_aa(80, 7, res_buf, 0xA0AEC0);

    /* 中间：桌面指示 */
    gfx_draw_string_aa(gfx_width / 2 - 30, 7, "Desktop", 0xA0AEC0);

    /* 右侧：系统托盘图标 + 实时时间 */
    extern int rtc_get_time(int *h, int *m, int *s, int *d, int *mo, int *y);
    int h, m, s, d, mo, y;
    rtc_get_time(&h, &m, &s, &d, &mo, &y);
    char time_buf[16];
    snprintf(time_buf, sizeof(time_buf), "%02d:%02d", h, m);

    /* 系统托盘图标 (在时间左侧) */
    draw_tray_icons(gfx_width - 160, 6);

    /* 时间 - 抗锯齿 */
    gfx_draw_string_aa(gfx_width - 60, 7, time_buf, 0xFFFFFF);
}

/* ============================================================================
 * 应用图标绘制 (V6.90 真彩色渐变)
 * ========================================================================== */
typedef struct {
    const char *name;
    uint32_t color1;      /* 渐变起始色 */
    uint32_t color2;      /* 渐变结束色 */
    int symbol_type;
} app_icon_t;

static const app_icon_t app_icons[] = {
    {"Files",    RGB_ICON_BLUE1,   RGB_ICON_BLUE2,   0},
    {"Terminal", RGB_ICON_GREEN1,  RGB_ICON_GREEN2,  1},
    {"Browser",  RGB_ICON_CYAN1,   RGB_ICON_CYAN2,   2},
    {"Settings", RGB_ICON_PURPLE1, RGB_ICON_PURPLE2, 3},
    {"Games",    RGB_ICON_RED1,    RGB_ICON_RED2,    4},
    {"App Store",RGB_ICON_BLUE1,   RGB_ICON_PURPLE2, 5},
    {"Assistant",RGB_ICON_ORANGE1, RGB_ICON_ORANGE2, 6},
    {"Camera",   RGB_ICON_YELLOW1, RGB_ICON_YELLOW2, 7},
};
#define APP_COUNT (sizeof(app_icons)/sizeof(app_icons[0]))

/* 绘制图标内部符号 (V6.95 优化版 - 简洁白色符号) */
static void draw_icon_symbol(int cx, int cy, int type, uint32_t color_rgb)
{
    int s = 18; /* 符号大小 */
    switch (type) {
        case 0: { /* 文件 - 文件夹 */
            gfx_fill_rect(cx - s/2, cy - s/4, s, s*3/4, color_rgb);
            gfx_fill_rect(cx - s/2, cy - s/2, s*2/5, s/4, color_rgb);
            break;
        }
        case 1: { /* 终端 - 方框+提示符 */
            gfx_draw_rect(cx - s/2, cy - s/2, s, s, color_rgb);
            gfx_draw_line(cx - s/3, cy - s/4, cx - s/6, cy, color_rgb);
            gfx_draw_line(cx - s/6, cy, cx - s/3, cy + s/4, color_rgb);
            gfx_fill_rect(cx, cy + s/4 - 1, s/4, 2, color_rgb);
            break;
        }
        case 2: { /* 浏览器 - 圆形 */
            gfx_fill_circle(cx, cy, s/2, color_rgb);
            break;
        }
        case 3: { /* 设置 - 齿轮 */
            gfx_fill_circle(cx, cy, s/2 - 2, color_rgb);
            static const int gear_offsets[8][2] = {
                {0, -9}, {6, -6}, {9, 0}, {6, 6},
                {0, 9}, {-6, 6}, {-9, 0}, {-6, -6}
            };
            for (int i = 0; i < 8; i++) {
                gfx_fill_rect(cx + gear_offsets[i][0] - 2,
                                 cy + gear_offsets[i][1] - 2, 4, 4, color_rgb);
            }
            break;
        }
        case 4: { /* 游戏 - 手柄 */
            gfx_fill_rect(cx - s/2, cy - 3, s, 6, color_rgb);
            gfx_fill_circle(cx - s/2 + 3, cy + 2, 5, color_rgb);
            gfx_fill_circle(cx + s/2 - 3, cy + 2, 5, color_rgb);
            break;
        }
        case 5: { /* 应用商店 - 购物袋 */
            gfx_fill_rect(cx - s/3, cy - s/4, s*2/3, s*3/4, color_rgb);
            gfx_draw_ellipse(cx, cy - s/4, s/4, s/5, color_rgb);
            break;
        }
        case 6: { /* 助手 - 对话框 */
            gfx_fill_rect(cx - s/2, cy - s/3, s, s*2/3, color_rgb);
            gfx_draw_triangle(cx - 4, cy + s/3, cx + 4, cy + s/3, cx, cy + s/2, color_rgb);
            break;
        }
        case 7: { /* 相机 - 相机机身+镜头 */
            gfx_fill_rect(cx - s/2, cy - s/4, s, s*2/3, color_rgb);
            gfx_fill_rect(cx - s/4, cy - s/2, s/2, s/5, color_rgb);
            gfx_fill_circle(cx, cy + s/8, s/4, color_rgb);
            break;
        }
    }
}

/* 绘制单个应用图标 (V6.95 优化版 - 渐变+高光+精细符号) */
static void draw_app_icon_modern(int x, int y, const app_icon_t *app, int selected)
{
    int icon_size = ICON_SIZE;
    int icon_radius = 12; /* 更大圆角 */
    int offset_x = 0, offset_y = 0;

    /* 悬停放大效果 */
    if (selected) {
        icon_size = ICON_SIZE + 8;
        icon_radius = 14;
        offset_x = -4;
        offset_y = -4;
    }

    int ix = x + offset_x;
    int iy = y + offset_y;

    /* 图标阴影 */
    gfx_fill_rounded_rect(ix + 2, iy + 3, icon_size, icon_size, icon_radius, 0x000000);

    /* 图标背景 - 垂直渐变 (从上到下轻微变亮) */
    for (int row = 0; row < icon_size; row++) {
        int t = row * 100 / icon_size;
        uint32_t c1 = app->color1;
        uint32_t c2 = app->color2;
        uint8_t r = ((c1 >> 16) & 0xFF) + (((c2 >> 16) & 0xFF) - ((c1 >> 16) & 0xFF)) * t / 100;
        uint8_t g = ((c1 >> 8) & 0xFF) + (((c2 >> 8) & 0xFF) - ((c1 >> 8) & 0xFF)) * t / 100;
        uint8_t b = (c1 & 0xFF) + ((c2 & 0xFF) - (c1 & 0xFF)) * t / 100;
        uint32_t row_color = (r << 16) | (g << 8) | b;
        /* 用圆角矩形的每一行 */
        int clip_r = icon_radius;
        int row_y = iy + row;
        int left = ix, right = ix + icon_size;
        if (row < clip_r) {
            int d = clip_r - row;
            left += d;
            right -= d;
        } else if (row >= icon_size - clip_r) {
            int d = row - (icon_size - clip_r) + 1;
            left += d;
            right -= d;
        }
        if (left < right) {
            gfx_fill_rect(left, row_y, right - left, 1, row_color);
        }
    }

    /* 顶部高光 - 微妙的白色渐变 */
    for (int row = 0; row < icon_size / 3; row++) {
        int alpha = 40 - row * 40 / (icon_size / 3);
        if (alpha > 0) {
            int clip_r = icon_radius;
            int row_y = iy + row;
            int left = ix + 2, right = ix + icon_size - 2;
            if (row < clip_r) {
                int d = clip_r - row;
                left += d;
                right -= d;
            }
            if (left < right) {
                /* 用半透明白色模拟高光 */
                gfx_fill_rect(left, row_y, right - left, 1, 0xFFFFFF);
            }
        }
    }

    /* 选中状态 - 发光边框 */
    if (selected) {
        gfx_fill_rounded_rect(ix - 3, iy - 3, icon_size + 6, icon_size + 6, icon_radius + 3, 0xFFFFFF);
        gfx_fill_rounded_rect(ix - 2, iy - 2, icon_size + 4, icon_size + 4, icon_radius + 2, app->color1);
    }

    /* 图标符号 - 白色 */
    int sym_x = ix + icon_size / 2;
    int sym_y = iy + icon_size / 2 - 2;
    draw_icon_symbol(sym_x, sym_y, app->symbol_type, 0xFFFFFF);

    /* 图标名称 - 白色带阴影 */
    int name_len = strlen(app->name);
    int text_x = x + (ICON_SIZE - name_len * 8) / 2;
    desktop_puts(text_x + 1, y + ICON_SIZE + 7, app->name, 0x00); /* 阴影 */
    desktop_puts(text_x, y + ICON_SIZE + 6, app->name, 0x0F); /* 白色 */
}

/* ============================================================================
 * V6.98: UI组件库 (按钮/输入框/复选框)
 * ========================================================================== */

/* 绘制按钮 */
static void ui_draw_button(int x, int y, int w, int h, const char *label, int hovered, int pressed)
{
    uint32_t bg_color, border_color, text_color;
    if (pressed) {
        bg_color = 0x2B6CB0;
        border_color = 0x1A365D;
        text_color = 0xFFFFFF;
    } else if (hovered) {
        bg_color = 0x4299E1;
        border_color = 0x2B6CB0;
        text_color = 0xFFFFFF;
    } else {
        bg_color = 0x3182CE;
        border_color = 0x2B6CB0;
        text_color = 0xFFFFFF;
    }
    gfx_fill_rounded_rect(x - 1, y - 1, w + 2, h + 2, 6, border_color);
    gfx_fill_rounded_rect(x, y, w, h, 5, bg_color);
    /* 文字居中 */
    int text_w = 0;
    while (label[text_w]) text_w++;
    desktop_puts(x + (w - text_w * 8) / 2, y + (h - 16) / 2 + 2, label, 0x0F);
}

/* 绘制输入框 */
static void ui_draw_input(int x, int y, int w, int h, const char *text, int focused, int cursor_pos)
{
    /* 背景 */
    gfx_fill_rounded_rect(x - 1, y - 1, w + 2, h + 2, 4, focused ? 0x3182CE : 0xCBD5E0);
    gfx_fill_rect(x, y, w, h, 0xFFFFFF);
    /* 文字 */
    desktop_puts(x + 6, y + (h - 16) / 2 + 2, text, 0x00);
    /* 光标 */
    if (focused) {
        int cursor_x = x + 6 + cursor_pos * 8;
        gfx_fill_rect(cursor_x, y + 4, 1, h - 8, 0x1A202C);
    }
}

/* 绘制复选框 */
static void ui_draw_checkbox(int x, int y, const char *label, int checked)
{
    /* 方框 */
    gfx_fill_rounded_rect(x, y, 16, 16, 3, 0xCBD5E0);
    gfx_fill_rect(x + 1, y + 1, 14, 14, 0xFFFFFF);
    if (checked) {
        gfx_fill_rect(x + 3, y + 3, 10, 10, 0x3182CE);
    }
    /* 标签 */
    desktop_puts(x + 22, y + 2, label, 0x00);
}

/* 绘制滑块 */
static void ui_draw_slider(int x, int y, int w, int value, int min, int max)
{
    /* 轨道 */
    gfx_fill_rounded_rect(x, y + 6, w, 4, 2, 0xE2E8F0);
    /* 已填充部分 */
    int fill_w = (w - 16) * (value - min) / (max - min);
    gfx_fill_rounded_rect(x, y + 6, fill_w + 8, 4, 2, 0x3182CE);
    /* 滑块 */
    int knob_x = x + fill_w;
    gfx_fill_rounded_rect(knob_x, y, 16, 16, 8, 0x3182CE);
}

/* ============================================================================
 * 底部Dock栏 (V6.90 真彩色毛玻璃)
 * ========================================================================== */
static void draw_dock_modern(void)
{
    int dock_y = gfx_height - DOCK_HEIGHT - 10;
    int dock_w = (int)APP_COUNT * (ICON_SIZE + 16) + 20;
    int dock_x = (gfx_width - dock_w) / 2;

    /* Dock背景 - 扁平化纯色 */
    gfx_fill_rounded_rect(dock_x, dock_y, dock_w, DOCK_HEIGHT, 14, 0x1A202C);

    /* Dock图标 - 优化版 */
    for (int i = 0; i < (int)APP_COUNT; i++) {
        int ix = dock_x + 10 + i * (ICON_SIZE + 16);
        int iy = dock_y + (DOCK_HEIGHT - ICON_SIZE) / 2 - 4;
        dock_icon_positions[i][0] = ix;
        dock_icon_positions[i][1] = iy;
        const app_icon_t *app = &app_icons[i];
        /* 渐变背景 */
        gfx_fill_rounded_rect(ix, iy + 1, ICON_SIZE - 2, ICON_SIZE - 2, 10, app->color1);
        /* 符号 */
        draw_icon_symbol(ix + ICON_SIZE / 2 - 1, iy + ICON_SIZE / 2 - 2, app->symbol_type, 0xFFFFFF);

        /* V6.98: 窗口打开状态指示点 */
        int has_window = 0;
        int has_minimized = 0;
        for (int w = 0; w < MAX_WINDOWS; w++) {
            if (windows[w].used && windows[w].app_id == i) {
                has_window = 1;
                if (windows[w].minimized) has_minimized = 1;
            }
        }
        if (has_window) {
            uint32_t dot_color = has_minimized ? 0xFAAD14 : 0x52C41A;
            gfx_fill_rect(ix + ICON_SIZE / 2 - 2, iy + ICON_SIZE + 2, 4, 4, dot_color);
        }
    }
}

/* ============================================================================
 * 桌面主渲染
 * ========================================================================== */

/* 计算图标位置 */
static void calc_icon_positions(void)
{
    int icon_size = SCALE(ICON_SIZE);
    int icon_spacing = SCALE(ICON_SPACING);
    int area_top = STATUSBAR_HEIGHT + 30;
    int area_bottom = gfx_height - DOCK_HEIGHT - 40;
    int area_height = area_bottom - area_top;
    int icons_per_row = 4;
    int row_height = icon_size + 24;
    int total_width = icons_per_row * (icon_size + icon_spacing) - icon_spacing;
    int start_x = (gfx_width - total_width) / 2;
    int start_y = area_top + (area_height - 2 * row_height) / 2;

    for (int i = 0; i < (int)APP_COUNT && i < 8; i++) {
        int row = i / icons_per_row;
        int col = i % icons_per_row;
        icon_positions[i][0] = start_x + col * (icon_size + icon_spacing);
        icon_positions[i][1] = start_y + row * row_height;
    }
}

/* 检测点击的图标 */
static int hit_test_icon(int mx, int my)
{
    int icon_size = SCALE(ICON_SIZE);
    for (int i = 0; i < (int)APP_COUNT && i < 8; i++) {
        int ix = icon_positions[i][0];
        int iy = icon_positions[i][1];
        if (mx >= ix && mx <= ix + icon_size &&
            my >= iy && my <= iy + icon_size) {
            return i;
        }
    }
    return -1;
}

/* 检测点击的Dock栏图标 */
static int hit_test_dock_icon(int mx, int my)
{
    for (int i = 0; i < (int)APP_COUNT && i < 8; i++) {
        int ix = dock_icon_positions[i][0];
        int iy = dock_icon_positions[i][1];
        if (mx >= ix && mx <= ix + ICON_SIZE &&
            my >= iy && my <= iy + ICON_SIZE) {
            return i;
        }
    }
    return -1;
}

/* 绘制启动的应用窗口 */
/* 绘制单个窗口 (V6.93 扁平化 + 打开动画) */
static void draw_window(int win_idx)
{
    if (win_idx < 0 || win_idx >= MAX_WINDOWS || !windows[win_idx].used) return;

    int app_id = windows[win_idx].app_id;
    if (app_id < 0 || app_id >= (int)APP_COUNT) return;

    int wx = windows[win_idx].x;
    int wy = windows[win_idx].y;
    int win_w = SCALE(gfx_width - 200);
    int win_h = SCALE(gfx_height - 160);

    /* V6.98: 最小化窗口不显示 */
    if (windows[win_idx].minimized) return;

    /* V6.98: 最大化窗口占满屏幕（除状态栏和Dock） */
    if (windows[win_idx].maximized) {
        wx = 0;
        wy = STATUSBAR_HEIGHT;
        win_w = gfx_width;
        win_h = gfx_height - STATUSBAR_HEIGHT - DOCK_HEIGHT;
    }

    /* 打开动画：从小到大缩放 (10帧) */
    if (windows[win_idx].anim_state == 1) {
        int frame = windows[win_idx].anim_frame;
        if (frame < 10) {
            int scale = (frame + 1) * 100 / 10;
            int new_w = win_w * scale / 100;
            int new_h = win_h * scale / 100;
            int cx = wx + win_w / 2;
            int cy = wy + win_h / 2;
            wx = cx - new_w / 2;
            wy = cy - new_h / 2;
            win_w = new_w;
            win_h = new_h;
            windows[win_idx].anim_frame++;
        } else {
            windows[win_idx].anim_state = 0;
        }
    }

    /* 扁平化窗口背景 - 去掉阴影 */
    gfx_fill_rounded_rect(wx, wy, win_w, win_h, 8, 0xFFFFFF);
    gfx_fill_rounded_rect(wx - 1, wy - 1, win_w + 2, win_h + 2, 9, 0xCBD5E0);
    gfx_fill_rounded_rect(wx, wy, win_w, win_h, 8, 0xFFFFFF);

    /* 标题栏 - 扁平化纯色 */
    if (win_h > 50) {
        gfx_fill_rect(wx + 8, wy, win_w - 16, 36, 0xF7FAFC);
        desktop_puts(wx + 16, wy + 12, app_icons[app_id].name, 0x00);

        /* 关闭按钮 - 扁平化红色 */
        if (win_w > 80) {
            gfx_fill_rounded_rect(wx + win_w - 40, wy + 8, 24, 20, 4, 0xFC8181);
            desktop_puts(wx + win_w - 34, wy + 12, "X", 0x00);
        }

        /* V6.98: 最大化按钮 - 扁平化绿色 */
        if (win_w > 110) {
            uint32_t max_color = windows[win_idx].maximized ? 0x68D391 : 0x9AE6B4;
            gfx_fill_rounded_rect(wx + win_w - 70, wy + 8, 24, 20, 4, max_color);
            desktop_puts(wx + win_w - 63, wy + 12, windows[win_idx].maximized ? "□" : "▢", 0x00);
        }

        /* 最小化按钮 - 扁平化黄色 */
        if (win_w > 140) {
            gfx_fill_rounded_rect(wx + win_w - 100, wy + 8, 24, 20, 4, 0xF6E05E);
            desktop_puts(wx + win_w - 94, wy + 12, "-", 0x00);
        }
    }

    /* 应用内容区域 */
    if (win_h > 100) {
        int content_y = wy + 50;

        /* V6.97: 设置应用显示系统信息 */
        if (app_id == 3) {
            /* 左侧设置菜单 */
            gfx_fill_rect(wx + 8, content_y, 140, win_h - 80, 0xF7FAFC);
            const char *settings_menu[] = {
                "Display", "System", "Network", "Sound",
                "Power", "About"
            };
            for (int i = 0; i < 6; i++) {
                if (i == 0) {
                    gfx_fill_rect(wx + 8, content_y + i * 32, 140, 30, 0x3182CE);
                    desktop_puts(wx + 20, content_y + i * 32 + 9, settings_menu[i], 0x0F);
                } else {
                    desktop_puts(wx + 20, content_y + i * 32 + 9, settings_menu[i], 0x00);
                }
            }

            /* 右侧显示设置内容 - 显示信息 */
            int info_x = wx + 160;
            desktop_puts(info_x, content_y + 10, "Display Settings", 0x00);
            gfx_draw_hline(info_x, content_y + 28, win_w - 180, 0xE2E8F0);

            extern int gfx_refresh_rate;
            char info[128];
            snprintf(info, sizeof(info), "Resolution: %dx%d", gfx_width, gfx_height);
            desktop_puts(info_x, content_y + 40, info, 0x07);
            snprintf(info, sizeof(info), "Refresh Rate: %dHz", gfx_refresh_rate);
            desktop_puts(info_x, content_y + 60, info, 0x07);
            snprintf(info, sizeof(info), "Color Depth: %dbpp", gfx_bpp);
            desktop_puts(info_x, content_y + 80, info, 0x07);

            /* V6.98: UI组件演示 - 亮度滑块 */
            desktop_puts(info_x, content_y + 105, "Brightness", 0x07);
            ui_draw_slider(info_x, content_y + 120, 150, 70, 0, 100);

            /* V6.98: 复选框 - 夜间模式 */
            ui_draw_checkbox(info_x, content_y + 150, "Night Mode", 0);
            ui_draw_checkbox(info_x, content_y + 175, "Auto Rotate", 1);

            /* 系统信息 */
            desktop_puts(info_x, content_y + 210, "System Information", 0x00);
            gfx_draw_hline(info_x, content_y + 228, win_w - 180, 0xE2E8F0);
            desktop_puts(info_x, content_y + 240, "OS: Hepu OS v1.02", 0x07);
            desktop_puts(info_x, content_y + 260, "Kernel: v1.0.2", 0x07);
            desktop_puts(info_x, content_y + 280, "Architecture: x86", 0x07);

            /* V6.98: 输入框演示 - 主机名 */
            desktop_puts(info_x, content_y + 310, "Hostname", 0x07);
            ui_draw_input(info_x, content_y + 325, 150, 28, "hepu-os", 0, 7);

            /* 电源按钮 - 使用UI组件 */
            int btn_y = wy + win_h - 60;
            ui_draw_button(info_x, btn_y, 100, 32, "Shut Down", 0, 0);
            ui_draw_button(info_x + 110, btn_y, 100, 32, "Restart", 0, 0);
            ui_draw_button(info_x + 220, btn_y, 100, 32, "Apply", 0, 0);
        } else {
            desktop_puts(wx + 20, content_y, "Application launched:", 0x07);
            desktop_puts(wx + 20, content_y + 24, app_icons[app_id].name, 0x09);

            /* 应用图标预览 - 扁平化纯色 */
            const app_icon_t *app = &app_icons[app_id];
            gfx_fill_rounded_rect(wx + 20, content_y + 50, 32, 32, 6, app->color1);

            char msg[128];
            snprintf(msg, sizeof(msg), "This is the %s application window.",
                     app_icons[app_id].name);
            desktop_puts(wx + 60, content_y + 55, msg, 0x07);
            desktop_puts(wx + 60, content_y + 75, "Drag titlebar to move.", 0x07);
            desktop_puts(wx + 60, content_y + 95, "Click X to close. Press ESC to close top window.", 0x07);
        }

        /* 状态栏 */
        if (win_h > 180) {
            gfx_draw_hline(wx + 12, wy + win_h - 30, win_w - 24, 0xE2E8F0);
            desktop_puts(wx + 20, wy + win_h - 22, "Ready", 0x07);
            char status[64];
            snprintf(status, sizeof(status), "Window %d of %d", win_idx + 1, window_count);
            desktop_puts(wx + win_w - 100, wy + win_h - 22, status, 0x07);
        }
    }
}

/* 按Z轴顺序绘制所有窗口 */
static void draw_all_windows(void)
{
    /* 收集所有窗口并按z_order排序 */
    int indices[MAX_WINDOWS];
    int count = 0;
    for (int i = 0; i < MAX_WINDOWS; i++) {
        if (windows[i].used) {
            indices[count++] = i;
        }
    }

    /* 简单冒泡排序（按z_order从小到大） */
    for (int i = 0; i < count - 1; i++) {
        for (int j = 0; j < count - 1 - i; j++) {
            if (windows[indices[j]].z_order > windows[indices[j+1]].z_order) {
                int tmp = indices[j];
                indices[j] = indices[j+1];
                indices[j+1] = tmp;
            }
        }
    }

    /* 按顺序绘制 */
    for (int i = 0; i < count; i++) {
        draw_window(indices[i]);
    }
}

void elastic_desktop_render(void)
{
    /* 计算UI缩放因子 */
    calc_ui_scale();

    /* 绘制扁平化背景 */
    draw_modern_background();

    /* 绘制顶部状态栏 */
    draw_statusbar();

    /* 计算图标位置 */
    calc_icon_positions();

    /* 绘制桌面应用图标 */
    int icon_size = SCALE(ICON_SIZE);
    int icon_radius = SCALE(ICON_RADIUS);
    for (int i = 0; i < (int)APP_COUNT && i < 8; i++) {
        int ix = icon_positions[i][0];
        int iy = icon_positions[i][1];
        /* 临时修改图标大小绘制 */
        int old_size = ICON_SIZE;
        int old_radius = ICON_RADIUS;
        /* 直接绘制缩放后的图标 */
        const app_icon_t *app = &app_icons[i];
        int selected = (selected_icon == i);
        int s = icon_size + (selected ? 8 : 0);
        int r = icon_radius + (selected ? 2 : 0);
        int ox = selected ? -4 : 0;
        int oy = selected ? -4 : 0;
        gfx_fill_rounded_rect(ix + ox, iy + oy, s, s, r, app->color1);
        if (selected) {
            gfx_fill_rounded_rect(ix - 2, iy - 2, s + 4, s + 4, r + 2, 0xFFFFFF);
            gfx_fill_rounded_rect(ix - 1, iy - 1, s + 2, s + 2, r + 1, app->color1);
        }
        draw_icon_symbol(ix + s / 2, iy + s / 2 - 4, app->symbol_type, 0xFFFFFF);
        int name_len = strlen(app->name);
        int text_x = ix + (icon_size - name_len * 8) / 2;
        desktop_puts(text_x, iy + icon_size + 6, app->name, 0x0F);
    }

    /* 绘制底部Dock栏 */
    draw_dock_modern();

    /* 绘制所有应用窗口（按Z轴顺序） */
    draw_all_windows();

    /* 绘制右键菜单 */
    draw_context_menu();

    /* V6.97: 绘制关机/重启对话框 */
    draw_power_dialog();

    /* 绘制鼠标光标 */
    draw_mouse_cursor();
}

/* 找到指定位置最上层的窗口 */
static int find_top_window_at(int mx, int my)
{
    int win_w = gfx_width - 200;
    int win_h = gfx_height - 160;
    int top_idx = -1;
    int top_z = -1;

    for (int i = 0; i < MAX_WINDOWS; i++) {
        if (windows[i].used) {
            int wx = windows[i].x;
            int wy = windows[i].y;
            if (mx >= wx && mx <= wx + win_w &&
                my >= wy && my <= wy + win_h) {
                if (windows[i].z_order > top_z) {
                    top_z = windows[i].z_order;
                    top_idx = i;
                }
            }
        }
    }
    return top_idx;
}

/* 创建新窗口 */
static int create_window(int app_id)
{
    for (int i = 0; i < MAX_WINDOWS; i++) {
        if (!windows[i].used) {
            windows[i].used = 1;
            windows[i].app_id = app_id;
            windows[i].x = 100 + (window_count % 3) * 30;
            windows[i].y = 80 + (window_count % 3) * 20;
            windows[i].z_order = next_z++;
            windows[i].anim_state = 1;  /* 打开动画 */
            windows[i].anim_frame = 0;
            window_count++;
            return i;
        }
    }
    return -1;
}

/* 关闭窗口 */
static void close_window(int win_idx)
{
    if (win_idx >= 0 && win_idx < MAX_WINDOWS && windows[win_idx].used) {
        windows[win_idx].used = 0;
        window_count--;
    }
}

/* 将窗口置于最上层 */
static void bring_to_front(int win_idx)
{
    if (win_idx >= 0 && win_idx < MAX_WINDOWS && windows[win_idx].used) {
        windows[win_idx].z_order = next_z++;
    }
}

/* ============================================================================
 * 测试函数
 * ========================================================================== */
void desktop_render_test(void)
{
    elastic_desktop_render();
    gfx_flip();
}

/* ============================================================================
 * 桌面主循环 (带鼠标交互)
 * ========================================================================== */
void elastic_desktop_main_loop(void)
{
    extern void serial_puts(uint16_t, const char *);
    serial_puts(0x3F8, "[EDESKTOP] entering main loop with mouse...\n");

    /* 初始化鼠标位置到屏幕中央 */
    desktop_set_mouse(gfx_width / 2, gfx_height / 2);

    /* 鼠标状态 */
    extern int mouse_get_x(void);
    extern int mouse_get_y(void);
    extern uint8_t mouse_get_buttons(void);
    uint8_t prev_buttons = 0;

    /* 无限循环 */
    while (1) {
        /* 读取鼠标位置 */
        int mx = mouse_get_x();
        int my = mouse_get_y();
        uint8_t buttons = mouse_get_buttons();

        /* 限制鼠标在屏幕范围内 */
        if (mx < 0) mx = 0;
        if (mx > gfx_width - 1) mx = gfx_width - 1;
        if (my < 0) my = 0;
        if (my > gfx_height - 1) my = gfx_height - 1;
        desktop_set_mouse(mx, my);

        /* 鼠标悬停检测（仅在无窗口拖动时） */
        if (dragging_window < 0) {
            selected_icon = hit_test_icon(mx, my);
            if (selected_icon < 0) {
                selected_icon = hit_test_dock_icon(mx, my);
            }
        } else {
            selected_icon = -1;
        }

        /* 右键菜单悬停检测 */
        if (context_menu_visible) {
            context_menu_selected = hit_test_context_menu(mx, my);
        }

        /* 鼠标点击检测（左键按下沿） */
        if ((buttons & 1) && !(prev_buttons & 1)) {
            /* 如果右键菜单可见，先处理菜单点击 */
            if (context_menu_visible) {
                int menu_idx = hit_test_context_menu(mx, my);
                if (menu_idx >= 0) {
                    execute_context_menu(menu_idx);
                } else {
                    context_menu_visible = 0;  /* 点击菜单外关闭 */
                }
                prev_buttons = buttons;
                continue;
            }

            /* V6.97: 关机/重启对话框处理 */
            if (power_dialog_visible) {
                handle_power_dialog_click(mx, my);
                prev_buttons = buttons;
                continue;
            }

            int win_idx = find_top_window_at(mx, my);

            if (win_idx >= 0) {
                /* 点击了窗口 */
                bring_to_front(win_idx);
                int win_w = gfx_width - 200;
                int wx = windows[win_idx].x;
                int wy = windows[win_idx].y;

                /* V6.98: 最大化时使用全屏宽度 */
                if (windows[win_idx].maximized) {
                    win_w = gfx_width;
                }

                /* 检测是否点击关闭按钮 */
                int close_x = wx + win_w - 40;
                int close_y = wy + 8;
                if (mx >= close_x && mx <= close_x + 24 &&
                    my >= close_y && my <= close_y + 20) {
                    serial_puts(0x3F8, "[EDESKTOP] window closed\n");
                    close_window(win_idx);
                }
                /* V6.98: 检测是否点击最大化按钮 */
                else if (mx >= wx + win_w - 70 && mx <= wx + win_w - 46 &&
                         my >= wy + 8 && my <= wy + 28) {
                    if (windows[win_idx].maximized) {
                        /* 还原窗口 */
                        windows[win_idx].maximized = 0;
                        windows[win_idx].x = windows[win_idx].prev_x;
                        windows[win_idx].y = windows[win_idx].prev_y;
                        serial_puts(0x3F8, "[EDESKTOP] window restored\n");
                    } else {
                        /* 最大化窗口 */
                        windows[win_idx].prev_x = windows[win_idx].x;
                        windows[win_idx].prev_y = windows[win_idx].y;
                        windows[win_idx].maximized = 1;
                        serial_puts(0x3F8, "[EDESKTOP] window maximized\n");
                    }
                }
                /* V6.98: 检测是否点击最小化按钮 */
                else if (mx >= wx + win_w - 100 && mx <= wx + win_w - 76 &&
                         my >= wy + 8 && my <= wy + 28) {
                    windows[win_idx].minimized = 1;
                    serial_puts(0x3F8, "[EDESKTOP] window minimized\n");
                }
                /* 检测是否点击标题栏（开始拖动） */
                else if (mx >= wx && mx <= wx + win_w &&
                         my >= wy && my <= wy + 36) {
                    /* 最大化时拖动标题栏还原窗口 */
                    if (windows[win_idx].maximized) {
                        windows[win_idx].maximized = 0;
                        windows[win_idx].x = mx - (SCALE(gfx_width - 200) / 2);
                        windows[win_idx].y = STATUSBAR_HEIGHT + 10;
                    }
                    dragging_window = win_idx;
                    drag_offset_x = mx - windows[win_idx].x;
                    drag_offset_y = my - windows[win_idx].y;
                    serial_puts(0x3F8, "[EDESKTOP] window drag start\n");
                }
            } else {
                /* 点击桌面，检测图标 */
                int hit = hit_test_icon(mx, my);
                if (hit < 0) {
                    hit = hit_test_dock_icon(mx, my);
                }
                if (hit >= 0) {
                    /* V6.98: 检查是否有该应用的最小化窗口，有则恢复 */
                    int restored = 0;
                    for (int i = 0; i < MAX_WINDOWS; i++) {
                        if (windows[i].used && windows[i].app_id == hit &&
                            windows[i].minimized) {
                            windows[i].minimized = 0;
                            bring_to_front(i);
                            restored = 1;
                            serial_puts(0x3F8, "[EDESKTOP] window restored from dock\n");
                            break;
                        }
                    }
                    if (!restored) {
                        serial_puts(0x3F8, "[EDESKTOP] app launched: ");
                        serial_puts(0x3F8, app_icons[hit].name);
                        serial_puts(0x3F8, "\n");
                        create_window(hit);
                    }
                }
            }
        }

        /* 鼠标释放（结束拖动） */
        if (!(buttons & 1) && (prev_buttons & 1)) {
            if (dragging_window >= 0) {
                serial_puts(0x3F8, "[EDESKTOP] window drag end\n");
                dragging_window = -1;
            }
        }

        /* 右键按下沿 - 显示右键菜单 */
        if ((buttons & 2) && !(prev_buttons & 2)) {
            context_menu_x = mx;
            context_menu_y = my;
            context_menu_visible = 1;
            context_menu_selected = -1;
            /* 确保菜单不超出屏幕 */
            if (context_menu_x + CONTEXT_MENU_WIDTH > gfx_width) {
                context_menu_x = gfx_width - CONTEXT_MENU_WIDTH;
            }
            if (context_menu_y + CONTEXT_MENU_COUNT * CONTEXT_MENU_ITEM_HEIGHT > gfx_height) {
                context_menu_y = gfx_height - CONTEXT_MENU_COUNT * CONTEXT_MENU_ITEM_HEIGHT - 20;
            }
            serial_puts(0x3F8, "[EDESKTOP] context menu shown\n");
        }

        /* 窗口拖动 */
        if (dragging_window >= 0 && windows[dragging_window].used) {
            windows[dragging_window].x = mx - drag_offset_x;
            windows[dragging_window].y = my - drag_offset_y;
            /* 限制窗口在屏幕范围内 */
            int win_w = gfx_width - 200;
            int win_h = gfx_height - 160;
            if (windows[dragging_window].x < 0) windows[dragging_window].x = 0;
            if (windows[dragging_window].y < 0) windows[dragging_window].y = 0;
            if (windows[dragging_window].x > gfx_width - win_w) windows[dragging_window].x = gfx_width - win_w;
            if (windows[dragging_window].y > gfx_height - win_h) windows[dragging_window].y = gfx_height - win_h;
        }

        /* 键盘输入：ESC关闭最上层窗口 */
        extern char keyboard_getchar(void);
        char key = keyboard_getchar();
        if (key == 27 && window_count > 0) {  /* ESC */
            /* 找到最上层窗口并关闭 */
            int top_idx = -1;
            int top_z = -1;
            for (int i = 0; i < MAX_WINDOWS; i++) {
                if (windows[i].used && windows[i].z_order > top_z) {
                    top_z = windows[i].z_order;
                    top_idx = i;
                }
            }
            if (top_idx >= 0) {
                serial_puts(0x3F8, "[EDESKTOP] ESC pressed, window closed\n");
                close_window(top_idx);
                dragging_window = -1;
            }
        }

        prev_buttons = buttons;

        /* 渲染 */
        elastic_desktop_render();
        gfx_flip();

        /* 简单延时 */
        for (volatile int i = 0; i < 200000; i++);
    }

    serial_puts(0x3F8, "[EDESKTOP] main loop done\n");
}
