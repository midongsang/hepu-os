/* ============================================================================
 * 赫普OS - 现代桌面渲染器 (V6.80 重设计)
 * 现代渐变背景 + 圆角图标 + 半透明状态栏 + Dock栏
 * ========================================================================== */
#include <stdint.h>
#include <stddef.h>
#include "elastic_desktop.h"
#include "vga_gfx.h"
#include "string.h"
#include "kstdio.h"
#include "font_antialiased.h"

/* ============================================================================
 * 颜色定义 (VGA 256色调色板)
 * ========================================================================== */
#define COLOR_BG_DARK       0x10  /* 深蓝黑 */
#define COLOR_BG_MID        0x12  /* 深蓝 */
#define COLOR_BG_LIGHT      0x14  /* 蓝紫 */
#define COLOR_PANEL         0x08  /* 深灰面板 */
#define COLOR_PANEL_LIGHT   0x07  /* 浅灰面板 */
#define COLOR_TEXT          0x0F  /* 白色文字 */
#define COLOR_TEXT_DIM      0x07  /* 灰色文字 */
#define COLOR_ACCENT        0x09  /* 蓝色强调 */
#define COLOR_ACCENT_LIGHT  0x0B  /* 亮蓝 */
#define COLOR_BLUE          0x09  /* 蓝色 */
#define COLOR_GREEN         0x0A  /* 绿色 */
#define COLOR_RED           0x0C  /* 红色 */
#define COLOR_YELLOW        0x0E  /* 黄色 */
#define COLOR_ORANGE        0x06  /* 橙色 */
#define COLOR_PURPLE        0x05  /* 紫色 */
#define COLOR_CYAN          0x03  /* 青色 */
#define COLOR_BORDER        0x06  /* 边框色 */

/* 图标位置缓存（用于点击检测） */
static int icon_positions[8][2]; /* x, y */
static int dock_icon_positions[8][2]; /* Dock栏图标位置 */
static int selected_icon = -1;

/* 多窗口支持 */
#define MAX_WINDOWS 4
typedef struct {
    int used;
    int app_id;
    int x, y;
    int z_order;  /* Z轴顺序，越大越上层 */
} window_t;
static window_t windows[MAX_WINDOWS];
static int window_count = 0;
static int next_z = 0;
static int dragging_window = -1;
static int drag_offset_x = 0, drag_offset_y = 0;

/* 状态栏高度 */
#define STATUSBAR_HEIGHT    28
/* Dock栏高度 */
#define DOCK_HEIGHT         70
/* 图标大小 */
#define ICON_SIZE           56
#define ICON_RADIUS         8
/* 图标间距 */
#define ICON_SPACING        20

/* 鼠标光标位置 */
static int mouse_x = 0;
static int mouse_y = 0;
static int mouse_visible = 1;

/* ============================================================================
 * 鼠标控制
 * ========================================================================== */
void desktop_set_mouse(int x, int y)
{
    if (x < 0) x = 0;
    if (y < 0) y = 0;
    if (x >= gfx_width) x = gfx_width - 1;
    if (y >= gfx_height) y = gfx_height - 1;
    mouse_x = x;
    mouse_y = y;
}

void desktop_get_mouse(int *x, int *y)
{
    if (x) *x = mouse_x;
    if (y) *y = mouse_y;
}

void desktop_show_mouse(int show)
{
    mouse_visible = show;
}

/* 绘制鼠标光标（箭头形状） */
static void draw_mouse_cursor(void)
{
    if (!mouse_visible) return;
    int x = mouse_x, y = mouse_y;
    static const uint8_t cursor_mask[] = {
        0x01,0x00, 0x03,0x00, 0x07,0x00, 0x0F,0x00,
        0x1F,0x00, 0x3F,0x00, 0x7F,0x00, 0xFF,0x00,
        0xFF,0x01, 0xE7,0x01, 0xC3,0x01, 0x81,0x03,
        0x01,0x03, 0x01,0x06, 0x01,0x0C, 0x00,0x08,
    };
    for (int row = 0; row < 16; row++) {
        for (int col = 0; col < 11; col++) {
            int byte_idx = row * 2 + (col >= 8 ? 1 : 0);
            int bit_idx = col % 8;
            if (cursor_mask[byte_idx] & (1 << bit_idx)) {
                gfx_putpixel(x + col, y + row, 0x00);
                if (col > 0 && row > 0 && col < 10 && row < 15) {
                    int ic = col - 1, ir = row - 1;
                    int ib = ir * 2 + (ic >= 8 ? 1 : 0);
                    if (cursor_mask[ib] & (1 << (ic % 8)))
                        gfx_putpixel(x + col, y + row, 0x0F);
                }
            }
        }
    }
}

/* ============================================================================
 * 圆角矩形绘制 (用多个矩形模拟)
 * ========================================================================== */
static void draw_rounded_rect(int x, int y, int w, int h, int r, uint8_t color)
{
    /* 中心矩形 */
    gfx_fillrect(x + r, y, w - 2*r, h, color);
    /* 左右矩形 */
    gfx_fillrect(x, y + r, r, h - 2*r, color);
    gfx_fillrect(x + w - r, y + r, r, h - 2*r, color);
    /* 四个角用圆形近似 */
    gfx_fillcircle(x + r, y + r, r, color);
    gfx_fillcircle(x + w - r, y + r, r, color);
    gfx_fillcircle(x + r, y + h - r, r, color);
    gfx_fillcircle(x + w - r, y + h - r, r, color);
}

/* ============================================================================
 * 现代背景绘制
 * ========================================================================== */
static void draw_modern_background(void)
{
    /* 深蓝到深紫的垂直渐变 */
    gfx_gradient_v(0, 0, gfx_width, gfx_height, COLOR_BG_DARK, COLOR_BG_LIGHT);

    /* 装饰性光斑 - 左上角蓝色光晕 */
    for (int r = 120; r > 0; r -= 20) {
        uint8_t c = (r > 80) ? 0x12 : (r > 40) ? 0x14 : 0x16;
        gfx_fillcircle(150, 100, r, c);
    }
    /* 右下角紫色光晕 */
    for (int r = 100; r > 0; r -= 20) {
        uint8_t c = (r > 60) ? 0x14 : 0x16;
        gfx_fillcircle(gfx_width - 100, gfx_height - 150, r, c);
    }
    /* 中间偏右的青色小光斑 */
    gfx_fillcircle(gfx_width - 250, 200, 40, 0x18);
}

/* ============================================================================
 * 顶部状态栏
 * ========================================================================== */
static void draw_statusbar(void)
{
    /* 半透明深色状态栏 */
    gfx_fillrect(0, 0, gfx_width, STATUSBAR_HEIGHT, COLOR_PANEL);
    /* 顶部高光 */
    gfx_hline(0, 0, gfx_width, COLOR_PANEL_LIGHT);
    /* 底部分隔线 */
    gfx_hline(0, STATUSBAR_HEIGHT - 1, gfx_width, 0x00);

    /* 左侧：系统名称（大尺寸字体） */
    gfx_puts_large(12, 6, "Hepu OS", COLOR_TEXT, 1);

    /* 中间：状态指示 */
    gfx_puts(gfx_width / 2 - 30, 9, "Desktop", COLOR_TEXT_DIM);

    /* 右侧：实时时间 */
    extern int rtc_get_time(int *h, int *m, int *s, int *d, int *mo, int *y);
    int h, m, s, d, mo, y;
    rtc_get_time(&h, &m, &s, &d, &mo, &y);
    char time_buf[16];
    snprintf(time_buf, sizeof(time_buf), "%02d:%02d", h, m);
    gfx_puts(gfx_width - 60, 9, time_buf, COLOR_TEXT);
}

/* ============================================================================
 * 应用图标绘制 (现代风格)
 * ========================================================================== */
typedef struct {
    const char *name;       /* 英文名称 */
    uint8_t bg_color;       /* 图标背景色 */
    uint8_t symbol_color;   /* 符号颜色 */
    int symbol_type;        /* 符号类型: 0=文件 1=终端 2=浏览器 3=设置 4=游戏 5=应用商店 6=助手 7=相机 */
} app_icon_t;

/* 应用图标定义 */
static const app_icon_t app_icons[] = {
    {"Files",    COLOR_BLUE,    COLOR_TEXT,   0},
    {"Terminal", COLOR_GREEN,   COLOR_TEXT,   1},
    {"Browser",  COLOR_CYAN,    COLOR_TEXT,   2},
    {"Settings", COLOR_PURPLE,  COLOR_TEXT,   3},
    {"Games",    COLOR_RED,     COLOR_TEXT,   4},
    {"App Store",COLOR_ACCENT,  COLOR_TEXT,   5},
    {"Assistant",COLOR_ORANGE,  COLOR_TEXT,   6},
    {"Camera",   COLOR_YELLOW,  COLOR_TEXT,   7},
};
#define APP_COUNT (sizeof(app_icons)/sizeof(app_icons[0]))

/* 绘制图标内部符号 */
static void draw_icon_symbol(int cx, int cy, int type, uint8_t color)
{
    int s = 16; /* 符号大小 */
    switch (type) {
        case 0: /* 文件 - 文件夹 */
            gfx_fillrect(cx - s/2, cy - s/4, s, s*3/4, color);
            gfx_fillrect(cx - s/2, cy - s/2, s/2, s/4, color);
            break;
        case 1: /* 终端 - 方框+光标 */
            gfx_rect(cx - s/2, cy - s/2, s, s, color);
            gfx_fillrect(cx - s/4, cy - 2, 4, 4, color);
            break;
        case 2: /* 浏览器 - 圆形 */
            gfx_fillcircle(cx, cy, s/2, color);
            gfx_fillcircle(cx, cy, s/3, COLOR_BG_DARK);
            break;
        case 3: /* 设置 - 齿轮(用矩形模拟) */
            gfx_fillrect(cx - 2, cy - s/2, 4, s, color);
            gfx_fillrect(cx - s/2, cy - 2, s, 4, color);
            gfx_fillcircle(cx, cy, 4, color);
            break;
        case 4: /* 游戏 - 手柄 */
            gfx_fillrect(cx - s/2, cy - 4, s, 8, color);
            gfx_fillcircle(cx - s/2 + 4, cy, 5, color);
            gfx_fillcircle(cx + s/2 - 4, cy, 5, color);
            break;
        case 5: /* 应用商店 - 购物袋 */
            gfx_fillrect(cx - s/3, cy - s/2, s*2/3, s, color);
            gfx_line(cx - s/4, cy - s/2, cx - s/4, cy - s/2 - 4, color);
            gfx_line(cx + s/4, cy - s/2, cx + s/4, cy - s/2 - 4, color);
            break;
        case 6: /* 助手 - 对话框 */
            gfx_fillrect(cx - s/2, cy - s/3, s, s*2/3, color);
            gfx_triangle(cx - 4, cy + s/3, cx + 4, cy + s/3, cx, cy + s/2, color);
            break;
        case 7: /* 相机 - 方框+圆 */
            gfx_fillrect(cx - s/2, cy - s/3, s, s*2/3, color);
            gfx_fillcircle(cx, cy, s/4, COLOR_BG_DARK);
            gfx_fillrect(cx - s/4, cy - s/2, s/2, 4, color);
            break;
    }
}

/* 绘制单个应用图标 */
static void draw_app_icon_modern(int x, int y, const app_icon_t *app, int selected)
{
    /* 图标阴影 */
    draw_rounded_rect(x + 2, y + 3, ICON_SIZE, ICON_SIZE, ICON_RADIUS, 0x00);

    /* 图标背景 - 渐变效果 */
    draw_rounded_rect(x, y, ICON_SIZE, ICON_SIZE, ICON_RADIUS, app->bg_color);

    /* 图标高光 */
    gfx_fillrect(x + ICON_RADIUS, y + 2, ICON_SIZE - 2*ICON_RADIUS, 4, app->bg_color + 2);

    /* 选中状态 - 白色边框 */
    if (selected) {
        gfx_rect(x - 1, y - 1, ICON_SIZE + 2, ICON_SIZE + 2, COLOR_TEXT);
    }

    /* 图标符号 */
    draw_icon_symbol(x + ICON_SIZE/2, y + ICON_SIZE/2 - 4, app->symbol_type, app->symbol_color);

    /* 图标名称 */
    int name_len = strlen(app->name);
    int text_x = x + (ICON_SIZE - name_len * 8) / 2;
    gfx_puts(text_x, y + ICON_SIZE + 6, app->name, COLOR_TEXT);
}

/* ============================================================================
 * 底部Dock栏
 * ========================================================================== */
static void draw_dock_modern(void)
{
    int dock_y = gfx_height - DOCK_HEIGHT - 10;
    int dock_w = (int)APP_COUNT * (ICON_SIZE + 16) + 20;
    int dock_x = (gfx_width - dock_w) / 2;

    /* Dock背景 - 半透明圆角面板 */
    draw_rounded_rect(dock_x, dock_y, dock_w, DOCK_HEIGHT, 14, COLOR_PANEL);
    /* Dock顶部高光 */
    gfx_hline(dock_x + 14, dock_y, dock_w - 28, COLOR_PANEL_LIGHT);

    /* Dock图标 */
    for (int i = 0; i < (int)APP_COUNT; i++) {
        int ix = dock_x + 10 + i * (ICON_SIZE + 16);
        int iy = dock_y + (DOCK_HEIGHT - ICON_SIZE) / 2 - 4;
        /* 缓存位置用于点击检测 */
        dock_icon_positions[i][0] = ix;
        dock_icon_positions[i][1] = iy;
        /* 只绘制图标，不绘制文字（Dock空间有限） */
        draw_rounded_rect(ix + 1, iy + 2, ICON_SIZE - 2, ICON_SIZE - 2, ICON_RADIUS - 2, 0x00);
        draw_rounded_rect(ix, iy, ICON_SIZE - 2, ICON_SIZE - 2, ICON_RADIUS - 2, app_icons[i].bg_color);
        draw_icon_symbol(ix + ICON_SIZE/2 - 1, iy + ICON_SIZE/2 - 3, app_icons[i].symbol_type, app_icons[i].symbol_color);
    }
}

/* ============================================================================
 * 桌面主渲染
 * ========================================================================== */

/* 计算图标位置 */
static void calc_icon_positions(void)
{
    int area_top = STATUSBAR_HEIGHT + 30;
    int area_bottom = gfx_height - DOCK_HEIGHT - 40;
    int area_height = area_bottom - area_top;
    int icons_per_row = 4;
    int row_height = ICON_SIZE + 24;
    int total_width = icons_per_row * (ICON_SIZE + ICON_SPACING) - ICON_SPACING;
    int start_x = (gfx_width - total_width) / 2;
    int start_y = area_top + (area_height - 2 * row_height) / 2;

    for (int i = 0; i < (int)APP_COUNT && i < 8; i++) {
        int row = i / icons_per_row;
        int col = i % icons_per_row;
        icon_positions[i][0] = start_x + col * (ICON_SIZE + ICON_SPACING);
        icon_positions[i][1] = start_y + row * row_height;
    }
}

/* 检测点击的图标 */
static int hit_test_icon(int mx, int my)
{
    for (int i = 0; i < (int)APP_COUNT && i < 8; i++) {
        int ix = icon_positions[i][0];
        int iy = icon_positions[i][1];
        if (mx >= ix && mx <= ix + ICON_SIZE &&
            my >= iy && my <= iy + ICON_SIZE) {
            return i;
        }
    }
    return -1;
}

/* 检测点击的Dock栏图标 */
static int hit_test_dock_icon(int mx, int my)
{
    for (int i = 0; i < (int)APP_COUNT && i < 8; i++) {
        int ix = dock_icon_positions[i][0];
        int iy = dock_icon_positions[i][1];
        if (mx >= ix && mx <= ix + ICON_SIZE &&
            my >= iy && my <= iy + ICON_SIZE) {
            return i;
        }
    }
    return -1;
}

/* 绘制启动的应用窗口 */
/* 绘制单个窗口 */
static void draw_window(int win_idx)
{
    if (win_idx < 0 || win_idx >= MAX_WINDOWS || !windows[win_idx].used) return;

    int app_id = windows[win_idx].app_id;
    if (app_id < 0 || app_id >= (int)APP_COUNT) return;

    int wx = windows[win_idx].x;
    int wy = windows[win_idx].y;
    int win_w = gfx_width - 200;
    int win_h = gfx_height - 160;

    /* 窗口背景 */
    draw_rounded_rect(wx, wy, win_w, win_h, 12, COLOR_PANEL);
    gfx_rect(wx, wy, win_w, win_h, COLOR_BORDER);

    /* 标题栏 */
    gfx_fillrect(wx, wy, win_w, 36, COLOR_PANEL_LIGHT);
    gfx_puts(wx + 16, wy + 12, app_icons[app_id].name, COLOR_TEXT);

    /* 关闭按钮 */
    draw_rounded_rect(wx + win_w - 40, wy + 8, 24, 20, 4, COLOR_RED);
    gfx_puts(wx + win_w - 34, wy + 12, "X", COLOR_TEXT);

    /* 应用内容区域 */
    int content_y = wy + 50;
    gfx_puts(wx + 20, content_y, "Application launched:", COLOR_TEXT_DIM);
    gfx_puts(wx + 20, content_y + 24, app_icons[app_id].name, COLOR_ACCENT);

    char msg[128];
    snprintf(msg, sizeof(msg), "This is the %s application window.",
             app_icons[app_id].name);
    gfx_puts(wx + 20, content_y + 50, msg, COLOR_TEXT_DIM);
    gfx_puts(wx + 20, content_y + 74, "Drag titlebar to move. Click X to close.", COLOR_TEXT_DIM);
}

/* 按Z轴顺序绘制所有窗口 */
static void draw_all_windows(void)
{
    /* 收集所有窗口并按z_order排序 */
    int indices[MAX_WINDOWS];
    int count = 0;
    for (int i = 0; i < MAX_WINDOWS; i++) {
        if (windows[i].used) {
            indices[count++] = i;
        }
    }

    /* 简单冒泡排序（按z_order从小到大） */
    for (int i = 0; i < count - 1; i++) {
        for (int j = 0; j < count - 1 - i; j++) {
            if (windows[indices[j]].z_order > windows[indices[j+1]].z_order) {
                int tmp = indices[j];
                indices[j] = indices[j+1];
                indices[j+1] = tmp;
            }
        }
    }

    /* 按顺序绘制 */
    for (int i = 0; i < count; i++) {
        draw_window(indices[i]);
    }
}

void elastic_desktop_render(void)
{
    /* 绘制现代背景 */
    draw_modern_background();

    /* 绘制顶部状态栏 */
    draw_statusbar();

    /* 计算图标位置 */
    calc_icon_positions();

    /* 绘制桌面应用图标 */
    for (int i = 0; i < (int)APP_COUNT && i < 8; i++) {
        int ix = icon_positions[i][0];
        int iy = icon_positions[i][1];
        draw_app_icon_modern(ix, iy, &app_icons[i], selected_icon == i);
    }

    /* 绘制底部Dock栏 */
    draw_dock_modern();

    /* 绘制所有应用窗口（按Z轴顺序） */
    draw_all_windows();

    /* 绘制鼠标光标 */
    draw_mouse_cursor();
}

/* 找到指定位置最上层的窗口 */
static int find_top_window_at(int mx, int my)
{
    int win_w = gfx_width - 200;
    int win_h = gfx_height - 160;
    int top_idx = -1;
    int top_z = -1;

    for (int i = 0; i < MAX_WINDOWS; i++) {
        if (windows[i].used) {
            int wx = windows[i].x;
            int wy = windows[i].y;
            if (mx >= wx && mx <= wx + win_w &&
                my >= wy && my <= wy + win_h) {
                if (windows[i].z_order > top_z) {
                    top_z = windows[i].z_order;
                    top_idx = i;
                }
            }
        }
    }
    return top_idx;
}

/* 创建新窗口 */
static int create_window(int app_id)
{
    for (int i = 0; i < MAX_WINDOWS; i++) {
        if (!windows[i].used) {
            windows[i].used = 1;
            windows[i].app_id = app_id;
            windows[i].x = 100 + (window_count % 3) * 30;
            windows[i].y = 80 + (window_count % 3) * 20;
            windows[i].z_order = next_z++;
            window_count++;
            return i;
        }
    }
    return -1;
}

/* 关闭窗口 */
static void close_window(int win_idx)
{
    if (win_idx >= 0 && win_idx < MAX_WINDOWS && windows[win_idx].used) {
        windows[win_idx].used = 0;
        window_count--;
    }
}

/* 将窗口置于最上层 */
static void bring_to_front(int win_idx)
{
    if (win_idx >= 0 && win_idx < MAX_WINDOWS && windows[win_idx].used) {
        windows[win_idx].z_order = next_z++;
    }
}

/* ============================================================================
 * 测试函数
 * ========================================================================== */
void desktop_render_test(void)
{
    elastic_desktop_render();
    gfx_flip();
}

/* ============================================================================
 * 桌面主循环 (带鼠标交互)
 * ========================================================================== */
void elastic_desktop_main_loop(void)
{
    extern void serial_puts(uint16_t, const char *);
    serial_puts(0x3F8, "[EDESKTOP] entering main loop with mouse...\n");

    /* 初始化鼠标位置到屏幕中央 */
    desktop_set_mouse(gfx_width / 2, gfx_height / 2);

    /* 鼠标状态 */
    extern int mouse_get_x(void);
    extern int mouse_get_y(void);
    extern uint8_t mouse_get_buttons(void);
    uint8_t prev_buttons = 0;

    /* 无限循环 */
    while (1) {
        /* 读取鼠标位置 */
        int mx = mouse_get_x();
        int my = mouse_get_y();
        uint8_t buttons = mouse_get_buttons();

        /* 限制鼠标在屏幕范围内 */
        if (mx < 0) mx = 0;
        if (mx > gfx_width - 1) mx = gfx_width - 1;
        if (my < 0) my = 0;
        if (my > gfx_height - 1) my = gfx_height - 1;
        desktop_set_mouse(mx, my);

        /* 鼠标悬停检测（仅在无窗口拖动时） */
        if (dragging_window < 0) {
            selected_icon = hit_test_icon(mx, my);
            if (selected_icon < 0) {
                selected_icon = hit_test_dock_icon(mx, my);
            }
        } else {
            selected_icon = -1;
        }

        /* 鼠标点击检测（左键按下沿） */
        if ((buttons & 1) && !(prev_buttons & 1)) {
            int win_idx = find_top_window_at(mx, my);

            if (win_idx >= 0) {
                /* 点击了窗口 */
                bring_to_front(win_idx);
                int win_w = gfx_width - 200;
                int wx = windows[win_idx].x;
                int wy = windows[win_idx].y;

                /* 检测是否点击关闭按钮 */
                int close_x = wx + win_w - 40;
                int close_y = wy + 8;
                if (mx >= close_x && mx <= close_x + 24 &&
                    my >= close_y && my <= close_y + 20) {
                    serial_puts(0x3F8, "[EDESKTOP] window closed\n");
                    close_window(win_idx);
                }
                /* 检测是否点击标题栏（开始拖动） */
                else if (mx >= wx && mx <= wx + win_w &&
                         my >= wy && my <= wy + 36) {
                    dragging_window = win_idx;
                    drag_offset_x = mx - wx;
                    drag_offset_y = my - wy;
                    serial_puts(0x3F8, "[EDESKTOP] window drag start\n");
                }
            } else {
                /* 点击桌面，检测图标 */
                int hit = hit_test_icon(mx, my);
                if (hit < 0) {
                    hit = hit_test_dock_icon(mx, my);
                }
                if (hit >= 0) {
                    serial_puts(0x3F8, "[EDESKTOP] app launched: ");
                    serial_puts(0x3F8, app_icons[hit].name);
                    serial_puts(0x3F8, "\n");
                    create_window(hit);
                }
            }
        }

        /* 鼠标释放（结束拖动） */
        if (!(buttons & 1) && (prev_buttons & 1)) {
            if (dragging_window >= 0) {
                serial_puts(0x3F8, "[EDESKTOP] window drag end\n");
                dragging_window = -1;
            }
        }

        /* 窗口拖动 */
        if (dragging_window >= 0 && windows[dragging_window].used) {
            windows[dragging_window].x = mx - drag_offset_x;
            windows[dragging_window].y = my - drag_offset_y;
            /* 限制窗口在屏幕范围内 */
            int win_w = gfx_width - 200;
            int win_h = gfx_height - 160;
            if (windows[dragging_window].x < 0) windows[dragging_window].x = 0;
            if (windows[dragging_window].y < 0) windows[dragging_window].y = 0;
            if (windows[dragging_window].x > gfx_width - win_w) windows[dragging_window].x = gfx_width - win_w;
            if (windows[dragging_window].y > gfx_height - win_h) windows[dragging_window].y = gfx_height - win_h;
        }

        /* 键盘输入：ESC关闭最上层窗口 */
        extern char keyboard_getchar(void);
        char key = keyboard_getchar();
        if (key == 27 && window_count > 0) {  /* ESC */
            /* 找到最上层窗口并关闭 */
            int top_idx = -1;
            int top_z = -1;
            for (int i = 0; i < MAX_WINDOWS; i++) {
                if (windows[i].used && windows[i].z_order > top_z) {
                    top_z = windows[i].z_order;
                    top_idx = i;
                }
            }
            if (top_idx >= 0) {
                serial_puts(0x3F8, "[EDESKTOP] ESC pressed, window closed\n");
                close_window(top_idx);
                dragging_window = -1;
            }
        }

        prev_buttons = buttons;

        /* 渲染 */
        elastic_desktop_render();
        gfx_flip();

        /* 简单延时 */
        for (volatile int i = 0; i < 200000; i++);
    }

    serial_puts(0x3F8, "[EDESKTOP] main loop done\n");
}
